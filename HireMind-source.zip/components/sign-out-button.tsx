'use client';

import { useState, type ReactNode } from 'react';

import { signOutAndRedirect } from '@/lib/supabase/client';

type SignOutButtonProps = {
  children?: ReactNode;
  className?: string;
  title?: string;
};

export function SignOutButton({ children = 'Sign out', className, title }: SignOutButtonProps) {
  const [signingOut, setSigningOut] = useState(false);

  return (
    <button
      type="button"
      className={className}
      title={title}
      disabled={signingOut}
      aria-busy={signingOut}
      onClick={() => {
        setSigningOut(true);
        void signOutAndRedirect();
      }}
    >
      {signingOut ? 'Signing out…' : children}
    </button>
  );
}
