import type { AnchorHTMLAttributes } from 'react';

type StableLinkProps = Omit<
  AnchorHTMLAttributes<HTMLAnchorElement>,
  'href'
> & {
  href: string;
};

/**
 * A regular browser link used intentionally for production reliability.
 *
 * HireMind runs on vinext. Its current client-side `next/link` adapter can
 * throw while setting up RSC prefetching, which leaves an otherwise valid
 * anchor unable to navigate. Native links keep the platform accessible and
 * make every route transition deterministic while that adapter matures.
 */
export function StableLink({ href, ...props }: StableLinkProps) {
  return <a href={href} {...props} />;
}
