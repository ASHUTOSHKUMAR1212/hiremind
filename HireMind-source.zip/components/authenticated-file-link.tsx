'use client';

import { useState, type ReactNode } from 'react';
import { downloadAuthenticatedFile } from '@/lib/supabase/client';

export function AuthenticatedFileLink({ fileId, filename, className, children }: {
  fileId: string; filename: string; className?: string; children: ReactNode;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  return <>
    <button type="button" className={className} disabled={busy} aria-busy={busy}
      onClick={async () => {
        if (busy) return;
        setBusy(true); setError('');
        try { await downloadAuthenticatedFile(fileId, filename); }
        catch (cause) { setError(cause instanceof Error ? cause.message : 'Download failed. Please retry.'); }
        finally { setBusy(false); }
      }}>{busy ? 'Downloading…' : children}</button>
    {error && <p role="alert">{error}</p>}
  </>;
}
