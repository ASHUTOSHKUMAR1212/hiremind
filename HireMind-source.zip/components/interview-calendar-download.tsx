'use client';
import { useState } from 'react';
import { authenticatedFetch } from '@/lib/supabase/client';

export function InterviewCalendarDownload({
  sessionId,
}: {
  sessionId: string;
}) {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  async function download() {
    setBusy(true);
    setMessage('');
    try {
      const response = await authenticatedFetch(
        `/api/interviews/calendar?id=${encodeURIComponent(sessionId)}`,
      );
      if (!response.ok) {
        const result = (await response.json()) as { error?: string };
        throw new Error(result.error || 'Calendar download failed.');
      }
      const url = URL.createObjectURL(await response.blob());
      const link = document.createElement('a');
      link.href = url;
      link.download = 'hiremind-interview.ics';
      link.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      setMessage(
        'Calendar file downloaded. Uses a 60-minute planning estimate; re-import if the interview changes.',
      );
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : 'Could not download calendar event.',
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="text-sm">
      <button
        type="button"
        disabled={busy}
        onClick={() => void download()}
        className="font-medium underline underline-offset-4 disabled:opacity-50"
      >
        {busy ? 'Preparing…' : 'Add to calendar (.ics)'}
      </button>
      {message && <output className="mt-2 block max-w-xs">{message}</output>}
    </div>
  );
}
