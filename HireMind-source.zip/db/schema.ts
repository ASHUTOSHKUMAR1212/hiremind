import {
  index,
  integer,
  primaryKey,
  sqliteTable,
  text,
  uniqueIndex,
} from 'drizzle-orm/sqlite-core';

const timestamps = {
  createdAt: integer('created_at', { mode: 'timestamp_ms' }).notNull(),
  updatedAt: integer('updated_at', { mode: 'timestamp_ms' }).notNull(),
};

export const savedTalentSearches = sqliteTable('saved_talent_searches', {
  id: text('id').primaryKey(),
  organizationId: text('organization_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  ownerUserId: text('owner_user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  jobId: text('job_id').notNull().references(() => jobs.id, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  nameKey: text('name_key').notNull(),
  query: text('query').notNull(),
  location: text('location').notNull(),
  createdAt: integer('created_at').notNull(),
}, table => [uniqueIndex('idx_saved_talent_search_owner_name').on(table.organizationId, table.ownerUserId, table.nameKey)]);

export const matchingBenchmarks = sqliteTable('matching_benchmarks', {
  id: text('id').primaryKey(),
  organizationId: text('organization_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  createdByUserId: text('created_by_user_id').references(() => users.id, { onDelete: 'set null' }),
  reportJson: text('report_json').notNull(),
  datasetJson: text('dataset_json').notNull(),
  createdAt: integer('created_at').notNull(),
}, table => [index('idx_benchmarks_org_time').on(table.organizationId, table.createdAt)]);

export const integrationKeys = sqliteTable('integration_keys', {
  id: text('id').primaryKey(),
  organizationId: text('organization_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  label: text('label').notNull(),
  tokenHash: text('token_hash').notNull(),
  scopesJson: text('scopes_json').notNull(),
  createdAt: integer('created_at').notNull(),
  expiresAt: integer('expires_at').notNull(),
  revokedAt: integer('revoked_at'),
  lastUsedAt: integer('last_used_at'),
}, table => [uniqueIndex('idx_integration_key_hash').on(table.tokenHash), index('idx_integration_keys_org').on(table.organizationId)]);

export const interviewTranscripts = sqliteTable('interview_transcripts', {
  sessionId: text('session_id').primaryKey().references(() => interviewSessions.id, { onDelete: 'cascade' }),
  organizationId: text('organization_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  revision: integer('revision').notNull(),
  segmentsJson: text('segments_json').notNull(),
  sourceName: text('source_name').notNull(),
  consentNote: text('consent_note').notNull(),
  createdByUserId: text('created_by_user_id').references(() => users.id, { onDelete: 'set null' }),
  ...timestamps,
});

export const interviewScorecards = sqliteTable('interview_scorecards', {
  sessionId: text('session_id').notNull().references(() => interviewSessions.id, { onDelete: 'cascade' }),
  reviewerUserId: text('reviewer_user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  transcriptRevision: integer('transcript_revision').notNull(),
  transcriptSnapshotJson: text('transcript_snapshot_json').notNull().default('[]'),
  rubricJson: text('rubric_json').notNull(),
  entriesJson: text('entries_json').notNull(),
  status: text('status').notNull(),
  revision: integer('revision').notNull(),
  ...timestamps,
}, table => [primaryKey({ columns: [table.sessionId, table.reviewerUserId] })]);

export const recruiterRelationships = sqliteTable('recruiter_relationships', {
  candidateId: text('candidate_id').primaryKey().references(() => organizationCandidates.id, { onDelete: 'cascade' }),
  organizationId: text('organization_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  stage: text('stage').notNull().default('new'),
  tagsJson: text('tags_json').notNull().default('[]'),
  notes: text('notes').notNull().default(''),
  suppressed: integer('suppressed').notNull().default(0),
  revision: integer('revision').notNull().default(1),
  ...timestamps,
}, table => [index('idx_relationships_org').on(table.organizationId)]);

export const recruiterOutreach = sqliteTable('recruiter_outreach', {
  id: text('id').primaryKey(),
  candidateId: text('candidate_id').notNull().references(() => organizationCandidates.id, { onDelete: 'cascade' }),
  organizationId: text('organization_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  createdByUserId: text('created_by_user_id').references(() => users.id, { onDelete: 'set null' }),
  subject: text('subject').notNull(),
  body: text('body').notNull(),
  status: text('status').notNull().default('draft'),
  dueAt: integer('due_at'),
  sentAt: integer('sent_at'),
  ...timestamps,
}, table => [index('idx_outreach_org_due').on(table.organizationId, table.dueAt), index('idx_outreach_candidate').on(table.candidateId, table.createdAt)]);

export const users = sqliteTable(
  'users',
  {
    id: text('id').primaryKey(),
    email: text('email').notNull(),
    fullName: text('full_name'),
    status: text('status').notNull().default('active'),
    ...timestamps,
  },
  (table) => [uniqueIndex('idx_users_email').on(table.email)],
);

export const authIdentities = sqliteTable(
  'auth_identities',
  {
    provider: text('provider').notNull(),
    providerSubject: text('provider_subject').notNull(),
    userId: text('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    emailAtLink: text('email_at_link').notNull(),
    linkedAt: integer('linked_at', { mode: 'timestamp_ms' }).notNull(),
    lastSeenAt: integer('last_seen_at', { mode: 'timestamp_ms' }).notNull(),
  },
  (table) => [
    primaryKey({ columns: [table.provider, table.providerSubject] }),
    index('idx_auth_identities_user').on(table.userId),
  ],
);

export const organizations = sqliteTable(
  'organizations',
  {
    id: text('id').primaryKey(),
    name: text('name').notNull(),
    slug: text('slug').notNull(),
    status: text('status').notNull().default('active'),
    settingsJson: text('settings_json', { mode: 'json' }),
    ...timestamps,
  },
  (table) => [uniqueIndex('idx_organizations_slug').on(table.slug)],
);

export const organizationMembers = sqliteTable(
  'organization_members',
  {
    organizationId: text('organization_id')
      .notNull()
      .references(() => organizations.id, { onDelete: 'cascade' }),
    userId: text('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    roleKey: text('role_key').notNull(),
    permissionOverridesJson: text('permission_overrides_json', {
      mode: 'json',
    }),
    status: text('status').notNull().default('active'),
    joinedAt: integer('joined_at', { mode: 'timestamp_ms' }).notNull(),
  },
  (table) => [
    primaryKey({ columns: [table.organizationId, table.userId] }),
    index('idx_organization_members_user').on(table.userId),
  ],
);

export const candidateProfiles = sqliteTable(
  'candidate_profiles',
  {
    id: text('id').primaryKey(),
    ownerUserId: text('owner_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    createdByOrganizationId: text('created_by_organization_id').references(
      () => organizations.id,
      { onDelete: 'set null' },
    ),
    profileType: text('profile_type').notNull().default('fresher'),
    fullName: text('full_name').notNull(),
    primaryEmail: text('primary_email'),
    phone: text('phone'),
    headline: text('headline'),
    summary: text('summary'),
    location: text('location'),
    workAuthorization: text('work_authorization'),
    availability: text('availability'),
    visibility: text('visibility').notNull().default('private'),
    metadataJson: text('metadata_json', { mode: 'json' }),
    ...timestamps,
  },
  (table) => [
    uniqueIndex('idx_candidate_profiles_owner').on(table.ownerUserId),
    index('idx_candidate_profiles_email').on(table.primaryEmail),
  ],
);

export const candidateExperiences = sqliteTable(
  'candidate_experiences',
  {
    id: text('id').primaryKey(),
    candidateProfileId: text('candidate_profile_id')
      .notNull()
      .references(() => candidateProfiles.id, { onDelete: 'cascade' }),
    experienceType: text('experience_type').notNull(),
    organizationName: text('organization_name'),
    title: text('title').notNull(),
    description: text('description'),
    startedOn: text('started_on'),
    endedOn: text('ended_on'),
    isCurrent: integer('is_current', { mode: 'boolean' })
      .notNull()
      .default(false),
    sourceType: text('source_type').notNull().default('candidate'),
    verificationStatus: text('verification_status')
      .notNull()
      .default('unverified'),
    evidenceFileId: text('evidence_file_id'),
    sortOrder: integer('sort_order').notNull().default(0),
    ...timestamps,
  },
  (table) => [
    index('idx_candidate_experiences_profile').on(
      table.candidateProfileId,
      table.sortOrder,
    ),
  ],
);

export const candidateEducation = sqliteTable(
  'candidate_education',
  {
    id: text('id').primaryKey(),
    candidateProfileId: text('candidate_profile_id')
      .notNull()
      .references(() => candidateProfiles.id, { onDelete: 'cascade' }),
    institution: text('institution').notNull(),
    qualification: text('qualification'),
    fieldOfStudy: text('field_of_study'),
    startedOn: text('started_on'),
    endedOn: text('ended_on'),
    verificationStatus: text('verification_status')
      .notNull()
      .default('unverified'),
    ...timestamps,
  },
  (table) => [
    index('idx_candidate_education_profile').on(table.candidateProfileId),
  ],
);

export const candidateProjects = sqliteTable(
  'candidate_projects',
  {
    id: text('id').primaryKey(),
    candidateProfileId: text('candidate_profile_id')
      .notNull()
      .references(() => candidateProfiles.id, { onDelete: 'cascade' }),
    title: text('title').notNull(),
    description: text('description'),
    projectUrl: text('project_url'),
    repositoryUrl: text('repository_url'),
    skillsJson: text('skills_json', { mode: 'json' }),
    outcomesJson: text('outcomes_json', { mode: 'json' }),
    verificationStatus: text('verification_status')
      .notNull()
      .default('unverified'),
    ...timestamps,
  },
  (table) => [
    index('idx_candidate_projects_profile').on(table.candidateProfileId),
  ],
);

export const organizationCandidates = sqliteTable(
  'organization_candidates',
  {
    id: text('id').primaryKey(),
    organizationId: text('organization_id')
      .notNull()
      .references(() => organizations.id, { onDelete: 'cascade' }),
    candidateProfileId: text('candidate_profile_id').references(
      () => candidateProfiles.id,
      {
        onDelete: 'set null',
      },
    ),
    displayName: text('display_name').notNull(),
    primaryEmail: text('primary_email'),
    sourceKey: text('source_key'),
    ownerUserId: text('owner_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    consentStatus: text('consent_status').notNull().default('pending'),
    retentionUntil: integer('retention_until', { mode: 'timestamp_ms' }),
    privateMetadataJson: text('private_metadata_json', { mode: 'json' }),
    deletedAt: integer('deleted_at', { mode: 'timestamp_ms' }),
    ...timestamps,
  },
  (table) => [
    index('idx_org_candidates_org').on(table.organizationId, table.deletedAt),
    index('idx_org_candidates_profile').on(table.candidateProfileId),
    index('idx_org_candidates_email').on(
      table.organizationId,
      table.primaryEmail,
    ),
  ],
);

export const jobs = sqliteTable(
  'jobs',
  {
    id: text('id').primaryKey(),
    organizationId: text('organization_id')
      .notNull()
      .references(() => organizations.id, { onDelete: 'cascade' }),
    title: text('title').notNull(),
    slug: text('slug').notNull(),
    status: text('status').notNull().default('draft'),
    description: text('description').notNull(),
    location: text('location'),
    workplaceType: text('workplace_type'),
    employmentType: text('employment_type'),
    experiencePolicy: text('experience_policy')
      .notNull()
      .default('evidence_first'),
    publishedAt: integer('published_at', { mode: 'timestamp_ms' }),
    closedAt: integer('closed_at', { mode: 'timestamp_ms' }),
    createdByUserId: text('created_by_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    ...timestamps,
  },
  (table) => [
    uniqueIndex('idx_jobs_org_slug').on(table.organizationId, table.slug),
    index('idx_jobs_org_status').on(table.organizationId, table.status),
  ],
);

export const jobCriteria = sqliteTable(
  'job_criteria',
  {
    id: text('id').primaryKey(),
    jobId: text('job_id')
      .notNull()
      .references(() => jobs.id, { onDelete: 'cascade' }),
    version: integer('version').notNull(),
    label: text('label').notNull(),
    criterionType: text('criterion_type').notNull(),
    requirementClass: text('requirement_class').notNull(),
    weight: integer('weight').notNull(),
    evidenceDefinition: text('evidence_definition'),
    equivalentSignalsJson: text('equivalent_signals_json', { mode: 'json' }),
    isActive: integer('is_active', { mode: 'boolean' }).notNull().default(true),
    sortOrder: integer('sort_order').notNull().default(0),
    ...timestamps,
  },
  (table) => [
    index('idx_job_criteria_job_version').on(
      table.jobId,
      table.version,
      table.sortOrder,
    ),
  ],
);

export const applications = sqliteTable(
  'applications',
  {
    id: text('id').primaryKey(),
    organizationId: text('organization_id')
      .notNull()
      .references(() => organizations.id, { onDelete: 'cascade' }),
    jobId: text('job_id')
      .notNull()
      .references(() => jobs.id, { onDelete: 'cascade' }),
    organizationCandidateId: text('organization_candidate_id')
      .notNull()
      .references(() => organizationCandidates.id, { onDelete: 'cascade' }),
    status: text('status').notNull().default('submitted'),
    currentStageKey: text('current_stage_key'),
    profileSnapshotJson: text('profile_snapshot_json', {
      mode: 'json',
    }).notNull(),
    submittedAt: integer('submitted_at', { mode: 'timestamp_ms' }).notNull(),
    withdrawnAt: integer('withdrawn_at', { mode: 'timestamp_ms' }),
    ...timestamps,
  },
  (table) => [
    uniqueIndex('idx_applications_job_candidate').on(
      table.jobId,
      table.organizationCandidateId,
    ),
    index('idx_applications_job_status').on(table.jobId, table.status),
    index('idx_applications_candidate').on(
      table.organizationCandidateId,
      table.submittedAt,
    ),
  ],
);

export const applicationEvents = sqliteTable(
  'application_events',
  {
    id: text('id').primaryKey(),
    applicationId: text('application_id')
      .notNull()
      .references(() => applications.id, { onDelete: 'cascade' }),
    actorUserId: text('actor_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    eventType: text('event_type').notNull(),
    fromStatus: text('from_status'),
    toStatus: text('to_status'),
    note: text('note'),
    visibleToCandidate: integer('visible_to_candidate', { mode: 'boolean' })
      .notNull()
      .default(true),
    occurredAt: integer('occurred_at', { mode: 'timestamp_ms' }).notNull(),
  },
  (table) => [
    index('idx_application_events_application_time').on(
      table.applicationId,
      table.occurredAt,
    ),
  ],
);

export const screeningRuns = sqliteTable(
  'screening_runs',
  {
    id: text('id').primaryKey(),
    jobId: text('job_id')
      .notNull()
      .references(() => jobs.id, { onDelete: 'cascade' }),
    criteriaVersion: integer('criteria_version').notNull(),
    modelVersion: text('model_version').notNull(),
    pipelineVersion: text('pipeline_version').notNull(),
    status: text('status').notNull().default('queued'),
    startedAt: integer('started_at', { mode: 'timestamp_ms' }),
    completedAt: integer('completed_at', { mode: 'timestamp_ms' }),
    validationJson: text('validation_json', { mode: 'json' }),
    ...timestamps,
  },
  (table) => [index('idx_screening_runs_job').on(table.jobId, table.createdAt)],
);

export const candidateEvidence = sqliteTable(
  'candidate_evidence',
  {
    id: text('id').primaryKey(),
    applicationId: text('application_id')
      .notNull()
      .references(() => applications.id, { onDelete: 'cascade' }),
    sourceType: text('source_type').notNull(),
    sourceRecordId: text('source_record_id'),
    category: text('category').notNull(),
    summary: text('summary').notNull(),
    evidenceQuote: text('evidence_quote'),
    sourceLocation: text('source_location'),
    confidence: integer('confidence').notNull(),
    verificationStatus: text('verification_status')
      .notNull()
      .default('unverified'),
    ...timestamps,
  },
  (table) => [
    index('idx_candidate_evidence_application').on(
      table.applicationId,
      table.category,
    ),
  ],
);

export const candidateCriterionAssessments = sqliteTable(
  'candidate_criterion_assessments',
  {
    id: text('id').primaryKey(),
    screeningRunId: text('screening_run_id')
      .notNull()
      .references(() => screeningRuns.id, { onDelete: 'cascade' }),
    applicationId: text('application_id')
      .notNull()
      .references(() => applications.id, { onDelete: 'cascade' }),
    criterionId: text('criterion_id')
      .notNull()
      .references(() => jobCriteria.id, { onDelete: 'cascade' }),
    classification: text('classification').notNull(),
    score: integer('score'),
    confidence: integer('confidence').notNull(),
    evidenceIdsJson: text('evidence_ids_json', { mode: 'json' }),
    explanation: text('explanation').notNull(),
    requiresHumanReview: integer('requires_human_review', { mode: 'boolean' })
      .notNull()
      .default(false),
    ...timestamps,
  },
  (table) => [
    uniqueIndex('idx_criterion_assessment_unique').on(
      table.screeningRunId,
      table.applicationId,
      table.criterionId,
    ),
    index('idx_criterion_assessments_application').on(table.applicationId),
  ],
);

export const shortlistRankings = sqliteTable(
  'shortlist_rankings',
  {
    id: text('id').primaryKey(),
    screeningRunId: text('screening_run_id')
      .notNull()
      .references(() => screeningRuns.id, { onDelete: 'cascade' }),
    applicationId: text('application_id')
      .notNull()
      .references(() => applications.id, { onDelete: 'cascade' }),
    rank: integer('rank').notNull(),
    fitScore: integer('fit_score').notNull(),
    decisionBand: text('decision_band').notNull(),
    evidenceCoverage: integer('evidence_coverage').notNull(),
    uncertainty: integer('uncertainty').notNull(),
    explanation: text('explanation').notNull(),
    ...timestamps,
  },
  (table) => [
    uniqueIndex('idx_shortlist_rankings_run_application').on(
      table.screeningRunId,
      table.applicationId,
    ),
    index('idx_shortlist_rankings_run_rank').on(
      table.screeningRunId,
      table.rank,
    ),
  ],
);

export const resumeComparisonRuns = sqliteTable(
  'resume_comparison_runs',
  {
    id: text('id').primaryKey(),
    organizationId: text('organization_id')
      .notNull()
      .references(() => organizations.id, { onDelete: 'cascade' }),
    jobId: text('job_id')
      .notNull()
      .references(() => jobs.id, { onDelete: 'cascade' }),
    createdByUserId: text('created_by_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    criteriaVersion: integer('criteria_version').notNull(),
    status: text('status').notNull().default('processing'),
    fileCount: integer('file_count').notNull(),
    completedAt: integer('completed_at', { mode: 'timestamp_ms' }),
    ...timestamps,
  },
  (table) => [
    index('idx_resume_comparison_runs_org_job').on(
      table.organizationId,
      table.jobId,
      table.createdAt,
    ),
  ],
);

export const resumeComparisonItems = sqliteTable(
  'resume_comparison_items',
  {
    id: text('id').primaryKey(),
    runId: text('run_id')
      .notNull()
      .references(() => resumeComparisonRuns.id, { onDelete: 'cascade' }),
    fileId: text('file_id').notNull(),
    filename: text('filename').notNull(),
    candidateName: text('candidate_name').notNull(),
    headline: text('headline'),
    parsedProfileJson: text('parsed_profile_json', { mode: 'json' }).notNull(),
    fitScore: integer('fit_score').notNull(),
    rank: integer('rank').notNull(),
    decisionBand: text('decision_band').notNull(),
    evidenceCoverage: integer('evidence_coverage').notNull(),
    uncertainty: integer('uncertainty').notNull(),
    explanation: text('explanation').notNull(),
    criterionResultsJson: text('criterion_results_json', {
      mode: 'json',
    }).notNull(),
    warningsJson: text('warnings_json', { mode: 'json' }),
    ...timestamps,
  },
  (table) => [
    uniqueIndex('idx_resume_comparison_items_run_rank').on(
      table.runId,
      table.rank,
    ),
    index('idx_resume_comparison_items_run').on(table.runId),
  ],
);

export const interviewPlans = sqliteTable(
  'interview_plans',
  {
    id: text('id').primaryKey(),
    jobId: text('job_id')
      .notNull()
      .references(() => jobs.id, { onDelete: 'cascade' }),
    version: integer('version').notNull(),
    name: text('name').notNull(),
    status: text('status').notNull().default('draft'),
    ...timestamps,
  },
  (table) => [
    uniqueIndex('idx_interview_plans_job_version').on(
      table.jobId,
      table.version,
    ),
  ],
);

export const interviewStages = sqliteTable(
  'interview_stages',
  {
    id: text('id').primaryKey(),
    interviewPlanId: text('interview_plan_id')
      .notNull()
      .references(() => interviewPlans.id, { onDelete: 'cascade' }),
    stageType: text('stage_type').notNull(),
    name: text('name').notNull(),
    sortOrder: integer('sort_order').notNull(),
    configurationJson: text('configuration_json', { mode: 'json' }),
    rubricVersion: integer('rubric_version').notNull().default(1),
    ...timestamps,
  },
  (table) => [
    index('idx_interview_stages_plan').on(
      table.interviewPlanId,
      table.sortOrder,
    ),
  ],
);

export const interviewSessions = sqliteTable(
  'interview_sessions',
  {
    id: text('id').primaryKey(),
    applicationId: text('application_id')
      .notNull()
      .references(() => applications.id, { onDelete: 'cascade' }),
    interviewStageId: text('interview_stage_id')
      .notNull()
      .references(() => interviewStages.id, { onDelete: 'cascade' }),
    mode: text('mode').notNull().default('structured_screening'),
    status: text('status').notNull().default('scheduled'),
    scheduledAt: integer('scheduled_at', { mode: 'timestamp_ms' }),
    startedAt: integer('started_at', { mode: 'timestamp_ms' }),
    completedAt: integer('completed_at', { mode: 'timestamp_ms' }),
    transcriptFileKey: text('transcript_file_key'),
    recordingFileKey: text('recording_file_key'),
    evaluationJson: text('evaluation_json', { mode: 'json' }),
    ...timestamps,
  },
  (table) => [
    index('idx_interview_sessions_application').on(
      table.applicationId,
      table.createdAt,
    ),
  ],
);

export const interviewSessionEvents = sqliteTable(
  'interview_session_events',
  {
    id: text('id').primaryKey(),
    interviewSessionId: text('interview_session_id')
      .notNull()
      .references(() => interviewSessions.id, { onDelete: 'cascade' }),
    eventType: text('event_type').notNull(),
    occurredAt: integer('occurred_at', { mode: 'timestamp_ms' }).notNull(),
    durationMs: integer('duration_ms'),
    payloadJson: text('payload_json', { mode: 'json' }),
    candidateExplanation: text('candidate_explanation'),
  },
  (table) => [
    index('idx_interview_events_session_time').on(
      table.interviewSessionId,
      table.occurredAt,
    ),
  ],
);

export const interviewRoomParticipants = sqliteTable(
  'interview_room_participants',
  {
    interviewSessionId: text('interview_session_id')
      .notNull()
      .references(() => interviewSessions.id, { onDelete: 'cascade' }),
    userId: text('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    role: text('role').notNull(),
    displayName: text('display_name').notNull(),
    peerId: text('peer_id').notNull(),
    mediaStateJson: text('media_state_json', { mode: 'json' }),
    joinedAt: integer('joined_at', { mode: 'timestamp_ms' }).notNull(),
    lastSeenAt: integer('last_seen_at', { mode: 'timestamp_ms' }).notNull(),
    leftAt: integer('left_at', { mode: 'timestamp_ms' }),
  },
  (table) => [
    primaryKey({ columns: [table.interviewSessionId, table.userId] }),
    index('idx_interview_room_presence').on(
      table.interviewSessionId,
      table.lastSeenAt,
    ),
  ],
);

export const interviewRoomSignals = sqliteTable(
  'interview_room_signals',
  {
    id: text('id').primaryKey(),
    interviewSessionId: text('interview_session_id')
      .notNull()
      .references(() => interviewSessions.id, { onDelete: 'cascade' }),
    senderUserId: text('sender_user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    targetUserId: text('target_user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    signalType: text('signal_type').notNull(),
    payloadJson: text('payload_json', { mode: 'json' }).notNull(),
    createdAt: integer('created_at', { mode: 'timestamp_ms' }).notNull(),
    expiresAt: integer('expires_at', { mode: 'timestamp_ms' }).notNull(),
  },
  (table) => [
    index('idx_interview_room_signals_target').on(
      table.interviewSessionId,
      table.targetUserId,
      table.createdAt,
    ),
    index('idx_interview_room_signals_expiry').on(table.expiresAt),
  ],
);

export const interviewRoomNotes = sqliteTable(
  'interview_room_notes',
  {
    interviewSessionId: text('interview_session_id')
      .notNull()
      .references(() => interviewSessions.id, { onDelete: 'cascade' }),
    authorUserId: text('author_user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    notes: text('notes').notNull().default(''),
    ...timestamps,
  },
  (table) => [
    primaryKey({ columns: [table.interviewSessionId, table.authorUserId] }),
  ],
);

export const files = sqliteTable(
  'files',
  {
    id: text('id').primaryKey(),
    organizationId: text('organization_id').references(() => organizations.id, {
      onDelete: 'cascade',
    }),
    ownerUserId: text('owner_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    entityType: text('entity_type').notNull(),
    entityId: text('entity_id').notNull(),
    r2Key: text('r2_key').notNull(),
    filename: text('filename').notNull(),
    contentType: text('content_type').notNull(),
    sizeBytes: integer('size_bytes').notNull(),
    processingStatus: text('processing_status').notNull().default('pending'),
    checksum: text('checksum'),
    ...timestamps,
  },
  (table) => [
    uniqueIndex('idx_files_r2_key').on(table.r2Key),
    index('idx_files_entity').on(table.entityType, table.entityId),
  ],
);

export const customFieldDefinitions = sqliteTable(
  'custom_field_definitions',
  {
    id: text('id').primaryKey(),
    organizationId: text('organization_id')
      .notNull()
      .references(() => organizations.id, { onDelete: 'cascade' }),
    entityType: text('entity_type').notNull(),
    fieldKey: text('field_key').notNull(),
    label: text('label').notNull(),
    dataType: text('data_type').notNull(),
    configurationJson: text('configuration_json', { mode: 'json' }),
    isActive: integer('is_active', { mode: 'boolean' }).notNull().default(true),
    ...timestamps,
  },
  (table) => [
    uniqueIndex('idx_custom_fields_org_entity_key').on(
      table.organizationId,
      table.entityType,
      table.fieldKey,
    ),
  ],
);

export const customFieldValues = sqliteTable(
  'custom_field_values',
  {
    id: text('id').primaryKey(),
    definitionId: text('definition_id')
      .notNull()
      .references(() => customFieldDefinitions.id, { onDelete: 'cascade' }),
    entityId: text('entity_id').notNull(),
    valueJson: text('value_json', { mode: 'json' }),
    ...timestamps,
  },
  (table) => [
    uniqueIndex('idx_custom_field_values_entity').on(
      table.definitionId,
      table.entityId,
    ),
  ],
);

export const auditEvents = sqliteTable(
  'audit_events',
  {
    id: text('id').primaryKey(),
    organizationId: text('organization_id').references(() => organizations.id, {
      onDelete: 'set null',
    }),
    actorUserId: text('actor_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    action: text('action').notNull(),
    entityType: text('entity_type').notNull(),
    entityId: text('entity_id').notNull(),
    payloadJson: text('payload_json', { mode: 'json' }),
    occurredAt: integer('occurred_at', { mode: 'timestamp_ms' }).notNull(),
  },
  (table) => [
    index('idx_audit_events_org_time').on(
      table.organizationId,
      table.occurredAt,
    ),
    index('idx_audit_events_entity').on(
      table.entityType,
      table.entityId,
      table.occurredAt,
    ),
  ],
);
