import assert from 'node:assert/strict';
import test from 'node:test';

import {
  getLiveRoomAvailability,
  isAllowedLiveSignal,
  LIVE_EMPLOYER_EARLY_ACCESS_MS,
} from '../lib/live-interview.ts';
import { INTERVIEW_EARLY_ACCESS_MS } from '../lib/interview-status.ts';

test('candidate and employer receive role-specific live-room opening windows', () => {
  const scheduledAt = Date.UTC(2030, 0, 1, 12, 0, 0);
  assert.equal(
    getLiveRoomAvailability(
      'candidate',
      'scheduled',
      scheduledAt,
      scheduledAt - INTERVIEW_EARLY_ACCESS_MS - 1,
    ).canJoin,
    false,
  );
  assert.equal(
    getLiveRoomAvailability(
      'candidate',
      'scheduled',
      scheduledAt,
      scheduledAt - INTERVIEW_EARLY_ACCESS_MS,
    ).canJoin,
    true,
  );
  assert.equal(
    getLiveRoomAvailability(
      'employer',
      'scheduled',
      scheduledAt,
      scheduledAt - LIVE_EMPLOYER_EARLY_ACCESS_MS,
    ).canJoin,
    true,
  );
});

test('completed live interviews cannot be rejoined', () => {
  assert.deepEqual(
    getLiveRoomAvailability('employer', 'completed', Date.now(), Date.now())
      .reason,
    'closed',
  );
});

test('live signaling accepts only bounded WebRTC message types', () => {
  assert.equal(isAllowedLiveSignal('description', '{}'), true);
  assert.equal(isAllowedLiveSignal('candidate', '{}'), true);
  assert.equal(isAllowedLiveSignal('renegotiate', '{}'), true);
  assert.equal(isAllowedLiveSignal('chat', '{}'), false);
  assert.equal(isAllowedLiveSignal('description', 'x'.repeat(50_001)), false);
});
