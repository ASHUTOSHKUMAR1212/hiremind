import assert from 'node:assert/strict';
import test from 'node:test';

import { parseResumeProfile } from '../lib/resume-text.ts';

test('résumé parser structures distinct candidate content instead of reusing a template', () => {
  const analyst = parseResumeProfile(`
Priya Nair
Product Analyst
Bengaluru, India

SUMMARY
Product analyst who improved activation through customer research and SQL analysis.

SKILLS
SQL, Tableau, User research, Stakeholder management

EXPERIENCE
Product Analyst | Northstar Labs | Jan 2023 - Present
- Built activation dashboards and reduced onboarding drop-off by 18%.

EDUCATION
2022: Bachelor of Technology from Anna University

PROJECTS
Activation research dashboard
- Combined interview themes and funnel analysis using SQL and Tableau.
  `);
  const engineer = parseResumeProfile(`
Rohan Mehta
Backend Engineer
Pune, India

SUMMARY
Backend engineer building reliable commerce services.

SKILLS
Java, PostgreSQL, Docker, Kubernetes, AWS

EXPERIENCE
Backend Engineer | CartWorks | Mar 2021 - Dec 2025
- Reduced checkout latency by 35% and operated services on Kubernetes.

EDUCATION
2020: Bachelor of Engineering from Pune University
  `);

  assert.equal(analyst.fullName, 'Priya Nair');
  assert.equal(engineer.fullName, 'Rohan Mehta');
  assert.notDeepEqual(analyst.skills, engineer.skills);
  assert.equal(analyst.experiences.length, 1);
  assert.equal(engineer.experiences.length, 1);
  assert.equal(analyst.education.length, 1);
  assert.equal(engineer.education.length, 1);
});

test('résumé parser reports section gaps instead of fabricating entries', () => {
  const parsed = parseResumeProfile(
    'Sam Rivera\nVisual Designer\nPortfolio available on request',
  );
  assert.equal(parsed.fullName, 'Sam Rivera');
  assert.equal(parsed.experiences.length, 0);
  assert.equal(parsed.education.length, 0);
  assert.equal(parsed.projects.length, 0);
  assert.ok(
    parsed.warnings.includes('No clearly labelled summary section was found.'),
  );
});
