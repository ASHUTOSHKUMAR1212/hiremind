import assert from 'node:assert/strict';
import test from 'node:test';
import { assessCandidateEvidence } from '../lib/evidence-screening.ts';
import { buildRecruiterBrief } from '../lib/recruiter-brief.ts';

const assess = (label: string, description: string, extra = {}) => assessCandidateEvidence({
  experiences: [{ description, startedOn: '2020-01', endedOn: '2024-12' }], ...extra,
}, [{ id: 'task', label, weight: 100, requirementClass: 'essential', evidenceDefinition: null, equivalentSignalsJson: '[]' }]);

test('same task with another tool becomes a review lead, never exact-tool credit', () => {
  const result = assess('Python data pipelines', 'Ingested customer records using SQL into a warehouse.');
  const criterion = result.criterionResults[0];
  assert.equal(criterion.review.status, 'related_work');
  assert.equal(criterion.score, 0);
  assert.equal(result.fitScore, 0);
  assert.equal(result.decisionBand, 'needs_review');
  assert.equal(criterion.evidence.length, 0);
  assert.equal(criterion.review.responsibilities[0].supported, false);
  const related = criterion.review.relatedWork![0];
  assert.deepEqual(related.namedTools, ['sql']);
  assert.deepEqual(related.unprovenToolGroups, [['python']]);
  assert.equal(related.quote, 'Ingested customer records using SQL into a warehouse');
  assert.match(criterion.review.question, /using python/);
  assert.match(criterion.explanation, /no additional score or tenure credit/);
});

test('exact tools remain credited; OR alternatives are respected', () => {
  for (const label of ['SQL data pipelines', 'Python or SQL data pipelines']) {
    const criterion = assess(label, 'Ingested customer records using SQL into a warehouse.').criterionResults[0];
    assert.ok(criterion.score >= 55);
    assert.deepEqual(criterion.review.relatedWork, []);
  }
  const criterion = assess('Python and SQL data pipelines', 'Ingested customer records using SQL into a warehouse.').criterionResults[0];
  assert.deepEqual(criterion.review.relatedWork![0].unprovenToolGroups, [['python']]);
  assert.ok(criterion.score <= 44);
});

test('tools from a different sentence do not satisfy task requirements', () => {
  const criterion = assess('Python data pipelines', 'Built Python login services. Ingested records using SQL into a warehouse.').criterionResults[0];
  assert.deepEqual(criterion.review.relatedWork![0].namedTools, ['sql']);
  assert.deepEqual(criterion.review.relatedWork![0].unprovenToolGroups, [['python']]);
});

test('plans, observation, negation, slides and tags do not become related work', () => {
  for (const text of [
    'I would have ingested records using SQL into a warehouse.',
    'Observed colleagues who ingested records using SQL into a warehouse.',
    'The team ingested records using SQL into a warehouse.',
    'Never ingested records using SQL into a warehouse.',
    'Built slides about data pipelines using SQL.',
  ]) assert.deepEqual(assess('Python data pipelines', text).criterionResults[0].review.relatedWork, [], text);
  const result = assess('Python data pipelines', '', { metadata: { skills: ['SQL data pipelines'] }, projects: [{ title: 'Built SQL data pipelines', description: '' }] });
  assert.deepEqual(result.criterionResults[0].review.relatedWork, []);
});

test('original quote is retained while negated tools stay excluded', () => {
  const text = 'Ingested records using SQL, not Python scripts, into a warehouse';
  const related = assess('Python data pipelines', text).criterionResults[0].review.relatedWork![0];
  assert.equal(related.quote, text);
  assert.deepEqual(related.namedTools, ['sql']);
});

test('candidate-stated gaps remain explicit even when related work exists', () => {
  const criterion = assess('Python data pipelines', 'Ingested records using SQL into a warehouse.', { summary: 'I have never used Python.' }).criterionResults[0];
  assert.equal(criterion.review.status, 'stated_gap');
  assert.equal(criterion.review.relatedWork!.length, 1);
  assert.match(criterion.review.question, /still current/);
});

test('already-supported tasks do not show redundant missing-tool leads', () => {
  const criterion = assess('Python data pipelines', 'Ingested records using SQL into a warehouse. Ingested records using Python into a warehouse.').criterionResults[0];
  assert.equal(criterion.review.responsibilities[0].supported, true);
  assert.deepEqual(criterion.review.relatedWork, []);
});

test('unknown tool labels are not invented as mapped equivalences', () => {
  assert.deepEqual(assess('Rust data pipelines', 'Ingested records using SQL into a warehouse.').criterionResults[0].review.relatedWork, []);
  const related = assess('Python data pipelines', 'Ingested records into a warehouse.').criterionResults[0].review.relatedWork![0];
  assert.deepEqual(related.namedTools, []);
});

test('related evidence survives persisted JSON and is included in interview briefs', () => {
  const criteria = JSON.parse(JSON.stringify(assess('Python data pipelines', 'Ingested records using SQL into a warehouse.').criterionResults));
  const brief = buildRecruiterBrief('Data engineer', 'Example candidate', criteria);
  assert.match(brief, /Related task evidence — not exact-tool proof/);
  assert.match(brief, /Ingested records using SQL into a warehouse/);
  assert.match(brief, /Required tools unproven in this excerpt: python/);
  assert.match(brief, /Have you personally done this using python/);
});

test('dated related work does not earn required-tool tenure', () => {
  const criterion = assess('3 years Python data pipelines', 'Ingested records using SQL into a warehouse.').criterionResults[0];
  assert.equal(criterion.review.relatedWork!.length, 1);
  assert.equal(criterion.tenure?.supportedMonths, 0);
  assert.equal(criterion.tenure?.requiredMonths, 36);
});

test('review leads cover all six bounded responsibilities without waiving tool requirements', () => {
  for (const [task, description] of [
    ['data pipelines', 'Ingested records into a warehouse'],
    ['incident response', 'Investigated outages and restored service'],
    ['A/B testing', 'Randomized users into control and treatment cohorts'],
    ['requirements gathering', 'Interviewed business users and mapped workflows'],
    ['process automation', 'Automated invoicing workflows'],
    ['mentor developers', 'Coached developers through pairing sessions and feedback'],
  ]) {
    const criterion = assess(`Python ${task}`, description).criterionResults[0];
    assert.equal(criterion.review.relatedWork!.length, 1, task);
    assert.ok(criterion.score <= 44, `${task}: exact-tool requirement must remain unmet`);
  }
});
