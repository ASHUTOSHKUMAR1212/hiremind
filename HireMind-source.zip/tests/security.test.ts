import assert from 'node:assert/strict';
import test from 'node:test';

import { csvCell } from '../lib/csv.ts';
import { hasExpectedDocumentSignature } from '../lib/file-security.ts';
import { canOrganizationRole } from '../lib/organization-permissions.ts';

test('organization roles receive only their intended capabilities', () => {
  assert.equal(canOrganizationRole('owner', 'manage_team'), true);
  assert.equal(canOrganizationRole('admin', 'manage_team'), true);
  assert.equal(canOrganizationRole('recruiter', 'manage_jobs'), true);
  assert.equal(canOrganizationRole('hiring_manager', 'manage_jobs'), false);
  assert.equal(canOrganizationRole('hiring_manager', 'review_candidates'), true);
  assert.equal(canOrganizationRole('interviewer', 'view_pipeline'), false);
  assert.equal(canOrganizationRole('unknown', 'export_data'), false);
});

test('CSV export neutralizes spreadsheet formulas and escapes quotes', () => {
  assert.equal(csvCell('=HYPERLINK("https://bad.example")'), `"'=HYPERLINK(""https://bad.example"")"`);
  assert.equal(csvCell('  +SUM(1,1)'), `"'  +SUM(1,1)"`);
  assert.equal(csvCell('safe "candidate"'), `"safe ""candidate"""`);
});

test('résumé uploads require signatures matching their extensions', () => {
  assert.equal(hasExpectedDocumentSignature(new TextEncoder().encode('%PDF-1.7'), 'pdf'), true);
  assert.equal(hasExpectedDocumentSignature(Uint8Array.from([0x50, 0x4b, 0x03, 0x04]), 'docx'), true);
  assert.equal(hasExpectedDocumentSignature(Uint8Array.from([0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1]), 'doc'), true);
  assert.equal(hasExpectedDocumentSignature(new TextEncoder().encode('<script>alert(1)</script>'), 'pdf'), false);
  assert.equal(hasExpectedDocumentSignature(Uint8Array.from([0x50, 0x4b, 0x03, 0x04]), 'pdf'), false);
});
