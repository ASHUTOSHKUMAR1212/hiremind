import assert from 'node:assert/strict';
import test from 'node:test';
import { assessCandidateEvidence } from '../lib/evidence-screening.ts';
import { extractWordXmlText, parseResumeProfile } from '../lib/resume-text.ts';
import { normalizeSkillPhrases } from '../lib/skills-context.ts';

const score = (description: string, label = 'SQL') =>
  assessCandidateEvidence({ experiences: [{ description }] }, [
    {
      id: 'skill',
      label,
      weight: 100,
      requirementClass: 'essential',
      evidenceDefinition: null,
      equivalentSignalsJson: '[]',
    },
  ]);

test('Word soft breaks preserve sections, styled words and tabs', () => {
  const text = extractWordXmlText(
    '<w:p><w:r><w:t>SUMMARY</w:t><w:br/><w:t>Analyst.</w:t><w:cr/><w:t>WORK HISTORY</w:t><w:br/><w:t>Developer | Acme | Jan 2022 - Present</w:t><w:br/><w:t>Built S</w:t></w:r><w:r><w:t>QL</w:t><w:tab/><w:t>reports for customer payments.</w:t></w:r></w:p>',
  );
  assert.match(text, /SUMMARY\nAnalyst\.\nWORK HISTORY\n/);
  assert.match(text, /SQL reports/);
  const parsed = parseResumeProfile(text);
  assert.equal(parsed.experiences.length, 1);
  assert.match(parsed.experiences[0].description, /SQL reports/);
});

test('common section variants and inline headings retain their own content', () => {
  const result = parseResumeProfile(
    'Asha Rao\nExecutive Summary: Data analyst.\nSkills Summary\nSQL, Python\nProfessional Background\nDeveloper | Acme | Jan 2021 - Present\nBuilt SQL reports for monthly payments.\nEducation and Training\n2020: Bachelor of Science from Example University',
  );
  assert.equal(result.summary, 'Data analyst.');
  assert.equal(result.experiences.length, 1);
  assert.equal(result.education.length, 1);
  assert.ok(result.skills.includes('SQL'));
});

test('missing work and education are explicitly disclosed', () => {
  const result = parseResumeProfile('Asha Rao\nAnalyst');
  assert.ok(result.warnings.some((w) => w.includes('work-history')));
  assert.ok(result.warnings.some((w) => w.includes('education section')));
});

test('undelimited layout headings retain work and education without inventing dates', () => {
  const result = parseResumeProfile(
    'Asha Rao\nSUMMARY Analyst building reports.\nSkills Summary\nSQL, Python\nWork experience 04/2022 07/2022\nFull Stack Engineer\nBuilt SQL reports for customer payments.\nEducation Bachelor of Science\nExample University',
  );
  assert.equal(result.summary, 'Analyst building reports.');
  assert.equal(result.experiences.length, 1);
  assert.equal(result.experiences[0].startedOn, '');
  assert.match(result.experiences[0].description, /SQL reports/);
  assert.equal(result.education.length, 1);
  assert.ok(result.skills.includes('SQL'));
});

test('short concrete work is supported without rewarding a list of tools', () => {
  assert.ok(score('Optimized SQL queries.').fitScore >= 45);
  assert.ok(score('Used SQL extensively.').fitScore <= 44);
  assert.ok(score('Used SQL and Python and Java extensively.').fitScore <= 44);
});

test('observations, team output and funding do not prove personal technical work', () => {
  for (const value of [
    'The team built SQL queries for customer reports; I did not write or maintain those queries.',
    'Observed colleagues who built SQL pipelines to reconcile customer payments.',
    'Watched a colleague implement SQL queries for revenue reports.',
    'Managed the budget for a SQL migration delivered by an external engineering team.',
    'SQL reporting was built by the team for customer payments.',
  ])
    assert.ok(score(value).fitScore <= 44, value);
  assert.ok(
    score('Built SQL queries with my team to reconcile customer payments.')
      .fitScore >= 45,
  );
  assert.ok(
    score('SQL payment reports were built and maintained by me.').fitScore >=
      45,
  );
});

test('imagined or planned work does not become performed work', () => {
  for (const value of [
    'If assigned the task, I would have built SQL queries to reconcile customer payments.',
    'I might build SQL reports for customer payments.',
    'I intend to learn SQL next year.',
    'I could have optimized SQL queries for customer reporting.',
  ])
    assert.ok(score(value).fitScore <= 44, value);
});

test('scoped denial excludes only the denied technology and preserves source quote', () => {
  const description =
    'Built SQL reconciliation queries, not Python scripts, for monthly customer payments.';
  assert.ok(score(description).fitScore >= 45);
  assert.equal(score(description, 'Python').fitScore, 0);
  assert.equal(
    score(description).criterionResults[0].evidence[0].source.quote,
    description,
  );
  assert.ok(
    score(
      'Not only built SQL payment reports but also maintained the monthly reconciliation process.',
    ).fitScore >= 45,
  );
});

test('CI and CD need relevant context while delivery aliases remain usable', () => {
  assert.equal(
    score(
      'Managed CI investigations into employee misconduct and workplace complaints.',
      'Continuous integration',
    ).fitScore,
    0,
  );
  assert.equal(
    score(
      'Created CD artwork for an independent music album.',
      'Continuous delivery',
    ).fitScore,
    0,
  );
  assert.ok(
    score(
      'Built CI pipelines to test software releases.',
      'Continuous integration',
    ).fitScore >= 45,
  );
  assert.ok(
    score(
      'Built CI/CD pipelines to automate software releases.',
      'Continuous delivery',
    ).fitScore >= 45,
  );
  assert.match(
    normalizeSkillPhrases('CI/CD pipelines'),
    /continuous_integration\/continuous_delivery/,
  );
});
