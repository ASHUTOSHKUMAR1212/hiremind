import assert from 'node:assert/strict';
import test from 'node:test';
import { resolveInterviewViewer } from '../lib/interview-viewer.ts';
import { isUpcomingInterview, isOverdueInterview, getSessionContextChoice } from '../lib/interview-status.ts';
import { extractWordXmlText, parseResumeProfile } from '../lib/resume-text.ts';
import { calculateProfileCompletion, getProfileQualityWarnings } from '../lib/profile-quality.ts';

test('explicit interview workspace resolves dual-role viewers without granting permissions', () => {
  assert.equal(resolveInterviewViewer('employer', true, true), 'employer');
  assert.equal(resolveInterviewViewer('candidate', true, true), 'candidate');
  assert.equal(resolveInterviewViewer(null, true, true), 'candidate');
  assert.equal(resolveInterviewViewer('employer', true, false), null);
  assert.equal(resolveInterviewViewer('candidate', false, true), null);
  assert.equal(resolveInterviewViewer(null, false, false), null);
  assert.equal(resolveInterviewViewer('admin', true, true), null);
});

test('upcoming excludes overdue, undated, active, completed and cancelled interviews', () => {
  const now = Date.UTC(2026, 8, 16);
  assert.equal(isUpcomingInterview({ status: 'scheduled', scheduledAt: now + 1 }, now), true);
  assert.equal(isUpcomingInterview({ status: 'scheduled', scheduledAt: now }, now), true);
  assert.equal(isOverdueInterview({ status: 'scheduled', scheduledAt: now - 1 }, now), true);
  for (const item of [
    { status: 'scheduled', scheduledAt: now - 1 },
    { status: 'scheduled', scheduledAt: null },
    { status: 'in_progress', scheduledAt: now },
    { status: 'completed', scheduledAt: now + 1 },
    { status: 'cancelled', scheduledAt: now + 1 },
  ]) assert.equal(isUpcomingInterview(item, now), false);
});

test('unrecorded consent is not presented as a candidate refusal', () => {
  assert.equal(getSessionContextChoice(false, []).title, 'Not provided yet');
  assert.equal(getSessionContextChoice(false, ['tab_visibility']).shared, false);
  assert.equal(getSessionContextChoice(true, []).title, 'Not shared');
  assert.equal(getSessionContextChoice(true, ['tab_visibility']).shared, true);
});

test('Word extraction joins styled runs and excludes drawing coordinates and deleted text', () => {
  const xml = '<w:document><w:p><w:r><w:t>Pri</w:t></w:r><w:r><w:t>ya Nair</w:t></w:r></w:p>'
    + '<w:p><wp:positionH><wp:posOffset>1470660</wp:posOffset></wp:positionH><wp:positionV><wp:posOffset>476885</wp:posOffset></wp:positionV>'
    + '<w:r><w:t>+91 98765 43210</w:t></w:r></w:p><w:p><w:r><w:t>Supervise</w:t></w:r><w:r><w:t>d Learning &amp; SQL</w:t></w:r></w:p>'
    + '<w:del><w:r><w:t>Old name</w:t></w:r></w:del></w:document>';
  const extracted = extractWordXmlText(xml);
  assert.equal(extracted, 'Priya Nair\n+91 98765 43210\nSupervised Learning & SQL\n');
  const parsed = parseResumeProfile(extracted);
  assert.equal(parsed.fullName, 'Priya Nair');
  assert.equal(parsed.phone, '+91 98765 43210');
});

test('parser rejects portfolio headings and layout-number phone matches', () => {
  const parsed = parseResumeProfile('Portfol i o\nPriya Nair\n1470660 476885 0 0\nSUMMARY\nAnalyst with SQL experience.');
  assert.equal(parsed.fullName, 'Priya Nair');
  assert.equal(parsed.phone, '');
});

test('project tools stay in descriptions rather than becoming project titles', () => {
  const parsed = parseResumeProfile('Priya Nair\nPROJECTS\nCustomer feedback classifier\nTools: NLP, Python\n- Classified customer feedback and measured precision on held-out data.');
  assert.equal(parsed.projects.length, 1);
  assert.equal(parsed.projects[0].title, 'Customer feedback classifier');
  assert.match(parsed.projects[0].description, /Tools:/);
});

test('existing malformed profile is warned about without being mutated or marked complete', () => {
  const profile = { fullName: 'Portfol i o', phone: '1470660 476885 0 0', headline: 'Analyst', summary: 'SQL analyst',
    location: 'Pune', skills: ['SQL'], profileType: 'fresher', resume: { id: 'file' },
    experiences: [{ title: 'Analyst' }], education: [{ institution: 'College -25400 36830 0 0' }],
    projects: [{ title: 'Tools: Python' }] };
  const snapshot = JSON.stringify(profile);
  assert.equal(getProfileQualityWarnings(profile).length, 4);
  assert.ok(calculateProfileCompletion(profile) < 100);
  assert.equal(JSON.stringify(profile), snapshot);
  const corrected = { ...profile, fullName: 'Priya Nair', phone: '+91 98765 43210',
    education: [{ institution: 'College' }], projects: [{ title: 'Reporting dashboard' }] };
  assert.equal(getProfileQualityWarnings(corrected).length, 0);
  assert.equal(calculateProfileCompletion(corrected), 100);
});
