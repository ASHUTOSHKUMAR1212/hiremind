import test from 'node:test';
import assert from 'node:assert/strict';
import { talentSearchFilters } from '../lib/talent-search.ts';
test('Talent filters bound input and deduplicate search terms', () => {
  const r = talentSearchFilters(
    new URLSearchParams('jobId=job&q=SQL+Python+SQL&location=Pune'),
    100000000,
  );
  assert.deepEqual(r.terms, ['SQL', 'Python']);
  assert.equal(r.location, 'Pune');
  assert.throws(() =>
    talentSearchFilters(new URLSearchParams('jobId=job&q=a+b+c+d+e+f+g')),
  );
  assert.throws(() => talentSearchFilters(new URLSearchParams()));
});
test('Talent page cursors preserve boundary and reject future or expired searches', () => {
  const params = (value: unknown) =>
    new URLSearchParams({ jobId: 'job', cursor: JSON.stringify(value) });
  assert.equal(
    talentSearchFilters(params({ at: 90, id: 'last', asOf: 100 }), 200).cursor
      ?.id,
    'last',
  );
  for (const value of [
    { at: 101, id: 'x', asOf: 100 },
    { at: 1, id: '', asOf: 100 },
    { at: 1, id: 'x', asOf: 201 },
    null,
  ])
    assert.throws(() => talentSearchFilters(params(value), 200));
  assert.throws(() =>
    talentSearchFilters(params({ at: 90, id: 'last', asOf: 100 }), 86400200),
  );
});
