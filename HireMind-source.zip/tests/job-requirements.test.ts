import assert from 'node:assert/strict';
import test from 'node:test';
import { draftJobCriteria } from '../lib/job-criteria.ts';

const draft = (description: string, title = 'Developer') =>
  draftJobCriteria(title, description);
const labels = (description: string) =>
  draft(description).criteria.map((item) => item.label);

test('JavaScript does not invent a TypeScript requirement', () => {
  assert.deepEqual(labels('Required: JavaScript development.'), ['JavaScript']);
});
test('required and preferred headings carry over to following bullets', () => {
  const result = draft(
    'Requirements:\n- SQL\nPreferred:\n- Python\nBenefits:\nFree AWS certification training.',
  );
  assert.deepEqual(
    result.criteria.map((item) => [item.label, item.requirementClass]),
    [
      ['SQL', 'essential'],
      ['Python', 'preferred'],
    ],
  );
});
test('OR alternatives stay alternatives and explicitly non-required skills are excluded', () => {
  assert.deepEqual(
    labels('Python or Java is required. SQL experience is not required.'),
    ['Python or Java'],
  );
});
test('AND requirements become separately weighted criteria', () => {
  assert.deepEqual(labels('Python and Java are required.'), ['Python', 'Java']);
});
test('preferred wording is respected within one paragraph', () => {
  const result = draft('SQL is required; Python is preferred.');
  assert.deepEqual(
    result.criteria.map((item) => item.requirementClass),
    ['essential', 'preferred'],
  );
});
test('the job title is not a hidden source of invented qualifications', () => {
  assert.deepEqual(
    draft(
      'Work with our team to deliver excellent customer outcomes.',
      'Python engineer',
    ).criteria,
    [],
  );
});
test('vague descriptions request manual criteria, not a generic invented rubric', () => {
  const result = draft(
    'Join our enthusiastic team and help our business grow.',
  );
  assert.equal(result.criteria.length, 0);
  assert.match(result.cautions[0], /not invented/);
});
test('single-skill tenure remains attached to the actual skill', () => {
  assert.deepEqual(labels('At least 3 years of Python experience required.'), [
    '3 years Python',
  ]);
});
test('ambiguous multi-skill duration is not silently copied to every tool', () => {
  const result = draft(
    'At least 3 years of Python and SQL experience required.',
  );
  assert.ok(result.criteria.every((item) => !item.label.includes('years')));
  assert.ok(result.cautions.some((item) => item.includes('duration')));
});
test('degree and generic coursework are not silently equivalent qualifications', () => {
  const result = draft('SQL is required. A degree is preferred.');
  assert.deepEqual(result.criteria[0].equivalentSignals, []);
  assert.ok(result.cautions.some((item) => item.includes('education')));
});
test('source context and weights remain inspectable', () => {
  const result = draft('Requirements:\nSQL and Python\nPreferred:\nDocker');
  assert.equal(
    result.criteria.reduce((sum, item) => sum + item.weight, 0),
    100,
  );
  assert.ok(
    result.criteria.every((item) => item.sourceHint.includes(item.label)),
  );
  assert.ok(result.criteria[0].weight > result.criteria.at(-1)!.weight);
});
test('explicit general competencies remain available without inferring them from a tool', () => {
  assert.ok(
    labels(
      'Stakeholder communication and people management are required.',
    ).includes('Stakeholder communication'),
  );
  assert.deepEqual(labels('Figma required.'), ['Figma']);
});
test('conflicting requirement classes produce an employer review warning', () => {
  assert.ok(
    draft('SQL required. SQL preferred.').cautions.some((item) =>
      item.includes('conflict'),
    ),
  );
});
test('more than ten detected criteria are disclosed rather than silently omitted', () => {
  const result = draft(
    'SQL, Python, Java, JavaScript, TypeScript, Docker, Kubernetes, MySQL, MongoDB, Redis, Terraform, Figma required.',
  );
  assert.equal(result.criteria.length, 10);
  assert.ok(result.cautions.some((item) => item.includes('omitted')));
});

test('unhandled requirements retain exact source text for recruiter review', () => {
  const result = draft(
    'Required: An active professional license.\nAt least 3 years of Python and SQL experience required.\nA degree or equivalent experience is preferred.',
  );
  assert.ok(
    result.reviewItems.some(
      (item) =>
        item.source.includes('An active professional license.') &&
        item.reason.includes('No automatic criterion'),
    ),
  );
  assert.ok(
    result.reviewItems.some(
      (item) =>
        item.source.includes('3 years') && item.reason.includes('duration'),
    ),
  );
  assert.ok(
    result.reviewItems.some(
      (item) =>
        item.source.includes('degree or equivalent experience') &&
        item.reason.includes('alternative'),
    ),
  );
  assert.ok(
    result.criteria.every((item) => !/license|degree/.test(item.label)),
  );
});

test('mixed technical and credential clauses and month durations need explicit review', () => {
  const result = draft(
    'SQL and an active professional license are required. At least 18 months of Python and SQL experience required.',
  );
  assert.ok(
    result.reviewItems.some(
      (item) =>
        item.source.includes('license') && item.reason.includes('credential'),
    ),
  );
  assert.ok(
    result.reviewItems.some(
      (item) =>
        item.source.includes('18 months') && item.reason.includes('duration'),
    ),
  );
});
