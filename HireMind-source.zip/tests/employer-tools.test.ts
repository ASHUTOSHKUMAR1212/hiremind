import test from 'node:test';
import assert from 'node:assert/strict';
import {
  assessCandidateEvidence,
  type ScreeningCriterion,
} from '../lib/evidence-screening.ts';
import {
  relevantTenure,
  normalizeSkillPhrases,
} from '../lib/skills-context.ts';
import {
  evaluateBenchmark,
  validateBenchmark,
} from '../lib/matching-benchmark.ts';
import {
  parseTranscript,
  validateScorecard,
} from '../lib/interview-transcript.ts';
import {
  validateCrmContact,
  validateOutreach,
  canTransitionOutreach,
} from '../lib/recruiter-crm.ts';
import {
  interviewCalendar,
  hashIntegrationToken,
} from '../lib/integrations.ts';

const criterion: ScreeningCriterion = {
  id: 'sql',
  label: 'SQL',
  weight: 100,
  requirementClass: 'essential',
  evidenceDefinition: null,
  equivalentSignalsJson: '[]',
};
const work = {
  title: 'Analyst',
  description: 'Built SQL queries to reconcile transactions and report sales.',
  startedOn: '2020-01',
  endedOn: '2024-01',
};
const assess = (profile: Record<string, unknown>, label = 'SQL') =>
  assessCandidateEvidence(profile, [{ ...criterion, label }]);
const dataset = () => ({
  name: 'Synthetic regression fixture, not accuracy evidence',
  labelSource: 'Developer-authored test cases; not independent labels.',
  heldOut: false,
  consentConfirmed: true,
  cases: [
    {
      id: 'a',
      jobId: 'j',
      profile: { experiences: [work] },
      criteria: [criterion],
      relevance: 3,
    },
    { id: 'b', jobId: 'j', profile: {}, criteria: [criterion], relevance: 0 },
  ],
});
const transcript =
  'WEBVTT\n\n00:00:01.000 --> 00:00:04.000\n<v Candidate>I built SQL reports for the billing team.</v>\n\n00:00:05.000 --> 00:00:08.000\nInterviewer: What did you validate?';

test('matching treats full skill phrase and acronym as synonyms', () =>
  assert.equal(
    assess({ experiences: [work] }).fitScore,
    assess({
      experiences: [
        {
          ...work,
          description: work.description.replace(
            'SQL',
            'structured query language',
          ),
        },
      ],
    }).fitScore,
  ));
test('synonyms do not equate different tools', () =>
  assert.notEqual(
    normalizeSkillPhrases('Java'),
    normalizeSkillPhrases('JavaScript'),
  ));
test('SQL duration is supported only by relevant dated work', () => {
  assert.ok(
    assess({ experiences: [work] }, '3 years SQL experience').fitScore >= 50,
  );
  assert.ok(
    assess(
      {
        experiences: [
          { ...work, endedOn: '2021-01' },
          { ...work, description: 'Prepared tax returns.', endedOn: '2026-01' },
        ],
      },
      '3 years SQL experience',
    ).fitScore < 50,
  );
});
test('overlapping roles count elapsed months only once', () =>
  assert.deepEqual(
    relevantTenure([
      { startedOn: '2020-01', endedOn: '2023-01' },
      { startedOn: '2021-01', endedOn: '2024-01' },
    ]),
    { months: 48, unresolved: 0 },
  ));
test('year-only, future, and reversed dates remain unresolved', () =>
  assert.deepEqual(
    relevantTenure([
      { startedOn: '2020', endedOn: '2023' },
      { startedOn: '2024-01', endedOn: '2020-01' },
      { startedOn: '2020-01', endedOn: '2099-01' },
    ]),
    { months: 0, unresolved: 3 },
  ));
test('current roles use the explicit evaluation date', () =>
  assert.equal(
    relevantTenure(
      [{ startedOn: '2024-01', isCurrent: true }],
      new Date('2025-01-01'),
    ).months,
    12,
  ));
test('benchmark computes ranking agreement and preserves declared scope', () => {
  const result = evaluateBenchmark(validateBenchmark(dataset()));
  assert.equal(result.ndcgAt10, 1);
  assert.equal(result.precisionAtK, 0.5);
  assert.equal(result.recallAtK, 1);
  assert.equal(result.heldOut, false);
  assert.equal(result.jobs[0].k, 2);
});
test('benchmark refuses duplicate cases, missing labels, and inconsistent rubrics', () => {
  const duplicate = dataset();
  duplicate.cases[1].id = 'a';
  assert.throws(() => validateBenchmark(duplicate));
  const invalid = dataset();
  invalid.cases[1].relevance = 4;
  assert.throws(() => validateBenchmark(invalid));
  const mismatch = dataset();
  mismatch.cases[1].criteria = [{ ...criterion, weight: 50 }];
  assert.throws(() => validateBenchmark(mismatch));
});
test('benchmark requires consent and label provenance', () => {
  assert.throws(() =>
    validateBenchmark({ ...dataset(), consentConfirmed: false }),
  );
  assert.throws(() => validateBenchmark({ ...dataset(), labelSource: '' }));
});
test('no relevant benchmark labels means recall and nDCG are undefined', () => {
  const data = dataset();
  data.cases.forEach((item) => {
    item.relevance = 0;
  });
  const report = evaluateBenchmark(validateBenchmark(data));
  assert.equal(report.recallAtK, null);
  assert.equal(report.ndcgAt10, null);
});
test('VTT retains exact text, speaker labels, and timestamps', () => {
  const segments = parseTranscript(transcript);
  assert.equal(segments.length, 2);
  assert.equal(segments[0].speaker, 'Candidate');
  assert.equal(segments[0].startMs, 1000);
  assert.equal(segments[1].speaker, 'Interviewer');
});
test('SRT imports timing and removes markup as text, never executes it', () => {
  const segments = parseTranscript(
    '1\n00:00:01,000 --> 00:00:03,000\nCandidate: <b>SQL</b>',
  );
  assert.equal(segments[0].text, 'SQL');
});
test('transcript refuses unstructured, reversed, and invalid timing', () => {
  assert.throws(() => parseTranscript('ordinary notes'));
  assert.throws(() => parseTranscript('00:02.000 --> 00:01.000\nBad'));
  assert.throws(() => parseTranscript('00:99.000 --> 00:100.000\nBad'));
});
test('scorecard submission requires source-linked ratings', () => {
  const entry = {
    criterionId: 'sql',
    rating: 3,
    rationale: 'Describes concrete SQL reporting work.',
    segmentIds: ['segment-1'],
  };
  assert.equal(
    validateScorecard([entry], ['sql'], parseTranscript(transcript), true)
      .length,
    1,
  );
  assert.throws(() =>
    validateScorecard(
      [{ ...entry, segmentIds: [] }],
      ['sql'],
      parseTranscript(transcript),
      true,
    ),
  );
  assert.throws(() =>
    validateScorecard(
      [{ ...entry, segmentIds: ['fake'] }],
      ['sql'],
      parseTranscript(transcript),
      true,
    ),
  );
});
test('unassessed scorecard requires a reason but no fabricated citation', () =>
  assert.equal(
    validateScorecard(
      [
        {
          criterionId: 'sql',
          rating: null,
          rationale: 'This topic was not covered in the interview.',
          segmentIds: [],
        },
      ],
      ['sql'],
      [],
      true,
    )[0].rating,
    null,
  ));
test('scorecards reject duplicates and out-of-range ratings', () => {
  const entry = {
    criterionId: 'sql',
    rating: 5,
    rationale: 'Something described',
    segmentIds: [],
  };
  assert.throws(() => validateScorecard([entry], ['sql'], [], false));
  assert.throws(() =>
    validateScorecard(
      [
        { ...entry, rating: 1 },
        { ...entry, rating: 1 },
      ],
      ['sql', 'python'],
      [],
      false,
    ),
  );
});
test('CRM validates notes, tags, and explicit boolean suppression', () => {
  assert.deepEqual(
    validateCrmContact({
      stage: 'new',
      tags: ['SQL', 'SQL'],
      notes: '',
      suppressed: false,
    }).tags,
    ['SQL'],
  );
  assert.throws(() =>
    validateCrmContact({
      stage: 'new',
      tags: [],
      notes: '',
      suppressed: 'false',
    }),
  );
});
test('outreach rejects header injection and past follow-up times', () => {
  assert.throws(() =>
    validateOutreach({
      subject: 'Job\r\nBcc: evil@example.test',
      body: 'A message with sufficient length.',
      dueAt: null,
    }),
  );
  assert.throws(() =>
    validateOutreach({
      subject: 'Job',
      body: 'A message with sufficient length.',
      dueAt: 1,
    }),
  );
});
test('outreach cannot skip approval or revive cancelled sends', () => {
  assert.equal(canTransitionOutreach('draft', 'sent'), false);
  assert.equal(canTransitionOutreach('approved', 'sent'), true);
  assert.equal(canTransitionOutreach('cancelled', 'approved'), false);
});
test('integration key hash is stable and not the raw credential', async () => {
  const hash = await hashIntegrationToken('example');
  assert.equal(hash.length, 64);
  assert.equal(hash, await hashIntegrationToken('example'));
  assert.notEqual(hash, await hashIntegrationToken('other'));
});
test('calendar exports UTC times, stable IDs, escaped input, and bounded UTF-8 lines', () => {
  const body = interviewCalendar({
    id: 'session',
    jobTitle: 'SQL\nATTENDEE:bad@example.test;' + '😀'.repeat(90),
    companyName: 'Company',
    scheduledAt: Date.UTC(2026, 8, 10, 8),
    updatedAt: Date.UTC(2026, 8, 9),
    status: 'scheduled',
    url: 'https://example.test/interview?id=session',
  });
  assert.ok(body.includes('DTSTART:20260910T080000Z'));
  assert.ok(body.includes('UID:session@hiremind'));
  assert.ok(!body.includes('\r\nATTENDEE:'));
  assert.ok(
    body
      .split('\r\n')
      .every((line) => new TextEncoder().encode(line).length <= 75),
  );
});
test('calendar cancellation and invalid duration are explicit', () => {
  const data = {
    id: 's',
    jobTitle: 'j',
    companyName: 'c',
    scheduledAt: Date.now(),
    updatedAt: Date.now(),
    status: 'cancelled',
    url: 'https://example.test',
  };
  assert.ok(interviewCalendar(data).includes('STATUS:CANCELLED'));
  assert.throws(() => interviewCalendar(data, -5));
});
