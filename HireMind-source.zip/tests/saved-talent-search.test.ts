import test from 'node:test';
import assert from 'node:assert/strict';
import { validateSavedTalentSearch } from '../lib/saved-talent-search.ts';

const valid = {
  name: ' Pune Analysts ',
  jobId: 'job',
  q: ' SQL ',
  location: ' Pune ',
};
test('Saved talent searches normalize definitions without retaining result data', () => {
  assert.deepEqual(
    validateSavedTalentSearch({
      ...valid,
      cursor: 'old',
      candidates: ['private'],
    }),
    {
      name: 'Pune Analysts',
      nameKey: 'pune analysts',
      jobId: 'job',
      q: 'SQL',
      location: 'Pune',
    },
  );
});
test('Saved talent searches reject invalid names, filters and unbounded payloads', () => {
  for (const patch of [
    { name: '' },
    { name: 'x'.repeat(61) },
    { name: 'bad\nname' },
    { name: 5 },
    { jobId: '' },
    { jobId: null },
    { q: [] },
    { q: 'a b c d e f g' },
    { location: 'x'.repeat(101) },
  ]) {
    assert.throws(() => validateSavedTalentSearch({ ...valid, ...patch }));
  }
});
