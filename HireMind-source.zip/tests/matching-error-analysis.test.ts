import assert from 'node:assert/strict';
import test from 'node:test';
import { evaluateBenchmark } from '../lib/matching-benchmark.ts';

const criteria = [
  {
    id: 'sql',
    label: 'SQL',
    weight: 100,
    requirementClass: 'essential',
    evidenceDefinition: null,
    equivalentSignalsJson: '[]',
  },
];
const strong = {
  experiences: [
    {
      description: 'Built SQL queries to reconcile monthly customer payments.',
    },
  ],
};
const dataset = {
  name: 'Synthetic disagreement regression, not accuracy evidence',
  labelSource: 'Developer-authored labels for testing report calculations.',
  heldOut: false,
  consentConfirmed: true,
  cases: [
    { id: 'tp', jobId: 'j', relevance: 3, profile: strong, criteria },
    { id: 'fp', jobId: 'j', relevance: 0, profile: strong, criteria },
    { id: 'fn', jobId: 'j', relevance: 2, profile: {}, criteria },
    { id: 'tn', jobId: 'j', relevance: 0, profile: {}, criteria },
  ],
};

test('benchmark exposes both over-selection and missed relevant profiles with reasons', () => {
  const report = evaluateBenchmark(dataset);
  assert.deepEqual(
    { ...report.selectionDiagnostics, rule: undefined },
    {
      rule: undefined,
      truePositives: 1,
      falsePositives: 1,
      falseNegatives: 1,
      trueNegatives: 1,
      precision: 0.5,
      recall: 0.5,
    },
  );
  assert.equal(
    report.jobs[0].ranked.find((item) => item.id === 'fp')?.disagreement,
    'strong_match_with_low_label',
  );
  assert.equal(
    report.jobs[0].ranked.find((item) => item.id === 'fn')?.disagreement,
    'relevant_not_strong',
  );
  assert.ok(report.jobs[0].ranked[0].criteria[0].explanation.length > 0);
});
test('undefined strong-selection metrics are not invented as zero or perfect', () => {
  const report = evaluateBenchmark({
    ...dataset,
    cases: dataset.cases.map((item) => ({
      ...item,
      profile: {},
      relevance: 0,
    })),
  });
  assert.equal(report.selectionDiagnostics.precision, null);
  assert.equal(report.selectionDiagnostics.recall, null);
  assert.equal(report.selectionDiagnostics.trueNegatives, 4);
});
