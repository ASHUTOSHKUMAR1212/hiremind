import assert from 'node:assert/strict';
import test from 'node:test';
import { assessCandidateEvidence, usesCurrentMatchingEngine, type ScreeningCriterion } from '../lib/evidence-screening.ts';
import { rankResumeComparisons } from '../lib/resume-comparison.ts';

const criterion: ScreeningCriterion = { id: 'sql', label: 'SQL', weight: 100, requirementClass: 'essential', evidenceDefinition: null, equivalentSignalsJson: '[]' };
const work = { title: 'Analyst', organizationName: 'Example', description: 'Built SQL queries to reconcile payment records and resolve duplicate transactions.' };
const assess = (profile: Record<string, unknown>, requirement = criterion) => assessCandidateEvidence(profile, [requirement]);

test('unversioned saved comparisons require rerunning rather than silently adopting new labels', () => {
  assert.equal(usesCurrentMatchingEngine([{ score: 99 }]), false);
  assert.equal(usesCurrentMatchingEngine(assess({ experiences: [work] }).criterionResults), true);
});

test('whole skills match: NoSQL is not SQL', () => {
  assert.equal(assess({ experiences: [{ ...work, description: 'Built NoSQL document stores for customer records.' }] }).fitScore, 0);
});
test('listing a skill alone is not strong evidence', () => {
  assert.ok(assess({ metadata: { skills: ['SQL'] } }).fitScore < 50);
});
test('duplicate skill tags cannot improve rank', () => {
  assert.equal(assess({ metadata: { skills: ['SQL', 'SQL', 'sql'] } }).fitScore, assess({ metadata: { skills: ['SQL'] } }).fitScore);
});
test('duplicated work descriptions do not corroborate themselves', () => {
  assert.equal(assess({ experiences: [work, work, work] }).fitScore, assess({ experiences: [work] }).fitScore);
});
test('candidate name and employer name cannot supply skills', () => {
  assert.equal(assess({ fullName: 'SQL', experiences: [{ title: 'Accountant', organizationName: 'SQL', description: 'Prepared quarterly tax returns.' }] }).fitScore, 0);
});
test('school name cannot supply a skill', () => {
  assert.equal(assess({ education: [{ institution: 'SQL', qualification: 'Bachelor', fieldOfStudy: 'History' }] }).fitScore, 0);
});
test('equivalent signals require the entire approved phrase', () => {
  const requirement = { ...criterion, equivalentSignalsJson: '["relational database queries"]' };
  assert.equal(assess({ summary: 'Answered customer queries about opening hours.' }, requirement).fitScore, 0);
});
test('job title alone is not evidence of performed work', () => {
  assert.ok(assess({ experiences: [{ title: 'SQL', organizationName: 'Example', description: '' }] }).fitScore < 50);
});
test('denied experience is never positive evidence', () => {
  assert.equal(assess({ experiences: [{ ...work, description: 'I have never used SQL.' }] }).fitScore, 0);
});
test('relevant work outranks a keyword list', () => {
  assert.ok(assess({ experiences: [work] }).fitScore > assess({ metadata: { skills: ['SQL'] } }).fitScore);
});
test('names and contact details do not change evidence score', () => {
  assert.equal(assess({ fullName: 'Asha', email: 'a@example.test', experiences: [work] }).fitScore, assess({ fullName: 'Zara', email: 'z@example.test', experiences: [work] }).fitScore);
});
test('ties preserve input order rather than sorting by candidate name', () => {
  assert.deepEqual(rankResumeComparisons([{ candidateName: 'Zara', fitScore: 50, uncertainty: 40 }, { candidateName: 'Asha', fitScore: 50, uncertainty: 40 }]).map(item => item.candidateName), ['Zara', 'Asha']);
});
test('missing evidence is review, never automatic rejection', () => {
  const result = assess({});
  assert.equal(result.decisionBand, 'needs_review');
  assert.equal(result.criterionResults[0].requiresHumanReview, true);
});
test('unverified years-of-experience requirement cannot become a strong match', () => {
  const result = assess({ experiences: [work] }, { ...criterion, label: '3 years SQL experience' });
  assert.ok(result.fitScore < 50);
  assert.equal(result.decisionBand, 'needs_review');
});
