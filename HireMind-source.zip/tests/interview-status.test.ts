import assert from 'node:assert/strict';
import test from 'node:test';

import {
  INTERVIEW_EARLY_ACCESS_MS,
  getCandidateInterviewPresentation,
  getInterviewStartAvailability,
} from '../lib/interview-status.ts';

test('candidate interview actions describe the next usable action', () => {
  const scheduledAt = Date.UTC(2026, 8, 2, 8, 0);
  assert.deepEqual(
    getCandidateInterviewPresentation(
      'scheduled',
      scheduledAt,
      'structured_screening',
      scheduledAt - INTERVIEW_EARLY_ACCESS_MS - 1,
    ),
    {
      title: 'Screening scheduled',
      actionLabel: 'Prepare',
      canBegin: false,
      availableAt: scheduledAt - INTERVIEW_EARLY_ACCESS_MS,
    },
  );
  assert.deepEqual(
    getCandidateInterviewPresentation(
      'scheduled',
      scheduledAt,
      'structured_screening',
      scheduledAt - INTERVIEW_EARLY_ACCESS_MS,
    ),
    {
      title: 'Screening ready',
      actionLabel: 'Start screening',
      canBegin: true,
      availableAt: scheduledAt - INTERVIEW_EARLY_ACCESS_MS,
    },
  );
  assert.deepEqual(getCandidateInterviewPresentation('in_progress'), {
    title: 'Screening in progress',
    actionLabel: 'Continue screening',
    canBegin: true,
    availableAt: null,
  });
  assert.equal(
    getCandidateInterviewPresentation('completed').actionLabel,
    null,
  );
  assert.equal(
    getCandidateInterviewPresentation('cancelled').actionLabel,
    null,
  );
  assert.equal(
    getCandidateInterviewPresentation(
      'scheduled',
      scheduledAt,
      'live_video',
      scheduledAt,
    ).actionLabel,
    'Join live interview',
  );
});

test('the server-side start window opens fifteen minutes before the scheduled time', () => {
  const scheduledAt = 2_000_000_000_000;
  assert.deepEqual(
    getInterviewStartAvailability(
      'scheduled',
      scheduledAt,
      scheduledAt - INTERVIEW_EARLY_ACCESS_MS - 1,
    ),
    {
      canBegin: false,
      availableAt: scheduledAt - INTERVIEW_EARLY_ACCESS_MS,
    },
  );
  assert.equal(
    getInterviewStartAvailability(
      'scheduled',
      scheduledAt,
      scheduledAt - INTERVIEW_EARLY_ACCESS_MS,
    ).canBegin,
    true,
  );
  assert.equal(
    getInterviewStartAvailability('in_progress', scheduledAt, 0).canBegin,
    true,
  );
});
