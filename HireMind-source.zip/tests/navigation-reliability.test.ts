import assert from 'node:assert/strict';
import { readFile, readdir } from 'node:fs/promises';
import test from 'node:test';

async function sourceFiles(directory: string): Promise<string[]> {
  const entries = await readdir(directory, { withFileTypes: true });
  const nested = await Promise.all(
    entries.map(async (entry) => {
      const path = `${directory}/${entry.name}`;
      if (entry.isDirectory()) return sourceFiles(path);
      return /\.(ts|tsx)$/.test(entry.name) ? [path] : [];
    }),
  );
  return nested.flat();
}

test('production navigation avoids the broken vinext next/link adapter', async () => {
  const files = await sourceFiles('app');
  const offenders: string[] = [];

  for (const file of files) {
    const source = await readFile(file, 'utf8');
    if (/from ['"]next\/link['"]/.test(source)) offenders.push(file);
  }

  assert.deepEqual(offenders, []);
});

test('the shared link renders as a native browser anchor', async () => {
  const source = await readFile('components/stable-link.tsx', 'utf8');
  assert.match(source, /return <a href=\{href\}/);
});
