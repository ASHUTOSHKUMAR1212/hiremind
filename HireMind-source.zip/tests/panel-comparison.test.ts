import test from 'node:test';
import assert from 'node:assert/strict';
import { comparePanel, type PanelReview } from '../lib/panel-comparison.ts';
const rubric = [{ id: 'sql', label: 'SQL' }];
const review = (id: string, rating: number | null): PanelReview => ({
  reviewerId: id,
  reviewerName: id,
  status: 'submitted',
  stale: false,
  transcriptRevision: 1,
  entries: [
    {
      criterionId: 'sql',
      rating,
      rationale: 'Specific assessment rationale.',
      segmentIds: rating === null ? [] : ['s1'],
    },
  ],
  sourceSegments: [
    {
      id: 's1',
      startMs: 1000,
      endMs: 5000,
      speaker: 'Candidate',
      text: 'I built SQL reports.',
    },
  ],
});
test('Panel highlights a two-point disagreement with original evidence, not an average', () => {
  const p = comparePanel(rubric, [review('a', 1), review('b', 3)], 1);
  assert.equal(p.criteria[0].needsDiscussion, true);
  assert.equal(p.criteria[0].minimum, 1);
  assert.equal(p.criteria[0].maximum, 3);
  assert.equal(
    p.criteria[0].assessments[1].sources[0].text,
    'I built SQL reports.',
  );
  assert.ok(!('average' in p.criteria[0]));
});
test('Panel excludes private drafts and stale reviews', () => {
  const p = comparePanel(
    rubric,
    [
      { ...review('draft', 1), status: 'draft' },
      { ...review('stale', 1), stale: true },
      review('current', 4),
    ],
    1,
  );
  assert.equal(p.reviewerCount, 1);
  assert.equal(p.excludedSubmitted, 1);
  assert.equal(p.criteria[0].needsDiscussion, false);
  assert.ok(!JSON.stringify(p).includes('draft'));
});
test('Mismatched transcript revisions cannot contribute to agreement', () => {
  const p = comparePanel(
    rubric,
    [review('a', 1), { ...review('b', 4), transcriptRevision: 2 }],
    1,
  );
  assert.equal(p.reviewerCount, 1);
  assert.equal(p.excludedSubmitted, 1);
});
test('Unassessed and broken citations remain missing, never zero', () => {
  const p = comparePanel(
    rubric,
    [review('a', null), { ...review('b', 4), sourceSegments: [] }],
    1,
  );
  assert.equal(p.criteria[0].ratedCount, 0);
  assert.equal(p.criteria[0].unassessedCount, 2);
  assert.equal(p.criteria[0].minimum, null);
  assert.equal(p.criteria[0].assessments[1].missingCitation, true);
});
test('Same reviewer is counted only once and one-point spread is not flagged', () => {
  const p = comparePanel(
    rubric,
    [review('a', 1), review('a', 3), review('b', 4)],
    1,
  );
  assert.equal(p.reviewerCount, 2);
  assert.equal(p.criteria[0].needsDiscussion, false);
});
