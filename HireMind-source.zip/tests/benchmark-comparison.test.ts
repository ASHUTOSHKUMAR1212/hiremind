import assert from 'node:assert/strict';
import test from 'node:test';
import { evaluateBenchmark, validateBenchmark, type BenchmarkDataset } from '../lib/matching-benchmark.ts';
import { tieAveragedMetrics, pairedInterval } from '../lib/benchmark-comparison.ts';
import { MATCHING_ENGINE_VERSION } from '../lib/evidence-screening.ts';

const fixture = (): BenchmarkDataset => ({
  name: 'Synthetic calculation test — not competitor evidence', labelSource: 'Developer labels; no independent recruiters or competitor outputs.',
  heldOut: false, consentConfirmed: true,
  cases: [3, 0].map((relevance, index) => ({ id: `c${index}`, jobId: 'j1', relevance,
    profile: index ? {} : { experiences: [{ description: 'Built SQL queries to reconcile monthly customer payments.' }] },
    criteria: [{ id: 'sql', label: 'SQL', weight: 100, requirementClass: 'essential', evidenceDefinition: null, equivalentSignalsJson: '[]' }] })),
  comparison: { competitor: 'Synthetic comparator', competitorVersion: 'Fixture v1', outputSource: 'Developer-created rankings, not Eightfold results.', capturedAt: '2026-01-01T00:00:00Z',
    protocolReference: 'Synthetic unit test protocol', expectedEngineVersion: MATCHING_ENGINE_VERSION, independentBlindLabels: false, sameInputsConfirmed: true,
    rankings: [{ jobId: 'j1', rankGroups: [['c1'], ['c0']] }] },
});

test('comparison measures the actual HireMind output and reports losses as well as wins', () => {
  const data = validateBenchmark(fixture());
  const report = evaluateBenchmark(data).comparison!;
  assert.equal(report.metrics[0].hiremind, 1);
  assert.ok(Math.abs(report.metrics[0].competitor! - 1 / Math.log2(3)) < 1e-12);
  assert.equal(report.metrics[0].wins, 1);
  assert.equal(report.metrics[0].interval, null);
  assert.match(report.evidenceStatus, /Exploratory/);
  data.cases.forEach((item) => { item.relevance = 3 - item.relevance; });
  assert.equal(evaluateBenchmark(data).comparison!.metrics[0].losses, 1);
});

test('ties average all permutations and are invariant to input order', () => {
  const expected = (1 + 1 / Math.log2(3)) / 2;
  assert.equal(tieAveragedMetrics([[3, 0]]).ndcgAt10, expected);
  assert.deepEqual(tieAveragedMetrics([[3, 0]]), tieAveragedMetrics([[0, 3]]));
  const data = fixture();
  data.cases.forEach((item) => { item.profile = {}; });
  const first = evaluateBenchmark(data).comparison!.metrics;
  data.cases.reverse();
  assert.deepEqual(evaluateBenchmark(data).comparison!.metrics, first);
});

test('ties crossing top-5 and top-10 cutoffs use expected gains, not truncated tie members', () => {
  const result = tieAveragedMetrics([Array.from({ length: 12 }, (_, i) => i < 6 ? 3 : 0)]);
  assert.equal(result.precisionAtK, 0.5);
  assert.equal(result.recallAtK, 2.5 / 6);
  const numerator = Array.from({ length: 10 }, (_, i) => 3.5 / Math.log2(i + 2)).reduce((a,b) => a+b, 0);
  const denominator = Array.from({ length: 6 }, (_, i) => 7 / Math.log2(i + 2)).reduce((a,b) => a+b, 0);
  assert.ok(Math.abs(result.ndcgAt10! - numerator / denominator) < 1e-12);
});

test('undefined labels do not become fake perfect scores, and excluded jobs are explicit', () => {
  const data = fixture(); data.cases.forEach((item) => { item.relevance = 0; });
  const report = evaluateBenchmark(data).comparison!;
  assert.equal(report.metrics[0].delta, null);
  assert.equal(report.metrics[0].excludedJobs, 1);
  assert.equal(report.metrics[2].eligibleJobs, 0);
  assert.equal(report.metrics[1].delta, 0);
});

test('legacy datasets work without competitor data', () => {
  const data = fixture(); delete data.comparison;
  assert.equal(evaluateBenchmark(validateBenchmark(data)).comparison, null);
});

test('malformed, incomplete, duplicate, cross-job, and phantom rankings are rejected', () => {
  const mutations = [
    (d: BenchmarkDataset) => { d.comparison!.rankings = []; },
    (d: BenchmarkDataset) => { d.comparison!.rankings[0].rankGroups = [['c0']]; },
    (d: BenchmarkDataset) => { d.comparison!.rankings[0].rankGroups = [['c0'], ['c0']]; },
    (d: BenchmarkDataset) => { d.comparison!.rankings[0].rankGroups = [['c0'], ['unknown']]; },
    (d: BenchmarkDataset) => { d.comparison!.rankings[0].rankGroups = [[], ['c0', 'c1']]; },
    (d: BenchmarkDataset) => { d.comparison!.rankings[0].jobId = 'other-job'; },
    (d: BenchmarkDataset) => { d.cases[1].jobId = 'other-job'; },
    (d: BenchmarkDataset) => { d.comparison!.sameInputsConfirmed = false; },
    (d: BenchmarkDataset) => { d.comparison!.expectedEngineVersion = 'old-engine'; },
    (d: BenchmarkDataset) => { d.comparison!.capturedAt = '2099-01-01T00:00:00Z'; },
    (d: BenchmarkDataset) => { d.comparison!.capturedAt = '2026-01-01'; },
    (d: BenchmarkDataset) => { d.comparison!.outputSource = ''; },
  ];
  for (const mutate of mutations) { const data = fixture(); mutate(data); assert.throws(() => validateBenchmark(data)); }
  assert.throws(() => validateBenchmark({ ...fixture(), comparison: null }));
  assert.throws(() => validateBenchmark({ ...fixture(), comparison: { ...fixture().comparison, rankings: [null] } }));
});

test('job means are paired and do not silently weight large pools more', () => {
  const data = fixture();
  const additional = data.cases.map((item, index) => ({ ...item, id: `other-${index}`, jobId: 'j2' }));
  data.cases.push(...additional);
  data.comparison!.rankings.push({ jobId: 'j2', rankGroups: [['other-0'], ['other-1']] });
  const report = evaluateBenchmark(validateBenchmark(data)).comparison!;
  assert.equal(report.metrics[0].eligibleJobs, 2);
  assert.ok(Math.abs(report.metrics[0].delta! - (1 - 1 / Math.log2(3)) / 2) < 1e-12);
  assert.equal(report.metrics[0].wins, 1);
  assert.equal(report.metrics[0].ties, 1);
});

test('bootstrap is deterministic, paired at job level, and withheld for small samples', () => {
  assert.equal(pairedInterval([1, 1]), null);
  assert.deepEqual(pairedInterval(Array(10).fill(0)), { lower: 0, upper: 0, resamples: 2000, seed: 19840719 });
  const values = [-.5, .5, -.1, .1, -.3, .3, -.2, .2, 0, 0];
  assert.deepEqual(pairedInterval(values), pairedInterval(values));
  assert.ok(pairedInterval(values)!.lower < 0 && pairedInterval(values)!.upper > 0);
});

test('declared independent status never claims independent verification or superiority', () => {
  const data = fixture(); data.heldOut = true; data.comparison!.independentBlindLabels = true;
  const report = evaluateBenchmark(data).comparison!;
  assert.match(report.evidenceStatus, /not independently audited/);
  assert.ok(report.limitations.some((item) => item.includes('does not prove general superiority')));
});
