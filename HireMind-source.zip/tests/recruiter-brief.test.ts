import assert from 'node:assert/strict';
import test from 'node:test';
import { buildRecruiterBrief } from '../lib/recruiter-brief.ts';

test('interview brief prioritizes unresolved essentials and preserves actual source quotes', () => {
  const brief = buildRecruiterBrief('Analyst', 'Example', [
    {
      label: 'Excel',
      requirementClass: 'preferred',
      weight: 30,
      score: 90,
      evidence: [],
    },
    {
      label: 'SQL',
      requirementClass: 'essential',
      weight: 70,
      score: 20,
      evidence: [
        {
          source: {
            quote: 'Built a reporting query.',
            sourceLocation: 'Project: Reporting',
          },
        },
      ],
    },
  ]);
  assert.ok(brief.indexOf('1. SQL') < brief.indexOf('2. Excel'));
  assert.ok(
    brief.includes(
      'Submitted evidence [Project: Reporting]: "Built a reporting query."',
    ),
  );
  assert.ok(brief.includes('not proof of inability'));
  assert.ok(brief.includes('Reviewer notes:'));
  assert.ok(brief.includes('not independently verified'));
});

test('empty evidence does not fabricate candidate achievements', () => {
  const brief = buildRecruiterBrief('Analyst', 'Example', [
    {
      label: 'SQL',
      requirementClass: 'essential',
      weight: 100,
      score: 0,
      evidence: [],
    },
  ]);
  assert.ok(!brief.includes('Submitted evidence ['));
  assert.ok(brief.includes('What was the problem'));
});
