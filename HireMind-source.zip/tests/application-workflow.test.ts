import assert from 'node:assert/strict';
import test from 'node:test';

import {
  applicationStage,
  canTransitionApplication,
  isApplicationStatus,
} from '../lib/application-workflow.ts';

test('application workflow allows forward hiring decisions and blocks terminal rewrites', () => {
  assert.equal(canTransitionApplication('submitted', 'shortlisted'), true);
  assert.equal(canTransitionApplication('shortlisted', 'offer'), true);
  assert.equal(canTransitionApplication('offer', 'hired'), true);
  assert.equal(canTransitionApplication('hired', 'rejected'), false);
  assert.equal(canTransitionApplication('withdrawn', 'in_review'), false);
});

test('application statuses map to candidate-facing pipeline stages', () => {
  assert.equal(isApplicationStatus('offer'), true);
  assert.equal(isApplicationStatus('unknown'), false);
  assert.equal(applicationStage('shortlisted'), 'shortlist');
  assert.equal(applicationStage('offer'), 'decision');
});
