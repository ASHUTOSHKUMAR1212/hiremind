import assert from 'node:assert/strict';
import test from 'node:test';
import { assessCandidateEvidence } from '../lib/evidence-screening.ts';
import { buildRecruiterBrief } from '../lib/recruiter-brief.ts';
import { draftJobCriteria } from '../lib/job-criteria.ts';

const assess = (label: string, description: string, extra: Record<string, unknown> = {}) =>
  assessCandidateEvidence({ experiences: [{ description, startedOn: '2020-01', endedOn: '2024-12' }], ...extra }, [{
    id: 'requirement', label, weight: 100, requirementClass: 'essential', evidenceDefinition: null, equivalentSignalsJson: '[]',
  }]);

const examples = [
  ['Build data pipelines', 'Ingested customer events into a warehouse and normalized records for nightly reporting.'],
  ['Production incident response', 'Investigated outages, identified the failing dependency, and restored service for customers.'],
  ['A/B testing', 'Randomized users into control and treatment cohorts to measure checkout conversion.'],
  ['Business requirements gathering', 'Interviewed business users and mapped workflows into acceptance criteria for the delivery team.'],
  ['Process automation', 'Replaced manual spreadsheet handoffs with scheduled scripts for monthly reconciliation.'],
  ['Mentor developers', 'Coached junior developers through pairing sessions and code reviews with specific feedback.'],
];

for (const [label, description] of examples) {
  test(`responsibility evidence: ${label}`, () => {
    const result = assess(label, description).criterionResults[0];
    assert.ok(result.score >= 55, `${result.score}: ${result.explanation}`);
    assert.equal(result.review.status, 'supported');
    assert.ok(result.review.responsibilities.every((task) => task.supported));
    assert.equal(result.evidence[0].source.quote, description);
    assert.match(result.review.question, /\?/);
    assert.equal(result.requiresHumanReview, true);
  });
  test(`non-personal and future responsibility work does not qualify: ${label}`, () => {
    for (const prefix of ['I would have ', 'Observed colleagues who ', 'The team ', 'I plan to have ']) {
      const result = assess(label, prefix + description.toLowerCase()).criterionResults[0];
      assert.ok(result.score <= 44, `${prefix}: ${result.score}`);
      assert.ok(result.review.responsibilities.every((task) => !task.supported));
    }
  });
}

test('exact keywords without the required work do not override responsibility coverage', () => {
  const result = assess('Data pipelines', 'Built slides about data pipelines for a monthly sales pitch.').criterionResults[0];
  assert.ok(result.score <= 44);
  assert.equal(result.review.responsibilities[0].supported, false);
});

test('a responsibility does not waive named tools, seniority, scale or domain', () => {
  for (const label of ['Python data pipelines', 'Lead data pipelines', 'Healthcare data pipelines', 'Rust data pipelines', 'Data pipelines handling 1 billion events']) {
    assert.ok(assess(label, examples[0][1]).fitScore <= 44, label);
  }
  const wrongTool = assess('Python data pipelines', 'Built Python services for login. Ingested records using SQL into a warehouse.');
  assert.ok(wrongTool.fitScore <= 44);
  const correctTool = assess('Python data pipelines', 'Ingested customer records using Python into a warehouse.');
  assert.ok(correctTool.fitScore >= 55);
});

test('skill tags and job titles cannot become responsibility proof', () => {
  const result = assess('Data pipelines', '', { metadata: { skills: ['Data pipelines'] }, experiences: [{ title: 'Built data pipelines' }] });
  assert.ok(result.fitScore <= 44);
  assert.equal(result.criterionResults[0].review.responsibilities[0].supported, false);
});

test('a stated gap differs from missing evidence; neither causes automatic rejection', () => {
  const missing = assess('SQL', 'Handled customer invoices.').criterionResults[0];
  const denied = assess('SQL', 'No experience with SQL.').criterionResults[0];
  assert.equal(missing.review.status, 'not_found');
  assert.equal(missing.review.statedGaps.length, 0);
  assert.equal(denied.review.status, 'stated_gap');
  assert.equal(denied.review.statedGaps[0].quote, 'No experience with SQL');
  assert.equal(assess('SQL', 'No experience with SQL.').decisionBand, 'needs_review');
});

test('conflicting positive work and a stated gap require clarification before strong match', () => {
  const result = assess('SQL', 'Built SQL queries for monthly payments.', { summary: 'I have never used SQL.' });
  assert.equal(result.criterionResults[0].review.status, 'conflicting');
  assert.ok(result.fitScore <= 44);
  assert.equal(result.decisionBand, 'needs_review');
  assert.match(result.criterionResults[0].review.question, /differ/);
  assert.ok(result.criterionResults[0].evidence.length > 0);
});

test('unrelated, historical, third-party and optional-skill statements do not create a gap', () => {
  for (const description of ['No experience with Python.', 'Our team has no experience with SQL.', 'No experience with SQL before 2020.', 'No experience with SQL is required.'])
    assert.equal(assess('SQL', description).criterionResults[0].review.statedGaps.length, 0, description);
  assert.equal(assess('SQL or Python', 'No experience with SQL. Built Python scripts for monthly invoicing.').criterionResults[0].review.statedGaps.length, 0);
});

test('claims stay claims and a saved JSON result retains review details and tailored brief', () => {
  const claim = assess('SQL', '', { metadata: { skills: ['SQL'] } }).criterionResults[0];
  assert.equal(claim.review.status, 'claim_only');
  const result = assess('SQL', 'No experience with SQL.');
  const persisted = JSON.parse(JSON.stringify(result));
  const brief = buildRecruiterBrief('Analyst', 'Synthetic Example', persisted.criterionResults);
  assert.match(brief, /Candidate-stated gap.*No experience with SQL/);
  assert.match(brief, /Is that still current/);
  assert.ok(!brief.includes('not proof of inability') || brief.includes('Candidate-stated gap'));
});

test('job drafting keeps a responsibility and its named tool bound together', () => {
  const draft = draftJobCriteria('Engineer', 'Requirements:\nBuild data pipelines using Python.\nPreferred:\nA/B testing.');
  assert.deepEqual(draft.criteria.map((item) => [item.label, item.requirementClass]), [
    ['Build data pipelines using Python.', 'essential'], ['A/B testing.', 'preferred'],
  ]);
  assert.equal(draft.criteria.reduce((sum, item) => sum + item.weight, 0), 100);
  assert.ok(draft.criteria.every((item) => item.sourceHint.includes(item.label)));
  assert.ok(draftJobCriteria('Engineer', 'Build healthcare data pipelines.').reviewItems.some((item) => /additional scope/.test(item.reason)));
  assert.equal(draftJobCriteria('Engineer', 'A/B testing is not required.').criteria.length, 0);
});

test('personal administrative involvement does not borrow a team technical achievement', () => {
  assert.ok(assess('Production incident response', 'The team investigated outages while I wrote meeting notes.').fitScore <= 44);
  assert.ok(assess('Production incident response', 'Investigated outages with my team and restored service for customers.').fitScore >= 55);
});

test('positive evidence for a different AND skill is not a contradiction', () => {
  const result = assess('SQL and Python', 'Built SQL queries for monthly payments.', { summary: 'No experience with Python.' }).criterionResults[0];
  assert.equal(result.review.status, 'stated_gap');
  assert.deepEqual(result.review.statedGaps[0].deniedSkills, ['python']);
});
