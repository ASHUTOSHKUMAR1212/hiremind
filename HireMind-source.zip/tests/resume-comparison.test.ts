import assert from 'node:assert/strict';
import test from 'node:test';

import { assessCandidateEvidence, type ScreeningCriterion } from '../lib/evidence-screening.ts';
import { buildResumeScreeningProfile, rankResumeComparisons, resumeCandidateName } from '../lib/resume-comparison.ts';
import { parseResumeProfile } from '../lib/resume-text.ts';

const criteria: ScreeningCriterion[] = [{
  id: 'criterion_sql', label: 'SQL data analysis', weight: 100, requirementClass: 'essential',
  evidenceDefinition: 'Uses SQL to analyze datasets and communicate findings.',
  equivalentSignalsJson: '["analytics projects","querying data"]',
}];

test('multiple résumé profiles are ranked by job evidence rather than upload order', () => {
  const analyst = parseResumeProfile(`Asha Rao\nData Analyst\nSUMMARY\nData analyst focused on customer insights.\nSKILLS\nSQL, Data analysis, Excel\nPROJECTS\nCustomer retention analysis\nUsed SQL to query customer datasets and communicated findings to a product team.`);
  const designer = parseResumeProfile(`Mina Shah\nVisual Designer\nSUMMARY\nDesigner focused on brand systems.\nSKILLS\nFigma, illustration\nPROJECTS\nBrand refresh\nCreated a visual identity and illustration library.`);
  const analystResult = assessCandidateEvidence(buildResumeScreeningProfile(analyst, 'asha.pdf'), criteria);
  const designerResult = assessCandidateEvidence(buildResumeScreeningProfile(designer, 'mina.pdf'), criteria);
  const ranked = rankResumeComparisons([
    { candidateName: 'Mina Shah', fitScore: designerResult.fitScore, uncertainty: designerResult.uncertainty },
    { candidateName: 'Asha Rao', fitScore: analystResult.fitScore, uncertainty: analystResult.uncertainty },
  ]);
  assert.equal(ranked[0].candidateName, 'Asha Rao');
  assert.ok(analystResult.fitScore > designerResult.fitScore);
});

test('comparison names fall back to a cleaned filename when parsing cannot identify a name', () => {
  assert.equal(resumeCandidateName('', 'Example_Updated_CV.pdf'), 'Example');
});
