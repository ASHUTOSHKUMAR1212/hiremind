import test from 'node:test';
import assert from 'node:assert/strict';
import {
  summarizeHiring,
  parseAnalyticsFilters,
  DAY_MS,
  type AnalyticsApplication,
  type AnalyticsEvent,
} from '../lib/hiring-analytics.ts';
const now = Date.UTC(2026, 8, 10);
const app = (
  id: string,
  status = 'submitted',
  daysAgo = 30,
): AnalyticsApplication => ({
  id,
  jobId: 'job',
  jobTitle: 'Analyst',
  status,
  submittedAt: now - daysAgo * DAY_MS,
});
const event = (
  id: string,
  fromStatus: string,
  toStatus: string,
  daysAgo: number,
): AnalyticsEvent => ({
  applicationId: id,
  fromStatus,
  toStatus,
  occurredAt: now - daysAgo * DAY_MS,
});

test('Empty cohorts use null medians and percentages, not invented success rates', () => {
  const r = summarizeHiring([], [], now, 7);
  assert.equal(r.total, 0);
  assert.equal(r.medianDaysToHire, null);
  assert.equal(r.offerToHirePercent, null);
  assert.ok(r.stages.every((row) => row.cohortPercent === null));
});
test('Skipped stages are not inferred; repeats count only once', () => {
  const r = summarizeHiring(
    [app('a', 'interview')],
    [
      event('a', 'submitted', 'interview', 20),
      event('a', 'interview', 'interview', 10),
    ],
    now,
    7,
  );
  assert.equal(r.stages.find((s) => s.key === 'interview')?.reached, 1);
  assert.equal(r.stages.find((s) => s.key === 'in_review')?.reached, 0);
  assert.equal(r.attention[0].ageDays, 20);
});
test('Returning to review resets the current-stage clock', () => {
  const r = summarizeHiring(
    [app('a', 'in_review')],
    [
      event('a', 'submitted', 'in_review', 25),
      event('a', 'in_review', 'interview', 15),
      event('a', 'interview', 'in_review', 2),
    ],
    now,
    7,
  );
  assert.equal(r.attentionCount, 0);
  assert.equal(r.medianDaysToFirstReview, 5);
  assert.equal(
    r.stages.find((s) => s.key === 'in_review')?.medianCurrentAgeDays,
    2,
  );
});
test('Missing or contradictory stage history is unknown rather than guessed', () => {
  const r = summarizeHiring(
    [app('a', 'in_review'), app('b', 'interview')],
    [event('b', 'submitted', 'shortlisted', 10)],
    now,
    7,
  );
  assert.equal(r.unknownAge, 2);
  assert.equal(r.attentionCount, 0);
});
test('Terminal outcomes never appear in the aging queue', () => {
  const r = summarizeHiring(
    [app('a', 'rejected'), app('b', 'withdrawn'), app('c', 'hired')],
    [],
    now,
    7,
  );
  assert.equal(r.active, 0);
  assert.equal(r.attentionCount, 0);
  assert.equal(r.hireSample, 0);
});
test('Future and pre-application events cannot contaminate metrics', () => {
  const r = summarizeHiring(
    [app('a', 'in_review')],
    [
      event('a', 'submitted', 'in_review', 40),
      event('a', 'submitted', 'in_review', -1),
    ],
    now,
    7,
  );
  assert.equal(r.firstReviewSample, 0);
  assert.equal(r.unknownAge, 1);
});
test('Offer conversion includes pending offers and uses observed offers only', () => {
  const r = summarizeHiring(
    [app('a', 'hired'), app('b', 'offer'), app('c', 'hired')],
    [event('a', 'offer', 'hired', 10)],
    now,
    7,
  );
  assert.equal(r.offerToHirePercent, 50);
  assert.equal(r.offersObserved, 2);
  assert.equal(r.hireSample, 1);
  assert.equal(r.medianDaysToHire, 20);
});
test('Even medians are correct and age threshold is inclusive', () => {
  const r = summarizeHiring(
    [app('a', 'in_review'), app('b', 'in_review')],
    [
      event('a', 'submitted', 'in_review', 7),
      event('b', 'submitted', 'in_review', 3),
    ],
    now,
    7,
  );
  assert.equal(r.medianDaysToFirstReview, 25);
  assert.equal(r.attentionCount, 1);
  assert.equal(r.attention[0].id, 'a');
});
test('Filters accept bounded windows and reject malformed input', () => {
  assert.equal(parseAnalyticsFilters(new URLSearchParams(), now).days, 90);
  assert.equal(
    parseAnalyticsFilters(
      new URLSearchParams('days=30&ageDays=3&format=csv'),
      now,
    ).since,
    now - 30 * DAY_MS,
  );
  for (const input of [
    'days=0',
    'days=all',
    'days=90.0',
    'ageDays=-1',
    'format=html',
  ])
    assert.throws(() => parseAnalyticsFilters(new URLSearchParams(input), now));
});
