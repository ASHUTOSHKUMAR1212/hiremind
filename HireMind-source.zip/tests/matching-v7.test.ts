import assert from 'node:assert/strict';
import test from 'node:test';
import { assessCandidateEvidence } from '../lib/evidence-screening.ts';
import { parseResumeProfile } from '../lib/resume-text.ts';
import { normalizeSkillPhrases } from '../lib/skills-context.ts';

const assess = (skill: string, description: string) =>
  assessCandidateEvidence({ experiences: [{ description, startedOn: '2020-01', endedOn: '2024-12' }] }, [{
    id: 'skill', label: `2 years ${skill}`, weight: 100,
    requirementClass: 'essential', evidenceDefinition: null, equivalentSignalsJson: '[]',
  }]);

for (const [skill, alias] of [['React', 'React.js'], ['Vue', 'Vue.js'], ['Node.js', 'nodejs']]) {
  test(`${skill}: dotted and plain aliases preserve score, evidence and tenure`, () => {
    const canonical = assess(skill, `Built ${skill} customer interfaces.`);
    const alternate = assess(skill, `Built ${alias} customer interfaces.`);
    assert.equal(alternate.fitScore, canonical.fitScore);
    assert.ok(alternate.fitScore >= 80);
    assert.equal(alternate.criterionResults[0].tenure?.supportedMonths, 59);
    assert.equal(alternate.criterionResults[0].evidence[0].evidenceLevel, 'demonstrated');
  });
}

test('skill normalization is atomic and idempotent', () => {
  const normalized = normalizeSkillPhrases('React.js Vue.js Node.js JS React Native AWS CI/CD pipelines');
  assert.equal(normalized, 'react vue nodejs javascript react_native amazon_web_services continuous_integration/continuous_delivery pipelines');
  assert.equal(normalizeSkillPhrases(normalized), normalized);
});

for (const [skill, text] of [
  ['React', 'Built React Native customer interfaces.'],
  ['AWS', 'Built Azure customer service applications.'],
  ['AWS', 'Built Docker customer service routing pipelines, not AWS services, for monthly reporting.'],
]) {
  test(`${skill}: unrelated work cannot supply a citation or tenure: ${text}`, () => {
    const result = assess(skill, text).criterionResults[0];
    assert.equal(result.score, 0);
    assert.equal(result.tenure?.supportedMonths, 0);
    assert.ok(result.evidence.every((item) => item.evidenceLevel !== 'demonstrated'));
  });
}

test('resume import does not manufacture React or JavaScript from longer skill names', () => {
  const parsed = (description: string) => parseResumeProfile(`Asha Rao\nWORK HISTORY\nDeveloper | Fictional Studio | Jan 2020 - Dec 2024\n${description}`).skills;
  const native = parsed('Built React Native customer interfaces.');
  assert.ok(native.includes('React Native'));
  assert.ok(!native.includes('React'));
  const web = parsed('Built React.js and Next.js customer interfaces.');
  assert.ok(web.includes('React'));
  assert.ok(web.includes('Next.js'));
  assert.ok(!web.includes('JavaScript'));
  assert.ok(parsed('Built SQL queries and Python scripts.').includes('SQL'));
});

for (const [verb, base, skill, object] of [
  ['Authored', 'author', 'SQL', 'reconciliation queries'],
  ['Engineered', 'engineer', 'Python', 'validation services'],
  ['Sustained', 'sustain', 'React', 'customer interfaces'],
]) {
  test(`${verb}: concrete personal work counts, hypothetical and others' work does not`, () => {
    assert.ok(assess(skill, `${verb} ${skill} ${object}.`).fitScore >= 80);
    for (const text of [
      `I would ${base} ${skill} ${object}.`,
      `I could have ${verb.toLowerCase()} ${skill} ${object}.`,
      `The team ${verb.toLowerCase()} ${skill} ${object}.`,
      `Observed colleagues who ${verb.toLowerCase()} ${skill} ${object}.`,
      `${skill} ${object} were ${verb.toLowerCase()} by the team.`,
    ]) {
      const result = assess(skill, text);
      assert.ok(result.fitScore <= 44, text);
      assert.equal(result.criterionResults[0].tenure?.supportedMonths, 0, text);
    }
  });
}
