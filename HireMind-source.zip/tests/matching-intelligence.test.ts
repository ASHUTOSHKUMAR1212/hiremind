import assert from 'node:assert/strict';
import test from 'node:test';
import {
  assessCandidateEvidence,
  type ScreeningCriterion,
} from '../lib/evidence-screening.ts';
import {
  namedSkillSpans,
  requiredSkillGroups,
} from '../lib/matching-signals.ts';

const requirement: ScreeningCriterion = {
  id: 'data',
  label: 'SQL and Python',
  weight: 100,
  requirementClass: 'essential',
  evidenceDefinition: 'Build data pipelines with SQL and Python',
  equivalentSignalsJson: '[]',
};
const score = (description: string, criterion = requirement) =>
  assessCandidateEvidence(
    { experiences: [{ title: 'Analyst', description }] },
    [criterion],
  );

test('keyword stuffing in work history is not demonstrated work', () => {
  const claims = score('SQL and Python');
  const work = score('Built SQL and Python pipelines to reconcile orders.');
  assert.ok(claims.fitScore <= 44);
  assert.ok(work.fitScore >= 75);
  assert.equal(claims.decisionBand, 'needs_review');
  assert.equal(claims.criterionResults[0].evidence[0].evidenceLevel, 'claimed');
});
test('intent to learn is not existing proficiency', () => {
  assert.equal(
    score('Planning to learn SQL and Python next year.').fitScore,
    0,
  );
});
test('adding an action word to a tool list does not fabricate work context', () => {
  assert.ok(score('Used SQL and Python and Java extensively.').fitScore <= 44);
});
test('all explicit AND skills need performed-work support', () => {
  const result = score('Built SQL data pipelines to reconcile orders.');
  assert.ok(result.fitScore <= 44);
  assert.equal(result.decisionBand, 'needs_review');
  assert.deepEqual(result.criterionResults[0].skillCoverage, [
    { requirement: 'sql', status: 'demonstrated' },
    { requirement: 'python', status: 'not_found' },
  ]);
  assert.match(result.criterionResults[0].explanation, /python.*not found/);
});
test('explicit OR alternatives do not require both tools', () => {
  const result = score(
    'Built Python pipelines to reconcile monthly payment records.',
    { ...requirement, label: 'SQL or Python', evidenceDefinition: null },
  );
  assert.ok(result.fitScore >= 55);
  assert.equal(
    result.criterionResults[0].skillCoverage[0].status,
    'demonstrated',
  );
  assert.deepEqual(requiredSkillGroups('SQL and Python or Java'), [
    ['sql'],
    ['python', 'java'],
  ]);
});
test('an unrelated action cannot validate a trailing keyword sentence', () => {
  assert.ok(
    score('Built dashboards to track monthly customer churn. SQL and Python.')
      .fitScore <= 44,
  );
});
test('a separately claimed skill cannot borrow proof from another skill', () => {
  const result = score(
    'Built SQL pipelines to reconcile payment records. Python.',
  );
  assert.ok(result.fitScore <= 44);
  assert.equal(result.criterionResults[0].skillCoverage[1].status, 'claimed');
  assert.deepEqual(result.criterionResults[0].evidence[0].demonstratedSkills, [
    'sql',
  ]);
  assert.equal(
    result.criterionResults[0].evidence[0].source.quote,
    'Built SQL pipelines to reconcile payment records. Python.',
  );
});
test('independent sentences describing both skills are supported', () => {
  const result = score(
    'Built SQL pipelines to reconcile payment records. Used Python scripts to remove duplicate records.',
  );
  assert.ok(result.fitScore >= 55);
  assert.ok(
    result.criterionResults[0].skillCoverage.every(
      (item) => item.status === 'demonstrated',
    ),
  );
});
test('project title and skill tags cannot supply hidden proof', () => {
  const result = assessCandidateEvidence(
    {
      projects: [
        {
          title: 'SQL and Python',
          skills: ['SQL', 'Python'],
          description: 'Built a dashboard to track customer orders.',
        },
      ],
    },
    [requirement],
  );
  assert.ok(result.fitScore <= 44);
  assert.ok(
    result.criterionResults[0].evidence.every(
      (item) => item.evidenceLevel === 'claimed',
    ),
  );
});
test('punctuation after a named skill does not lose the match', () => {
  assert.ok(
    score('Reconciled monthly payment records using SQL.', {
      ...requirement,
      label: 'SQL',
      evidenceDefinition: null,
    }).fitScore >= 75,
  );
});
test('related frameworks are not silently interchangeable', () => {
  assert.deepEqual(
    namedSkillSpans('React Native').map((item) => item.skill),
    ['react native'],
  );
  assert.deepEqual(
    namedSkillSpans('AngularJS').map((item) => item.skill),
    ['angularjs'],
  );
  assert.ok(
    score('Built React Native applications to serve mobile customers.', {
      ...requirement,
      label: 'React',
      evidenceDefinition: null,
    }).fitScore <= 44,
  );
});
test('machine learning and coursework projects can describe real performed work', () => {
  const result = score(
    'Built machine learning classifiers to identify duplicate customer records.',
    { ...requirement, label: 'Machine learning', evidenceDefinition: null },
  );
  assert.ok(result.fitScore >= 75);
  assert.ok(
    score(
      'Built SQL and Python pipelines to reconcile orders in a coursework project.',
    ).fitScore >= 75,
  );
});
test('full employer-approved equivalents support reviewable matches', () => {
  const result = score(
    'Built relational database queries to reconcile monthly payment records.',
    {
      ...requirement,
      label: 'SQL',
      evidenceDefinition: null,
      equivalentSignalsJson: '["relational database queries"]',
    },
  );
  assert.ok(result.fitScore >= 55);
  assert.match(
    result.criterionResults[0].explanation,
    /employer-approved equivalent/,
  );
  assert.equal(result.criterionResults[0].requiresHumanReview, true);
});
test('duplicate descriptions cannot boost matching intelligence', () => {
  const entry = {
    description: 'Built SQL and Python pipelines to reconcile orders.',
  };
  assert.equal(
    assessCandidateEvidence({ experiences: [entry, entry] }, [requirement])
      .fitScore,
    score(entry.description).fitScore,
  );
});
