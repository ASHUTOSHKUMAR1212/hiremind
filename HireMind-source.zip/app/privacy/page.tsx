import { LegalPage, LegalSection } from '../legal-page';

export default function PrivacyPage() {
  return (
    <LegalPage
      eyebrow="Privacy"
      title="How HireMind handles your data"
      updated="10 September 2026"
    >
      <LegalSection title="What we collect">
        <p>
          HireMind stores the identity information needed for sign-in, candidate
          profile information you provide, employer workspace records, job
          criteria, applications, interview records, and files you choose to
          upload.
        </p>
      </LegalSection>
      <LegalSection title="Why we use it">
        <p>
          We use this information to operate role-specific workspaces, preserve
          application snapshots, organize candidate-provided evidence, support
          hiring-team review, schedule interviews, and keep an auditable history
          of decisions.
        </p>
      </LegalSection>
      <LegalSection title="Candidate and employer boundaries">
        <p>
          Candidate profiles are private by default. An employer receives a
          dated snapshot only when the candidate applies to that employer’s
          role. Employer pipeline data is limited to authorized members of that
          organization.
        </p>
      </LegalSection>
      <LegalSection title="Optional consideration for future roles">
        <p>
          Future-role searches are off by default. If you enable this option and
          save your profile, employers you have already applied to may reconsider
          your submitted application snapshot for another role. Searches include
          applications from the past 12 months, exclude withdrawn applications,
          and do not create applications or contact you automatically. Turning
          the option off and saving removes you from subsequent future-role
          searches; it does not delete existing applications or records already
          received by an employer.
        </p>
      </LegalSection>
      <LegalSection title="Automated assistance and human decisions">
        <p>
          HireMind can structure résumé text, compare evidence with
          employer-defined criteria, and suggest follow-up questions. It does
          not make the final hiring decision, infer personality or emotion, or
          treat missing evidence as proof that a candidate lacks a capability.
        </p>
      </LegalSection>
      <LegalSection title="Files, calls, and retention">
        <p>
          Résumé files are stored privately and served only after an ownership
          check. Live interviews use encrypted browser media and are not
          recorded by HireMind. Employers and candidates should retain records
          only as long as required for the hiring purpose and applicable law.
        </p>
      </LegalSection>
      <LegalSection title="Interview transcripts and reviewer scorecards">
        <p>Authorized employers can import timestamped transcripts after recording participant-consent confirmation. HireMind does not automatically record or transcribe calls. Imported text, source filenames, consent records, and source-linked reviews are stored for hiring review. Private drafts are visible to their author; submitted reviews are visible to authorized hiring-team members. Saved reviews preserve the transcript text used for that review even if a newer transcript is imported.</p>
      </LegalSection>
      <LegalSection title="Recruiter contacts and external tools">
        <p>Employers can keep team-only relationship notes, tags, suppression choices, outreach drafts, and follow-up tasks. The current workflow opens approved drafts in the employer’s email app; it does not automatically send email or verify delivery. Company administrators can authorize read-only integration keys, including optional access to candidate names and email addresses. Exported copies are controlled by the receiving employer or system. Keys can be revoked and expire after 90 days.</p>
      </LegalSection>
      <LegalSection title="Matching evaluation datasets">
        <p>Employers can upload authorized résumé/job evaluation datasets with human labels. Datasets and reports remain within the employer workspace and can be deleted there. Use de-identified data where possible. Uploaders declare labeling provenance and held-out status; HireMind does not independently verify these declarations or use these datasets to train a shared model.</p>
      </LegalSection>
      <LegalSection title="Your choices">
        <p>
          You can edit your candidate profile, replace your résumé, withdraw an
          active application, decline optional interview context signals, and
          sign out at any time. For deletion or correction requests that cannot
          be completed in the workspace, contact the operator who provided this
          HireMind deployment.
        </p>
      </LegalSection>
    </LegalPage>
  );
}
