'use client';

import { useEffect, useState } from 'react';
import { StableLink as Link } from '@/components/stable-link';
import {
  ArrowRight,
  BadgeCheck,
  Brain,
  BriefcaseBusiness,
  Building2,
  GraduationCap,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';

import { Badge } from '@/components/ui/badge';
import {
  authenticatedFetch,
  getSupabaseBrowserClient,
} from '@/lib/supabase/client';

export default function PublicHome() {
  const [user, setUser] = useState<{ email: string } | null>(null);
  const [account, setAccount] = useState<{
    candidate: unknown;
    organization: unknown;
  } | null>(null);
  useEffect(() => {
    async function loadSession() {
      const { data } = await getSupabaseBrowserClient().auth.getSession();
      if (!data.session?.user.email) return;
      setUser({ email: data.session.user.email });
      const response = await authenticatedFetch('/api/me');
      if (response.ok) setAccount(await response.json());
    }
    void loadSession();
  }, []);
  const primaryWorkspace = account?.organization
    ? '/company'
    : account?.candidate
      ? '/candidate'
      : '/onboarding';
  const candidateWorkspace = account?.candidate
    ? '/candidate'
    : '/onboarding?role=candidate';
  const employerWorkspace = account?.organization
    ? '/company'
    : '/onboarding?role=company';

  return (
    <main className="public-home min-h-screen">
      <header className="public-nav">
        <Link href="/" className="candidate-brand" aria-label="HireMind home">
          <span className="candidate-brand-mark" aria-hidden="true">
            h
          </span>
          <span>hiremind</span>
        </Link>
        <nav className="hidden items-center gap-7 text-sm text-muted-foreground md:flex">
          <Link href="#why">Why HireMind</Link>
          <Link href="#how">How it works</Link>
          <Link href="#trust">Trust</Link>
        </nav>
        {user ? (
          <div className="flex items-center gap-3">
            <span className="hidden text-xs text-muted-foreground sm:block">
              {user.email}
            </span>
            <Link href="/logout" className="public-text-button">
              Sign out
            </Link>
            <Link href={primaryWorkspace} className="public-primary-button">
              Open workspace <ArrowRight />
            </Link>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <Link href="/login" className="public-text-button">
              Sign in
            </Link>
            <Link href="/login" className="public-primary-button">
              Create account <ArrowRight />
            </Link>
          </div>
        )}
      </header>

      <section className="public-hero">
        <div className="public-hero-copy">
          <Badge className="border-0 bg-[#eee6f0] text-[#59445d] hover:bg-[#eee6f0]">
            <Sparkles data-icon="inline-start" /> Evidence over keywords
          </Badge>
          <h1>Hire people for what they can actually do.</h1>
          <p>
            HireMind connects explainable résumé shortlisting, candidate
            profiles and structured interviews in one calm hiring workspace.
          </p>
          <div className="mt-7 flex flex-wrap gap-3">
            {user ? (
              <>
                <Link
                  href={employerWorkspace}
                  className="public-primary-button public-hero-button"
                >
                  <Building2 /> Employer workspace
                </Link>
                <Link
                  href={candidateWorkspace}
                  className="public-secondary-button public-hero-button"
                >
                  <GraduationCap /> Candidate workspace
                </Link>
              </>
            ) : (
              <>
                <Link
                  href="/login?role=company"
                  className="public-primary-button public-hero-button"
                >
                  <Building2 /> Create company account
                </Link>
                <Link
                  href="/login?role=candidate"
                  className="public-secondary-button public-hero-button"
                >
                  <GraduationCap /> Create candidate account
                </Link>
              </>
            )}
          </div>
          <p className="public-auth-note">
            <ShieldCheck /> Secure email verification. HireMind never stores
            your password.
          </p>
        </div>

        <div
          className="public-product-card"
          aria-label="HireMind matching preview"
        >
          <div className="public-card-head">
            <div>
              <span>Senior product designer</span>
              <small>Evidence shortlist · updated now</small>
            </div>
            <BadgeCheck />
          </div>
          {[
            ['01', 'Systems thinking', '94'],
            ['02', 'Research depth', '91'],
            ['03', 'Hidden fit rescued', '89'],
          ].map(([rank, label, score]) => (
            <div className="public-candidate-line" key={rank}>
              <span>{rank}</span>
              <i aria-hidden="true" />
              <strong>{label}</strong>
              <b>{score}</b>
            </div>
          ))}
          <div className="public-proof-note">
            <Brain /> Every rank includes evidence, uncertainty and missing
            information.
          </div>
        </div>
      </section>

      <section id="why" className="public-proof-grid">
        {[
          [
            BriefcaseBusiness,
            'Company workspace',
            'Create jobs, calibrate criteria and review explainable shortlists.',
          ],
          [
            GraduationCap,
            'Candidate account',
            'Apply with work history—or projects and learning when you are a fresher.',
          ],
          [
            ShieldCheck,
            'Human decisions',
            'AI organizes evidence. Hiring teams remain responsible for every decision.',
          ],
        ].map(([Icon, title, body]) => {
          const CardIcon = Icon as typeof Brain;
          return (
            <article key={title as string}>
              <CardIcon />
              <h2>{title as string}</h2>
              <p>{body as string}</p>
            </article>
          );
        })}
      </section>

      <section id="how" className="public-explainer">
        <div className="public-section-heading">
          <span>From role brief to decision</span>
          <h2>A hiring system your team can explain.</h2>
          <p>
            HireMind keeps criteria, candidate evidence, interviews, and human
            decisions connected instead of hiding them behind one unexplained
            score.
          </p>
        </div>
        <ol>
          <li>
            <b>01</b>
            <div>
              <strong>Define evidence before reviewing people</strong>
              <p>
                Turn the job description into editable, weighted criteria and
                accept equivalent proof from work, projects, coursework, and
                internships.
              </p>
            </div>
          </li>
          <li>
            <b>02</b>
            <div>
              <strong>Review fit with citations and uncertainty</strong>
              <p>
                Every recommendation links back to candidate-provided evidence,
                identifies missing information, and remains a human decision.
              </p>
            </div>
          </li>
          <li>
            <b>03</b>
            <div>
              <strong>Interview the gaps that matter</strong>
              <p>
                Structured questions adapt once when an answer needs
                clarification, then present the transcript and rubric to the
                hiring team.
              </p>
            </div>
          </li>
        </ol>
      </section>

      <section id="trust" className="public-trust-panel">
        <div>
          <ShieldCheck />
          <span>
            <strong>Built for accountable hiring</strong>
            <small>
              Security and candidate dignity are product requirements.
            </small>
          </span>
        </div>
        <ul>
          <li>Role-based employer access enforced by the server</li>
          <li>Candidate and employer workspaces remain separate</li>
          <li>No automatic rejection or invented credentials</li>
          <li>Optional session signals never determine interview scores</li>
        </ul>
      </section>
      <footer className="public-footer">
        <span>© 2026 HireMind</span>
        <div>
          <Link href="/privacy">Privacy</Link>
          <Link href="/terms">Terms</Link>
        </div>
      </footer>
    </main>
  );
}
