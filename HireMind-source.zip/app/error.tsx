'use client';

import { StableLink as Link } from '@/components/stable-link';
import { RefreshCw, TriangleAlert } from 'lucide-react';

export default function ErrorPage({
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <main className="product-error-page">
      <section>
        <TriangleAlert />
        <span>Something interrupted this view</span>
        <h1>Your saved hiring data has not been discarded.</h1>
        <p>
          Retry this screen. If the service is still unavailable, return to the
          workspace and continue from the last saved state.
        </p>
        <div>
          <button type="button" onClick={reset}>
            <RefreshCw /> Retry
          </button>
          <Link href="/">HireMind home</Link>
        </div>
      </section>
    </main>
  );
}
