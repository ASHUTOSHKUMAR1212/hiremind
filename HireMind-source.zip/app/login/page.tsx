'use client';

import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type SyntheticEvent,
} from 'react';
import { StableLink as Link } from '@/components/stable-link';
import {
  ArrowRight,
  Building2,
  CheckCircle2,
  GraduationCap,
  KeyRound,
  Mail,
  ShieldCheck,
} from 'lucide-react';

import { getSupabaseBrowserClient } from '@/lib/supabase/client';

type Step = 'email' | 'code';
type Role = 'candidate' | 'company';
const OTP_LENGTH = 8;

export default function LoginPage() {
  const [step, setStep] = useState<Step>('email');
  const [selectedRole, setSelectedRole] = useState<Role>('company');
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [status, setStatus] = useState('');
  const [busy, setBusy] = useState(false);
  const [resendIn, setResendIn] = useState(0);
  const [signedIn, setSignedIn] = useState(false);
  const [sessionChecked, setSessionChecked] = useState(false);
  const requestInFlight = useRef(false);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      const params = new URLSearchParams(window.location.search);
      setSelectedRole(
        params.get('role') === 'candidate' ||
          params.get('next')?.startsWith('/candidate')
          ? 'candidate'
          : 'company',
      );
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);
  const destination = useMemo(() => {
    if (typeof window === 'undefined') return '/onboarding';
    const params = new URLSearchParams(window.location.search);
    const next = params.get('next');
    const interviewReturn = next?.startsWith('/interview?') || next === '/interview';
    const nextMatchesRole = interviewReturn || (
      selectedRole === 'company'
        ? next?.startsWith('/company')
        : next?.startsWith('/candidate'));
    if (nextMatchesRole && next?.startsWith('/') && !next.startsWith('//'))
      return next;
    return `/onboarding?role=${selectedRole}`;
  }, [selectedRole]);

  useEffect(() => {
    void getSupabaseBrowserClient()
      .auth.getSession()
      .then(({ data }) => {
        setSignedIn(Boolean(data.session));
        setSessionChecked(true);
      });
  }, []);

  useEffect(() => {
    if (resendIn <= 0) return;
    const timer = window.setInterval(
      () => setResendIn((value) => Math.max(0, value - 1)),
      1000,
    );
    return () => window.clearInterval(timer);
  }, [resendIn]);

  async function sendCode(event: SyntheticEvent<HTMLFormElement>) {
    event.preventDefault();
    await requestCode();
  }

  async function requestCode() {
    if (requestInFlight.current) return;
    const address = email.trim().toLowerCase();
    if (!address) return;

    requestInFlight.current = true;
    setBusy(true);
    setStatus('Sending your secure code…');
    try {
      const { error } = await getSupabaseBrowserClient().auth.signInWithOtp({
        email: address,
        options: { shouldCreateUser: true },
      });
      if (error) {
        setStatus(
          error.message.toLowerCase().includes('rate')
            ? 'Please wait a minute before requesting another code.'
            : 'We could not send the code. Check the email address and try again.',
        );
        return;
      }
      setEmail(address);
      setStep('code');
      setResendIn(60);
      setStatus(`One eight-digit code was sent to ${address}.`);
    } catch {
      setStatus(
        'We could not reach the email service. Check your connection and try again.',
      );
    } finally {
      requestInFlight.current = false;
      setBusy(false);
    }
  }

  async function verifyCode(event: SyntheticEvent<HTMLFormElement>) {
    event.preventDefault();
    if (requestInFlight.current || code.length !== OTP_LENGTH) return;
    requestInFlight.current = true;
    setBusy(true);
    setStatus('Verifying your code…');
    try {
      const { error } = await getSupabaseBrowserClient().auth.verifyOtp({
        email,
        token: code,
        type: 'email',
      });
      if (error) {
        setStatus(
          'That code is incorrect or expired. Check the latest email and try again.',
        );
        return;
      }
      window.location.replace(destination);
    } catch {
      setStatus(
        'We could not verify the code. Check your connection and try again.',
      );
    } finally {
      requestInFlight.current = false;
      setBusy(false);
    }
  }

  return (
    <main className="login-page">
      <section className="login-story" aria-label="HireMind introduction">
        <Link href="/" className="candidate-brand login-brand">
          <span className="candidate-brand-mark" aria-hidden="true">
            h
          </span>
          <span>hiremind</span>
        </Link>
        <div>
          <span className="login-eyebrow">
            {selectedRole === 'company'
              ? 'Evidence over assumptions'
              : 'Your work, clearly represented'}
          </span>
          <h1>
            {selectedRole === 'company'
              ? 'See the potential others miss.'
              : 'Let your work speak for you.'}
          </h1>
          <p>
            {selectedRole === 'company'
              ? 'Find your next candidate. Build your next team.'
              : 'Build one credible profile. Find roles where your evidence fits.'}
          </p>
        </div>
        <div className="login-trust-list">
          <span>
            <ShieldCheck /> HireMind never stores your password
          </span>
          <span>
            <CheckCircle2 /> Candidate and employer data stay separate
          </span>
        </div>
      </section>

      <section className="login-panel">
        <div className="login-card">
          <span className="login-icon">
            <KeyRound />
          </span>
          <p className="login-kicker">
            {signedIn
              ? 'Choose your workspace'
              : step === 'email'
                ? 'Welcome to HireMind'
                : 'Check your inbox'}
          </p>
          <h2>
            {signedIn
              ? 'Where do you want to work?'
              : step === 'email'
                ? 'Sign in or create an account'
                : 'Enter your eight-digit code'}
          </h2>
          <p className="login-subtitle">
            {signedIn
              ? 'Your identity is verified. Candidate and Employer open different products with separate data and actions.'
              : step === 'email'
                ? 'No password to remember. We will verify your email before creating your account.'
                : `Enter the code sent to ${email} for your ${selectedRole === 'company' ? 'Employer' : 'Candidate'} workspace.`}
          </p>

          {!sessionChecked ? (
            <output className="login-status">
              Checking your secure session…
            </output>
          ) : signedIn ? (
            <div className="workspace-gateway">
              <Link
                href="/onboarding?role=candidate"
                className="workspace-gateway-card workspace-gateway-candidate"
              >
                <span>
                  <GraduationCap />
                </span>
                <strong>Candidate workspace</strong>
                <small>
                  Discover jobs, build your evidence profile, apply, and track
                  every application.
                </small>
                <b>
                  Open candidate portal <ArrowRight />
                </b>
              </Link>
              <Link
                href="/onboarding?role=company"
                className="workspace-gateway-card workspace-gateway-employer"
              >
                <span>
                  <Building2 />
                </span>
                <strong>Employer workspace</strong>
                <small>
                  Create roles, receive applicants, shortlist with evidence, and
                  manage interviews.
                </small>
                <b>
                  Open hiring console <ArrowRight />
                </b>
              </Link>
              <Link href="/logout" className="workspace-gateway-signout">
                Use a different email
              </Link>
            </div>
          ) : step === 'email' ? (
            <form onSubmit={sendCode} className="login-form">
              <fieldset className="login-role-choice">
                <legend>Continue as</legend>
                <div>
                  <button
                    type="button"
                    aria-pressed={selectedRole === 'company'}
                    onClick={() => setSelectedRole('company')}
                  >
                    <Building2 /> Employer
                  </button>
                  <button
                    type="button"
                    aria-pressed={selectedRole === 'candidate'}
                    onClick={() => setSelectedRole('candidate')}
                  >
                    <GraduationCap /> Candidate
                  </button>
                </div>
              </fieldset>
              <label>
                <span>Email address</span>
                <div className="login-input-wrap">
                  <Mail />
                  <input
                    type="email"
                    required
                    autoComplete="email"
                    disabled={busy}
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                    placeholder="you@example.com"
                  />
                </div>
              </label>
              <button type="submit" disabled={busy}>
                {busy ? 'Sending…' : 'Continue with email'} <ArrowRight />
              </button>
            </form>
          ) : (
            <form onSubmit={verifyCode} className="login-form">
              <label>
                <span>Verification code</span>
                <input
                  className="login-code-input"
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  aria-label="Eight-digit verification code"
                  minLength={OTP_LENGTH}
                  maxLength={OTP_LENGTH}
                  required
                  value={code}
                  onChange={(event) =>
                    setCode(
                      event.target.value
                        .replace(/\D/g, '')
                        .slice(0, OTP_LENGTH),
                    )
                  }
                  placeholder="00000000"
                />
              </label>
              <button
                type="submit"
                disabled={busy || code.length !== OTP_LENGTH}
              >
                {busy ? 'Verifying…' : 'Verify and continue'} <ArrowRight />
              </button>
              <div className="login-code-actions">
                <button
                  type="button"
                  className="login-link-button"
                  disabled={resendIn > 0 || busy}
                  onClick={requestCode}
                >
                  {resendIn > 0 ? `Resend in ${resendIn}s` : 'Resend code'}
                </button>
                <button
                  type="button"
                  className="login-link-button"
                  onClick={() => {
                    setStep('email');
                    setCode('');
                    setStatus('');
                  }}
                >
                  Change email
                </button>
              </div>
            </form>
          )}

          {status ? <output className="login-status">{status}</output> : null}
          <p className="login-legal">
            By continuing, you agree to HireMind’s{' '}
            <Link href="/terms">Terms</Link> and{' '}
            <Link href="/privacy">Privacy Policy</Link>.
          </p>
        </div>
      </section>
    </main>
  );
}
