import type { Metadata } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import './globals.css';

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
});

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

export const metadata: Metadata = {
  metadataBase: new URL('https://hiremind-evidence-first.sharmaaishu84.chatgpt.site'),
  title: 'HireMind — Evidence-first hiring',
  description:
    'Discover qualified candidates with explainable shortlisting and connected interviews.',
  icons: {
    icon: '/favicon.svg',
    shortcut: '/favicon.svg',
  },
  openGraph: {
    type: 'website',
    url: 'https://hiremind-evidence-first.sharmaaishu84.chatgpt.site',
    siteName: 'HireMind',
    title: 'HireMind — Evidence-first hiring',
    description:
      'Discover qualified candidates with explainable shortlisting and connected interviews.',
    images: [
      {
        url: 'https://hiremind-evidence-first.sharmaaishu84.chatgpt.site/og-nocturne.png',
        width: 1731,
        height: 909,
        alt: 'HireMind — Evidence-first hiring',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'HireMind — Evidence-first hiring',
    description:
      'Discover qualified candidates with explainable shortlisting and connected interviews.',
    images: [
      'https://hiremind-evidence-first.sharmaaishu84.chatgpt.site/og-nocturne.png',
    ],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
