'use client';

import { useState, type SyntheticEvent } from 'react';
import { Building2, GraduationCap, ShieldCheck, Sparkles } from 'lucide-react';

import { authenticatedFetch } from '@/lib/supabase/client';

type Role = 'candidate' | 'company';

export default function OnboardingForm({
  defaultRole,
  defaultName,
}: {
  defaultRole: Role;
  defaultName: string;
}) {
  const [role, setRole] = useState<Role>(defaultRole);
  const [status, setStatus] = useState('');
  const [busy, setBusy] = useState(false);

  async function createAccount(event: SyntheticEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setStatus('Creating your workspace…');
    try {
      const response = await authenticatedFetch('/api/account', {
        method: 'POST',
        body: new FormData(event.currentTarget),
      });
      if (!response.ok) {
        setStatus(
          (await response.text()) || 'We could not create your account.',
        );
        setBusy(false);
        return;
      }
      window.location.replace(response.url);
    } catch {
      setStatus(
        'The account service is temporarily unreachable. Check your connection and try again.',
      );
      setBusy(false);
    }
  }

  return (
    <form onSubmit={createAccount} className="onboarding-form">
      <fieldset>
        <legend>I want to use HireMind as</legend>
        <div className="role-choice-grid">
          <label>
            <input
              type="radio"
              name="role"
              value="candidate"
              checked={role === 'candidate'}
              onChange={() => setRole('candidate')}
            />
            <span>
              <GraduationCap />
              <strong>Candidate</strong>
              <small>
                Find jobs, build your profile and track applications.
              </small>
            </span>
          </label>
          <label>
            <input
              type="radio"
              name="role"
              value="company"
              checked={role === 'company'}
              onChange={() => setRole('company')}
            />
            <span>
              <Building2 />
              <strong>Employer</strong>
              <small>
                Create jobs, shortlist talent and manage interviews.
              </small>
            </span>
          </label>
        </div>
      </fieldset>

      <label className="onboarding-field">
        <span>Your full name</span>
        <input
          name="fullName"
          required
          minLength={2}
          maxLength={100}
          defaultValue={defaultName}
          placeholder="e.g. Anika Rao"
        />
      </label>

      {role === 'company' ? (
        <label className="onboarding-field onboarding-field-enter">
          <span>Company name</span>
          <input
            name="organizationName"
            required
            maxLength={120}
            placeholder="e.g. Nova Labs"
          />
        </label>
      ) : (
        <label className="onboarding-field onboarding-field-enter">
          <span>Which describes you?</span>
          <select name="profileType" defaultValue="fresher">
            <option value="fresher">Fresher / student</option>
            <option value="experienced">Experienced professional</option>
            <option value="returner">Returning to work</option>
          </select>
        </label>
      )}

      <button type="submit" className="onboarding-submit" disabled={busy}>
        {busy
          ? 'Creating workspace…'
          : `Create ${role === 'company' ? 'employer' : 'candidate'} account`}{' '}
        <Sparkles />
      </button>
      {status ? <output className="login-status">{status}</output> : null}
      <p className="onboarding-security">
        <ShieldCheck /> One identity, separate role-specific workspace. No
        HireMind password to remember.
      </p>
    </form>
  );
}
