'use client';

import { useEffect, useState } from 'react';
import { StableLink as Link } from '@/components/stable-link';
import { Sparkles } from 'lucide-react';

import { authenticatedFetch, getSupabaseBrowserClient } from '@/lib/supabase/client';

import OnboardingForm from './onboarding-form';

export default function OnboardingPage() {
  const [identity, setIdentity] = useState<{ email: string; fullName: string | null } | null>(null);
  const [loading, setLoading] = useState(true);
  const [defaultRole, setDefaultRole] = useState<'candidate' | 'company' | null>(null);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      setDefaultRole(
        new URLSearchParams(window.location.search).get('role') === 'company'
          ? 'company'
          : 'candidate',
      );
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (!defaultRole) return;
    async function loadAccount() {
      const { data } = await getSupabaseBrowserClient().auth.getSession();
      if (!data.session) {
        window.location.replace(`/login?role=${defaultRole}`);
        return;
      }
      const response = await authenticatedFetch('/api/me');
      if (!response.ok) {
        window.location.replace(`/login?role=${defaultRole}`);
        return;
      }
      const account = await response.json() as {
        user: { email: string; fullName: string | null };
        organization: unknown;
        candidate: unknown;
      };
      if (defaultRole === 'company' && account.organization) {
        window.location.replace('/company');
        return;
      }
      if (defaultRole === 'candidate' && account.candidate) {
        window.location.replace('/candidate');
        return;
      }
      setIdentity(account.user);
      setLoading(false);
    }
    void loadAccount();
  }, [defaultRole]);

  if (!defaultRole || loading || !identity) {
    return <main className="auth-transition"><span className="candidate-brand-mark">h</span><p>Preparing your HireMind account…</p></main>;
  }

  return (
    <main className="onboarding-page min-h-screen">
      <Link href="/" className="candidate-brand onboarding-brand">
        <span className="candidate-brand-mark" aria-hidden="true">h</span>
        <span>hiremind</span>
      </Link>
      <section className="onboarding-card">
        <div className="onboarding-intro">
          <span className="onboarding-pill"><Sparkles /> One-minute setup</span>
          <h1>Choose your HireMind workspace</h1>
          <p>Email verified as <strong>{identity.email}</strong>. Candidate and Employer accounts have separate tools and navigation.</p>
        </div>
        <OnboardingForm defaultRole={defaultRole} defaultName={identity.fullName ?? ''} />
      </section>
    </main>
  );
}
