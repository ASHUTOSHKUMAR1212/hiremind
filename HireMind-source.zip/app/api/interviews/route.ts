import { env } from 'cloudflare:workers';
import { applicationAllowsInterview } from '@/lib/interview-lifecycle';

import { getAccountContext } from '@/lib/account';
import { ensureAuthenticatedUser } from '@/lib/authenticated-user';
import {
  buildInterviewPlan,
  type InterviewCriterion,
} from '@/lib/interview-engine';
import { canOrganizationRole } from '@/lib/organization-permissions';
import { getHireMindIdentity } from '@/lib/supabase/server';

export async function POST(request: Request) {
  const identity = await getHireMindIdentity(request);
  if (!identity)
    return Response.json({ error: 'Sign in required.' }, { status: 401 });
  const appUserId = await ensureAuthenticatedUser(identity);
  const account = await getAccountContext(appUserId);
  if (!account.organization)
    return Response.json(
      { error: 'Employer account required.' },
      { status: 403 },
    );
  if (!canOrganizationRole(account.organization.roleKey, 'schedule_interviews'))
    return Response.json(
      { error: 'Your team role cannot schedule interviews.' },
      { status: 403 },
    );

  const payload = (await request.json()) as Record<string, unknown>;
  const applicationId = text(payload.applicationId);
  const mode =
    payload.mode === 'live_video' ? 'live_video' : 'structured_screening';
  const scheduledAt = new Date(text(payload.scheduledAt)).getTime();
  if (
    !applicationId ||
    !Number.isFinite(scheduledAt) ||
    scheduledAt < Date.now() - 60_000
  ) {
    return Response.json(
      { error: 'Choose a valid future interview time.' },
      { status: 400 },
    );
  }

  const application = await env.DB.prepare(
    `SELECT a.id, a.job_id AS jobId, a.status, j.title AS jobTitle, j.description
     FROM applications a JOIN jobs j ON j.id = a.job_id
     WHERE a.id = ? AND a.organization_id = ? LIMIT 1`,
  )
    .bind(applicationId, account.organization.id)
    .first<{
      id: string;
      jobId: string;
      status: string;
      jobTitle: string;
      description: string;
    }>();
  if (!application)
    return Response.json({ error: 'Application not found.' }, { status: 404 });
  if (['withdrawn', 'rejected', 'offer', 'hired'].includes(application.status))
    return Response.json(
      { error: 'This application is no longer available for interviewing.' },
      { status: 409 },
    );

  const existing = await env.DB.prepare(
    `SELECT id FROM interview_sessions WHERE application_id = ? AND status IN ('scheduled', 'in_progress') LIMIT 1`,
  )
    .bind(applicationId)
    .first<{ id: string }>();
  if (existing)
    return Response.json(
      { error: 'An active interview already exists for this candidate.' },
      { status: 409 },
    );

  const criteriaResult = await env.DB.prepare(
    `SELECT id, label, requirement_class AS requirementClass, weight,
            evidence_definition AS evidenceDefinition, equivalent_signals_json AS equivalentSignalsJson,
            version
     FROM job_criteria WHERE job_id = ? AND is_active = 1 ORDER BY sort_order LIMIT 6`,
  )
    .bind(application.jobId)
    .all<Record<string, unknown>>();
  const criteria = criteriaResult.results.map((item) => ({
    id: text(item.id),
    label: text(item.label),
    requirementClass: text(item.requirementClass),
    weight: Number(item.weight) || 1,
    evidenceDefinition: text(item.evidenceDefinition),
    equivalentSignals: safeArray(item.equivalentSignalsJson).map(String),
  })) satisfies InterviewCriterion[];
  const criteriaVersion = Math.max(
    1,
    ...criteriaResult.results.map((item) => Number(item.version) || 1),
  );
  const questionPlan = buildInterviewPlan(application.jobTitle, criteria);

  const activePlan = await env.DB.prepare(
    `SELECT plan.id AS planId, plan.version AS planVersion, stage.id AS stageId,
            stage.configuration_json AS configurationJson
     FROM interview_plans plan JOIN interview_stages stage ON stage.interview_plan_id = plan.id
     WHERE plan.job_id = ? AND plan.status = 'active'
     ORDER BY plan.version DESC, stage.sort_order LIMIT 1`,
  )
    .bind(application.jobId)
    .first<{
      planId: string;
      planVersion: number;
      stageId: string;
      configurationJson: string | null;
    }>();
  const activeConfiguration = safeJson(activePlan?.configurationJson);
  const now = Date.now();
  const statements = [];
  let stageId = activePlan?.stageId ?? '';
  if (
    !activePlan ||
    Number(activeConfiguration.criteriaVersion) !== criteriaVersion
  ) {
    const planId = `interview_plan_${crypto.randomUUID()}`;
    stageId = `interview_stage_${crypto.randomUUID()}`;
    const planVersion = (activePlan?.planVersion ?? 0) + 1;
    if (activePlan)
      statements.push(
        env.DB.prepare(
          `UPDATE interview_plans SET status = 'inactive', updated_at = ? WHERE job_id = ? AND status = 'active'`,
        ).bind(now, application.jobId),
      );
    statements.push(
      env.DB.prepare(
        `INSERT INTO interview_plans (id, job_id, version, name, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, 'active', ?, ?)`,
      ).bind(
        planId,
        application.jobId,
        planVersion,
        `${application.jobTitle} evidence interview`,
        now,
        now,
      ),
      env.DB.prepare(
        `INSERT INTO interview_stages
         (id, interview_plan_id, stage_type, name, sort_order, configuration_json, rubric_version, created_at, updated_at)
         VALUES (?, ?, 'evidence_interview', 'Evidence interview', 1, ?, 1, ?, ?)`,
      ).bind(
        stageId,
        planId,
        JSON.stringify({
          criteriaVersion,
          questionPlan,
          durationMinutes: 25,
          maximumFollowUpsPerQuestion: 1,
          integritySignals: [
            'tab_visibility',
            'fullscreen_exit',
            'camera_availability',
          ],
          scoringNotice:
            'Answer evidence indicators support human review and never make an automatic hiring decision.',
        }),
        now,
        now,
      ),
    );
  }

  const sessionId = `interview_${crypto.randomUUID()}`;
  statements.push(
    env.DB.prepare(
      `INSERT INTO interview_sessions
       (id, application_id, interview_stage_id, mode, status, scheduled_at, created_at, updated_at)
       VALUES (?, ?, ?, ?, 'scheduled', ?, ?, ?)`,
    ).bind(sessionId, applicationId, stageId, mode, scheduledAt, now, now),
    env.DB.prepare(
      `UPDATE applications SET status = 'interview', current_stage_key = 'interview', updated_at = ?
       WHERE id = ? AND organization_id = ?`,
    ).bind(now, applicationId, account.organization.id),
    applicationEventStatement(
      applicationId,
      appUserId,
      'interview_scheduled',
      application.status,
      'interview',
      `${mode === 'live_video' ? 'A live video interview' : 'A structured screening'} was scheduled. See the interview card for the time in your local time zone.`,
      now,
    ),
  );
  await env.DB.batch(statements);
  return Response.json(
    {
      id: sessionId,
      mode,
      scheduledAt,
      status: 'scheduled',
      questionCount: questionPlan.length,
    },
    { status: 201 },
  );
}

export async function PATCH(request: Request) {
  const identity = await getHireMindIdentity(request);
  if (!identity)
    return Response.json({ error: 'Sign in required.' }, { status: 401 });
  const appUserId = await ensureAuthenticatedUser(identity);
  const account = await getAccountContext(appUserId);
  const payload = (await request.json()) as Record<string, unknown>;
  const sessionId = text(payload.sessionId);
  const action = text(payload.action);
  const session = await env.DB.prepare(
    `SELECT session.id, session.application_id AS applicationId, session.status,
            session.scheduled_at AS scheduledAt, application.status AS applicationStatus,
            application.organization_id AS organizationId,
            candidate.candidate_profile_id AS candidateProfileId
     FROM interview_sessions session
     JOIN applications application ON application.id = session.application_id
     JOIN organization_candidates candidate ON candidate.id = application.organization_candidate_id
     WHERE session.id = ? LIMIT 1`,
  )
    .bind(sessionId)
    .first<{
      id: string;
      applicationId: string;
      status: string;
      scheduledAt: number | null;
      applicationStatus: string;
      organizationId: string;
      candidateProfileId: string | null;
    }>();
  if (!session)
    return Response.json({ error: 'Interview not found.' }, { status: 404 });

  const isCandidate = account.candidate?.id === session.candidateProfileId;
  const isEmployer = account.organization?.id === session.organizationId;
  const canSchedule =
    isEmployer &&
    canOrganizationRole(account.organization?.roleKey, 'schedule_interviews');
  const now = Date.now();

  if (action === 'request_reschedule' && isCandidate) {
    if (!applicationAllowsInterview(session.applicationStatus)) return Response.json({ error: 'This application is no longer participating.' }, { status: 409 });
    if (session.status !== 'scheduled')
      return Response.json(
        { error: 'Only a scheduled interview can be changed.' },
        { status: 409 },
      );
    const note = clean(payload.note, 700);
    if (note.length < 5)
      return Response.json(
        { error: 'Add a short note with your timing needs.' },
        { status: 400 },
      );
    await env.DB.batch([
      interviewEventStatement(
        sessionId,
        'candidate_reschedule_requested',
        { note },
        now,
      ),
      applicationEventStatement(
        session.applicationId,
        appUserId,
        'interview_change_requested',
        null,
        null,
        note,
        now,
      ),
    ]);
    return Response.json({ requested: true });
  }

  if (!canSchedule)
    return Response.json(
      { error: 'Your team role cannot manage interviews.' },
      { status: 403 },
    );

  if (action === 'reschedule') {
    if (!applicationAllowsInterview(session.applicationStatus)) return Response.json({ error: 'This application is no longer participating.' }, { status: 409 });
    if (session.status !== 'scheduled')
      return Response.json(
        { error: 'Only a scheduled interview can be rescheduled.' },
        { status: 409 },
      );
    const scheduledAt = new Date(text(payload.scheduledAt)).getTime();
    if (!Number.isFinite(scheduledAt) || scheduledAt < now + 60_000)
      return Response.json(
        { error: 'Choose a future interview time.' },
        { status: 400 },
      );
    await env.DB.batch([
      env.DB.prepare(
        `UPDATE interview_sessions SET scheduled_at = ?, updated_at = ? WHERE id = ? AND status = 'scheduled'`,
      ).bind(scheduledAt, now, sessionId),
      interviewEventStatement(
        sessionId,
        'interview_rescheduled',
        { from: session.scheduledAt, to: scheduledAt },
        now,
      ),
      applicationEventStatement(
        session.applicationId,
        appUserId,
        'interview_rescheduled',
        null,
        null,
        'The employer changed the interview time. See the interview card for the updated time in your local time zone.',
        now,
      ),
    ]);
    return Response.json({ id: sessionId, status: 'scheduled', scheduledAt });
  }

  if (action === 'cancel') {
    if (!['scheduled', 'in_progress'].includes(session.status))
      return Response.json(
        { error: 'This interview is already closed.' },
        { status: 409 },
      );
    const note = clean(payload.note, 700);
    if (note.length < 3)
      return Response.json(
        { error: 'Add a short cancellation note for the candidate.' },
        { status: 400 },
      );
    const statements = [
      env.DB.prepare(
        `UPDATE interview_sessions SET status = 'cancelled', updated_at = ? WHERE id = ? AND status IN ('scheduled', 'in_progress')`,
      ).bind(now, sessionId),
      env.DB.prepare(
        `UPDATE interview_room_participants SET left_at = ?, last_seen_at = ? WHERE interview_session_id = ?`,
      ).bind(now, now, sessionId),
      interviewEventStatement(sessionId, 'interview_cancelled', { note }, now),
      applicationEventStatement(
        session.applicationId,
        appUserId,
        'interview_cancelled',
        null,
        null,
        note,
        now,
      ),
    ];
    if (session.applicationStatus === 'interview') {
      statements.push(
        env.DB.prepare(
          `UPDATE applications SET status = 'in_review', current_stage_key = 'review', updated_at = ? WHERE id = ? AND status = 'interview'`,
        ).bind(now, session.applicationId),
        applicationEventStatement(
          session.applicationId,
          appUserId,
          'application_stage_changed',
          'interview',
          'in_review',
          'Returned to review after the interview was cancelled.',
          now,
        ),
      );
    }
    await env.DB.batch(statements);
    return Response.json({ id: sessionId, status: 'cancelled' });
  }

  return Response.json(
    { error: 'This interview action is unavailable.' },
    { status: 400 },
  );
}

function interviewEventStatement(
  sessionId: string,
  eventType: string,
  payload: Record<string, unknown>,
  occurredAt: number,
) {
  return env.DB.prepare(
    `INSERT INTO interview_session_events
     (id, interview_session_id, event_type, occurred_at, duration_ms, payload_json, candidate_explanation)
     VALUES (?, ?, ?, ?, NULL, ?, NULL)`,
  ).bind(
    `event_${crypto.randomUUID()}`,
    sessionId,
    eventType,
    occurredAt,
    JSON.stringify(payload),
  );
}

function applicationEventStatement(
  applicationId: string,
  actorUserId: string,
  eventType: string,
  fromStatus: string | null,
  toStatus: string | null,
  note: string | null,
  occurredAt: number,
) {
  return env.DB.prepare(
    `INSERT INTO application_events
     (id, application_id, actor_user_id, event_type, from_status, to_status, note, visible_to_candidate, occurred_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)`,
  ).bind(
    `application_event_${crypto.randomUUID()}`,
    applicationId,
    actorUserId,
    eventType,
    fromStatus,
    toStatus,
    note,
    occurredAt,
  );
}

function clean(value: unknown, maxLength: number) {
  return text(value).trim().replace(/\s+/g, ' ').slice(0, maxLength);
}

function safeJson(value: unknown): Record<string, unknown> {
  if (typeof value === 'object' && value !== null)
    return value as Record<string, unknown>;
  if (typeof value !== 'string') return {};
  try {
    return JSON.parse(value) as Record<string, unknown>;
  } catch {
    return {};
  }
}

function safeArray(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  if (typeof value !== 'string') return [];
  try {
    const parsed = JSON.parse(value) as unknown;
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function text(value: unknown) {
  return typeof value === 'string' || typeof value === 'number'
    ? `${value}`
    : '';
}
