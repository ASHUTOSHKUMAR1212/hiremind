import { env } from 'cloudflare:workers';
import { resolveInterviewViewer } from '@/lib/interview-viewer';
import { applicationAllowsInterview } from '@/lib/interview-lifecycle';

import { getAccountContext } from '@/lib/account';
import { ensureAuthenticatedUser } from '@/lib/authenticated-user';
import {
  getLiveRoomAvailability,
  isAllowedLiveSignal,
} from '@/lib/live-interview';
import { canOrganizationRole } from '@/lib/organization-permissions';
import { getHireMindIdentity } from '@/lib/supabase/server';

const PRESENCE_WINDOW_MS = 15_000;
const SIGNAL_TTL_MS = 10 * 60_000;

type LiveSession = {
  id: string;
  applicationId: string;
  organizationId: string;
  candidateProfileId: string | null;
  candidateName: string;
  companyName: string;
  jobTitle: string;
  mode: string;
  status: string;
  applicationStatus: string;
  scheduledAt: number | null;
};

export async function GET(request: Request) {
  const context = await getContext(request);
  if (!context)
    return Response.json({ error: 'Sign in required.' }, { status: 401 });
  const url = new URL(request.url);
  const session = await loadSession(url.searchParams.get('id') ?? '');
  const role = session ? viewerRole(session, context, new URL(request.url).searchParams.get('view')) : null;
  if (!session || !role || session.mode !== 'live_video')
    return Response.json(
      { error: 'Live interview not found.' },
      { status: 404 },
    );

  const now = Date.now();
  const since = Math.max(0, Number(url.searchParams.get('since')) || 0);
  const [participants, signals, note] = await Promise.all([
    env.DB.prepare(
      `SELECT user_id AS userId, role, display_name AS displayName, peer_id AS peerId,
              media_state_json AS mediaStateJson, joined_at AS joinedAt, last_seen_at AS lastSeenAt
       FROM interview_room_participants
       WHERE interview_session_id = ? AND left_at IS NULL AND last_seen_at >= ?
       ORDER BY joined_at`,
    )
      .bind(session.id, now - PRESENCE_WINDOW_MS)
      .all<Record<string, unknown>>(),
    env.DB.prepare(
      `SELECT id, sender_user_id AS senderUserId, signal_type AS signalType,
              payload_json AS payloadJson, created_at AS createdAt
       FROM interview_room_signals
       WHERE interview_session_id = ? AND target_user_id = ? AND created_at >= ? AND expires_at > ?
       ORDER BY created_at, id LIMIT 100`,
    )
      .bind(session.id, context.appUserId, since, now)
      .all<Record<string, unknown>>(),
    role === 'employer'
      ? env.DB.prepare(
          `SELECT notes, updated_at AS updatedAt FROM interview_room_notes
         WHERE interview_session_id = ? AND author_user_id = ? LIMIT 1`,
        )
          .bind(session.id, context.appUserId)
          .first<Record<string, unknown>>()
      : Promise.resolve(null),
  ]);

  return Response.json({
    role,
    session: {
      id: session.id,
      status: session.status,
      scheduledAt: session.scheduledAt,
      candidateName: session.candidateName,
      companyName: session.companyName,
      jobTitle: session.jobTitle,
    },
    participants: participants.results.map((participant) => ({
      ...participant,
      mediaState: safeJson(participant.mediaStateJson),
      mediaStateJson: undefined,
    })),
    signals: signals.results.map((signal) => ({
      ...signal,
      payload: safeJson(signal.payloadJson),
      payloadJson: undefined,
    })),
    cursor: signals.results.reduce(
      (latest, signal) => Math.max(latest, Number(signal.createdAt) || 0),
      since,
    ),
    note:
      role === 'employer'
        ? {
            notes: text(note?.notes),
            updatedAt: Number(note?.updatedAt) || null,
          }
        : undefined,
  });
}

export async function POST(request: Request) {
  const context = await getContext(request);
  if (!context)
    return Response.json({ error: 'Sign in required.' }, { status: 401 });
  const payload = (await request.json()) as Record<string, unknown>;
  const session = await loadSession(text(payload.sessionId));
  const role = session ? viewerRole(session, context, new URL(request.url).searchParams.get('view')) : null;
  if (!session || !role || session.mode !== 'live_video')
    return Response.json(
      { error: 'Live interview not found.' },
      { status: 404 },
    );
  const action = text(payload.action);
  const now = Date.now();
  if (['join', 'heartbeat', 'signal', 'end'].includes(action) &&
      (!applicationAllowsInterview(session.applicationStatus) || !['scheduled', 'in_progress'].includes(session.status))) {
    return Response.json({ error: 'This interview is closed because the session or application has ended.' }, { status: 409 });
  }

  if (action === 'join') {
    const availability = getLiveRoomAvailability(
      role,
      session.status,
      session.scheduledAt,
      now,
    );
    if (!availability.canJoin)
      return Response.json(
        {
          error:
            availability.reason === 'too_early'
              ? 'The live room is not open yet.'
              : 'This live interview is no longer open.',
          availableAt: availability.availableAt,
        },
        { status: 409 },
      );
    const peerId = clean(payload.peerId, 120);
    if (!peerId)
      return Response.json(
        { error: 'A secure peer identifier is required.' },
        { status: 400 },
      );
    const occupiedRole = await env.DB.prepare(
      `SELECT 1 AS found FROM interview_room_participants
       WHERE interview_session_id = ? AND role = ? AND user_id <> ?
         AND left_at IS NULL AND last_seen_at >= ? LIMIT 1`,
    )
      .bind(session.id, role, context.appUserId, now - PRESENCE_WINDOW_MS)
      .first();
    if (occupiedRole)
      return Response.json(
        {
          error:
            role === 'employer'
              ? 'Another interviewer is already in this private room.'
              : 'This candidate room is already active in another browser.',
        },
        { status: 409 },
      );
    const mediaState = validMediaState(payload.mediaState);
    await env.DB.batch([
      env.DB.prepare(
        `INSERT INTO interview_room_participants
         (interview_session_id, user_id, role, display_name, peer_id, media_state_json, joined_at, last_seen_at, left_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL)
         ON CONFLICT(interview_session_id, user_id) DO UPDATE SET
           role = excluded.role, display_name = excluded.display_name, peer_id = excluded.peer_id,
           media_state_json = excluded.media_state_json, last_seen_at = excluded.last_seen_at, left_at = NULL`,
      ).bind(
        session.id,
        context.appUserId,
        role,
        displayName(role, session, context),
        peerId,
        JSON.stringify(mediaState),
        now,
        now,
      ),
      env.DB.prepare(
        `UPDATE interview_sessions SET status = 'in_progress', started_at = COALESCE(started_at, ?), updated_at = ?
          WHERE id = ? AND status = 'scheduled' AND ? = 'candidate'`,
      ).bind(now, now, session.id, role),
      eventStatement(session.id, 'live_room_joined', { role, mediaState }, now),
    ]);
    return Response.json({
      role,
      userId: context.appUserId,
      iceServers: await getIceServers(),
      joinedAt: now,
    });
  }

  if (action === 'heartbeat') {
    const mediaState = validMediaState(payload.mediaState);
    const result = await env.DB.prepare(
      `UPDATE interview_room_participants SET media_state_json = ?, last_seen_at = ?, left_at = NULL
       WHERE interview_session_id = ? AND user_id = ?`,
    )
      .bind(JSON.stringify(mediaState), now, session.id, context.appUserId)
      .run();
    if (!result.meta.changes)
      return Response.json(
        { error: 'Join the room before sending presence.' },
        { status: 409 },
      );
    return Response.json({ present: true, at: now });
  }

  if (action === 'signal') {
    const targetUserId = clean(payload.targetUserId, 100);
    const signalType = text(payload.signalType);
    const signalPayload = payload.payload;
    const serialized = JSON.stringify(signalPayload ?? {});
    if (
      !targetUserId ||
      targetUserId === context.appUserId ||
      !isAllowedLiveSignal(signalType, serialized)
    ) {
      return Response.json(
        { error: 'Invalid live-room signal.' },
        { status: 400 },
      );
    }
    const activeParticipants = await env.DB.prepare(
      `SELECT user_id AS userId, role FROM interview_room_participants
       WHERE interview_session_id = ? AND user_id IN (?, ?) AND left_at IS NULL AND last_seen_at >= ?`,
    )
      .bind(
        session.id,
        context.appUserId,
        targetUserId,
        now - PRESENCE_WINDOW_MS,
      )
      .all<{ userId: string; role: string }>();
    const activeById = new Map(
      activeParticipants.results.map((participant) => [
        participant.userId,
        participant.role,
      ]),
    );
    if (activeById.get(context.appUserId) !== role)
      return Response.json(
        { error: 'Join the room before signaling.' },
        { status: 409 },
      );
    const targetRole = activeById.get(targetUserId);
    if (!targetRole)
      return Response.json(
        { error: 'The other participant is not in the room yet.' },
        { status: 409 },
      );
    if (targetRole === role)
      return Response.json(
        { error: 'Live-room signaling must target the other participant.' },
        { status: 400 },
      );
    await env.DB.batch([
      env.DB.prepare(
        `INSERT INTO interview_room_signals
         (id, interview_session_id, sender_user_id, target_user_id, signal_type, payload_json, created_at, expires_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      ).bind(
        `signal_${crypto.randomUUID()}`,
        session.id,
        context.appUserId,
        targetUserId,
        signalType,
        serialized,
        now,
        now + SIGNAL_TTL_MS,
      ),
      env.DB.prepare(
        `DELETE FROM interview_room_signals WHERE expires_at <= ?`,
      ).bind(now),
    ]);
    return Response.json({ sent: true, at: now });
  }

  if (action === 'save_note') {
    if (role !== 'employer')
      return Response.json(
        { error: 'Only the interviewer can save private notes.' },
        { status: 403 },
      );
    const notes = clean(payload.notes, 12_000);
    await env.DB.prepare(
      `INSERT INTO interview_room_notes (interview_session_id, author_user_id, notes, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(interview_session_id, author_user_id) DO UPDATE SET notes = excluded.notes, updated_at = excluded.updated_at`,
    )
      .bind(session.id, context.appUserId, notes, now, now)
      .run();
    return Response.json({ saved: true, updatedAt: now });
  }

  if (action === 'leave') {
    await env.DB.batch([
      env.DB.prepare(
        `UPDATE interview_room_participants SET left_at = ?, last_seen_at = ?
         WHERE interview_session_id = ? AND user_id = ?`,
      ).bind(now, now, session.id, context.appUserId),
      eventStatement(session.id, 'live_room_left', { role }, now),
    ]);
    return Response.json({ left: true });
  }

  if (action === 'end') {
    if (!['scheduled', 'in_progress'].includes(session.status))
      return Response.json(
        { error: 'This live interview is already closed.' },
        { status: 409 },
      );
    if (
      role !== 'employer' ||
      !canOrganizationRole(
        context.account.organization?.roleKey,
        'schedule_interviews',
      )
    ) {
      return Response.json(
        { error: 'Only an authorized interviewer can end this session.' },
        { status: 403 },
      );
    }
    await env.DB.batch([
      env.DB.prepare(
        `UPDATE interview_sessions SET status = 'completed', completed_at = ?, updated_at = ? WHERE id = ?`,
      ).bind(now, now, session.id),
      env.DB.prepare(
        `UPDATE interview_room_participants SET left_at = ?, last_seen_at = ? WHERE interview_session_id = ?`,
      ).bind(now, now, session.id),
      env.DB.prepare(
        `UPDATE applications SET status = 'in_review', current_stage_key = 'interview_review', updated_at = ? WHERE id = ? AND status = 'interview'`,
      ).bind(now, session.applicationId),
      eventStatement(
        session.id,
        'live_interview_ended',
        { endedBy: context.appUserId },
        now,
      ),
      env.DB.prepare(
        `INSERT INTO application_events
         (id, application_id, actor_user_id, event_type, from_status, to_status, note, visible_to_candidate, occurred_at)
         VALUES (?, ?, ?, 'live_interview_completed', 'interview', 'in_review', ?, 1, ?)`,
      ).bind(
        `application_event_${crypto.randomUUID()}`,
        session.applicationId,
        context.appUserId,
        'Live interview completed and returned to employer review.',
        now,
      ),
    ]);
    return Response.json({ status: 'completed' });
  }

  return Response.json(
    { error: 'This live-room action is unavailable.' },
    { status: 400 },
  );
}

async function getContext(request: Request) {
  const identity = await getHireMindIdentity(request);
  if (!identity) return null;
  const appUserId = await ensureAuthenticatedUser(identity);
  const account = await getAccountContext(appUserId);
  return { identity, appUserId, account };
}

function loadSession(id: string) {
  return env.DB.prepare(
    `SELECT s.id, s.application_id AS applicationId, s.mode, s.status, s.scheduled_at AS scheduledAt, a.status AS applicationStatus,
            a.organization_id AS organizationId, oc.candidate_profile_id AS candidateProfileId,
            oc.display_name AS candidateName, o.name AS companyName, j.title AS jobTitle
     FROM interview_sessions s
     JOIN applications a ON a.id = s.application_id
     JOIN organization_candidates oc ON oc.id = a.organization_candidate_id
     JOIN organizations o ON o.id = a.organization_id
     JOIN jobs j ON j.id = a.job_id
     WHERE s.id = ? LIMIT 1`,
  )
    .bind(id)
    .first<LiveSession>();
}

function viewerRole(
  session: LiveSession,
  context: NonNullable<Awaited<ReturnType<typeof getContext>>>,
  requested: string | null,
) {
  return resolveInterviewViewer(requested,
    Boolean(context.account.candidate && context.account.candidate.id === session.candidateProfileId),
    context.account.organization?.id === session.organizationId &&
    canOrganizationRole(context.account.organization.roleKey, 'view_pipeline'),
  );
}

function displayName(
  role: 'candidate' | 'employer',
  session: LiveSession,
  context: NonNullable<Awaited<ReturnType<typeof getContext>>>,
) {
  return role === 'candidate'
    ? session.candidateName
    : context.identity.fullName ||
        context.identity.email.split('@')[0] ||
        'Interviewer';
}

async function getIceServers(): Promise<RTCIceServer[]> {
  const runtime = env as unknown as {
    TURN_KEY_ID?: string;
    TURN_KEY_API_TOKEN?: string;
  };
  if (runtime.TURN_KEY_ID && runtime.TURN_KEY_API_TOKEN) {
    try {
      const response = await fetch(
        `https://rtc.live.cloudflare.com/v1/turn/keys/${encodeURIComponent(runtime.TURN_KEY_ID)}/credentials/generate-ice-servers`,
        {
          method: 'POST',
          headers: {
            authorization: `Bearer ${runtime.TURN_KEY_API_TOKEN}`,
            'content-type': 'application/json',
          },
          body: JSON.stringify({ ttl: 7200 }),
        },
      );
      if (response.ok) {
        const result = (await response.json()) as {
          iceServers?: RTCIceServer[];
        };
        if (result.iceServers?.length) {
          const servers = result.iceServers
            .map((server) => ({
              ...server,
              urls: filterBrowserIceUrls(server.urls),
            }))
            .filter((server) =>
              Array.isArray(server.urls)
                ? server.urls.length > 0
                : Boolean(server.urls),
            );
          if (servers.length) return servers;
        }
      }
    } catch {
      /* Direct peer connection remains available through STUN. */
    }
  }
  return [{ urls: ['stun:stun.cloudflare.com:3478'] }];
}

function filterBrowserIceUrls(urls: string | string[]) {
  const values = Array.isArray(urls) ? urls : [urls];
  return values.filter((url) => !/:53(?:\?|$)/.test(url));
}

function validMediaState(value: unknown) {
  const state = safeJson(value);
  return {
    microphone: state.microphone !== false,
    camera: state.camera !== false,
    screen: state.screen === true,
  };
}

function eventStatement(
  sessionId: string,
  eventType: string,
  payload: Record<string, unknown>,
  occurredAt: number,
) {
  return env.DB.prepare(
    `INSERT INTO interview_session_events (id, interview_session_id, event_type, occurred_at, payload_json)
     VALUES (?, ?, ?, ?, ?)`,
  ).bind(
    `event_${crypto.randomUUID()}`,
    sessionId,
    eventType,
    occurredAt,
    JSON.stringify(payload),
  );
}

function safeJson(value: unknown): Record<string, unknown> {
  if (typeof value === 'object' && value !== null)
    return value as Record<string, unknown>;
  if (typeof value !== 'string') return {};
  try {
    return JSON.parse(value) as Record<string, unknown>;
  } catch {
    return {};
  }
}

function clean(value: unknown, maxLength: number) {
  return text(value).trim().slice(0, maxLength);
}
function text(value: unknown) {
  return typeof value === 'string' || typeof value === 'number'
    ? `${value}`
    : '';
}
