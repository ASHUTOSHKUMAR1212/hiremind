import { env } from 'cloudflare:workers';
import { ensureAuthenticatedUser } from '@/lib/authenticated-user';
import { getAccountContext } from '@/lib/account';
import { getHireMindIdentity } from '@/lib/supabase/server';
import { canOrganizationRole } from '@/lib/organization-permissions';
import { interviewCalendar } from '@/lib/integrations';
import { json } from '@/lib/employer-tools-access';

export async function GET(request: Request) {
  const identity = await getHireMindIdentity(request);
  if (!identity) return json({ error: 'Sign in required.' }, 401);
  const account = await getAccountContext(
    await ensureAuthenticatedUser(identity),
  );
  const url = new URL(request.url);
  const row = await env.DB.prepare(
    `SELECT s.id, s.scheduled_at AS scheduledAt, s.updated_at AS updatedAt, s.status, j.title AS jobTitle, o.name AS companyName, a.organization_id AS organizationId, oc.candidate_profile_id AS candidateId FROM interview_sessions s JOIN applications a ON a.id = s.application_id JOIN jobs j ON j.id = a.job_id JOIN organizations o ON o.id = a.organization_id JOIN organization_candidates oc ON oc.id = a.organization_candidate_id WHERE s.id = ?`,
  )
    .bind(url.searchParams.get('id') ?? '')
    .first<{
      id: string;
      scheduledAt: number;
      updatedAt: number;
      status: string;
      jobTitle: string;
      companyName: string;
      organizationId: string;
      candidateId: string | null;
    }>();
  const employer =
    row &&
    account.organization?.id === row.organizationId &&
    canOrganizationRole(account.organization.roleKey, 'schedule_interviews');
  const candidate = row && account.candidate?.id === row.candidateId;
  if (!row || (!employer && !candidate))
    return json({ error: 'Interview not found.' }, 404);
  if (!row.scheduledAt)
    return json({ error: 'This interview has no scheduled time.' }, 409);
  const duration = Number(url.searchParams.get('duration') ?? 60);
  if (!Number.isInteger(duration) || duration < 15 || duration > 240)
    return json({ error: 'Duration must be 15–240 minutes.' }, 400);
  // Use the configured public product origin, never an untrusted forwarded host.
  const body = interviewCalendar(
    {
      ...row,
      url: `https://hiremind-evidence-first.sharmaaishu84.chatgpt.site/interview?id=${encodeURIComponent(row.id)}`,
    },
    duration,
  );
  return new Response(body, {
    headers: {
      'content-type': 'text/calendar; charset=utf-8',
      'content-disposition': 'attachment; filename="hiremind-interview.ics"',
      'cache-control': 'private, no-store',
    },
  });
}
