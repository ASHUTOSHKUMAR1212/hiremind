import { env } from 'cloudflare:workers';
import { resolveInterviewViewer } from '@/lib/interview-viewer';
import { applicationAllowsInterview } from '@/lib/interview-lifecycle';

import { getAccountContext } from '@/lib/account';
import { ensureAuthenticatedUser } from '@/lib/authenticated-user';
import {
  assessInterviewAnswer,
  buildAdaptiveFollowUp,
  evaluateInterview,
  type AnswerAssessment,
  type InterviewQuestion,
} from '@/lib/interview-engine';
import { getInterviewStartAvailability } from '@/lib/interview-status';
import { canOrganizationRole } from '@/lib/organization-permissions';
import { getHireMindIdentity } from '@/lib/supabase/server';

type EventRow = {
  id: string;
  eventType: string;
  occurredAt: number;
  durationMs: number | null;
  payloadJson: string | null;
  candidateExplanation: string | null;
};

export async function GET(request: Request) {
  const context = await getContext(request);
  if (!context)
    return Response.json({ error: 'Sign in required.' }, { status: 401 });
  const sessionId = new URL(request.url).searchParams.get('id') ?? '';
  const session = await loadSession(sessionId);
  if (!session || !canAccess(session, context))
    return Response.json({ error: 'Interview not found.' }, { status: 404 });
  const viewerRole = resolveInterviewViewer(
    new URL(request.url).searchParams.get('view'),
    Boolean(context.account.candidate && session.candidateProfileId === context.account.candidate.id),
    context.account.organization?.id === session.organizationId &&
      canOrganizationRole(context.account.organization.roleKey, 'view_pipeline'),
  );
  if (!viewerRole) return Response.json({ error: 'Interview not found.' }, { status: 404 });
  const configuration = safeJson(session.configurationJson);
  const eventRows = await loadEvents(sessionId);
  const events = eventRows.map(toEvent);
  const questions = buildQuestionSequence(configuration, events);
  const answeredIds = new Set(
    events
      .filter((event) => event.eventType === 'answer_submitted')
      .map((event) => answerQuestionId(event.payload, questions))
      .filter(Boolean),
  );
  const currentQuestion =
    questions.find((question) => !answeredIds.has(question.id)) ?? null;
  const consent = events.find(
    (event) => event.eventType === 'consent_recorded',
  );
  const acceptedSignals = safeArray(consent?.payload.acceptedSignals).map(
    String,
  );
  const liveNotes =
    viewerRole === 'employer' && session.mode === 'live_video'
      ? await env.DB.prepare(
          `SELECT note.notes, note.updated_at AS updatedAt,
                  COALESCE(user.full_name, user.email, 'Interviewer') AS authorName
           FROM interview_room_notes note
           JOIN users user ON user.id = note.author_user_id
           WHERE note.interview_session_id = ? AND note.notes <> ''
           ORDER BY note.updated_at DESC`,
        )
          .bind(sessionId)
          .all<{ notes: string; updatedAt: number; authorName: string }>()
      : null;
  return Response.json({
    session: {
      ...session,
      configurationJson: undefined,
      evaluationJson: undefined,
      questions,
      currentQuestion,
      answeredCount: answeredIds.size,
      acceptedSignals,
      evaluation:
        viewerRole === 'employer'
          ? safeJson(session.evaluationJson)
          : undefined,
      liveNotes:
        viewerRole === 'employer' ? (liveNotes?.results ?? []) : undefined,
    },
    events: events.map((event) =>
      viewerRole === 'candidate' && event.eventType === 'answer_submitted'
        ? { ...event, payload: { ...event.payload, assessment: undefined } }
        : event,
    ),
    viewerRole,
  });
}

export async function PATCH(request: Request) {
  const context = await getContext(request);
  if (!context)
    return Response.json({ error: 'Sign in required.' }, { status: 401 });
  const payload = (await request.json()) as Record<string, unknown>;
  const sessionId = text(payload.sessionId);
  const action = text(payload.action);
  const session = await loadSession(sessionId);
  if (!session || !canAccess(session, context))
    return Response.json({ error: 'Interview not found.' }, { status: 404 });
  const isCandidate = Boolean(
    context.account.candidate &&
    session.candidateProfileId === context.account.candidate.id,
  );
  const now = Date.now();
  if (session.mode !== 'structured_screening') {
    return Response.json({ error: 'Use the live interview room for this session.' }, { status: 400 });
  }
  if (action !== 'explain_event' && !applicationAllowsInterview(session.applicationStatus)) {
    return Response.json({ error: 'This application is no longer participating in an interview.' }, { status: 409 });
  }

  if (action === 'start' && isCandidate && session.status === 'in_progress') {
    const events = (await loadEvents(sessionId)).map(toEvent);
    const questions = buildQuestionSequence(
      safeJson(session.configurationJson),
      events,
    );
    const answeredIds = new Set(
      events
        .filter((event) => event.eventType === 'answer_submitted')
        .map((event) => answerQuestionId(event.payload, questions))
        .filter(Boolean),
    );
    const nextQuestion =
      questions.find((question) => !answeredIds.has(question.id)) ?? null;
    return Response.json({
      status: 'in_progress',
      nextQuestion,
      alreadyStarted: true,
    });
  }
  if (action === 'start' && isCandidate && session.status === 'scheduled') {
    const availability = getInterviewStartAvailability(
      session.status,
      session.scheduledAt,
      now,
    );
    if (!availability.canBegin) {
      return Response.json(
        {
          error: 'This screening opens 15 minutes before its scheduled time.',
          availableAt: availability.availableAt,
        },
        { status: 409 },
      );
    }
    const acceptedSignals = safeArray(payload.acceptedSignals)
      .map(String)
      .filter((signal) =>
        [
          'answer_transcript',
          'tab_visibility',
          'fullscreen_exit',
          'camera_availability',
        ].includes(signal),
      );
    if (!acceptedSignals.includes('answer_transcript'))
      return Response.json(
        { error: 'Consent to save interview answers is required to begin.' },
        { status: 400 },
      );
    const questions = buildQuestionSequence(
      safeJson(session.configurationJson),
      [],
    );
    if (!questions.length)
      return Response.json(
        {
          error:
            'The employer must finish this interview plan before it can begin.',
        },
        { status: 409 },
      );
    const statements = [
      env.DB.prepare(
        `UPDATE interview_sessions SET status = 'in_progress', started_at = COALESCE(started_at, ?), updated_at = ? WHERE id = ?`,
      ).bind(now, now, sessionId),
      eventStatement(
        sessionId,
        'consent_recorded',
        { consentVersion: '2026-09-01', acceptedSignals },
        now,
      ),
      eventStatement(sessionId, 'interview_started', payload, now),
    ];
    const cameraStatus = text(payload.cameraStatus);
    if (
      acceptedSignals.includes('camera_availability') &&
      ['available', 'unavailable'].includes(cameraStatus)
    )
      statements.push(
        eventStatement(sessionId, `camera_${cameraStatus}`, {}, now),
      );
    await env.DB.batch(statements);
    return Response.json({ status: 'in_progress', nextQuestion: questions[0] });
  }
  if (action === 'answer' && isCandidate && session.status === 'in_progress') {
    return saveAnswer(session, sessionId, payload, now);
  }
  if (action === 'explain_event' && isCandidate) {
    const eventId = text(payload.eventId);
    const explanation = clean(payload.explanation, 500);
    if (!eventId || explanation.length < 2)
      return Response.json(
        { error: 'Add a short explanation first.' },
        { status: 400 },
      );
    const result = await env.DB.prepare(
      `UPDATE interview_session_events SET candidate_explanation = ?
       WHERE id = ? AND interview_session_id = ?
         AND event_type IN ('tab_hidden', 'fullscreen_exit', 'camera_unavailable')`,
    )
      .bind(explanation, eventId, sessionId)
      .run();
    if (!result.meta.changes)
      return Response.json(
        { error: 'This session event cannot be explained.' },
        { status: 404 },
      );
    return Response.json({ saved: true });
  }
  if (
    [
      'tab_hidden',
      'tab_visible',
      'fullscreen_exit',
      'camera_available',
      'camera_unavailable',
    ].includes(action) &&
    isCandidate &&
    session.status === 'in_progress'
  ) {
    const events = (await loadEvents(sessionId)).map(toEvent);
    const acceptedSignals = safeArray(
      events.find((event) => event.eventType === 'consent_recorded')?.payload
        .acceptedSignals,
    ).map(String);
    const requiredConsent = action.startsWith('tab_')
      ? 'tab_visibility'
      : action === 'fullscreen_exit'
        ? 'fullscreen_exit'
        : 'camera_availability';
    if (!acceptedSignals.includes(requiredConsent))
      return Response.json(
        { error: 'This optional session signal was not consented to.' },
        { status: 403 },
      );
    await eventStatement(sessionId, action, payload, now).run();
    return Response.json({ saved: true });
  }
  if (
    action === 'complete' &&
    isCandidate &&
    session.status === 'in_progress'
  ) {
    return completeSession(session, sessionId, payload, now);
  }
  if (
    action === 'cancel' &&
    !isCandidate &&
    context.account.organization?.id === session.organizationId &&
    canOrganizationRole(
      context.account.organization.roleKey,
      'schedule_interviews',
    ) &&
    ['scheduled', 'in_progress'].includes(session.status)
  ) {
    const note =
      clean(payload.note, 700) || 'Interview cancelled by the employer.';
    await env.DB.batch([
      env.DB.prepare(
        `UPDATE interview_sessions SET status = 'cancelled', updated_at = ? WHERE id = ?`,
      ).bind(now, sessionId),
      env.DB.prepare(
        `UPDATE applications SET status = 'in_review', current_stage_key = 'review', updated_at = ?
         WHERE id = ? AND status = 'interview'`,
      ).bind(now, session.applicationId),
      eventStatement(sessionId, 'interview_cancelled', { note }, now),
      env.DB.prepare(
        `INSERT INTO application_events
         (id, application_id, actor_user_id, event_type, from_status, to_status, note, visible_to_candidate, occurred_at)
         VALUES (?, ?, ?, 'interview_cancelled', NULL, NULL, ?, 1, ?)`,
      ).bind(
        `application_event_${crypto.randomUUID()}`,
        session.applicationId,
        context.appUserId,
        note,
        now,
      ),
    ]);
    return Response.json({ status: 'cancelled' });
  }
  return Response.json(
    { error: 'This interview action is not available.' },
    { status: 400 },
  );
}

async function saveAnswer(
  session: NonNullable<Awaited<ReturnType<typeof loadSession>>>,
  sessionId: string,
  payload: Record<string, unknown>,
  now: number,
) {
  const answer = clean(payload.answer, 5000);
  if (answer.length < 2)
    return Response.json(
      { error: 'Add an answer before continuing.' },
      { status: 400 },
    );
  const configuration = safeJson(session.configurationJson);
  const eventRows = await loadEvents(sessionId);
  const events = eventRows.map(toEvent);
  const questions = buildQuestionSequence(configuration, events);
  const requestedId = text(payload.questionId);
  const fallbackIndex = Math.max(
    0,
    Math.min(20, Number(payload.questionIndex) || 0),
  );
  const question =
    questions.find((item) => item.id === requestedId) ??
    questions[fallbackIndex];
  if (!question)
    return Response.json(
      { error: 'This interview question is unavailable.' },
      { status: 400 },
    );
  const priorAnswers = events.filter(
    (event) => event.eventType === 'answer_submitted',
  );
  const answeredIds = new Set(
    priorAnswers
      .map((event) => answerQuestionId(event.payload, questions))
      .filter(Boolean),
  );
  if (answeredIds.has(question.id)) {
    const nextQuestion =
      questions.find((item) => !answeredIds.has(item.id)) ?? null;
    return Response.json({
      saved: true,
      nextQuestion,
      answeredCount: answeredIds.size,
      totalQuestions: questions.length,
      shouldComplete: !nextQuestion,
    });
  }

  const assessment = assessInterviewAnswer(question, answer);
  const statements = [
    eventStatement(
      sessionId,
      'answer_submitted',
      {
        questionId: question.id,
        questionIndex: fallbackIndex,
        answer,
        assessment,
      },
      now,
    ),
  ];
  answeredIds.add(question.id);
  let nextQuestions = questions;
  const alreadyAskedFollowUp = questions.some(
    (item) => item.parentQuestionId === question.id,
  );
  if (assessment.needsFollowUp && !alreadyAskedFollowUp) {
    const followUp = buildAdaptiveFollowUp(question, assessment);
    statements.push(
      eventStatement(
        sessionId,
        'question_asked',
        {
          question: followUp,
          afterQuestionId: question.id,
          reason: assessment.missingSignals[0] ?? 'clarification',
        },
        now + 1,
      ),
    );
    nextQuestions = insertFollowUp(questions, followUp);
  }
  await env.DB.batch(statements);
  const nextQuestion =
    nextQuestions.find((item) => !answeredIds.has(item.id)) ?? null;
  return Response.json({
    saved: true,
    nextQuestion,
    answeredCount: answeredIds.size,
    totalQuestions: nextQuestions.length,
    shouldComplete: !nextQuestion,
  });
}

async function completeSession(
  session: NonNullable<Awaited<ReturnType<typeof loadSession>>>,
  sessionId: string,
  payload: Record<string, unknown>,
  now: number,
) {
  const configuration = safeJson(session.configurationJson);
  const events = (await loadEvents(sessionId)).map(toEvent);
  const questions = buildQuestionSequence(configuration, events);
  const answers = events
    .filter((event) => event.eventType === 'answer_submitted')
    .map((event) => ({
      questionId: answerQuestionId(event.payload, questions),
      answer: text(event.payload.answer),
      assessment: asAssessment(event.payload.assessment),
    }));
  const answeredIds = new Set(answers.map((answer) => answer.questionId));
  const unanswered = questions.find(
    (question) => !answeredIds.has(question.id),
  );
  if (unanswered)
    return Response.json(
      {
        error: 'Finish the current question before submitting the interview.',
        nextQuestion: unanswered,
      },
      { status: 409 },
    );
  const evaluation = evaluateInterview(questions, answers);
  await env.DB.batch([
    env.DB.prepare(
      `UPDATE interview_sessions SET status = 'completed', completed_at = ?, evaluation_json = ?, updated_at = ? WHERE id = ?`,
    ).bind(now, JSON.stringify(evaluation), now, sessionId),
    env.DB.prepare(
      `UPDATE applications SET status = 'in_review', current_stage_key = 'interview_review', updated_at = ? WHERE id = ? AND status = 'interview'`,
    ).bind(now, session.applicationId),
    eventStatement(sessionId, 'interview_completed', payload, now),
    applicationEventStatement(
      session.applicationId,
      'structured_interview_completed',
      'interview',
      'in_review',
      'Structured screening completed and returned to employer review.',
      now,
    ),
  ]);
  return Response.json({ status: 'completed' });
}

function applicationEventStatement(
  applicationId: string,
  eventType: string,
  fromStatus: string | null,
  toStatus: string | null,
  note: string | null,
  occurredAt: number,
) {
  return env.DB.prepare(
    `INSERT INTO application_events
     (id, application_id, actor_user_id, event_type, from_status, to_status, note, visible_to_candidate, occurred_at)
     VALUES (?, ?, NULL, ?, ?, ?, ?, 1, ?)`,
  ).bind(
    `application_event_${crypto.randomUUID()}`,
    applicationId,
    eventType,
    fromStatus,
    toStatus,
    note,
    occurredAt,
  );
}

async function getContext(request: Request) {
  const identity = await getHireMindIdentity(request);
  if (!identity) return null;
  const appUserId = await ensureAuthenticatedUser(identity);
  const account = await getAccountContext(appUserId);
  return { identity, appUserId, account };
}

async function loadSession(id: string) {
  return env.DB.prepare(
    `SELECT s.id, s.application_id AS applicationId, s.mode, s.status, s.scheduled_at AS scheduledAt, a.status AS applicationStatus,
            s.started_at AS startedAt, s.completed_at AS completedAt, s.evaluation_json AS evaluationJson,
            stage.name AS stageName, stage.configuration_json AS configurationJson,
            j.title AS jobTitle, o.name AS companyName, a.organization_id AS organizationId,
            oc.candidate_profile_id AS candidateProfileId, oc.display_name AS candidateName
     FROM interview_sessions s
     JOIN interview_stages stage ON stage.id = s.interview_stage_id
     JOIN applications a ON a.id = s.application_id
     JOIN jobs j ON j.id = a.job_id
     JOIN organizations o ON o.id = a.organization_id
     JOIN organization_candidates oc ON oc.id = a.organization_candidate_id
     WHERE s.id = ? LIMIT 1`,
  )
    .bind(id)
    .first<{
      id: string;
      applicationId: string;
      mode: string;
      status: string;
      applicationStatus: string;
      scheduledAt: number | null;
      startedAt: number | null;
      completedAt: number | null;
      evaluationJson: string | null;
      stageName: string;
      configurationJson: string | null;
      jobTitle: string;
      companyName: string;
      organizationId: string;
      candidateProfileId: string | null;
      candidateName: string;
    }>();
}

function canAccess(
  session: NonNullable<Awaited<ReturnType<typeof loadSession>>>,
  context: NonNullable<Awaited<ReturnType<typeof getContext>>>,
) {
  return (
    context.account.candidate?.id === session.candidateProfileId ||
    (context.account.organization?.id === session.organizationId &&
      canOrganizationRole(
        context.account.organization.roleKey,
        'view_pipeline',
      ))
  );
}

function loadEvents(sessionId: string) {
  return env.DB.prepare(
    `SELECT id, event_type AS eventType, occurred_at AS occurredAt, duration_ms AS durationMs,
            payload_json AS payloadJson, candidate_explanation AS candidateExplanation
     FROM interview_session_events WHERE interview_session_id = ? ORDER BY occurred_at, id`,
  )
    .bind(sessionId)
    .all<EventRow>()
    .then((result) => result.results);
}

function toEvent(event: EventRow) {
  return {
    ...event,
    payload: safeJson(event.payloadJson),
    payloadJson: undefined,
  };
}

function buildQuestionSequence(
  configuration: Record<string, unknown>,
  events: Array<ReturnType<typeof toEvent>>,
) {
  const configured = Array.isArray(configuration.questionPlan)
    ? (configuration.questionPlan
        .map(asQuestion)
        .filter(Boolean) as InterviewQuestion[])
    : [];
  const legacy: InterviewQuestion[] = Array.isArray(configuration.questions)
    ? configuration.questions.map((prompt, index) => ({
        id: `legacy_${index + 1}`,
        kind: index === 0 ? ('opening' as const) : ('criterion' as const),
        criterionId: null,
        criterionLabel:
          index === 0 ? 'Role readiness' : `Question ${index + 1}`,
        prompt: text(prompt),
        guidance:
          'Use a specific example and explain your contribution and the outcome.',
        expectedSignals: [],
      }))
    : [];
  const base = configured.length ? configured : legacy;
  const followUps = events
    .filter((event) => event.eventType === 'question_asked')
    .map((event) => asQuestion(event.payload.question))
    .filter(Boolean) as InterviewQuestion[];
  return base.flatMap((question) => [
    question,
    ...followUps.filter(
      (followUp) => followUp.parentQuestionId === question.id,
    ),
  ]);
}

function insertFollowUp(
  questions: InterviewQuestion[],
  followUp: InterviewQuestion,
) {
  const parentIndex = questions.findIndex(
    (question) => question.id === followUp.parentQuestionId,
  );
  if (parentIndex < 0) return [...questions, followUp];
  return [
    ...questions.slice(0, parentIndex + 1),
    followUp,
    ...questions.slice(parentIndex + 1),
  ];
}

function answerQuestionId(
  payload: Record<string, unknown>,
  questions: InterviewQuestion[],
) {
  const stored = text(payload.questionId);
  if (stored) return stored;
  return questions[Math.max(0, Number(payload.questionIndex) || 0)]?.id ?? '';
}

function asQuestion(value: unknown): InterviewQuestion | null {
  if (typeof value !== 'object' || value === null) return null;
  const item = value as Record<string, unknown>;
  const id = text(item.id);
  const prompt = text(item.prompt);
  if (!id || !prompt) return null;
  const kindValue = text(item.kind);
  const kind: InterviewQuestion['kind'] = [
    'opening',
    'criterion',
    'reflection',
    'follow_up',
  ].includes(kindValue)
    ? (kindValue as InterviewQuestion['kind'])
    : 'criterion';
  return {
    id,
    prompt,
    kind,
    criterionId: text(item.criterionId) || null,
    criterionLabel: text(item.criterionLabel) || 'Role evidence',
    guidance: text(item.guidance),
    expectedSignals: safeArray(item.expectedSignals).map(String),
    ...(text(item.parentQuestionId)
      ? { parentQuestionId: text(item.parentQuestionId) }
      : {}),
  };
}

function asAssessment(value: unknown): AnswerAssessment | undefined {
  return typeof value === 'object' && value !== null
    ? (value as AnswerAssessment)
    : undefined;
}

function eventStatement(
  sessionId: string,
  eventType: string,
  payload: Record<string, unknown>,
  now: number,
) {
  const safePayload = { ...payload, sessionId: undefined, action: undefined };
  return env.DB.prepare(
    `INSERT INTO interview_session_events
     (id, interview_session_id, event_type, occurred_at, duration_ms, payload_json, candidate_explanation)
     VALUES (?, ?, ?, ?, NULL, ?, NULL)`,
  ).bind(
    `event_${crypto.randomUUID()}`,
    sessionId,
    eventType,
    now,
    JSON.stringify(safePayload),
  );
}

function safeJson(value: unknown): Record<string, unknown> {
  if (typeof value === 'object' && value !== null)
    return value as Record<string, unknown>;
  if (typeof value !== 'string') return {};
  try {
    return JSON.parse(value) as Record<string, unknown>;
  } catch {
    return {};
  }
}
function safeArray(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  if (typeof value !== 'string') return [];
  try {
    const parsed = JSON.parse(value) as unknown;
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}
function clean(value: unknown, maxLength: number) {
  return text(value).trim().replace(/\s+/g, ' ').slice(0, maxLength);
}
function text(value: unknown) {
  return typeof value === 'string' || typeof value === 'number'
    ? `${value}`
    : '';
}
