import { env } from 'cloudflare:workers';
import { closeApplicationInterviews } from '@/lib/interview-lifecycle';

import { getAccountContext } from '@/lib/account';
import { MATCHING_ENGINE_VERSION } from '@/lib/evidence-screening';
import {
  applicationEventType,
  applicationStage,
  canTransitionApplication,
  isApplicationStatus,
} from '@/lib/application-workflow';
import { ensureAuthenticatedUser } from '@/lib/authenticated-user';
import { canOrganizationRole } from '@/lib/organization-permissions';
import { getHireMindIdentity } from '@/lib/supabase/server';

export async function GET(request: Request) {
  const user = await getHireMindIdentity(request);
  if (!user)
    return Response.json({ error: 'Sign in required.' }, { status: 401 });

  const appUserId = await ensureAuthenticatedUser(user);
  const account = await getAccountContext(appUserId);
  if (!account.candidate) {
    return Response.json(
      { error: 'Candidate account required.' },
      { status: 403 },
    );
  }

  const [result, eventResult] = await Promise.all([
    env.DB.prepare(
      `SELECT a.id, a.job_id AS jobId, a.status, a.current_stage_key AS currentStage,
            a.submitted_at AS submittedAt, j.title AS jobTitle, o.name AS companyName,
            sr.fit_score AS fitScore, sr.decision_band AS decisionBand,
            sr.explanation AS screeningExplanation,
            interview.id AS interviewSessionId, interview.status AS interviewStatus,
            interview.mode AS interviewMode,
            interview.scheduled_at AS interviewScheduledAt
     FROM applications a
     JOIN organization_candidates oc ON oc.id = a.organization_candidate_id
     JOIN jobs j ON j.id = a.job_id
     JOIN organizations o ON o.id = a.organization_id
     LEFT JOIN shortlist_rankings sr ON sr.application_id = a.id
       AND sr.screening_run_id = (
         SELECT id FROM screening_runs WHERE job_id = a.job_id AND status = 'completed'
         AND completed_at >= j.updated_at AND model_version = ?
         ORDER BY completed_at DESC LIMIT 1
       )
     LEFT JOIN interview_sessions interview ON interview.id = (
       SELECT id FROM interview_sessions WHERE application_id = a.id ORDER BY created_at DESC LIMIT 1
     )
     WHERE oc.candidate_profile_id = ?
     ORDER BY a.submitted_at DESC`,
    )
      .bind(MATCHING_ENGINE_VERSION, account.candidate.id)
      .all(),
    env.DB.prepare(
      `SELECT event.id, event.application_id AS applicationId, event.event_type AS eventType,
              event.from_status AS fromStatus, event.to_status AS toStatus, event.note,
              event.occurred_at AS occurredAt
       FROM application_events event
       JOIN applications application ON application.id = event.application_id
       JOIN organization_candidates candidate ON candidate.id = application.organization_candidate_id
       WHERE candidate.candidate_profile_id = ? AND event.visible_to_candidate = 1
       ORDER BY event.occurred_at, event.id`,
    )
      .bind(account.candidate.id)
      .all(),
  ]);

  return Response.json({
    applications: result.results.map((application) => ({
      ...application,
      timeline: eventResult.results.filter(
        (event) => event.applicationId === application.id,
      ),
    })),
  });
}

export async function POST(request: Request) {
  const user = await getHireMindIdentity(request);
  if (!user)
    return Response.json({ error: 'Sign in required.' }, { status: 401 });

  const appUserId = await ensureAuthenticatedUser(user);
  const account = await getAccountContext(appUserId);
  if (!account.candidate) {
    return Response.json(
      { error: 'Candidate account required.' },
      { status: 403 },
    );
  }

  const payload = (await request.json()) as { jobId?: unknown };
  const jobId = typeof payload.jobId === 'string' ? payload.jobId : '';
  const job = await env.DB.prepare(
    `SELECT id, organization_id AS organizationId, title
     FROM jobs WHERE id = ? AND status = 'published' LIMIT 1`,
  )
    .bind(jobId)
    .first<{ id: string; organizationId: string; title: string }>();
  if (!job)
    return Response.json(
      { error: 'This job is not available.' },
      { status: 404 },
    );

  const [profile, experiences, education, projects, resume] = await Promise.all(
    [
      env.DB.prepare(
        `SELECT id, full_name AS fullName, primary_email AS primaryEmail, profile_type AS profileType,
            headline, summary, location, availability, work_authorization AS workAuthorization,
            metadata_json AS metadataJson
     FROM candidate_profiles WHERE id = ? LIMIT 1`,
      )
        .bind(account.candidate.id)
        .first<Record<string, unknown>>(),
      env.DB.prepare(
        `SELECT title, organization_name AS organizationName, description,
              started_on AS startedOn, ended_on AS endedOn, is_current AS isCurrent
       FROM candidate_experiences WHERE candidate_profile_id = ? ORDER BY sort_order`,
      )
        .bind(account.candidate.id)
        .all(),
      env.DB.prepare(
        `SELECT institution, qualification, field_of_study AS fieldOfStudy,
              started_on AS startedOn, ended_on AS endedOn
       FROM candidate_education WHERE candidate_profile_id = ? ORDER BY created_at`,
      )
        .bind(account.candidate.id)
        .all(),
      env.DB.prepare(
        `SELECT title, description, project_url AS projectUrl, repository_url AS repositoryUrl,
              skills_json AS skillsJson
       FROM candidate_projects WHERE candidate_profile_id = ? ORDER BY created_at`,
      )
        .bind(account.candidate.id)
        .all(),
      env.DB.prepare(
        `SELECT id, filename FROM files WHERE entity_type = 'candidate_resume' AND entity_id = ?
       ORDER BY created_at DESC LIMIT 1`,
      )
        .bind(account.candidate.id)
        .first(),
    ],
  );
  if (!profile)
    return Response.json(
      { error: 'Candidate profile not found.' },
      { status: 404 },
    );
  const profileSnapshot = {
    ...profile,
    metadata: safeJson(profile.metadataJson),
    metadataJson: undefined,
    experiences: experiences.results,
    education: education.results,
    projects: projects.results.map((project) => ({
      ...project,
      skills: safeArray(project.skillsJson),
      skillsJson: undefined,
    })),
    resume: resume ?? null,
  };

  let organizationCandidate = await env.DB.prepare(
    `SELECT id FROM organization_candidates
     WHERE organization_id = ? AND candidate_profile_id = ? AND deleted_at IS NULL
     LIMIT 1`,
  )
    .bind(job.organizationId, account.candidate.id)
    .first<{ id: string }>();

  const now = Date.now();
  if (!organizationCandidate) {
    const relationshipId = `orgcandidate_${crypto.randomUUID()}`;
    await env.DB.prepare(
      `INSERT INTO organization_candidates
       (id, organization_id, candidate_profile_id, display_name, primary_email,
        source_key, owner_user_id, consent_status, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, 'direct_application', ?, 'granted', ?, ?)`,
    )
      .bind(
        relationshipId,
        job.organizationId,
        account.candidate.id,
        account.candidate.fullName,
        user.email,
        appUserId,
        now,
        now,
      )
      .run();
    organizationCandidate = { id: relationshipId };
  }

  const existing = await env.DB.prepare(
    `SELECT id FROM applications WHERE job_id = ? AND organization_candidate_id = ? LIMIT 1`,
  )
    .bind(job.id, organizationCandidate.id)
    .first<{ id: string }>();
  if (existing) {
    return Response.json(
      { error: 'You have already applied for this job.' },
      { status: 409 },
    );
  }

  const applicationId = `application_${crypto.randomUUID()}`;
  await env.DB.batch([
    env.DB.prepare(
      `INSERT INTO applications
     (id, organization_id, job_id, organization_candidate_id, status, current_stage_key,
      profile_snapshot_json, submitted_at, created_at, updated_at)
     VALUES (?, ?, ?, ?, 'submitted', 'application_review', ?, ?, ?, ?)`,
    ).bind(
      applicationId,
      job.organizationId,
      job.id,
      organizationCandidate.id,
      JSON.stringify(profileSnapshot),
      now,
      now,
      now,
    ),
    applicationEventStatement(
      applicationId,
      appUserId,
      'application_submitted',
      null,
      'submitted',
      null,
      true,
      now,
    ),
  ]);

  return Response.json(
    { id: applicationId, status: 'submitted', jobTitle: job.title },
    { status: 201 },
  );
}

export async function PATCH(request: Request) {
  const user = await getHireMindIdentity(request);
  if (!user)
    return Response.json({ error: 'Sign in required.' }, { status: 401 });
  const appUserId = await ensureAuthenticatedUser(user);
  const account = await getAccountContext(appUserId);
  const payload = (await request.json()) as Record<string, unknown>;
  const applicationId =
    typeof payload.applicationId === 'string' ? payload.applicationId : '';
  if (payload.status === 'withdrawn' && account.candidate) {
    const existing = await env.DB.prepare(
      `SELECT a.status FROM applications a
       WHERE a.id = ? AND a.organization_candidate_id IN (
         SELECT id FROM organization_candidates WHERE candidate_profile_id = ? AND deleted_at IS NULL
       ) LIMIT 1`,
    )
      .bind(applicationId, account.candidate.id)
      .first<{ status: string }>();
    if (!existing)
      return Response.json(
        { error: 'Application not found.' },
        { status: 404 },
      );
    if (!canTransitionApplication(existing.status, 'withdrawn'))
      return Response.json(
        { error: 'This application can no longer be withdrawn.' },
        { status: 409 },
      );
    const now = Date.now();
    const update = env.DB.prepare(
      `UPDATE applications SET status = 'withdrawn', current_stage_key = 'withdrawn', withdrawn_at = ?, updated_at = ?
       WHERE id = ? AND status = ?
         AND organization_candidate_id IN (
           SELECT id FROM organization_candidates WHERE candidate_profile_id = ? AND deleted_at IS NULL
         )`,
    ).bind(now, now, applicationId, existing.status, account.candidate.id);
    await env.DB.batch([
      update,
      ...closeApplicationInterviews(applicationId, now),
      applicationEventStatement(
        applicationId,
        appUserId,
        'application_withdrawn',
        existing.status,
        'withdrawn',
        clean(payload.note, 500) || null,
        true,
        now,
      ),
    ]);
    return Response.json({
      applicationId,
      status: 'withdrawn',
      currentStage: 'withdrawn',
    });
  }
  if (!account.organization)
    return Response.json(
      { error: 'Employer account required.' },
      { status: 403 },
    );
  if (!canOrganizationRole(account.organization.roleKey, 'manage_candidates'))
    return Response.json(
      { error: 'Your team role cannot change candidate stages.' },
      { status: 403 },
    );
  const status = isApplicationStatus(payload.status) ? payload.status : null;
  if (!applicationId || !status || status === 'withdrawn')
    return Response.json(
      { error: 'Choose a valid application action.' },
      { status: 400 },
    );
  const existing = await env.DB.prepare(
    `SELECT status FROM applications WHERE id = ? AND organization_id = ? LIMIT 1`,
  )
    .bind(applicationId, account.organization.id)
    .first<{ status: string }>();
  if (!existing)
    return Response.json({ error: 'Application not found.' }, { status: 404 });
  if (!canTransitionApplication(existing.status, status))
    return Response.json(
      {
        error: `A ${existing.status.replaceAll('_', ' ')} application cannot move to ${status.replaceAll('_', ' ')}.`,
      },
      { status: 409 },
    );
  const note = clean(payload.note, 1000);
  if (['offer', 'hired', 'rejected'].includes(status) && note.length < 3)
    return Response.json(
      { error: 'Add a short candidate-visible decision note.' },
      { status: 400 },
    );
  const stage = applicationStage(status);
  const now = Date.now();
  const result = await env.DB.batch([
    env.DB.prepare(
      `UPDATE applications SET status = ?, current_stage_key = ?, updated_at = ?
     WHERE id = ? AND organization_id = ? AND status = ?`,
    ).bind(
      status,
      stage,
      now,
      applicationId,
      account.organization.id,
      existing.status,
    ),
    ...(['offer', 'hired', 'rejected'].includes(status)
      ? closeApplicationInterviews(applicationId, now)
      : []),
    applicationEventStatement(
      applicationId,
      appUserId,
      applicationEventType(status),
      existing.status,
      status,
      note || null,
      true,
      now,
    ),
  ]);
  if (!result[0]?.meta.changes)
    return Response.json(
      { error: 'Application changed; refresh and try again.' },
      { status: 409 },
    );
  return Response.json({ applicationId, status, currentStage: stage });
}

function applicationEventStatement(
  applicationId: string,
  actorUserId: string,
  eventType: string,
  fromStatus: string | null,
  toStatus: string | null,
  note: string | null,
  visibleToCandidate: boolean,
  occurredAt: number,
) {
  return env.DB.prepare(
    `INSERT INTO application_events
     (id, application_id, actor_user_id, event_type, from_status, to_status, note, visible_to_candidate, occurred_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).bind(
    `application_event_${crypto.randomUUID()}`,
    applicationId,
    actorUserId,
    eventType,
    fromStatus,
    toStatus,
    note,
    visibleToCandidate ? 1 : 0,
    occurredAt,
  );
}

function clean(value: unknown, maxLength: number) {
  return (
    typeof value === 'string' || typeof value === 'number' ? `${value}` : ''
  )
    .trim()
    .replace(/\s+/g, ' ')
    .slice(0, maxLength);
}

function safeJson(value: unknown): Record<string, unknown> {
  if (typeof value === 'object' && value !== null)
    return value as Record<string, unknown>;
  if (typeof value !== 'string') return {};
  try {
    return JSON.parse(value) as Record<string, unknown>;
  } catch {
    return {};
  }
}

function safeArray(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  if (typeof value !== 'string') return [];
  try {
    const parsed = JSON.parse(value) as unknown;
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}
