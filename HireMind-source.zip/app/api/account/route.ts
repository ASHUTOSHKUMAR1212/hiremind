import { env } from 'cloudflare:workers';

import { getAccountContext } from '@/lib/account';
import { ensureAuthenticatedUser } from '@/lib/authenticated-user';
import { getHireMindIdentity } from '@/lib/supabase/server';

export async function POST(request: Request) {
  const user = await getHireMindIdentity(request);
  if (!user) return new Response('Sign in required', { status: 401 });

  const form = await request.formData();
  const role = formText(form.get('role'));
  const fullName = cleanText(form.get('fullName'), 100);
  const organizationName = cleanText(form.get('organizationName'), 120);
  const profileTypeValue = formText(form.get('profileType')) || 'fresher';
  const profileType = ['fresher', 'experienced', 'returner'].includes(profileTypeValue)
    ? profileTypeValue
    : 'fresher';

  if (!fullName || !['candidate', 'company'].includes(role)) {
    return new Response('Please complete the required fields.', { status: 400 });
  }
  if (role === 'company' && !organizationName) {
    return new Response('Company name is required.', { status: 400 });
  }

  const now = Date.now();
  const appUserId = await ensureAuthenticatedUser({ ...user, fullName });
  const account = await getAccountContext(appUserId);

  if (role === 'candidate') {
    if (account.candidate) {
      return Response.redirect(new URL('/candidate', request.url), 303);
    }
    const profileId = `candidate_${crypto.randomUUID()}`;
    await env.DB.batch([
      env.DB.prepare(
        `INSERT OR IGNORE INTO candidate_profiles
         (id, owner_user_id, profile_type, full_name, primary_email, visibility, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, 'private', ?, ?)`,
      ).bind(profileId, appUserId, profileType, fullName, user.email, now, now),
    ]);
    return Response.redirect(new URL('/candidate', request.url), 303);
  }

  if (account.organization) {
    return Response.redirect(new URL('/company', request.url), 303);
  }

  const organizationId = `org_${crypto.randomUUID()}`;
  const slugBase = slugify(organizationName) || 'company';
  const slug = `${slugBase}-${crypto.randomUUID().slice(0, 8)}`;
  await env.DB.batch([
    env.DB.prepare(
      `INSERT INTO organizations (id, name, slug, status, created_at, updated_at)
       VALUES (?, ?, ?, 'active', ?, ?)`,
    ).bind(organizationId, organizationName, slug, now, now),
    env.DB.prepare(
      `INSERT INTO organization_members
       (organization_id, user_id, role_key, status, joined_at)
       VALUES (?, ?, 'owner', 'active', ?)`,
    ).bind(organizationId, appUserId, now),
  ]);

  return Response.redirect(new URL('/company', request.url), 303);
}

function cleanText(value: FormDataEntryValue | null, maxLength: number) {
  return formText(value).trim().replace(/\s+/g, ' ').slice(0, maxLength);
}

function formText(value: FormDataEntryValue | null) {
  return typeof value === 'string' ? value : '';
}

function slugify(value: string) {
  return value
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48);
}
