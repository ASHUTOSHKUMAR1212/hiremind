import { getAccountContext } from '@/lib/account';
import { ensureAuthenticatedUser } from '@/lib/authenticated-user';
import { getHireMindIdentity } from '@/lib/supabase/server';

export async function GET(request: Request) {
  const user = await getHireMindIdentity(request);
  if (!user) return Response.json({ error: 'Sign in required.' }, { status: 401 });
  const appUserId = await ensureAuthenticatedUser(user);
  const account = await getAccountContext(appUserId);
  return Response.json({ user, ...account });
}
