import { env } from 'cloudflare:workers';
import { hashIntegrationToken } from '@/lib/integrations';
import { json } from '@/lib/employer-tools-access';

// Machine-to-machine, read-only API. Never accepts a key from a URL or cookie.
export async function GET(request: Request) {
  const token =
    request.headers.get('authorization')?.replace(/^Bearer /, '') ?? '';
  if (!/^hm_[a-f0-9]{64}$/.test(token))
    return json({ error: 'Valid integration bearer key required.' }, 401);
  const key = await env.DB.prepare(
    'SELECT id, organization_id AS organizationId, scopes_json AS scopesJson FROM integration_keys WHERE token_hash = ? AND revoked_at IS NULL AND expires_at > ?',
  )
    .bind(await hashIntegrationToken(token), Date.now())
    .first<{ id: string; organizationId: string; scopesJson: string }>();
  if (!key) return json({ error: 'Integration key expired or revoked.' }, 401);
  const url = new URL(request.url);
  const resource = url.searchParams.get('resource') ?? 'jobs';
  if (!['jobs', 'applications'].includes(resource))
    return json({ error: 'Resource must be jobs or applications.' }, 400);
  if (!JSON.parse(key.scopesJson).includes(`${resource}:read`))
    return json(
      { error: 'This key does not grant access to this resource.' },
      403,
    );
  const after = url.searchParams.get('after') ?? '';
  if (after.length > 100) return json({ error: 'Invalid cursor.' }, 400);
  const rows =
    resource === 'jobs'
      ? await env.DB.prepare(
          'SELECT id, title, description, status, location, updated_at AS updatedAt FROM jobs WHERE organization_id = ? AND id > ? ORDER BY id LIMIT 101',
        )
          .bind(key.organizationId, after)
          .all<Record<string, unknown>>()
      : await env.DB.prepare(
          `SELECT a.id, a.job_id AS jobId, a.status, a.submitted_at AS submittedAt, a.updated_at AS updatedAt, oc.display_name AS candidateName, oc.primary_email AS candidateEmail FROM applications a JOIN organization_candidates oc ON oc.id = a.organization_candidate_id WHERE a.organization_id = ? AND a.id > ? AND oc.deleted_at IS NULL AND (oc.retention_until IS NULL OR oc.retention_until > ?) ORDER BY a.id LIMIT 101`,
        )
          .bind(key.organizationId, after, Date.now())
          .all<Record<string, unknown>>();
  await env.DB.prepare(
    'UPDATE integration_keys SET last_used_at = ? WHERE id = ?',
  )
    .bind(Date.now(), key.id)
    .run();
  const items = rows.results.slice(0, 100);
  return json({
    schemaVersion: 1,
    resource,
    items,
    nextCursor: rows.results.length > 100 ? items.at(-1)!.id : null,
    mode: 'read_only_snapshot',
  });
}
