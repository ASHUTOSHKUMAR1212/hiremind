import { env } from 'cloudflare:workers';

import { getAccountContext } from '@/lib/account';
import { ensureAuthenticatedUser } from '@/lib/authenticated-user';
import { canOrganizationRole } from '@/lib/organization-permissions';
import { getHireMindIdentity } from '@/lib/supabase/server';

export async function GET(request: Request) {
  const identity = await getHireMindIdentity(request);
  if (!identity) return Response.json({ error: 'Sign in required.' }, { status: 401 });
  const appUserId = await ensureAuthenticatedUser(identity);
  const account = await getAccountContext(appUserId);
  const fileId = new URL(request.url).searchParams.get('id') ?? '';
  const file = await env.DB.prepare(
    `SELECT id, owner_user_id AS ownerUserId, entity_type AS entityType, entity_id AS entityId, r2_key AS r2Key,
            filename, content_type AS contentType, organization_id AS organizationId
     FROM files WHERE id = ? LIMIT 1`,
  ).bind(fileId).first<{
    id: string; ownerUserId: string | null; entityType: string; entityId: string; r2Key: string;
    filename: string; contentType: string; organizationId: string | null;
  }>();
  if (!file) return Response.json({ error: 'File not found.' }, { status: 404 });

  let allowed = file.ownerUserId === appUserId;
  if (!allowed && account.organization && canOrganizationRole(account.organization.roleKey, 'view_pipeline')) {
    if (file.organizationId === account.organization.id && file.entityType === 'resume_comparison') allowed = true;
    else {
      const linked = await env.DB.prepare(
        `SELECT 1 AS allowed
         FROM organization_candidates oc
         JOIN applications a ON a.organization_candidate_id = oc.id
         WHERE oc.candidate_profile_id = ? AND a.organization_id = ?
           AND json_extract(a.profile_snapshot_json, '$.resume.id') = ? LIMIT 1`,
      ).bind(file.entityId, account.organization.id, file.id).first();
      allowed = Boolean(linked);
    }
  }
  if (!allowed) return Response.json({ error: 'You do not have access to this file.' }, { status: 403 });

  const object = await env.FILES.get(file.r2Key);
  if (!object) return Response.json({ error: 'File not found.' }, { status: 404 });
  return new Response(object.body, {
    headers: {
      'content-type': file.contentType,
      'content-disposition': `attachment; filename="${file.filename.replace(/[^a-zA-Z0-9._-]/g, '_')}"; filename*=UTF-8''${encodeURIComponent(file.filename)}`,
      'cache-control': 'private, no-store',
      'content-security-policy': "sandbox; default-src 'none'; object-src 'self'",
      'x-content-type-options': 'nosniff',
    },
  });
}
