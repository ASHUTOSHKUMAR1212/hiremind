import { env } from 'cloudflare:workers';
import { calculateProfileCompletion, getProfileQualityWarnings } from '@/lib/profile-quality';

import { getAccountContext } from '@/lib/account';
import { ensureAuthenticatedUser } from '@/lib/authenticated-user';
import { getHireMindIdentity } from '@/lib/supabase/server';

type ExperienceInput = {
  title?: unknown;
  organizationName?: unknown;
  description?: unknown;
  startedOn?: unknown;
  endedOn?: unknown;
  isCurrent?: unknown;
};

type EducationInput = {
  institution?: unknown;
  qualification?: unknown;
  fieldOfStudy?: unknown;
  startedOn?: unknown;
  endedOn?: unknown;
};

type ProjectInput = {
  title?: unknown;
  description?: unknown;
  projectUrl?: unknown;
  repositoryUrl?: unknown;
  skills?: unknown;
};

async function requireCandidate(request: Request) {
  const identity = await getHireMindIdentity(request);
  if (!identity) return null;
  const appUserId = await ensureAuthenticatedUser(identity);
  const account = await getAccountContext(appUserId);
  if (!account.candidate) return null;
  return { identity, appUserId, candidate: account.candidate };
}

export async function GET(request: Request) {
  const context = await requireCandidate(request);
  if (!context) return Response.json({ error: 'Candidate account required.' }, { status: 403 });

  const candidateId = context.candidate.id;
  const [profile, experiences, education, projects, resume] = await Promise.all([
    env.DB.prepare(
      `SELECT id, profile_type AS profileType, full_name AS fullName, primary_email AS primaryEmail,
              phone, headline, summary, location, work_authorization AS workAuthorization,
              availability, visibility, metadata_json AS metadataJson
       FROM candidate_profiles WHERE id = ? LIMIT 1`,
    ).bind(candidateId).first<Record<string, unknown>>(),
    env.DB.prepare(
      `SELECT id, title, organization_name AS organizationName, description,
              started_on AS startedOn, ended_on AS endedOn, is_current AS isCurrent
       FROM candidate_experiences WHERE candidate_profile_id = ?
       ORDER BY sort_order, created_at`,
    ).bind(candidateId).all(),
    env.DB.prepare(
      `SELECT id, institution, qualification, field_of_study AS fieldOfStudy,
              started_on AS startedOn, ended_on AS endedOn
       FROM candidate_education WHERE candidate_profile_id = ? ORDER BY created_at`,
    ).bind(candidateId).all(),
    env.DB.prepare(
      `SELECT id, title, description, project_url AS projectUrl, repository_url AS repositoryUrl,
              skills_json AS skillsJson
       FROM candidate_projects WHERE candidate_profile_id = ? ORDER BY created_at`,
    ).bind(candidateId).all(),
    env.DB.prepare(
      `SELECT id, filename, content_type AS contentType, size_bytes AS sizeBytes, created_at AS createdAt
       FROM files WHERE entity_type = 'candidate_resume' AND entity_id = ?
       ORDER BY created_at DESC LIMIT 1`,
    ).bind(candidateId).first<Record<string, unknown>>(),
  ]);

  if (!profile) return Response.json({ error: 'Candidate profile not found.' }, { status: 404 });
  const metadata = safeJson(profile.metadataJson);
  const normalizedProjects = projects.results.map((project) => ({
    ...project,
    skills: safeArray(project.skillsJson),
    skillsJson: undefined,
  }));
  const profileData = {
    ...profile,
    skills: safeArray(metadata.skills),
    experiences: experiences.results,
    education: education.results,
    projects: normalizedProjects,
    resume,
  };
  const completion = calculateProfileCompletion(profileData);

  return Response.json({
    profile: {
      ...profile,
      metadataJson: undefined,
      skills: safeArray(metadata.skills),
      resumeText: typeof metadata.resumeText === 'string' ? metadata.resumeText : '',
      resumeTextExtracted: metadata.resumeTextExtracted === true,
      futureRoleConsent: metadata.futureRoleConsent === true,
    },
    experiences: experiences.results,
    education: education.results,
    projects: normalizedProjects,
    resume: resume ?? null,
    completion,
    qualityWarnings: getProfileQualityWarnings(profileData),
  });
}

export async function PUT(request: Request) {
  const context = await requireCandidate(request);
  if (!context) return Response.json({ error: 'Candidate account required.' }, { status: 403 });

  const submitted = await request.json() as Record<string, unknown>;
  if ('futureRoleConsent' in submitted && typeof submitted.futureRoleConsent !== 'boolean') {
    return Response.json({ error: 'Future-role consent must be true or false.' }, { status: 400 });
  }
  const existing = await env.DB.prepare(
    `SELECT full_name AS fullName, profile_type AS profileType, phone, headline, summary, location,
            work_authorization AS workAuthorization, availability, metadata_json AS metadataJson
     FROM candidate_profiles WHERE id = ? LIMIT 1`,
  ).bind(context.candidate.id).first<Record<string, unknown>>();
  if (!existing) return Response.json({ error: 'Candidate profile not found.' }, { status: 404 });
  for (const section of ['experiences', 'education', 'projects', 'skills']) {
    if (section in submitted && !Array.isArray(submitted[section])) {
      return Response.json({ error: `Invalid ${section}. Reload your profile and try again.` }, { status: 400 });
    }
  }
  // Omitted fields are not an instruction to erase existing evidence.
  const payload: Record<string, unknown> = { ...existing, skills: safeJson(existing.metadataJson).skills ?? [], ...submitted };
  const fullName = clean(payload.fullName, 100);
  const profileType = ['fresher', 'experienced', 'returner'].includes(String(payload.profileType))
    ? String(payload.profileType)
    : 'fresher';
  if (fullName.length < 2) {
    return Response.json({ error: 'Add your full name.' }, { status: 400 });
  }

  const skills = safeArray(payload.skills).map((skill) => clean(skill, 60)).filter(Boolean).slice(0, 30);
  const experiences = Array.isArray(payload.experiences) ? payload.experiences.slice(0, 12) as ExperienceInput[] : [];
  const education = Array.isArray(payload.education) ? payload.education.slice(0, 8) as EducationInput[] : [];
  const projects = Array.isArray(payload.projects) ? payload.projects.slice(0, 12) as ProjectInput[] : [];
  const candidateId = context.candidate.id;
  const now = Date.now();
  const current = await env.DB.prepare(
    `SELECT metadata_json AS metadataJson FROM candidate_profiles WHERE id = ? LIMIT 1`,
  ).bind(candidateId).first<{ metadataJson: string | null }>();
  const nextMetadata = { ...safeJson(current?.metadataJson), skills,
    ...('futureRoleConsent' in submitted ? { futureRoleConsent: submitted.futureRoleConsent, futureRoleConsentUpdatedAt: now } : {}),
  };

  const statements = [
    env.DB.prepare(
      `UPDATE candidate_profiles SET profile_type = ?, full_name = ?, phone = ?, headline = ?,
              summary = ?, location = ?, work_authorization = ?, availability = ?, metadata_json = ?, updated_at = ?
       WHERE id = ?`,
    ).bind(
      profileType,
      fullName,
      nullable(clean(payload.phone, 30)),
      nullable(clean(payload.headline, 140)),
      nullable(clean(payload.summary, 1200)),
      nullable(clean(payload.location, 120)),
      nullable(clean(payload.workAuthorization, 120)),
      nullable(clean(payload.availability, 120)),
      JSON.stringify(nextMetadata),
      now,
      candidateId,
    ),
    env.DB.prepare('UPDATE users SET full_name = ?, updated_at = ? WHERE id = ?').bind(fullName, now, context.appUserId),
    ...('experiences' in submitted ? [env.DB.prepare('DELETE FROM candidate_experiences WHERE candidate_profile_id = ?').bind(candidateId)] : []),
    ...('education' in submitted ? [env.DB.prepare('DELETE FROM candidate_education WHERE candidate_profile_id = ?').bind(candidateId)] : []),
    ...('projects' in submitted ? [env.DB.prepare('DELETE FROM candidate_projects WHERE candidate_profile_id = ?').bind(candidateId)] : []),
  ];

  experiences.forEach((item, index) => {
    const title = clean(item.title, 140);
    if (!title) return;
    statements.push(env.DB.prepare(
      `INSERT INTO candidate_experiences
       (id, candidate_profile_id, experience_type, organization_name, title, description,
        started_on, ended_on, is_current, source_type, verification_status, sort_order, created_at, updated_at)
       VALUES (?, ?, 'work', ?, ?, ?, ?, ?, ?, 'candidate', 'self_attested', ?, ?, ?)`,
    ).bind(
      `experience_${crypto.randomUUID()}`,
      candidateId,
      nullable(clean(item.organizationName, 140)),
      title,
      nullable(clean(item.description, 1200)),
      nullable(clean(item.startedOn, 20)),
      nullable(clean(item.endedOn, 20)),
      item.isCurrent ? 1 : 0,
      index,
      now,
      now,
    ));
  });

  education.forEach((item) => {
    const institution = clean(item.institution, 160);
    if (!institution) return;
    statements.push(env.DB.prepare(
      `INSERT INTO candidate_education
       (id, candidate_profile_id, institution, qualification, field_of_study,
        started_on, ended_on, verification_status, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'self_attested', ?, ?)`,
    ).bind(
      `education_${crypto.randomUUID()}`,
      candidateId,
      institution,
      nullable(clean(item.qualification, 120)),
      nullable(clean(item.fieldOfStudy, 120)),
      nullable(clean(item.startedOn, 20)),
      nullable(clean(item.endedOn, 20)),
      now,
      now,
    ));
  });

  projects.forEach((item) => {
    const title = clean(item.title, 160);
    if (!title) return;
    const projectSkills = safeArray(item.skills).map((skill) => clean(skill, 60)).filter(Boolean).slice(0, 20);
    statements.push(env.DB.prepare(
      `INSERT INTO candidate_projects
       (id, candidate_profile_id, title, description, project_url, repository_url,
        skills_json, outcomes_json, verification_status, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, NULL, 'self_attested', ?, ?)`,
    ).bind(
      `project_${crypto.randomUUID()}`,
      candidateId,
      title,
      nullable(clean(item.description, 1500)),
      nullable(clean(item.projectUrl, 500)),
      nullable(clean(item.repositoryUrl, 500)),
      JSON.stringify(projectSkills),
      now,
      now,
    ));
  });

  await env.DB.batch(statements);
  return Response.json({ saved: true });
}

function clean(value: unknown, maxLength: number) {
  return (typeof value === 'string' || typeof value === 'number' ? `${value}` : '').trim().replace(/\s+/g, ' ').slice(0, maxLength);
}

function nullable(value: string) {
  return value || null;
}

function safeJson(value: unknown): Record<string, unknown> {
  if (typeof value === 'object' && value !== null) return value as Record<string, unknown>;
  if (typeof value !== 'string') return {};
  try { return JSON.parse(value) as Record<string, unknown>; } catch { return {}; }
}

function safeArray(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  if (typeof value !== 'string') return [];
  try {
    const parsed = JSON.parse(value) as unknown;
    return Array.isArray(parsed) ? parsed : [];
  } catch { return []; }
}
