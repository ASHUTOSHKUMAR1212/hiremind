import { env } from 'cloudflare:workers';

import { getAccountContext } from '@/lib/account';
import { ensureAuthenticatedUser } from '@/lib/authenticated-user';
import { hasExpectedDocumentSignature, hasValidDocxContainer } from '@/lib/file-security';
import { getHireMindIdentity } from '@/lib/supabase/server';

export async function POST(request: Request) {
  const identity = await getHireMindIdentity(request);
  if (!identity) return Response.json({ error: 'Sign in required.' }, { status: 401 });
  const appUserId = await ensureAuthenticatedUser(identity);
  const account = await getAccountContext(appUserId);
  if (!account.candidate) return Response.json({ error: 'Candidate account required.' }, { status: 403 });

  const form = await request.formData();
  const upload = form.get('resume');
  if (!(upload instanceof File)) return Response.json({ error: 'Choose a résumé file.' }, { status: 400 });
  const extension = upload.name.toLowerCase().match(/\.(pdf|doc|docx)$/)?.[1] ?? '';
  if (!extension) return Response.json({ error: 'Upload a PDF, DOC, or DOCX résumé.' }, { status: 400 });
  if (upload.size > 5 * 1024 * 1024) return Response.json({ error: 'Résumé must be 5 MB or smaller.' }, { status: 400 });
  const uploadBytes = new Uint8Array(await upload.arrayBuffer());
  if (!hasExpectedDocumentSignature(uploadBytes, extension)) return Response.json({ error: 'This file does not appear to be a valid PDF, DOC, or DOCX résumé.' }, { status: 400 });
  if (extension === 'docx' && !hasValidDocxContainer(uploadBytes)) return Response.json({ error: 'This Word file is damaged, encrypted, or too large when unpacked. Export it as a new DOCX or text-based PDF.' }, { status: 400 });
  const extractedTextValue = form.get('extractedText');
  const extractedText = typeof extractedTextValue === 'string' ? normalizeText(extractedTextValue).slice(0, 50_000) : '';
  const textExtracted = extractedText.replace(/[^a-zA-Z0-9]/g, '').length >= 40;

  const [oldFiles, profile] = await Promise.all([env.DB.prepare(
    `SELECT id, r2_key AS r2Key FROM files
     WHERE entity_type = 'candidate_resume' AND entity_id = ?
       AND NOT EXISTS (SELECT 1 FROM applications a WHERE json_extract(a.profile_snapshot_json, '$.resume.id') = files.id)`,
  ).bind(account.candidate.id).all<{ id: string; r2Key: string }>(), env.DB.prepare(
    `SELECT metadata_json AS metadataJson FROM candidate_profiles WHERE id = ? LIMIT 1`,
  ).bind(account.candidate.id).first<{ metadataJson: string | null }>()]);

  const id = `file_${crypto.randomUUID()}`;
  const safeName = upload.name.replace(/[^a-zA-Z0-9._-]+/g, '-').slice(-120) || 'resume.pdf';
  const key = `candidate-resumes/${account.candidate.id}/${id}-${safeName}`;
  const contentType = extension === 'pdf' ? 'application/pdf' : extension === 'docx' ? 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' : 'application/msword';
  await env.FILES.put(key, uploadBytes, { httpMetadata: { contentType } });
  const now = Date.now();
  const metadata = safeJson(profile?.metadataJson);
  const nextMetadata = {
    ...metadata,
    resumeText: textExtracted ? extractedText : '',
    resumeTextExtracted: textExtracted,
    resumeTextUpdatedAt: now,
  };
  try {
    await env.DB.batch([
      env.DB.prepare(
        `DELETE FROM files WHERE entity_type = 'candidate_resume' AND entity_id = ?
         AND NOT EXISTS (SELECT 1 FROM applications a WHERE json_extract(a.profile_snapshot_json, '$.resume.id') = files.id)`,
      ).bind(account.candidate.id),
      env.DB.prepare(
        `INSERT INTO files
         (id, organization_id, owner_user_id, entity_type, entity_id, r2_key, filename,
          content_type, size_bytes, processing_status, created_at, updated_at)
         VALUES (?, NULL, ?, 'candidate_resume', ?, ?, ?, ?, ?, 'stored', ?, ?)`,
      ).bind(id, appUserId, account.candidate.id, key, upload.name.slice(0, 180), contentType, upload.size, now, now),
      env.DB.prepare(
        `UPDATE candidate_profiles SET metadata_json = ?, updated_at = ? WHERE id = ?`,
      ).bind(JSON.stringify(nextMetadata), now, account.candidate.id),
    ]);
  } catch (error) {
    await env.FILES.delete(key);
    throw error;
  }
  await Promise.all(oldFiles.results.map((file) => env.FILES.delete(file.r2Key)));

  return Response.json({ id, filename: upload.name, sizeBytes: upload.size, textExtracted, textLength: textExtracted ? extractedText.length : 0 }, { status: 201 });
}

function normalizeText(value: string) {
  return value.replaceAll('\u0000', ' ').replace(/[ \t]+/g, ' ').replace(/\s*\n\s*/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
}

function safeJson(value: unknown): Record<string, unknown> {
  if (typeof value === 'object' && value !== null) return value as Record<string, unknown>;
  if (typeof value !== 'string') return {};
  try { return JSON.parse(value) as Record<string, unknown>; } catch { return {}; }
}
