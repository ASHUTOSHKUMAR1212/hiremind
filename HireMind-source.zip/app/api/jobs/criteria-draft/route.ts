import { getAccountContext } from '@/lib/account';
import { ensureAuthenticatedUser } from '@/lib/authenticated-user';
import { draftJobCriteria } from '@/lib/job-criteria';
import { canOrganizationRole } from '@/lib/organization-permissions';
import { getHireMindIdentity } from '@/lib/supabase/server';

export async function POST(request: Request) {
  const identity = await getHireMindIdentity(request);
  if (!identity) return Response.json({ error: 'Sign in required.' }, { status: 401 });
  const appUserId = await ensureAuthenticatedUser(identity);
  const account = await getAccountContext(appUserId);
  if (!account.organization) return Response.json({ error: 'Employer account required.' }, { status: 403 });
  if (!canOrganizationRole(account.organization.roleKey, 'manage_jobs')) return Response.json({ error: 'Your team role cannot draft job criteria.' }, { status: 403 });

  const payload = await request.json() as Record<string, unknown>;
  const title = clean(payload.title, 120);
  const description = cleanMultiline(payload.description, 5000);
  if (description.length < 40) return Response.json({ error: 'Add at least 40 characters of job context before drafting criteria.' }, { status: 400 });
  const draft = draftJobCriteria(title, description);
  return Response.json({ ...draft, generatedBy: 'transparent-description-analysis', requiresEmployerApproval: true });
}

function clean(value: unknown, maxLength: number) {
  return (typeof value === 'string' || typeof value === 'number' ? `${value}` : '').trim().replace(/\s+/g, ' ').slice(0, maxLength);
}

function cleanMultiline(value: unknown, maxLength: number) {
  return (typeof value === 'string' ? value : '').replaceAll('\u0000', '').trim().slice(0, maxLength);
}
