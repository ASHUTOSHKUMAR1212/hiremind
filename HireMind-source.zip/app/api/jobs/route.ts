import { env } from 'cloudflare:workers';

import { getAccountContext } from '@/lib/account';
import { ensureAuthenticatedUser } from '@/lib/authenticated-user';
import { canOrganizationRole } from '@/lib/organization-permissions';
import { getHireMindIdentity } from '@/lib/supabase/server';

export async function GET() {
  const [result, criteria] = await Promise.all([
    env.DB.prepare(
      `SELECT j.id, j.title, j.description, j.location,
            j.workplace_type AS workplaceType,
            j.employment_type AS employmentType,
            j.experience_policy AS experiencePolicy,
            j.published_at AS publishedAt,
            o.name AS companyName
     FROM jobs j
     JOIN organizations o ON o.id = j.organization_id
     WHERE j.status = 'published' AND j.created_by_user_id IS NOT NULL
     ORDER BY j.published_at DESC
     LIMIT 24`,
    ).all(),
    env.DB.prepare(
      `SELECT c.id, c.job_id AS jobId, c.label, c.requirement_class AS requirementClass,
              c.weight, c.evidence_definition AS evidenceDefinition,
              c.equivalent_signals_json AS equivalentSignalsJson
       FROM job_criteria c JOIN jobs j ON j.id = c.job_id
       WHERE j.status = 'published' AND j.created_by_user_id IS NOT NULL AND c.is_active = 1
       ORDER BY c.job_id, c.sort_order`,
    ).all(),
  ]);

  return Response.json({
    jobs: result.results.map((job) => ({
      ...job,
      criteria: criteria.results
        .filter((criterion) => criterion.jobId === job.id)
        .map((criterion) => ({
          ...criterion,
          equivalentSignals: safeArray(criterion.equivalentSignalsJson),
          equivalentSignalsJson: undefined,
        })),
    })),
  });
}

export async function POST(request: Request) {
  const user = await getHireMindIdentity(request);
  if (!user)
    return Response.json({ error: 'Sign in required.' }, { status: 401 });

  const appUserId = await ensureAuthenticatedUser(user);
  const account = await getAccountContext(appUserId);
  if (!account.organization) {
    return Response.json(
      { error: 'Employer account required.' },
      { status: 403 },
    );
  }
  if (!canOrganizationRole(account.organization.roleKey, 'manage_jobs')) {
    return Response.json(
      { error: 'Your team role cannot create jobs.' },
      { status: 403 },
    );
  }

  const payload = (await request.json()) as Record<string, unknown>;
  const title = clean(payload.title, 120);
  const description = clean(payload.description, 5000);
  const location = clean(payload.location, 120);
  const workplaceType = ['remote', 'hybrid', 'on-site'].includes(
    String(payload.workplaceType),
  )
    ? String(payload.workplaceType)
    : 'hybrid';
  const employmentType = [
    'full-time',
    'part-time',
    'contract',
    'internship',
  ].includes(String(payload.employmentType))
    ? String(payload.employmentType)
    : 'full-time';
  const criteria = normalizeCriteria(payload.criteria);

  if (!criteria.length)
    return Response.json(
      {
        error:
          'Add and review at least one job-specific criterion before publishing.',
      },
      { status: 400 },
    );

  if (title.length < 3 || description.length < 20) {
    return Response.json(
      { error: 'Add a job title and a description of at least 20 characters.' },
      { status: 400 },
    );
  }

  const now = Date.now();
  const id = `job_${crypto.randomUUID()}`;
  const slug = `${slugify(title) || 'role'}-${crypto.randomUUID().slice(0, 8)}`;
  const statements = [
    env.DB.prepare(
      `INSERT INTO jobs
     (id, organization_id, title, slug, status, description, location, workplace_type,
      employment_type, experience_policy, published_at, created_by_user_id, created_at, updated_at)
     VALUES (?, ?, ?, ?, 'published', ?, ?, ?, ?, 'evidence_first', ?, ?, ?, ?)`,
    ).bind(
      id,
      account.organization.id,
      title,
      slug,
      description,
      location || null,
      workplaceType,
      employmentType,
      now,
      appUserId,
      now,
      now,
    ),
  ];

  criteria.forEach((criterion, index) => {
    statements.push(
      env.DB.prepare(
        `INSERT INTO job_criteria
       (id, job_id, version, label, criterion_type, requirement_class, weight,
        evidence_definition, equivalent_signals_json, is_active, sort_order, created_at, updated_at)
       VALUES (?, ?, 1, ?, 'competency', ?, ?, ?, ?, 1, ?, ?, ?)`,
      ).bind(
        `criterion_${crypto.randomUUID()}`,
        id,
        criterion.label,
        criterion.requirementClass,
        criterion.weight,
        criterion.evidenceDefinition,
        JSON.stringify(criterion.equivalentSignals),
        index,
        now,
        now,
      ),
    );
  });
  statements.push(
    auditStatement(
      account.organization.id,
      appUserId,
      'job_created',
      id,
      { title, status: 'published', criteriaCount: criteria.length },
      now,
    ),
  );
  await env.DB.batch(statements);

  return Response.json(
    { id, title, status: 'published', criteriaCount: criteria.length },
    { status: 201 },
  );
}

export async function PATCH(request: Request) {
  const user = await getHireMindIdentity(request);
  if (!user)
    return Response.json({ error: 'Sign in required.' }, { status: 401 });
  const appUserId = await ensureAuthenticatedUser(user);
  const account = await getAccountContext(appUserId);
  if (!account.organization)
    return Response.json(
      { error: 'Employer account required.' },
      { status: 403 },
    );
  if (!canOrganizationRole(account.organization.roleKey, 'manage_jobs'))
    return Response.json(
      { error: 'Your team role cannot change jobs.' },
      { status: 403 },
    );

  const payload = (await request.json()) as Record<string, unknown>;
  const id = clean(payload.id, 200);
  if (!id)
    return Response.json({ error: 'Choose a valid job.' }, { status: 400 });

  if ('title' in payload || 'description' in payload || 'criteria' in payload) {
    return updateJobBrief(payload, id, account.organization.id, appUserId);
  }

  const status = ['published', 'paused', 'closed'].includes(
    String(payload.status),
  )
    ? String(payload.status)
    : '';
  if (!status)
    return Response.json(
      { error: 'Choose a valid job status.' },
      { status: 400 },
    );
  const now = Date.now();
  const existing = await env.DB.prepare(
    `SELECT status FROM jobs WHERE id = ? AND organization_id = ? LIMIT 1`,
  )
    .bind(id, account.organization.id)
    .first<{ status: string }>();
  if (!existing)
    return Response.json({ error: 'Job not found.' }, { status: 404 });
  const result = await env.DB.batch([
    env.DB.prepare(
      `UPDATE jobs SET status = ?, closed_at = ?, updated_at = ?
     WHERE id = ? AND organization_id = ? AND status = ?`,
    ).bind(
      status,
      status === 'closed' ? now : null,
      now,
      id,
      account.organization.id,
      existing.status,
    ),
    auditStatement(
      account.organization.id,
      appUserId,
      'job_status_changed',
      id,
      { from: existing.status, to: status },
      now,
    ),
  ]);
  if (!result[0]?.meta.changes)
    return Response.json(
      { error: 'Job changed; refresh and try again.' },
      { status: 409 },
    );
  return Response.json({ id, status });
}

async function updateJobBrief(
  payload: Record<string, unknown>,
  id: string,
  organizationId: string,
  actorUserId: string,
) {
  const title = clean(payload.title, 120);
  const description = clean(payload.description, 5000);
  const location = clean(payload.location, 120);
  const workplaceType = ['remote', 'hybrid', 'on-site'].includes(
    String(payload.workplaceType),
  )
    ? String(payload.workplaceType)
    : 'hybrid';
  const employmentType = [
    'full-time',
    'part-time',
    'contract',
    'internship',
  ].includes(String(payload.employmentType))
    ? String(payload.employmentType)
    : 'full-time';
  const criteria = normalizeCriteria(payload.criteria);
  if (!criteria.length)
    return Response.json(
      {
        error:
          'Keep at least one reviewed job-specific criterion. Your existing role has not been changed.',
      },
      { status: 400 },
    );
  if (title.length < 3 || description.length < 20)
    return Response.json(
      { error: 'Add a job title and a description of at least 20 characters.' },
      { status: 400 },
    );

  const existing = await env.DB.prepare(
    `SELECT j.id, COALESCE(MAX(c.version), 0) AS criteriaVersion
     FROM jobs j LEFT JOIN job_criteria c ON c.job_id = j.id
     WHERE j.id = ? AND j.organization_id = ? GROUP BY j.id`,
  )
    .bind(id, organizationId)
    .first<{ id: string; criteriaVersion: number }>();
  if (!existing)
    return Response.json({ error: 'Job not found.' }, { status: 404 });

  const now = Date.now();
  const version = Number(existing.criteriaVersion) + 1;
  const statements = [
    env.DB.prepare(
      `UPDATE jobs SET title = ?, description = ?, location = ?, workplace_type = ?, employment_type = ?, updated_at = ?
       WHERE id = ? AND organization_id = ?`,
    ).bind(
      title,
      description,
      location || null,
      workplaceType,
      employmentType,
      now,
      id,
      organizationId,
    ),
    env.DB.prepare(
      'UPDATE job_criteria SET is_active = 0, updated_at = ? WHERE job_id = ? AND is_active = 1',
    ).bind(now, id),
  ];
  criteria.forEach((criterion, index) =>
    statements.push(
      env.DB.prepare(
        `INSERT INTO job_criteria
     (id, job_id, version, label, criterion_type, requirement_class, weight,
      evidence_definition, equivalent_signals_json, is_active, sort_order, created_at, updated_at)
     VALUES (?, ?, ?, ?, 'competency', ?, ?, ?, ?, 1, ?, ?, ?)`,
      ).bind(
        `criterion_${crypto.randomUUID()}`,
        id,
        version,
        criterion.label,
        criterion.requirementClass,
        criterion.weight,
        criterion.evidenceDefinition,
        JSON.stringify(criterion.equivalentSignals),
        index,
        now,
        now,
      ),
    ),
  );
  statements.push(
    auditStatement(
      organizationId,
      actorUserId,
      'job_criteria_revised',
      id,
      { title, criteriaVersion: version, criteriaCount: criteria.length },
      now,
    ),
  );
  await env.DB.batch(statements);
  return Response.json({
    id,
    title,
    criteriaCount: criteria.length,
    criteriaVersion: version,
  });
}

function auditStatement(
  organizationId: string,
  actorUserId: string,
  action: string,
  entityId: string,
  payload: Record<string, unknown>,
  occurredAt: number,
) {
  return env.DB.prepare(
    `INSERT INTO audit_events
     (id, organization_id, actor_user_id, action, entity_type, entity_id, payload_json, occurred_at)
     VALUES (?, ?, ?, ?, 'job', ?, ?, ?)`,
  ).bind(
    `audit_${crypto.randomUUID()}`,
    organizationId,
    actorUserId || null,
    action,
    entityId,
    JSON.stringify(payload),
    occurredAt,
  );
}

function clean(value: unknown, maxLength: number) {
  return (
    typeof value === 'string' || typeof value === 'number' ? `${value}` : ''
  )
    .trim()
    .replace(/\s+/g, ' ')
    .slice(0, maxLength);
}

function slugify(value: string) {
  return value
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48);
}

function safeArray(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  if (typeof value !== 'string') return [];
  try {
    const parsed = JSON.parse(value) as unknown;
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function normalizeCriteria(value: unknown) {
  const provided = Array.isArray(value) ? value : [];
  const normalized = provided
    .map((item, index) => {
      const record =
        typeof item === 'object' && item !== null
          ? (item as Record<string, unknown>)
          : {};
      const label = clean(record.label, 120);
      return {
        label,
        requirementClass:
          record.requirementClass === 'preferred' ? 'preferred' : 'essential',
        weight: Math.max(
          1,
          Math.min(100, Number(record.weight) || (index < 3 ? 20 : 10)),
        ),
        evidenceDefinition: clean(record.evidenceDefinition || label, 500),
        equivalentSignals: Array.isArray(record.equivalentSignals)
          ? record.equivalentSignals
              .map((signal) => clean(signal, 100))
              .filter(Boolean)
              .slice(0, 10)
          : [],
      };
    })
    .filter((criterion) => criterion.label)
    .slice(0, 10);

  return normalized;
}
