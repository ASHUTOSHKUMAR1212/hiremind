import { env } from 'cloudflare:workers';
import { getAccountContext } from '@/lib/account';
import { ensureAuthenticatedUser } from '@/lib/authenticated-user';
import { getHireMindIdentity } from '@/lib/supabase/server';
import { canOrganizationRole } from '@/lib/organization-permissions';
import { talentSearchFilters, TALENT_PAGE_SIZE } from '@/lib/talent-search';
import {
  assessCandidateEvidence,
  buildRankingExplanation,
  type ScreeningCriterion,
} from '@/lib/evidence-screening';

export async function GET(request: Request) {
  try {
    return await loadTalent(request);
  } catch (error) {
    console.error(
      'Talent search unavailable',
      error instanceof Error ? error.name : 'UnknownError',
    );
    return Response.json(
      {
        error:
          'Talent search is temporarily unavailable. Your search was not changed. Please retry.',
      },
      { status: 503, headers: { 'Cache-Control': 'private, no-store' } },
    );
  }
}
async function loadTalent(request: Request) {
  const identity = await getHireMindIdentity(request);
  if (!identity)
    return Response.json({ error: 'Sign in required.' }, { status: 401 });
  const userId = await ensureAuthenticatedUser(identity);
  const account = await getAccountContext(userId);
  if (
    !account.organization ||
    !canOrganizationRole(account.organization.roleKey, 'review_candidates')
  ) {
    return Response.json(
      { error: 'Your account cannot review this talent pool.' },
      { status: 403 },
    );
  }
  let filters;
  try {
    filters = talentSearchFilters(new URL(request.url).searchParams);
  } catch (error) {
    return Response.json(
      { error: (error as Error).message },
      { status: 400, headers: { 'Cache-Control': 'private, no-store' } },
    );
  }
  const { jobId, terms, location, cursor, asOf } = filters;
  const job = await env.DB.prepare(
    'SELECT id, title FROM jobs WHERE id = ? AND organization_id = ? LIMIT 1',
  )
    .bind(jobId, account.organization.id)
    .first<{ id: string; title: string }>();
  if (!job) return Response.json({ error: 'Job not found.' }, { status: 404 });
  const criteria =
    await env.DB.prepare(`SELECT id, label, weight, requirement_class AS requirementClass,
    evidence_definition AS evidenceDefinition, equivalent_signals_json AS equivalentSignalsJson
    FROM job_criteria WHERE job_id = ? AND is_active = 1 ORDER BY sort_order`)
      .bind(jobId)
      .all<ScreeningCriterion>();
  if (!criteria.results.length)
    return Response.json(
      { error: 'Add job criteria before searching your talent pool.' },
      { status: 400 },
    );
  // Opt-in is checked live. Only previously submitted, same-company snapshots are read.
  // Choosing the latest application before filtering prevents a withdrawn profile resurfacing.
  const searchable = `lower(COALESCE(json_extract(snapshot, '$.fullName'), '') || ' ' || COALESCE(json_extract(snapshot, '$.headline'), '') || ' ' || previousJob || ' ' || COALESCE(json_extract(snapshot, '$.metadata.skills'), '') || ' ' || COALESCE(json_extract(snapshot, '$.skills'), ''))`;
  const records = await env.DB.prepare(`WITH previous AS (
    SELECT a.id, oc.id AS contactId, oc.candidate_profile_id, a.status, a.submitted_at,
      CASE WHEN json_valid(a.profile_snapshot_json) THEN a.profile_snapshot_json ELSE '{}' END AS snapshot, j.title AS previousJob,
      ROW_NUMBER() OVER (PARTITION BY oc.candidate_profile_id ORDER BY a.submitted_at DESC, a.id DESC) AS position
    FROM applications a JOIN jobs j ON j.id = a.job_id AND j.organization_id = a.organization_id
    JOIN organization_candidates oc ON oc.id = a.organization_candidate_id AND oc.organization_id = j.organization_id
    JOIN candidate_profiles p ON p.id = oc.candidate_profile_id
    WHERE j.organization_id = ? AND oc.deleted_at IS NULL
      AND json_extract(CASE WHEN json_valid(p.metadata_json) THEN p.metadata_json ELSE '{}' END, '$.futureRoleConsent') = 1
  )
  SELECT id, submitted_at AS submittedAt, snapshot, previousJob
  FROM previous WHERE position = 1 AND status NOT IN ('withdrawn', 'hired', 'offer') AND submitted_at >= ? AND submitted_at <= ?
    AND NOT EXISTS (SELECT 1 FROM recruiter_relationships r WHERE r.candidate_id = previous.contactId AND r.suppressed = 1)
    AND NOT EXISTS (SELECT 1 FROM applications applied JOIN organization_candidates existing ON existing.id = applied.organization_candidate_id WHERE existing.candidate_profile_id = previous.candidate_profile_id AND applied.job_id = ?)
    ${terms.map(() => `AND instr(${searchable}, lower(?)) > 0`).join('\n')}
    AND instr(lower(COALESCE(json_extract(snapshot, '$.location'), '')), lower(?)) > 0
    ${cursor ? 'AND (submitted_at < ? OR (submitted_at = ? AND id < ?))' : ''}
  ORDER BY submitted_at DESC, id DESC LIMIT ?`)
    .bind(
      account.organization.id,
      Date.now() - 365 * 24 * 60 * 60 * 1000,
      asOf,
      jobId,
      ...terms,
      location,
      ...(cursor ? [cursor.at, cursor.at, cursor.id] : []),
      TALENT_PAGE_SIZE + 1,
    )
    .all<{
      id: string;
      submittedAt: number;
      snapshot: string;
      previousJob: string;
    }>();
  const items = records.results
    .slice(0, TALENT_PAGE_SIZE)
    .map((row) => {
      let profile: Record<string, unknown> = {};
      try {
        profile = JSON.parse(row.snapshot);
      } catch {
        /* Missing evidence stays unknown. */
      }
      if (!profile || typeof profile !== 'object' || Array.isArray(profile))
        profile = {};
      const assessment = assessCandidateEvidence(profile, criteria.results);
      return {
        applicationId: row.id,
        candidateName:
          typeof profile.fullName === 'string' && profile.fullName.trim()
            ? profile.fullName
            : 'Unnamed candidate',
        headline: typeof profile.headline === 'string' ? profile.headline : '',
        location: typeof profile.location === 'string' ? profile.location : '',
        submittedAt: row.submittedAt,
        previousJob: row.previousJob,
        ...assessment,
        explanation: buildRankingExplanation(
          assessment.criterionResults,
          assessment.evidenceCoverage,
        ),
      };
    })
    .sort((a, b) => b.fitScore - a.fitScore || a.uncertainty - b.uncertainty);
  return Response.json(
    {
      job,
      items,
      nextCursor:
        records.results.length > TALENT_PAGE_SIZE
          ? JSON.stringify({
              at: records.results[TALENT_PAGE_SIZE - 1].submittedAt,
              id: records.results[TALENT_PAGE_SIZE - 1].id,
              asOf,
            })
          : null,
      pageSize: TALENT_PAGE_SIZE,
      filters: { jobId, q: filters.q, location },
      assessedAt: Date.now(),
    },
    { headers: { 'Cache-Control': 'private, no-store' } },
  );
}
