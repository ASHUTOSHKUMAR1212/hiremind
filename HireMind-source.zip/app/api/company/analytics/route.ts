import { env } from 'cloudflare:workers';
import { employerAccess, failure, json } from '@/lib/employer-tools-access';
import { canOrganizationRole } from '@/lib/organization-permissions';
import {
  parseAnalyticsFilters,
  summarizeHiring,
  type AnalyticsApplication,
  type AnalyticsEvent,
} from '@/lib/hiring-analytics';
import { MATCHING_ENGINE_VERSION } from '@/lib/evidence-screening';
import { csvCell } from '@/lib/csv';

export async function GET(request: Request) {
  const access = await employerAccess(request, 'view_pipeline');
  if ('error' in access) return access.error;
  let filters;
  try {
    filters = parseAnalyticsFilters(
      new URL(request.url).searchParams,
      Date.now(),
    );
  } catch (error) {
    return failure(error);
  }
  if (
    filters.format === 'csv' &&
    !canOrganizationRole(access.organization.roleKey, 'export_data')
  )
    return json({ error: 'Your team role cannot export reports.' }, 403);
  const { jobId, since, asOf } = filters;
  if (
    jobId &&
    !(await env.DB.prepare(
      'SELECT id FROM jobs WHERE id = ? AND organization_id = ?',
    )
      .bind(jobId, access.organization.id)
      .first())
  )
    return json({ error: 'Job not found.' }, 404);
  // Identical cohort boundary for every query. No names, contact details, or
  // profile text are needed for this report. Soft-deleted records are excluded.
  const cohort = `SELECT a.id, a.job_id, a.status, a.submitted_at, j.title
    FROM applications a JOIN jobs j ON j.id = a.job_id AND j.organization_id = a.organization_id
    JOIN organization_candidates oc ON oc.id = a.organization_candidate_id AND oc.organization_id = a.organization_id
    WHERE a.organization_id = ? AND oc.deleted_at IS NULL AND a.submitted_at >= ? AND a.submitted_at <= ?
      AND (? = '' OR a.job_id = ?)`;
  const bindings = [access.organization.id, since, asOf, jobId, jobId];
  const rows = await env.DB.prepare(
    `WITH cohort AS (${cohort}) SELECT id, job_id AS jobId, title AS jobTitle, status, submitted_at AS submittedAt FROM cohort ORDER BY submitted_at, id LIMIT 5001`,
  )
    .bind(...bindings)
    .all<AnalyticsApplication>();
  if (rows.results.length > 5000)
    return json(
      {
        error:
          'This cohort exceeds 5,000 applications. Choose a single job or a shorter period; no partial totals were calculated.',
      },
      422,
    );
  const events =
    await env.DB.prepare(`WITH cohort AS (${cohort}) SELECT e.application_id AS applicationId, e.from_status AS fromStatus, e.to_status AS toStatus, e.occurred_at AS occurredAt
    FROM application_events e JOIN cohort c ON c.id = e.application_id
    WHERE e.occurred_at >= c.submitted_at AND e.occurred_at <= ? AND (e.from_status IS NOT NULL OR e.to_status IS NOT NULL)
    ORDER BY e.occurred_at, e.id LIMIT 50001`)
      .bind(...bindings, asOf)
      .all<AnalyticsEvent>();
  if (events.results.length > 50000)
    return json(
      {
        error:
          'This cohort has too much event history. Choose a single job or a shorter period; no partial totals were calculated.',
      },
      422,
    );
  const summary = summarizeHiring(
    rows.results,
    events.results,
    asOf,
    filters.ageDays,
  );
  const coverage = await env.DB.prepare(`WITH cohort AS (${cohort}), latest AS (
    SELECT j.id AS job_id, (SELECT r.id FROM screening_runs r WHERE r.job_id = j.id AND r.status = 'completed'
      AND r.completed_at >= j.updated_at AND r.completed_at <= ? AND r.model_version = ? ORDER BY r.completed_at DESC, r.id DESC LIMIT 1) AS run_id
    FROM jobs j WHERE j.organization_id = ? AND (? = '' OR j.id = ?)
  ) SELECT k.id AS criterionId, k.job_id AS jobId, j.title AS jobTitle, k.label, k.requirement_class AS requirementClass,
    COUNT(c.id) AS applicants, COUNT(a.id) AS assessed,
    SUM(CASE WHEN a.classification = 'strong_evidence' THEN 1 ELSE 0 END) AS strong,
    SUM(CASE WHEN a.classification = 'partial_evidence' THEN 1 ELSE 0 END) AS partial,
    SUM(CASE WHEN a.classification = 'adjacent_evidence' THEN 1 ELSE 0 END) AS adjacent,
    SUM(CASE WHEN a.classification = 'insufficient_evidence' THEN 1 ELSE 0 END) AS insufficient
    FROM job_criteria k JOIN jobs j ON j.id = k.job_id JOIN latest l ON l.job_id = j.id
    JOIN cohort c ON c.job_id = j.id
    LEFT JOIN candidate_criterion_assessments a ON a.application_id = c.id AND a.criterion_id = k.id AND a.screening_run_id = l.run_id
    WHERE k.is_active = 1 GROUP BY k.id ORDER BY j.title, k.sort_order LIMIT 1001`)
    .bind(
      ...bindings,
      asOf,
      MATCHING_ENGINE_VERSION,
      access.organization.id,
      jobId,
      jobId,
    )
    .all<{
      criterionId: string;
      jobId: string;
      jobTitle: string;
      label: string;
      requirementClass: string;
      applicants: number;
      assessed: number;
      strong: number;
      partial: number;
      adjacent: number;
      insufficient: number;
    }>();
  if (coverage.results.length > 1000)
    return json(
      {
        error:
          'Choose a single job to review more than 1,000 criteria; no partial report was returned.',
      },
      422,
    );
  const report = {
    schemaVersion: 1,
    filters,
    summary,
    coverage: coverage.results.map((row) => ({
      ...row,
      unassessed: row.applicants - row.assessed,
    })),
    engineVersion: MATCHING_ENGINE_VERSION,
  };
  if (filters.format === 'csv') {
    const csv: unknown[][] = [
      [
        'HireMind hiring analytics',
        'Application cohort',
        `${filters.days} days`,
        'As of UTC',
        new Date(asOf).toISOString(),
      ],
      [
        'Cohort start UTC',
        new Date(since).toISOString(),
        'Job filter',
        jobId || 'All jobs',
      ],
      ['Metric', 'Value', 'Sample / denominator'],
      ['Applications', summary.total, summary.total],
      ['Active applications', summary.active, summary.total],
      [
        'Median days to first recorded review',
        summary.medianDaysToFirstReview,
        summary.firstReviewSample,
      ],
      [
        'Median days from application to recorded hire',
        summary.medianDaysToHire,
        summary.hireSample,
      ],
      [
        'Observed offer to hire percent',
        summary.offerToHirePercent,
        summary.offersObserved,
      ],
      [
        'Active applications with unknown stage age',
        summary.unknownAge,
        summary.active,
      ],
      [],
      [
        'Stage',
        'Ever observed',
        'Currently here',
        'Percent of cohort',
        'Median current age days',
        'Age sample',
      ],
      ...summary.stages.map((row) => [
        row.label,
        row.reached,
        row.current,
        row.cohortPercent,
        row.medianCurrentAgeDays,
        row.ageSample,
      ]),
      [],
      ['Outcome', 'Current count'],
      ['Rejected', summary.current.rejected],
      ['Withdrawn', summary.current.withdrawn],
      [],
      [
        'Job',
        'Criterion',
        'Requirement',
        'Cohort applicants',
        'Assessed',
        'Strong',
        'Partial',
        'Adjacent',
        'Insufficient',
        'Unassessed',
      ],
      ...report.coverage.map((row) => [
        row.jobTitle,
        row.label,
        row.requirementClass,
        row.applicants,
        row.assessed,
        row.strong,
        row.partial,
        row.adjacent,
        row.insufficient,
        row.unassessed,
      ]),
      [],
      [
        'Methodology',
        'Recorded states only; skipped stages are not inferred. Pending offers remain in the denominator. Missing/stale screening is unassessed, not evidence of missing skills. No candidate quality or fairness conclusion.',
      ],
    ];
    return new Response(
      csv.map((row) => row.map(csvCell).join(',')).join('\r\n'),
      {
        headers: {
          'content-type': 'text/csv; charset=utf-8',
          'cache-control': 'private, no-store',
          'content-disposition':
            'attachment; filename="hiremind-hiring-analytics.csv"',
        },
      },
    );
  }
  return json(report);
}
