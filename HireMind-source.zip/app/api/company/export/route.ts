import { env } from 'cloudflare:workers';

import { getAccountContext } from '@/lib/account';
import { ensureAuthenticatedUser } from '@/lib/authenticated-user';
import { csvCell } from '@/lib/csv';
import { MATCHING_ENGINE_VERSION } from '@/lib/evidence-screening';
import { canOrganizationRole } from '@/lib/organization-permissions';
import { getHireMindIdentity } from '@/lib/supabase/server';

export async function GET(request: Request) {
  const identity = await getHireMindIdentity(request);
  if (!identity)
    return Response.json({ error: 'Sign in required.' }, { status: 401 });
  const appUserId = await ensureAuthenticatedUser(identity);
  const account = await getAccountContext(appUserId);
  if (!account.organization)
    return Response.json(
      { error: 'Employer account required.' },
      { status: 403 },
    );
  if (!canOrganizationRole(account.organization.roleKey, 'export_data'))
    return Response.json(
      { error: 'Your team role cannot export candidate data.' },
      { status: 403 },
    );
  const jobId = new URL(request.url).searchParams.get('jobId') ?? '';
  const rows = await env.DB.prepare(
    `SELECT a.id AS applicationId, j.title AS jobTitle, oc.display_name AS candidateName,
            oc.primary_email AS candidateEmail, a.status, a.submitted_at AS submittedAt,
            ranking.fit_score AS fitScore, ranking.decision_band AS decisionBand,
            ranking.evidence_coverage AS evidenceCoverage, ranking.uncertainty,
            ranking.explanation AS screeningExplanation,
            interview.mode AS interviewMode, interview.status AS interviewStatus,
            interview.scheduled_at AS interviewScheduledAt,
            (
              SELECT event.note FROM application_events event
              WHERE event.application_id = a.id
                AND event.event_type IN ('offer_recorded', 'candidate_hired', 'application_rejected')
              ORDER BY event.occurred_at DESC LIMIT 1
            ) AS decisionNote
     FROM applications a JOIN jobs j ON j.id = a.job_id
     JOIN organization_candidates oc ON oc.id = a.organization_candidate_id
     LEFT JOIN shortlist_rankings ranking ON ranking.application_id = a.id
       AND ranking.screening_run_id = (SELECT id FROM screening_runs WHERE job_id = a.job_id AND status = 'completed' AND completed_at >= j.updated_at AND model_version = ? ORDER BY completed_at DESC LIMIT 1)
     LEFT JOIN interview_sessions interview ON interview.id = (SELECT id FROM interview_sessions WHERE application_id = a.id ORDER BY created_at DESC LIMIT 1)
     WHERE a.organization_id = ? AND (? = '' OR a.job_id = ?)
     ORDER BY j.title, a.submitted_at DESC`,
  )
    .bind(MATCHING_ENGINE_VERSION, account.organization.id, jobId, jobId)
    .all<Record<string, unknown>>();
  const columns = [
    'applicationId',
    'jobTitle',
    'candidateName',
    'candidateEmail',
    'status',
    'submittedAt',
    'fitScore',
    'decisionBand',
    'evidenceCoverage',
    'uncertainty',
    'screeningExplanation',
    'interviewMode',
    'interviewStatus',
    'interviewScheduledAt',
    'decisionNote',
  ];
  const dateColumns = new Set(['submittedAt', 'interviewScheduledAt']);
  const csv = [
    columns.join(','),
    ...rows.results.map((row) =>
      columns
        .map((column) =>
          csvCell(
            dateColumns.has(column) && row[column]
              ? new Date(Number(row[column])).toISOString()
              : row[column],
          ),
        )
        .join(','),
    ),
  ].join('\r\n');
  const filename = jobId
    ? `hiremind-${jobId.replace(/[^a-z0-9_-]/gi, '').slice(0, 50)}-applications.csv`
    : 'hiremind-all-applications.csv';
  return new Response(csv, {
    headers: {
      'content-type': 'text/csv; charset=utf-8',
      'content-disposition': `attachment; filename="${filename}"`,
      'cache-control': 'private, no-store',
    },
  });
}
