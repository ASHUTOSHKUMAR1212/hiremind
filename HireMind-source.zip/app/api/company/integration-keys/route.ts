import { env } from 'cloudflare:workers';
import {
  employerAccess,
  failure,
  json,
  readPayload,
  auditStatement,
} from '@/lib/employer-tools-access';
import { hashIntegrationToken, INTEGRATION_SCOPES } from '@/lib/integrations';

export async function GET(request: Request) {
  const access = await employerAccess(request, 'manage_team');
  if (access.error) return access.error;
  const rows = await env.DB.prepare(
    'SELECT id, label, scopes_json AS scopesJson, created_at AS createdAt, expires_at AS expiresAt, revoked_at AS revokedAt, last_used_at AS lastUsedAt FROM integration_keys WHERE organization_id = ? ORDER BY created_at DESC LIMIT 100',
  )
    .bind(access.organization.id)
    .all<Record<string, unknown>>();
  return json({
    items: rows.results.map((row) => ({
      ...row,
      scopes: JSON.parse(String(row.scopesJson)),
      scopesJson: undefined,
    })),
  });
}
export async function POST(request: Request) {
  const access = await employerAccess(request, 'manage_team');
  if (access.error) return access.error;
  try {
    const payload = await readPayload(request, 5000);
    if (
      typeof payload.label !== 'string' ||
      !payload.label.trim() ||
      payload.label.length > 80 ||
      !Array.isArray(payload.scopes) ||
      !payload.scopes.length ||
      payload.scopes.some((scope) => !INTEGRATION_SCOPES.includes(scope))
    )
      throw new Error('Provide a label and select supported read-only scopes.');
    if (
      payload.scopes.includes('applications:read') &&
      payload.candidateDataConfirmed !== true
    )
      throw new Error(
        'Explicitly authorize candidate-data access for this integration.',
      );
    const now = Date.now();
    const id = crypto.randomUUID();
    const token =
      'hm_' +
      [...crypto.getRandomValues(new Uint8Array(32))]
        .map((x) => x.toString(16).padStart(2, '0'))
        .join('');
    const result = await env.DB.prepare(
      'INSERT INTO integration_keys (id, organization_id, label, token_hash, scopes_json, created_at, expires_at) SELECT ?, ?, ?, ?, ?, ?, ? WHERE (SELECT COUNT(*) FROM integration_keys WHERE organization_id = ? AND revoked_at IS NULL AND expires_at > ?) < 5',
    )
      .bind(
        id,
        access.organization.id,
        payload.label.trim(),
        await hashIntegrationToken(token),
        JSON.stringify([...new Set(payload.scopes)]),
        now,
        now + 90 * 86400_000,
        access.organization.id,
        now,
      )
      .run();
    if (!result.meta.changes)
      return json(
        {
          error:
            'Revoke an existing key first. A company can have up to five active keys.',
        },
        409,
      );
    await auditStatement(
      access.organization.id,
      access.userId,
      'integration_key_created',
      id,
    ).run();
    return json({ id, token, expiresAt: now + 90 * 86400_000 }, 201);
  } catch (error) {
    return failure(error);
  }
}
export async function DELETE(request: Request) {
  const access = await employerAccess(request, 'manage_team');
  if (access.error) return access.error;
  const id = new URL(request.url).searchParams.get('id') ?? '';
  const result = await env.DB.prepare(
    'UPDATE integration_keys SET revoked_at = ? WHERE id = ? AND organization_id = ? AND revoked_at IS NULL',
  )
    .bind(Date.now(), id, access.organization.id)
    .run();
  if (!result.meta.changes)
    return json({ error: 'Active key not found.' }, 404);
  await auditStatement(
    access.organization.id,
    access.userId,
    'integration_key_revoked',
    id,
  ).run();
  return json({ revoked: true });
}
