import { env } from 'cloudflare:workers';

import { getAccountContext } from '@/lib/account';
import { ensureAuthenticatedUser } from '@/lib/authenticated-user';
import {
  assessCandidateEvidence,
  MATCHING_ENGINE_VERSION,
  buildRankingExplanation,
  type ScreeningCriterion,
} from '@/lib/evidence-screening';
import { canOrganizationRole } from '@/lib/organization-permissions';
import { getHireMindIdentity } from '@/lib/supabase/server';

type ApplicationRow = {
  id: string;
  status: string;
  profileSnapshotJson: string;
};

export async function POST(request: Request) {
  const identity = await getHireMindIdentity(request);
  if (!identity)
    return Response.json({ error: 'Sign in required.' }, { status: 401 });
  const appUserId = await ensureAuthenticatedUser(identity);
  const account = await getAccountContext(appUserId);
  if (!account.organization)
    return Response.json(
      { error: 'Employer account required.' },
      { status: 403 },
    );
  if (!canOrganizationRole(account.organization.roleKey, 'review_candidates'))
    return Response.json(
      { error: 'Your team role cannot run candidate screening.' },
      { status: 403 },
    );

  const payload = (await request.json()) as { jobId?: unknown };
  const jobId = typeof payload.jobId === 'string' ? payload.jobId : '';
  const job = await env.DB.prepare(
    `SELECT id, title, description FROM jobs WHERE id = ? AND organization_id = ? LIMIT 1`,
  )
    .bind(jobId, account.organization.id)
    .first<{ id: string; title: string; description: string }>();
  if (!job) return Response.json({ error: 'Job not found.' }, { status: 404 });

  const [criteriaResult, applicationsResult] = await Promise.all([
    env.DB.prepare(
      `SELECT id, version, label, weight, requirement_class AS requirementClass,
              evidence_definition AS evidenceDefinition,
              equivalent_signals_json AS equivalentSignalsJson
       FROM job_criteria WHERE job_id = ? AND is_active = 1 ORDER BY sort_order`,
    )
      .bind(jobId)
      .all<ScreeningCriterion>(),
    env.DB.prepare(
      `SELECT id, status, profile_snapshot_json AS profileSnapshotJson
       FROM applications WHERE job_id = ? AND status NOT IN ('rejected', 'withdrawn', 'hired')`,
    )
      .bind(jobId)
      .all<ApplicationRow>(),
  ]);
  if (!criteriaResult.results.length)
    return Response.json(
      { error: 'Add job criteria before screening.' },
      { status: 400 },
    );
  if (!applicationsResult.results.length)
    return Response.json(
      { error: 'No applicants to screen yet.' },
      { status: 400 },
    );

  const assessments = applicationsResult.results
    .map((application) => {
      const profile = safeJson(application.profileSnapshotJson);
      return {
        applicationId: application.id,
        previousStatus: application.status,
        ...assessCandidateEvidence(profile, criteriaResult.results),
      };
    })
    .sort((a, b) => b.fitScore - a.fitScore || a.uncertainty - b.uncertainty);

  const now = Date.now();
  const runId = `screening_${crypto.randomUUID()}`;
  const criteriaVersion = Math.max(
    1,
    ...criteriaResult.results.map(
      (criterion) =>
        Number(
          (criterion as ScreeningCriterion & { version?: number }).version,
        ) || 1,
    ),
  );
  const statements = [
    env.DB.prepare(
      `INSERT INTO screening_runs
     (id, job_id, criteria_version, model_version, pipeline_version, status,
      started_at, completed_at, validation_json, created_at, updated_at)
     VALUES (?, ?, ?, ?, 'evidence-citations-v4', 'completed', ?, ?, ?, ?, ?)`,
    ).bind(
      runId,
      jobId,
      criteriaVersion,
      MATCHING_ENGINE_VERSION,
      now,
      now,
      JSON.stringify({
        method: 'section_aware_structured_evidence',
        excludesRawResumeKeywordBag: true,
        citedSources: true,
        humanDecisionRequired: true,
      }),
      now,
      now,
    ),
  ];

  assessments.forEach((assessment, rankIndex) => {
    const explanation = buildRankingExplanation(
      assessment.criterionResults,
      assessment.evidenceCoverage,
    );
    const evidenceIds = new Map<string, string>();
    const citedSources = new Map(
      assessment.criterionResults.flatMap((criterion) =>
        criterion.evidence.map(
          (match) => [match.source.key, match.source] as const,
        ),
      ),
    );
    const nextStatus =
      assessment.previousStatus === 'submitted'
        ? 'in_review'
        : assessment.previousStatus;
    if (assessment.previousStatus === 'submitted') {
      statements.push(
        env.DB.prepare(
          `UPDATE applications SET status = 'in_review', current_stage_key = 'review', updated_at = ?
           WHERE id = ? AND status = 'submitted'`,
        ).bind(now, assessment.applicationId),
      );
    }
    statements.push(
      env.DB.prepare(
        `INSERT INTO application_events
         (id, application_id, actor_user_id, event_type, from_status, to_status, note, visible_to_candidate, occurred_at)
         VALUES (?, ?, ?, 'evidence_review_completed', ?, ?, ?, 1, ?)`,
      ).bind(
        `application_event_${crypto.randomUUID()}`,
        assessment.applicationId,
        appUserId,
        assessment.previousStatus,
        nextStatus,
        'The employer completed a criteria-based evidence review. Any fit explanation remains subject to human review.',
        now,
      ),
    );
    citedSources.forEach((source) => {
      const evidenceId = `evidence_${crypto.randomUUID()}`;
      evidenceIds.set(source.key, evidenceId);
      statements.push(
        env.DB.prepare(
          `INSERT INTO candidate_evidence
         (id, application_id, source_type, source_record_id, category, summary,
          evidence_quote, source_location, confidence, verification_status, created_at, updated_at)
         VALUES (?, ?, ?, NULL, ?, ?, ?, ?, ?, 'self_attested', ?, ?)`,
        ).bind(
          evidenceId,
          assessment.applicationId,
          source.sourceType,
          source.category,
          source.title,
          source.quote,
          source.sourceLocation,
          source.confidence,
          now,
          now,
        ),
      );
    });
    statements.push(
      env.DB.prepare(
        `INSERT INTO shortlist_rankings
       (id, screening_run_id, application_id, rank, fit_score, decision_band,
        evidence_coverage, uncertainty, explanation, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      ).bind(
        `ranking_${crypto.randomUUID()}`,
        runId,
        assessment.applicationId,
        rankIndex + 1,
        assessment.fitScore,
        assessment.decisionBand,
        assessment.evidenceCoverage,
        assessment.uncertainty,
        explanation,
        now,
        now,
      ),
    );
    assessment.criterionResults.forEach((criterion) => {
      statements.push(
        env.DB.prepare(
          `INSERT INTO candidate_criterion_assessments
         (id, screening_run_id, application_id, criterion_id, classification, score,
          confidence, evidence_ids_json, explanation, requires_human_review, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        ).bind(
          `assessment_${crypto.randomUUID()}`,
          runId,
          assessment.applicationId,
          criterion.id,
          criterion.classification,
          criterion.score,
          criterion.confidence,
          JSON.stringify(
            criterion.evidence
              .map((match) => evidenceIds.get(match.source.key))
              .filter(Boolean),
          ),
          criterion.explanation,
          criterion.requiresHumanReview ? 1 : 0,
          now,
          now,
        ),
      );
    });
  });

  await env.DB.batch(statements);
  return Response.json({
    runId,
    screened: assessments.length,
    rankings: assessments.map(
      (
        {
          criterionResults: _criterionResults,
          previousStatus: _previousStatus,
          ...ranking
        },
        index,
      ) => ({
        ...ranking,
        rank: index + 1,
      }),
    ),
  });
}

function safeJson(value: unknown): Record<string, unknown> {
  if (typeof value === 'object' && value !== null)
    return value as Record<string, unknown>;
  if (typeof value !== 'string') return {};
  try {
    return JSON.parse(value) as Record<string, unknown>;
  } catch {
    return {};
  }
}
