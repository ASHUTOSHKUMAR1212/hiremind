import { env } from 'cloudflare:workers';

import { getAccountContext } from '@/lib/account';
import { MATCHING_ENGINE_VERSION } from '@/lib/evidence-screening';
import { ensureAuthenticatedUser } from '@/lib/authenticated-user';
import { canOrganizationRole } from '@/lib/organization-permissions';
import { getHireMindIdentity } from '@/lib/supabase/server';

export async function GET(request: Request) {
  const user = await getHireMindIdentity(request);
  if (!user)
    return Response.json({ error: 'Sign in required.' }, { status: 401 });

  const appUserId = await ensureAuthenticatedUser(user);
  const account = await getAccountContext(appUserId);
  if (!account.organization) {
    return Response.json(
      { error: 'Employer account required.' },
      { status: 403 },
    );
  }
  if (!canOrganizationRole(account.organization.roleKey, 'view_pipeline')) {
    return Response.json(
      { error: 'Your team role cannot view this hiring pipeline.' },
      { status: 403 },
    );
  }

  const organizationId = account.organization.id;
  const [
    jobs,
    applications,
    criteria,
    interviews,
    criterionAssessments,
    candidateEvidence,
    applicationEvents,
    activity,
  ] = await Promise.all([
    env.DB.prepare(
      `SELECT j.id, j.title, j.status, j.description, j.location,
              j.workplace_type AS workplaceType,
              j.employment_type AS employmentType,
              j.published_at AS publishedAt,
              COUNT(a.id) AS applicantCount
       FROM jobs j
       LEFT JOIN applications a ON a.job_id = j.id
       WHERE j.organization_id = ?
       GROUP BY j.id
       ORDER BY j.created_at DESC`,
    )
      .bind(organizationId)
      .all(),
    env.DB.prepare(
      `SELECT a.id, a.job_id AS jobId, a.status, a.current_stage_key AS currentStage,
              a.submitted_at AS submittedAt,
              oc.display_name AS candidateName,
              cp.id AS candidateProfileId, cp.profile_type AS profileType,
              cp.headline, cp.location, cp.summary, cp.metadata_json AS metadataJson,
              a.profile_snapshot_json AS profileSnapshotJson,
              ranking.fit_score AS fitScore, ranking.decision_band AS decisionBand,
              ranking.evidence_coverage AS evidenceCoverage, ranking.uncertainty,
              ranking.explanation AS screeningExplanation,
              (SELECT id FROM files f WHERE f.entity_type = 'candidate_resume'
               AND f.entity_id = cp.id ORDER BY f.created_at DESC LIMIT 1) AS resumeFileId
       FROM applications a
       JOIN jobs j ON j.id = a.job_id
       JOIN organization_candidates oc ON oc.id = a.organization_candidate_id
       LEFT JOIN candidate_profiles cp ON cp.id = oc.candidate_profile_id
       LEFT JOIN shortlist_rankings ranking ON ranking.application_id = a.id
         AND ranking.screening_run_id = (
           SELECT id FROM screening_runs WHERE job_id = a.job_id AND status = 'completed'
           AND completed_at >= j.updated_at AND model_version = ?
           ORDER BY completed_at DESC LIMIT 1
         )
       WHERE a.organization_id = ? AND oc.deleted_at IS NULL
       ORDER BY a.submitted_at DESC`,
    )
      .bind(MATCHING_ENGINE_VERSION, organizationId)
      .all(),
    env.DB.prepare(
      `SELECT c.id, c.job_id AS jobId, c.label, c.requirement_class AS requirementClass,
              c.weight, c.evidence_definition AS evidenceDefinition,
              c.equivalent_signals_json AS equivalentSignalsJson
       FROM job_criteria c JOIN jobs j ON j.id = c.job_id
       WHERE j.organization_id = ? AND c.is_active = 1
       ORDER BY c.job_id, c.sort_order`,
    )
      .bind(organizationId)
      .all(),
    env.DB.prepare(
      `SELECT s.id, s.application_id AS applicationId, s.mode, s.status, s.scheduled_at AS scheduledAt,
              s.started_at AS startedAt, s.completed_at AS completedAt,
              stage.name AS stageName, stage.stage_type AS stageType,
              oc.display_name AS candidateName, j.title AS jobTitle,
              (
                SELECT request.payload_json FROM interview_session_events request
                WHERE request.interview_session_id = s.id
                  AND request.event_type = 'candidate_reschedule_requested'
                  AND NOT EXISTS (
                    SELECT 1 FROM interview_session_events resolved
                    WHERE resolved.interview_session_id = s.id
                      AND resolved.event_type IN ('interview_rescheduled', 'interview_cancelled')
                      AND resolved.occurred_at > request.occurred_at
                  )
                ORDER BY request.occurred_at DESC LIMIT 1
              ) AS changeRequestJson
       FROM interview_sessions s
       JOIN interview_stages stage ON stage.id = s.interview_stage_id
       JOIN applications a ON a.id = s.application_id
       JOIN organization_candidates oc ON oc.id = a.organization_candidate_id
       JOIN jobs j ON j.id = a.job_id
       WHERE a.organization_id = ? ORDER BY COALESCE(s.scheduled_at, s.created_at) DESC`,
    )
      .bind(organizationId)
      .all(),
    env.DB.prepare(
      `SELECT assessment.application_id AS applicationId, assessment.criterion_id AS criterionId,
              criterion.label, criterion.requirement_class AS requirementClass,
              assessment.classification, assessment.score, assessment.confidence,
              assessment.evidence_ids_json AS evidenceIdsJson,
              assessment.explanation, assessment.requires_human_review AS requiresHumanReview
       FROM candidate_criterion_assessments assessment
       JOIN job_criteria criterion ON criterion.id = assessment.criterion_id
       JOIN applications application ON application.id = assessment.application_id
       JOIN jobs job ON job.id = application.job_id
       WHERE application.organization_id = ?
         AND assessment.screening_run_id = (
           SELECT id FROM screening_runs WHERE job_id = application.job_id AND status = 'completed'
           AND completed_at >= job.updated_at AND model_version = ?
           ORDER BY completed_at DESC LIMIT 1
         )
       ORDER BY application.id, criterion.sort_order`,
    )
      .bind(organizationId, MATCHING_ENGINE_VERSION)
      .all(),
    env.DB.prepare(
      `SELECT evidence.id, evidence.application_id AS applicationId,
              evidence.source_type AS sourceType, evidence.category, evidence.summary,
              evidence.evidence_quote AS evidenceQuote,
              evidence.source_location AS sourceLocation, evidence.confidence,
              evidence.verification_status AS verificationStatus
       FROM candidate_evidence evidence
       JOIN applications application ON application.id = evidence.application_id
       WHERE application.organization_id = ?
       ORDER BY evidence.created_at`,
    )
      .bind(organizationId)
      .all(),
    env.DB.prepare(
      `SELECT event.id, event.application_id AS applicationId, event.event_type AS eventType,
              event.from_status AS fromStatus, event.to_status AS toStatus, event.note,
              event.visible_to_candidate AS visibleToCandidate, event.occurred_at AS occurredAt
       FROM application_events event
       JOIN applications application ON application.id = event.application_id
       WHERE application.organization_id = ?
       ORDER BY event.occurred_at DESC, event.id DESC`,
    )
      .bind(organizationId)
      .all(),
    env.DB.prepare(
      `SELECT * FROM (
         SELECT 'application_received' AS activityType, a.id AS entityId, a.submitted_at AS occurredAt,
                oc.display_name AS subject, j.title AS context
         FROM applications a JOIN organization_candidates oc ON oc.id = a.organization_candidate_id
         JOIN jobs j ON j.id = a.job_id WHERE a.organization_id = ?
           AND NOT EXISTS (
             SELECT 1 FROM application_events event
             WHERE event.application_id = a.id AND event.event_type = 'application_submitted'
           )
         UNION ALL
         SELECT 'interview_scheduled', s.id, s.created_at, oc.display_name, j.title
         FROM interview_sessions s JOIN applications a ON a.id = s.application_id
         JOIN organization_candidates oc ON oc.id = a.organization_candidate_id
         JOIN jobs j ON j.id = a.job_id WHERE a.organization_id = ?
           AND NOT EXISTS (
             SELECT 1 FROM application_events event
             WHERE event.application_id = a.id AND event.event_type = 'interview_scheduled'
           )
         UNION ALL
         SELECT 'role_created', j.id, j.created_at, j.title, j.status
         FROM jobs j WHERE j.organization_id = ?
         UNION ALL
         SELECT event.event_type, event.application_id, event.occurred_at,
                candidate.display_name, job.title
         FROM application_events event
         JOIN applications application ON application.id = event.application_id
         JOIN organization_candidates candidate ON candidate.id = application.organization_candidate_id
         JOIN jobs job ON job.id = application.job_id
         WHERE application.organization_id = ?
       ) ORDER BY occurredAt DESC LIMIT 12`,
    )
      .bind(organizationId, organizationId, organizationId, organizationId)
      .all(),
  ]);

  return Response.json({
    organization: account.organization,
    jobs: jobs.results.map((job) => ({
      ...job,
      criteria: criteria.results
        .filter((criterion) => criterion.jobId === job.id)
        .map((criterion) => ({
          ...criterion,
          equivalentSignals: safeArray(criterion.equivalentSignalsJson),
          equivalentSignalsJson: undefined,
        })),
    })),
    applications: applications.results.map((application) => {
      const profileSnapshot = safeJson(application.profileSnapshotJson);
      const snapshotMetadata = safeJson(profileSnapshot.metadata);
      const snapshotResume = safeJson(profileSnapshot.resume);
      return {
        ...application,
        candidateName:
          text(profileSnapshot.fullName) || application.candidateName,
        profileType:
          text(profileSnapshot.profileType) || application.profileType,
        headline: text(profileSnapshot.headline) || application.headline,
        location: text(profileSnapshot.location) || application.location,
        summary: text(profileSnapshot.summary) || application.summary,
        skills: safeArray(snapshotMetadata.skills),
        resumeFileId: text(snapshotResume.id) || application.resumeFileId,
        profileSnapshot,
        timeline: applicationEvents.results.filter(
          (event) => event.applicationId === application.id,
        ),
        criterionAssessments: criterionAssessments.results
          .filter((assessment) => assessment.applicationId === application.id)
          .map((assessment) => {
            const evidenceIds = new Set(
              safeArray(assessment.evidenceIdsJson).map(String),
            );
            return {
              ...assessment,
              evidence: candidateEvidence.results.filter((item) =>
                evidenceIds.has(String(item.id)),
              ),
              evidenceIdsJson: undefined,
            };
          }),
        metadataJson: undefined,
        profileSnapshotJson: undefined,
      };
    }),
    interviews: interviews.results.map((interview) => ({
      ...interview,
      changeRequest: safeJson(interview.changeRequestJson),
      changeRequestJson: undefined,
    })),
    activity: activity.results,
  });
}

function safeJson(value: unknown): Record<string, unknown> {
  if (typeof value === 'object' && value !== null)
    return value as Record<string, unknown>;
  if (typeof value !== 'string') return {};
  try {
    return JSON.parse(value) as Record<string, unknown>;
  } catch {
    return {};
  }
}

function safeArray(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  if (typeof value !== 'string') return [];
  try {
    const parsed = JSON.parse(value) as unknown;
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function text(value: unknown) {
  return typeof value === 'string' ? value.trim() : '';
}
