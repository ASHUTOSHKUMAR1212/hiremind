import { env } from 'cloudflare:workers';
import { employerAccess, json, readPayload } from '@/lib/employer-tools-access';
import {
  validateSavedTalentSearch,
  SAVED_TALENT_SEARCH_LIMIT,
} from '@/lib/saved-talent-search';

function unavailable(error: unknown) {
  console.error(
    'Saved talent searches unavailable',
    error instanceof Error ? error.name : 'UnknownError',
  );
  return json(
    { error: 'Saved searches are temporarily unavailable. Please retry.' },
    503,
  );
}

export async function GET(request: Request) {
  try {
    const access = await employerAccess(request);
    if (access.error) return access.error;
    const rows =
      await env.DB.prepare(`SELECT s.id, s.name, s.job_id AS jobId, s.query AS q, s.location, j.title AS jobTitle
      FROM saved_talent_searches s JOIN jobs j ON j.id = s.job_id AND j.organization_id = s.organization_id
      WHERE s.organization_id = ? AND s.owner_user_id = ? ORDER BY s.created_at DESC, s.id DESC LIMIT ?`)
        .bind(access.organization.id, access.userId, SAVED_TALENT_SEARCH_LIMIT)
        .all();
    return json({ searches: rows.results, limit: SAVED_TALENT_SEARCH_LIMIT });
  } catch (error) {
    return unavailable(error);
  }
}

export async function POST(request: Request) {
  try {
    const access = await employerAccess(request);
    if (access.error) return access.error;
    let data;
    try {
      data = validateSavedTalentSearch(await readPayload(request, 4000));
    } catch (error) {
      return json(
        { error: error instanceof Error ? error.message : 'Invalid search.' },
        400,
      );
    }
    const job = await env.DB.prepare(
      'SELECT id FROM jobs WHERE id = ? AND organization_id = ?',
    )
      .bind(data.jobId, access.organization.id)
      .first();
    if (!job) return json({ error: 'Job not found.' }, 404);
    const id = crypto.randomUUID();
    // One atomic statement enforces the per-owner cap even for concurrent saves.
    const result = await env.DB.prepare(`INSERT INTO saved_talent_searches
      (id, organization_id, owner_user_id, job_id, name, name_key, query, location, created_at)
      SELECT ?, ?, ?, ?, ?, ?, ?, ?, ? WHERE
      (SELECT COUNT(*) FROM saved_talent_searches WHERE organization_id = ? AND owner_user_id = ?) < ?
      ON CONFLICT (organization_id, owner_user_id, name_key) DO NOTHING`)
      .bind(
        id,
        access.organization.id,
        access.userId,
        data.jobId,
        data.name,
        data.nameKey,
        data.q,
        data.location,
        Date.now(),
        access.organization.id,
        access.userId,
        SAVED_TALENT_SEARCH_LIMIT,
      )
      .run();
    if (!result.meta.changes)
      return json(
        {
          error:
            'That name is already saved, or you have reached 20 saved searches. Use a different name or remove an old search.',
        },
        409,
      );
    return json({ id }, 201);
  } catch (error) {
    return unavailable(error);
  }
}

export async function DELETE(request: Request) {
  try {
    const access = await employerAccess(request);
    if (access.error) return access.error;
    const id = new URL(request.url).searchParams.get('id');
    if (!id || id.length > 128)
      return json({ error: 'Choose a saved search.' }, 400);
    const result = await env.DB.prepare(
      'DELETE FROM saved_talent_searches WHERE id = ? AND organization_id = ? AND owner_user_id = ?',
    )
      .bind(id, access.organization.id, access.userId)
      .run();
    return result.meta.changes
      ? json({ removed: true })
      : json({ error: 'Saved search not found.' }, 404);
  } catch (error) {
    return unavailable(error);
  }
}
