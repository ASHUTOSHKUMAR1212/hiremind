import { env } from 'cloudflare:workers';
import {
  auditStatement,
  employerAccess,
  failure,
  json,
  readPayload,
} from '@/lib/employer-tools-access';
import {
  parseTranscript,
  validateScorecard,
  type TranscriptSegment,
} from '@/lib/interview-transcript';

async function loadSession(id: string, orgId: string) {
  return env.DB.prepare(
    'SELECT s.id, a.job_id AS jobId FROM interview_sessions s JOIN applications a ON a.id = s.application_id WHERE s.id = ? AND a.organization_id = ?',
  )
    .bind(id, orgId)
    .first<{ id: string; jobId: string }>();
}
async function loadRubric(jobId: string) {
  return (
    await env.DB.prepare(
      'SELECT id, label, requirement_class AS requirementClass, evidence_definition AS evidenceDefinition FROM job_criteria WHERE job_id = ? AND is_active = 1 ORDER BY sort_order, id',
    )
      .bind(jobId)
      .all<{ id: string; label: string }>()
  ).results;
}
type TranscriptRow = {
  revision: number;
  segmentsJson: string;
  sourceName: string;
  consentNote: string;
};
async function loadTranscript(id: string) {
  return env.DB.prepare(
    'SELECT revision, segments_json AS segmentsJson, source_name AS sourceName, consent_note AS consentNote FROM interview_transcripts WHERE session_id = ?',
  )
    .bind(id)
    .first<TranscriptRow>();
}

export async function GET(request: Request) {
  const access = await employerAccess(request);
  if (access.error) return access.error;
  const session = await loadSession(
    new URL(request.url).searchParams.get('sessionId') ?? '',
    access.organization.id,
  );
  if (!session) return json({ error: 'Interview not found.' }, 404);
  const [transcript, rubric, cards] = await Promise.all([
    loadTranscript(session.id),
    loadRubric(session.jobId),
    env.DB.prepare(
      'SELECT c.reviewer_user_id AS reviewerId, u.full_name AS reviewerName, c.transcript_revision AS transcriptRevision, c.transcript_snapshot_json AS transcriptSnapshotJson, c.rubric_json AS rubricJson, c.entries_json AS entriesJson, c.status, c.revision, c.updated_at AS updatedAt FROM interview_scorecards c JOIN users u ON u.id = c.reviewer_user_id WHERE c.session_id = ? AND (c.reviewer_user_id = ? OR c.status = ?)',
    )
      .bind(session.id, access.userId, 'submitted')
      .all<Record<string, unknown>>(),
  ]);
  return json({
    userId: access.userId,
    rubric,
    transcript: transcript
      ? {
          revision: transcript.revision,
          segments: JSON.parse(transcript.segmentsJson),
          sourceName: transcript.sourceName,
          consentNote: transcript.consentNote,
        }
      : null,
    scorecards: cards.results.map((card) => ({
      ...card,
      entries: JSON.parse(String(card.entriesJson)),
      rubric: JSON.parse(String(card.rubricJson)),
      sourceSegments: JSON.parse(String(card.transcriptSnapshotJson)),
      stale:
        card.transcriptRevision !== transcript?.revision ||
        card.rubricJson !== JSON.stringify(rubric),
      entriesJson: undefined,
      rubricJson: undefined,
      transcriptSnapshotJson: undefined,
    })),
  });
}

export async function POST(request: Request) {
  const access = await employerAccess(request);
  if (access.error) return access.error;
  try {
    const payload = await readPayload(request);
    const session = await loadSession(
      typeof payload.sessionId === 'string' ? payload.sessionId : '',
      access.organization.id,
    );
    if (!session) return json({ error: 'Interview not found.' }, 404);
    const existing = await loadTranscript(session.id);
    const now = Date.now();
    if (payload.action === 'import') {
      if (
        payload.consentConfirmed !== true ||
        typeof payload.consentNote !== 'string' ||
        payload.consentNote.trim().length < 12 ||
        payload.consentNote.length > 600
      )
        throw new Error(
          'Confirm participant consent and record how it was obtained.',
        );
      if (
        typeof payload.sourceName !== 'string' ||
        !payload.sourceName.trim() ||
        payload.sourceName.length > 180 ||
        typeof payload.text !== 'string'
      )
        throw new Error('Provide a transcript filename and its text.');
      if (payload.revision !== (existing?.revision ?? 0))
        return json(
          {
            error:
              'Transcript changed. Reload before importing another version.',
          },
          409,
        );
      const segments = parseTranscript(payload.text);
      const result = await env.DB.prepare(
        'INSERT INTO interview_transcripts (session_id, organization_id, revision, segments_json, source_name, consent_note, created_by_user_id, created_at, updated_at) VALUES (?, ?, 1, ?, ?, ?, ?, ?, ?) ON CONFLICT(session_id) DO UPDATE SET revision = interview_transcripts.revision + 1, segments_json = excluded.segments_json, source_name = excluded.source_name, consent_note = excluded.consent_note, created_by_user_id = excluded.created_by_user_id, updated_at = excluded.updated_at WHERE interview_transcripts.revision = ?',
      )
        .bind(
          session.id,
          access.organization.id,
          JSON.stringify(segments),
          payload.sourceName.trim(),
          payload.consentNote.trim(),
          access.userId,
          now,
          now,
          payload.revision,
        )
        .run();
      if (!result.meta.changes)
        return json({ error: 'Transcript changed. Reload to retry.' }, 409);
      await auditStatement(
        access.organization.id,
        access.userId,
        'interview_transcript_imported',
        session.id,
      ).run();
      return json({ saved: true, revision: (existing?.revision ?? 0) + 1 });
    }
    if (payload.action !== 'scorecard')
      throw new Error('Unknown interview evidence action.');
    if (!existing || payload.transcriptRevision !== existing.revision)
      return json(
        {
          error:
            'Import a transcript or reload its latest revision before saving.',
        },
        409,
      );
    const rubric = await loadRubric(session.jobId);
    if (!rubric.length)
      throw new Error('Add job criteria before creating a scorecard.');
    if (JSON.stringify(payload.rubric) !== JSON.stringify(rubric))
      return json(
        { error: 'Job criteria changed. Reload before reviewing.' },
        409,
      );
    if (
      !['draft', 'submitted'].includes(String(payload.status)) ||
      !Number.isInteger(payload.revision) ||
      Number(payload.revision) < 0
    )
      throw new Error('Invalid scorecard status or revision.');
    const entries = validateScorecard(
      payload.entries,
      rubric.map((item) => item.id),
      JSON.parse(existing.segmentsJson) as TranscriptSegment[],
      payload.status === 'submitted',
    );
    const result =
      await env.DB.prepare(`INSERT INTO interview_scorecards (session_id, reviewer_user_id, transcript_revision, transcript_snapshot_json, rubric_json, entries_json, status, revision, created_at, updated_at)
      SELECT ?, ?, ?, ?, ?, ?, ?, 1, ?, ? WHERE EXISTS (SELECT 1 FROM interview_transcripts WHERE session_id = ? AND revision = ?)
      ON CONFLICT(session_id, reviewer_user_id) DO UPDATE SET transcript_revision = excluded.transcript_revision, transcript_snapshot_json = excluded.transcript_snapshot_json, rubric_json = excluded.rubric_json, entries_json = excluded.entries_json, status = excluded.status, revision = interview_scorecards.revision + 1, updated_at = excluded.updated_at WHERE interview_scorecards.revision = ?`)
        .bind(
          session.id,
          access.userId,
          existing.revision,
          existing.segmentsJson,
          JSON.stringify(rubric),
          JSON.stringify(entries),
          payload.status,
          now,
          now,
          session.id,
          existing.revision,
          payload.revision,
        )
        .run();
    if (!result.meta.changes)
      return json(
        { error: 'Review changed in another tab. Reload before saving.' },
        409,
      );
    await auditStatement(
      access.organization.id,
      access.userId,
      `interview_scorecard_${String(payload.status)}`,
      session.id,
    ).run();
    return json({ saved: true });
  } catch (error) {
    return failure(error);
  }
}
