import { env } from 'cloudflare:workers';

import { getAccountContext } from '@/lib/account';
import { ensureAuthenticatedUser } from '@/lib/authenticated-user';
import { canOrganizationRole } from '@/lib/organization-permissions';
import { getHireMindIdentity } from '@/lib/supabase/server';

const ASSIGNABLE_ROLES = new Set(['admin', 'recruiter', 'hiring_manager']);

export async function GET(request: Request) {
  const context = await employerContext(request);
  if (!context) return Response.json({ error: 'Employer account required.' }, { status: 403 });
  if (!canOrganizationRole(context.roleKey, 'manage_team')) return Response.json({ error: 'Only an owner or admin can view team administration.' }, { status: 403 });
  const members = await env.DB.prepare(
    `SELECT u.id AS userId, u.full_name AS fullName, u.email, m.role_key AS roleKey,
            m.status, m.joined_at AS joinedAt
     FROM organization_members m JOIN users u ON u.id = m.user_id
     WHERE m.organization_id = ? ORDER BY CASE m.role_key WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 ELSE 2 END, m.joined_at`,
  ).bind(context.organizationId).all();
  return Response.json({ members: members.results, canManage: canOrganizationRole(context.roleKey, 'manage_team'), currentUserId: context.appUserId });
}

export async function POST(request: Request) {
  const context = await employerContext(request);
  if (!context || !canOrganizationRole(context.roleKey, 'manage_team')) return Response.json({ error: 'Only an owner or admin can add team members.' }, { status: 403 });
  const payload = await request.json() as Record<string, unknown>;
  const email = clean(payload.email, 254).toLowerCase();
  const roleKey = clean(payload.roleKey, 40);
  if (!email.includes('@') || !ASSIGNABLE_ROLES.has(roleKey)) return Response.json({ error: 'Enter a valid account email and team role.' }, { status: 400 });
  const user = await env.DB.prepare(`SELECT id, full_name AS fullName, email FROM users WHERE lower(email) = ? LIMIT 1`).bind(email).first<{ id: string; fullName: string | null; email: string }>();
  if (!user) return Response.json({ error: 'That person needs to create a HireMind account first. No invitation email was sent.' }, { status: 404 });
  const existing = await env.DB.prepare(`SELECT status FROM organization_members WHERE organization_id = ? AND user_id = ?`).bind(context.organizationId, user.id).first<{ status: string }>();
  if (existing) return Response.json({ error: existing.status === 'active' ? 'This person already has access.' : 'This account already has a team membership. Reactivate it instead.' }, { status: 409 });
  const now = Date.now();
  await env.DB.batch([
    env.DB.prepare(`INSERT INTO organization_members (organization_id, user_id, role_key, permission_overrides_json, status, joined_at) VALUES (?, ?, ?, NULL, 'active', ?)`).bind(context.organizationId, user.id, roleKey, now),
    auditStatement(context.organizationId, context.appUserId, 'team_member_added', 'user', user.id, { email, roleKey }, now),
  ]);
  return Response.json({ member: { userId: user.id, fullName: user.fullName, email: user.email, roleKey, status: 'active', joinedAt: now } }, { status: 201 });
}

export async function PATCH(request: Request) {
  const context = await employerContext(request);
  if (!context || !canOrganizationRole(context.roleKey, 'manage_team')) return Response.json({ error: 'Only an owner or admin can change team access.' }, { status: 403 });
  const payload = await request.json() as Record<string, unknown>;
  const userId = clean(payload.userId, 200);
  const roleKey = clean(payload.roleKey, 40);
  const status = payload.status === 'inactive' ? 'inactive' : 'active';
  if (!userId) return Response.json({ error: 'Choose a valid team member.' }, { status: 400 });
  if (userId === context.appUserId && status === 'inactive') return Response.json({ error: 'You cannot remove your own access.' }, { status: 400 });
  const member = await env.DB.prepare(`SELECT role_key AS roleKey FROM organization_members WHERE organization_id = ? AND user_id = ?`).bind(context.organizationId, userId).first<{ roleKey: string }>();
  if (!member) return Response.json({ error: 'Team member not found.' }, { status: 404 });
  if (member.roleKey === 'owner') return Response.json({ error: 'Owner access cannot be changed here.' }, { status: 400 });
  if (!ASSIGNABLE_ROLES.has(roleKey) && roleKey !== member.roleKey) return Response.json({ error: 'Choose a valid team role.' }, { status: 400 });
  const now = Date.now();
  await env.DB.batch([
    env.DB.prepare(`UPDATE organization_members SET role_key = ?, status = ? WHERE organization_id = ? AND user_id = ?`).bind(roleKey, status, context.organizationId, userId),
    auditStatement(context.organizationId, context.appUserId, 'team_member_access_changed', 'user', userId, { roleKey, status }, now),
  ]);
  return Response.json({ userId, roleKey, status });
}

async function employerContext(request: Request) {
  const identity = await getHireMindIdentity(request);
  if (!identity) return null;
  const appUserId = await ensureAuthenticatedUser(identity);
  const account = await getAccountContext(appUserId);
  if (!account.organization) return null;
  return { appUserId, organizationId: account.organization.id, roleKey: account.organization.roleKey };
}

function auditStatement(organizationId: string, actorUserId: string, action: string, entityType: string, entityId: string, payload: Record<string, unknown>, occurredAt: number) {
  return env.DB.prepare(`INSERT INTO audit_events (id, organization_id, actor_user_id, action, entity_type, entity_id, payload_json, occurred_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).bind(`audit_${crypto.randomUUID()}`, organizationId, actorUserId, action, entityType, entityId, JSON.stringify(payload), occurredAt);
}
function clean(value: unknown, maxLength: number) { return (typeof value === 'string' || typeof value === 'number' ? `${value}` : '').trim().replace(/\s+/g, ' ').slice(0, maxLength); }
