import { env } from 'cloudflare:workers';
import {
  auditStatement,
  employerAccess,
  failure,
  json,
  readPayload,
} from '@/lib/employer-tools-access';
import { evaluateBenchmark, validateBenchmark } from '@/lib/matching-benchmark';

export async function GET(request: Request) {
  const access = await employerAccess(request);
  if (access.error) return access.error;
  const id = new URL(request.url).searchParams.get('id');
  if (id) {
    const row = await env.DB.prepare(
      'SELECT id, report_json AS report, dataset_json AS dataset FROM matching_benchmarks WHERE id = ? AND organization_id = ?',
    )
      .bind(id, access.organization.id)
      .first<{ id: string; report: string; dataset: string }>();
    return row
      ? json({
          id: row.id,
          report: JSON.parse(row.report),
          dataset: JSON.parse(row.dataset),
        })
      : json({ error: 'Benchmark not found.' }, 404);
  }
  const rows = await env.DB.prepare(
    'SELECT id, report_json AS report FROM matching_benchmarks WHERE organization_id = ? ORDER BY created_at DESC LIMIT 30',
  )
    .bind(access.organization.id)
    .all<{ id: string; report: string }>();
  return json({
    items: rows.results.map((row) => ({
      id: row.id,
      report: JSON.parse(row.report),
    })),
  });
}

export async function POST(request: Request) {
  const access = await employerAccess(request, 'manage_jobs');
  if (access.error) return access.error;
  try {
    const payload = await readPayload(request, 2_000_000);
    const data = validateBenchmark(payload);
    const report = evaluateBenchmark(data);
    const id = crypto.randomUUID();
    await env.DB.batch([
      env.DB.prepare(
        'INSERT INTO matching_benchmarks (id, organization_id, created_by_user_id, report_json, dataset_json, created_at) VALUES (?, ?, ?, ?, ?, ?)',
      ).bind(
        id,
        access.organization.id,
        access.userId,
        JSON.stringify(report),
        JSON.stringify(data),
        Date.now(),
      ),
      auditStatement(
        access.organization.id,
        access.userId,
        'matching_benchmark_created',
        id,
      ),
    ]);
    return json({ id, report }, 201);
  } catch (error) {
    return failure(error);
  }
}

export async function DELETE(request: Request) {
  const access = await employerAccess(request, 'manage_jobs');
  if (access.error) return access.error;
  const id = new URL(request.url).searchParams.get('id') ?? '';
  const result = await env.DB.prepare(
    'DELETE FROM matching_benchmarks WHERE id = ? AND organization_id = ?',
  )
    .bind(id, access.organization.id)
    .run();
  if (!result.meta.changes) return json({ error: 'Benchmark not found.' }, 404);
  await auditStatement(
    access.organization.id,
    access.userId,
    'matching_benchmark_deleted',
    id,
  ).run();
  return json({ deleted: true });
}
