import { env } from 'cloudflare:workers';

import { getAccountContext } from '@/lib/account';
import { ensureAuthenticatedUser } from '@/lib/authenticated-user';
import { assessCandidateEvidence, buildRankingExplanation, usesCurrentMatchingEngine, type ScreeningCriterion } from '@/lib/evidence-screening';
import { hasExpectedDocumentSignature, hasValidDocxContainer } from '@/lib/file-security';
import { canOrganizationRole } from '@/lib/organization-permissions';
import { buildResumeScreeningProfile, rankResumeComparisons, resumeCandidateName } from '@/lib/resume-comparison';
import { parseResumeProfile } from '@/lib/resume-text';
import { getHireMindIdentity } from '@/lib/supabase/server';

const MAX_FILES = 8;
const MAX_FILE_SIZE = 5 * 1024 * 1024;
const MAX_BATCH_SIZE = 25 * 1024 * 1024;

type ComparisonItemRow = {
  id: string; fileId: string; filename: string; candidateName: string; headline: string | null;
  fitScore: number; rank: number; decisionBand: string; evidenceCoverage: number; uncertainty: number;
  explanation: string; parsedProfileJson: string; criterionResultsJson: string; warningsJson: string | null;
};

export async function GET(request: Request) {
  const context = await employerContext(request);
  if (context instanceof Response) return context;
  const jobId = new URL(request.url).searchParams.get('jobId') ?? '';
  const job = await loadJob(jobId, context.organization.id);
  if (!job) return Response.json({ error: 'Job not found.' }, { status: 404 });

  const run = await env.DB.prepare(
    `SELECT id, job_id AS jobId, criteria_version AS criteriaVersion, file_count AS fileCount,
            status, completed_at AS completedAt, created_at AS createdAt
     FROM resume_comparison_runs
     WHERE organization_id = ? AND job_id = ? AND status = 'completed'
     ORDER BY created_at DESC LIMIT 1`,
  ).bind(context.organization.id, jobId).first<Record<string, unknown>>();
  if (!run) return Response.json({ job, run: null });
  const items = await loadItems(String(run.id));
  const stale = Number(run.criteriaVersion) !== job.criteriaVersion || items.some((item) => !usesCurrentMatchingEngine(safeArray(item.criterionResultsJson)));
  return Response.json({ job, run: { ...run, stale, items: items.map(serializeItem) } });
}

export async function POST(request: Request) {
  const context = await employerContext(request);
  if (context instanceof Response) return context;
  const form = await request.formData();
  const jobId = value(form.get('jobId'));
  const uploads = form.getAll('resumes').filter((item): item is File => item instanceof File);
  const extractedTexts = form.getAll('extractedText').map(value);
  if (uploads.length < 2) return Response.json({ error: 'Choose at least two résumés to compare.' }, { status: 400 });
  if (uploads.length > MAX_FILES) return Response.json({ error: `Compare up to ${MAX_FILES} résumés at a time.` }, { status: 400 });
  if (uploads.length !== extractedTexts.length) return Response.json({ error: 'One or more résumé files could not be read.' }, { status: 400 });
  if (uploads.reduce((sum, upload) => sum + upload.size, 0) > MAX_BATCH_SIZE) return Response.json({ error: 'The combined upload must be 25 MB or smaller.' }, { status: 400 });

  const job = await loadJob(jobId, context.organization.id);
  if (!job) return Response.json({ error: 'Job not found.' }, { status: 404 });
  const criteriaResult = await env.DB.prepare(
    `SELECT id, version, label, weight, requirement_class AS requirementClass,
            evidence_definition AS evidenceDefinition, equivalent_signals_json AS equivalentSignalsJson
     FROM job_criteria WHERE job_id = ? AND is_active = 1 ORDER BY sort_order`,
  ).bind(jobId).all<ScreeningCriterion & { version: number }>();
  if (!criteriaResult.results.length) return Response.json({ error: 'Add evidence criteria to this job before comparing résumés.' }, { status: 400 });

  const prepared = [] as Array<{
    id: string; fileId: string; file: File; bytes: Uint8Array; extension: string; contentType: string;
    checksum: string; candidateName: string; headline: string; parsedProfile: Record<string, unknown>;
    warnings: string[]; fitScore: number; evidenceCoverage: number; uncertainty: number; decisionBand: string;
    criterionResults: ReturnType<typeof assessCandidateEvidence>['criterionResults']; explanation: string;
  }>;
  for (let index = 0; index < uploads.length; index += 1) {
    const file = uploads[index];
    const extension = file.name.toLowerCase().match(/\.(pdf|doc|docx)$/)?.[1] ?? '';
    if (!extension) return Response.json({ error: `${file.name}: upload a PDF, DOC, or DOCX résumé.` }, { status: 400 });
    if (file.size > MAX_FILE_SIZE) return Response.json({ error: `${file.name}: each résumé must be 5 MB or smaller.` }, { status: 400 });
    const bytes = new Uint8Array(await file.arrayBuffer());
    if (!hasExpectedDocumentSignature(bytes, extension)) return Response.json({ error: `${file.name}: the file signature does not match its extension.` }, { status: 400 });
    if (extension === 'docx' && !hasValidDocxContainer(bytes)) return Response.json({ error: `${file.name}: this Word file is damaged, encrypted, or too large when unpacked. Export a new DOCX or PDF.` }, { status: 400 });
    const extractedText = normalizeText(extractedTexts[index]).slice(0, 50_000);
    if (extractedText.replace(/[^a-zA-Z0-9]/g, '').length < 40) return Response.json({ error: `${file.name}: not enough readable résumé text was found.` }, { status: 400 });
    const parsed = parseResumeProfile(extractedText);
    const profile = buildResumeScreeningProfile(parsed, file.name);
    const assessment = assessCandidateEvidence(profile, criteriaResult.results);
    const candidateName = resumeCandidateName(parsed.fullName, file.name);
    prepared.push({
      id: `resume_comparison_item_${crypto.randomUUID()}`,
      fileId: `file_${crypto.randomUUID()}`,
      file,
      bytes,
      extension,
      contentType: contentType(extension),
      checksum: await sha256(bytes),
      candidateName,
      headline: parsed.headline,
      parsedProfile: profile,
      warnings: parsed.warnings,
      ...assessment,
      explanation: buildRankingExplanation(assessment.criterionResults, assessment.evidenceCoverage),
    });
  }

  const ranked = rankResumeComparisons(prepared);
  const runId = `resume_comparison_${crypto.randomUUID()}`;
  const organizationId = context.organization.id;
  const now = Date.now();
  const criteriaVersion = Math.max(...criteriaResult.results.map((criterion) => Number(criterion.version) || 1));
  const storedKeys: string[] = [];
  try {
    for (const item of ranked) {
      const key = `comparison-resumes/${organizationId}/${runId}/${item.fileId}-${safeFilename(item.file.name)}`;
      await env.FILES.put(key, item.bytes, { httpMetadata: { contentType: item.contentType } });
      storedKeys.push(key);
      Object.assign(item, { r2Key: key });
    }
    const statements = [env.DB.prepare(
      `INSERT INTO resume_comparison_runs
       (id, organization_id, job_id, created_by_user_id, criteria_version, status,
        file_count, completed_at, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, 'completed', ?, ?, ?, ?)`,
    ).bind(runId, organizationId, jobId, context.appUserId, criteriaVersion, ranked.length, now, now, now)];
    ranked.forEach((item, index) => {
      const r2Key = String((item as typeof item & { r2Key: string }).r2Key);
      statements.push(env.DB.prepare(
        `INSERT INTO files
         (id, organization_id, owner_user_id, entity_type, entity_id, r2_key, filename,
          content_type, size_bytes, processing_status, checksum, created_at, updated_at)
         VALUES (?, ?, ?, 'resume_comparison', ?, ?, ?, ?, ?, 'stored', ?, ?, ?)`,
      ).bind(item.fileId, organizationId, context.appUserId, item.id, r2Key, item.file.name.slice(0, 180), item.contentType, item.file.size, item.checksum, now, now));
      statements.push(env.DB.prepare(
        `INSERT INTO resume_comparison_items
         (id, run_id, file_id, filename, candidate_name, headline, parsed_profile_json,
          fit_score, rank, decision_band, evidence_coverage, uncertainty, explanation,
          criterion_results_json, warnings_json, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      ).bind(item.id, runId, item.fileId, item.file.name.slice(0, 180), item.candidateName, item.headline || null, JSON.stringify(item.parsedProfile), item.fitScore, index + 1, item.decisionBand, item.evidenceCoverage, item.uncertainty, item.explanation, JSON.stringify(item.criterionResults), JSON.stringify(item.warnings), now, now));
    });
    statements.push(env.DB.prepare(
      `INSERT INTO audit_events (id, organization_id, actor_user_id, action, entity_type, entity_id, payload_json, occurred_at)
       VALUES (?, ?, ?, 'resume_comparison_completed', 'resume_comparison_run', ?, ?, ?)`,
    ).bind(`audit_${crypto.randomUUID()}`, organizationId, context.appUserId, runId, JSON.stringify({ jobId, fileCount: ranked.length, criteriaVersion, humanDecisionRequired: true }), now));
    await env.DB.batch(statements);
  } catch (error) {
    await Promise.allSettled(storedKeys.map((key) => env.FILES.delete(key)));
    throw error;
  }

  const items = await loadItems(runId);
  return Response.json({ job, run: { id: runId, jobId, criteriaVersion, fileCount: ranked.length, status: 'completed', completedAt: now, createdAt: now, stale: false, items: items.map(serializeItem) } }, { status: 201 });
}

export async function DELETE(request: Request) {
  const context = await employerContext(request);
  if (context instanceof Response) return context;
  const payload = await request.json() as Record<string, unknown>;
  const runId = value(payload.runId);
  const run = await env.DB.prepare(
    `SELECT id FROM resume_comparison_runs WHERE id = ? AND organization_id = ? LIMIT 1`,
  ).bind(runId, context.organization.id).first<{ id: string }>();
  if (!run) return Response.json({ error: 'Comparison not found.' }, { status: 404 });
  const files = await env.DB.prepare(
    `SELECT f.r2_key AS r2Key FROM files f
     JOIN resume_comparison_items item ON item.id = f.entity_id
     WHERE item.run_id = ? AND f.entity_type = 'resume_comparison' AND f.organization_id = ?`,
  ).bind(runId, context.organization.id).all<{ r2Key: string }>();
  const now = Date.now();
  await env.DB.batch([
    env.DB.prepare(
      `DELETE FROM files WHERE entity_type = 'resume_comparison' AND organization_id = ?
       AND entity_id IN (SELECT id FROM resume_comparison_items WHERE run_id = ?)`,
    ).bind(context.organization.id, runId),
    env.DB.prepare(`DELETE FROM resume_comparison_runs WHERE id = ? AND organization_id = ?`).bind(runId, context.organization.id),
    env.DB.prepare(
      `INSERT INTO audit_events (id, organization_id, actor_user_id, action, entity_type, entity_id, payload_json, occurred_at)
       VALUES (?, ?, ?, 'resume_comparison_deleted', 'resume_comparison_run', ?, NULL, ?)`,
    ).bind(`audit_${crypto.randomUUID()}`, context.organization.id, context.appUserId, runId, now),
  ]);
  await Promise.allSettled(files.results.map((file) => env.FILES.delete(file.r2Key)));
  return Response.json({ deleted: true });
}

async function employerContext(request: Request) {
  const identity = await getHireMindIdentity(request);
  if (!identity) return Response.json({ error: 'Sign in required.' }, { status: 401 });
  const appUserId = await ensureAuthenticatedUser(identity);
  const account = await getAccountContext(appUserId);
  if (!account.organization) return Response.json({ error: 'Employer account required.' }, { status: 403 });
  if (!canOrganizationRole(account.organization.roleKey, 'review_candidates')) return Response.json({ error: 'Your team role cannot compare candidate résumés.' }, { status: 403 });
  return { appUserId, organization: account.organization };
}

function loadJob(jobId: string, organizationId: string) {
  return env.DB.prepare(
    `SELECT j.id, j.title, j.status,
            COALESCE(MAX(CASE WHEN criterion.is_active = 1 THEN criterion.version END), 0) AS criteriaVersion
     FROM jobs j LEFT JOIN job_criteria criterion ON criterion.job_id = j.id
     WHERE j.id = ? AND j.organization_id = ? GROUP BY j.id LIMIT 1`,
  ).bind(jobId, organizationId).first<{ id: string; title: string; status: string; criteriaVersion: number }>();
}

function loadItems(runId: string) {
  return env.DB.prepare(
    `SELECT id, file_id AS fileId, filename, candidate_name AS candidateName, headline,
            fit_score AS fitScore, rank, decision_band AS decisionBand,
            evidence_coverage AS evidenceCoverage, uncertainty, explanation,
            parsed_profile_json AS parsedProfileJson, criterion_results_json AS criterionResultsJson,
            warnings_json AS warningsJson
     FROM resume_comparison_items WHERE run_id = ? ORDER BY rank`,
  ).bind(runId).all<ComparisonItemRow>().then((result) => result.results);
}

function serializeItem(item: ComparisonItemRow) {
  return { ...item, parsedProfile: safeJson(item.parsedProfileJson), criterionResults: safeArray(item.criterionResultsJson), warnings: safeArray(item.warningsJson).map(String), parsedProfileJson: undefined, criterionResultsJson: undefined, warningsJson: undefined };
}

function contentType(extension: string) {
  return extension === 'pdf' ? 'application/pdf' : extension === 'docx' ? 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' : 'application/msword';
}
function safeFilename(filename: string) { return filename.replace(/[^a-zA-Z0-9._-]+/g, '-').slice(-120) || 'resume.pdf'; }
function normalizeText(input: string) { return input.replaceAll('\u0000', ' ').replace(/[ \t]+/g, ' ').replace(/\s*\n\s*/g, '\n').replace(/\n{3,}/g, '\n\n').trim(); }
function value(input: unknown) { return typeof input === 'string' || typeof input === 'number' ? `${input}`.trim() : ''; }
function safeJson(input: unknown): Record<string, unknown> { if (typeof input === 'object' && input !== null) return input as Record<string, unknown>; if (typeof input !== 'string') return {}; try { return JSON.parse(input) as Record<string, unknown>; } catch { return {}; } }
function safeArray(input: unknown): unknown[] { if (Array.isArray(input)) return input; if (typeof input !== 'string') return []; try { const parsed = JSON.parse(input) as unknown; return Array.isArray(parsed) ? parsed : []; } catch { return []; } }
async function sha256(bytes: Uint8Array) { const digest = await crypto.subtle.digest('SHA-256', Uint8Array.from(bytes).buffer); return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, '0')).join(''); }
