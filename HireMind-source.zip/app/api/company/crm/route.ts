import { env } from 'cloudflare:workers';
import {
  auditStatement,
  employerAccess,
  failure,
  json,
  readPayload,
} from '@/lib/employer-tools-access';
import {
  canTransitionOutreach,
  validateCrmContact,
  validateOutreach,
} from '@/lib/recruiter-crm';

const contactSelect = `SELECT oc.id, oc.display_name AS name, oc.primary_email AS email,
  COALESCE(r.stage, 'new') AS stage, COALESCE(r.tags_json, '[]') AS tagsJson,
  COALESCE(r.notes, '') AS notes, COALESCE(r.suppressed, 0) AS suppressed, COALESCE(r.revision, 0) AS revision,
  CASE WHEN EXISTS (SELECT 1 FROM applications a WHERE a.organization_candidate_id = oc.id AND a.status IN ('submitted', 'in_review', 'shortlisted', 'interview')) THEN 1
    WHEN json_extract(p.metadata_json, '$.futureRoleConsent') = 1 AND EXISTS (SELECT 1 FROM applications a WHERE a.organization_candidate_id = oc.id AND a.submitted_at >= ? AND a.status NOT IN ('withdrawn', 'hired', 'offer') AND a.id = (SELECT latest.id FROM applications latest WHERE latest.organization_candidate_id = oc.id ORDER BY latest.submitted_at DESC, latest.id DESC LIMIT 1)) THEN 1 ELSE 0 END AS eligible
  FROM organization_candidates oc LEFT JOIN recruiter_relationships r ON r.candidate_id = oc.id
  LEFT JOIN candidate_profiles p ON p.id = oc.candidate_profile_id
  WHERE oc.organization_id = ? AND oc.deleted_at IS NULL AND (oc.retention_until IS NULL OR oc.retention_until > ?)`;

type Contact = {
  id: string;
  name: string;
  email: string | null;
  stage: string;
  tagsJson: string;
  notes: string;
  suppressed: number;
  revision: number;
  eligible: number;
};
async function getContact(id: string, orgId: string) {
  return env.DB.prepare(`${contactSelect} AND oc.id = ?`)
    .bind(Date.now() - 365 * 86400_000, orgId, Date.now(), id)
    .first<Contact>();
}

export async function GET(request: Request) {
  const access = await employerAccess(request, 'manage_candidates');
  if (access.error) return access.error;
  const url = new URL(request.url),
    candidateId = url.searchParams.get('candidateId');
  if (candidateId) {
    const contact = await getContact(candidateId, access.organization.id);
    if (!contact) return json({ error: 'Contact not found.' }, 404);
    const outreach = await env.DB.prepare(
      'SELECT id, subject, body, status, due_at AS dueAt, sent_at AS sentAt, updated_at AS updatedAt FROM recruiter_outreach WHERE candidate_id = ? AND organization_id = ? ORDER BY created_at DESC LIMIT 100',
    )
      .bind(candidateId, access.organization.id)
      .all<Record<string, unknown>>();
    return json({
      contact: {
        ...contact,
        tags: JSON.parse(contact.tagsJson),
        tagsJson: undefined,
      },
      outreach: outreach.results,
    });
  }
  const query = (url.searchParams.get('q') ?? '').slice(0, 100);
  const offset = Math.min(
    100000,
    Math.max(0, Math.floor(Number(url.searchParams.get('offset')) || 0)),
  );
  const rows = await env.DB.prepare(
    `${contactSelect} AND (instr(lower(oc.display_name), lower(?)) > 0 OR instr(lower(COALESCE(oc.primary_email, '')), lower(?)) > 0 OR instr(lower(COALESCE(r.tags_json, '')), lower(?)) > 0) ORDER BY oc.created_at DESC, oc.id LIMIT 51 OFFSET ?`,
  )
    .bind(
      Date.now() - 365 * 86400_000,
      access.organization.id,
      Date.now(),
      query,
      query,
      query,
      offset,
    )
    .all<Contact>();
  const due = await env.DB.prepare(
    `SELECT o.id, o.candidate_id AS candidateId, oc.display_name AS name, o.subject, o.due_at AS dueAt FROM recruiter_outreach o JOIN organization_candidates oc ON oc.id = o.candidate_id WHERE o.organization_id = ? AND o.status IN ('approved', 'sent') AND o.due_at <= ? AND oc.deleted_at IS NULL AND (oc.retention_until IS NULL OR oc.retention_until > ?) ORDER BY o.due_at LIMIT 50`,
  )
    .bind(access.organization.id, Date.now(), Date.now())
    .all<Record<string, unknown>>();
  return json({
    items: rows.results.slice(0, 50).map((row) => ({
      ...row,
      tags: JSON.parse(row.tagsJson),
      tagsJson: undefined,
    })),
    nextOffset: rows.results.length > 50 ? offset + 50 : null,
    due: due.results,
  });
}

export async function POST(request: Request) {
  const access = await employerAccess(request, 'manage_candidates');
  if (access.error) return access.error;
  try {
    const payload = await readPayload(request, 15000);
    const contact = await getContact(
      typeof payload.candidateId === 'string' ? payload.candidateId : '',
      access.organization.id,
    );
    if (!contact) return json({ error: 'Contact not found.' }, 404);
    const now = Date.now();
    if (payload.action === 'contact') {
      const data = validateCrmContact(payload);
      if (payload.revision !== contact.revision)
        return json({ error: 'Contact changed. Reload before saving.' }, 409);
      const result =
        await env.DB.prepare(`INSERT INTO recruiter_relationships (candidate_id, organization_id, stage, tags_json, notes, suppressed, revision, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)
        ON CONFLICT(candidate_id) DO UPDATE SET stage = excluded.stage, tags_json = excluded.tags_json, notes = excluded.notes, suppressed = excluded.suppressed, revision = recruiter_relationships.revision + 1, updated_at = excluded.updated_at WHERE recruiter_relationships.revision = ?`)
          .bind(
            contact.id,
            access.organization.id,
            data.stage,
            JSON.stringify(data.tags),
            data.notes,
            Number(data.suppressed),
            now,
            now,
            payload.revision,
          )
          .run();
      if (!result.meta.changes)
        return json({ error: 'Contact changed. Reload before saving.' }, 409);
      if (data.suppressed)
        await env.DB.prepare(
          "UPDATE recruiter_outreach SET status = 'cancelled', updated_at = ? WHERE candidate_id = ? AND status IN ('draft', 'approved')",
        )
          .bind(now, contact.id)
          .run();
      await auditStatement(
        access.organization.id,
        access.userId,
        data.suppressed ? 'crm_contact_suppressed' : 'crm_contact_updated',
        contact.id,
      ).run();
      return json({ saved: true });
    }
    const eligible =
      contact.eligible === 1 &&
      !contact.suppressed &&
      contact.email &&
      /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contact.email);
    if (payload.action === 'draft') {
      if (!eligible)
        return json(
          {
            error:
              'Outreach is blocked: an active application or future-role opt-in, a valid email, and no contact suppression are required.',
          },
          409,
        );
      const data = validateOutreach(payload);
      const id = crypto.randomUUID();
      await env.DB.batch([
        env.DB.prepare(
          'INSERT INTO recruiter_outreach (id, candidate_id, organization_id, created_by_user_id, subject, body, status, due_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        ).bind(
          id,
          contact.id,
          access.organization.id,
          access.userId,
          data.subject,
          data.body,
          'draft',
          data.dueAt,
          now,
          now,
        ),
        auditStatement(
          access.organization.id,
          access.userId,
          'outreach_drafted',
          id,
        ),
      ]);
      return json({ id }, 201);
    }
    const outreach = await env.DB.prepare(
      'SELECT id, status, subject, body, sent_at AS sentAt FROM recruiter_outreach WHERE id = ? AND candidate_id = ? AND organization_id = ?',
    )
      .bind(
        typeof payload.id === 'string' ? payload.id : '',
        contact.id,
        access.organization.id,
      )
      .first<{
        id: string;
        status: string;
        subject: string;
        body: string;
        sentAt: number | null;
      }>();
    if (!outreach) return json({ error: 'Outreach not found.' }, 404);
    if (payload.action === 'compose') {
      if (!eligible || outreach.status !== 'approved')
        return json(
          {
            error:
              'Only approved messages to eligible contacts can be composed.',
          },
          409,
        );
      return json({
        mailto: `mailto:${encodeURIComponent(contact.email!)}?subject=${encodeURIComponent(outreach.subject)}&body=${encodeURIComponent(outreach.body)}`,
        delivery: 'manual',
        note: 'Opening your email client does not send or mark this message as sent.',
      });
    }
    if (
      payload.action !== 'transition' ||
      !canTransitionOutreach(outreach.status, String(payload.status))
    )
      throw new Error('Invalid outreach transition.');
    if (['approved', 'sent'].includes(String(payload.status)) && !eligible)
      return json(
        { error: 'Outreach is no longer permitted for this contact.' },
        409,
      );
    if (payload.status === 'sent' && payload.confirmedSent !== true)
      throw new Error(
        'Confirm that you actually sent this email before recording it as sent.',
      );
    const result = await env.DB.prepare(
      'UPDATE recruiter_outreach SET status = ?, sent_at = ?, updated_at = ? WHERE id = ? AND status = ?',
    )
      .bind(
        payload.status,
        payload.status === 'sent' ? now : outreach.sentAt,
        now,
        outreach.id,
        outreach.status,
      )
      .run();
    if (!result.meta.changes)
      return json({ error: 'Outreach changed. Reload to retry.' }, 409);
    await auditStatement(
      access.organization.id,
      access.userId,
      `outreach_${String(payload.status)}`,
      outreach.id,
    ).run();
    return json({ saved: true });
  } catch (error) {
    return failure(error);
  }
}
