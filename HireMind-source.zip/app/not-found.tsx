import { StableLink as Link } from '@/components/stable-link';
import { ArrowLeft, SearchX } from 'lucide-react';

export default function NotFound() {
  return (
    <main className="product-error-page">
      <section>
        <SearchX />
        <span>404</span>
        <h1>This page is not part of the hiring workspace.</h1>
        <p>
          The link may be old, incomplete, or connected to a record you cannot
          access.
        </p>
        <Link href="/">
          <ArrowLeft /> Return to HireMind
        </Link>
      </section>
    </main>
  );
}
