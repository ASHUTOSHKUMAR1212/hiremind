import { LegalPage, LegalSection } from '../legal-page';

export default function TermsPage() {
  return (
    <LegalPage
      eyebrow="Terms"
      title="Terms for using HireMind"
      updated="2 September 2026"
    >
      <LegalSection title="Use of the service">
        <p>
          Use HireMind only for legitimate hiring and job-search activity. Do
          not upload information you do not have the right to process,
          impersonate another person, interfere with the service, or use
          candidate information outside the stated hiring purpose.
        </p>
      </LegalSection>
      <LegalSection title="Employer responsibilities">
        <p>
          Employers define the job criteria and remain accountable for every
          decision. They must review evidence and uncertainty, provide
          appropriate access only to authorized team members, follow employment
          and privacy law, and avoid unlawful discrimination.
        </p>
      </LegalSection>
      <LegalSection title="Candidate responsibilities">
        <p>
          Candidates are responsible for the accuracy of their profile, résumé,
          interview answers, and supporting evidence. Imported résumé fields are
          editable and remain self-attested unless separately verified.
        </p>
      </LegalSection>
      <LegalSection title="Evidence indicators">
        <p>
          Scores and classifications are decision-support signals, not
          guarantees of suitability, performance, eligibility, or employment.
          They must not be used as an automatic rejection or hiring mechanism.
        </p>
      </LegalSection>
      <LegalSection title="Availability and changes">
        <p>
          The service may change as reliability, security, and product behavior
          improve. Features that depend on third-party identity, email, storage,
          or network services may be affected by those services.
        </p>
      </LegalSection>
      <LegalSection title="No employment guarantee">
        <p>
          HireMind does not employ candidates, act as an employment agency, or
          guarantee interviews, offers, hires, or outcomes. Any offer or
          contract is between the candidate and employer.
        </p>
      </LegalSection>
    </LegalPage>
  );
}
