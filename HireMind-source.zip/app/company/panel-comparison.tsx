'use client';
import { comparePanel, type PanelReview } from '@/lib/panel-comparison';
import { transcriptTime } from '@/lib/interview-transcript';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

export default function PanelComparison({
  rubric,
  reviews,
  transcriptRevision,
}: {
  rubric: Array<{ id: string; label: string }>;
  reviews: PanelReview[];
  transcriptRevision: number;
}) {
  const panel = comparePanel(rubric, reviews, transcriptRevision);
  return (
    <Card>
      <CardContent className="space-y-4 p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-xl font-semibold">Panel comparison</h2>
          <Badge variant="outline">
            {panel.reviewerCount} current submitted reviews
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground">
          Compare evidence before deciding. A spread of two or more points on
          the 1–4 scale is flagged for discussion, not averaged into a hiring
          score. Drafts and {panel.excludedSubmitted} stale submitted reviews
          are excluded.
        </p>
        {!panel.reviewerCount ? (
          <p>
            Submit a source-linked review to begin. At least two current reviews
            are needed to compare ratings.
          </p>
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Job requirement</TableHead>
                  <TableHead>Rated</TableHead>
                  <TableHead>Unassessed</TableHead>
                  <TableHead>Range</TableHead>
                  <TableHead>Panel status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {panel.criteria.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>{item.label}</TableCell>
                    <TableCell>{item.ratedCount}</TableCell>
                    <TableCell>{item.unassessedCount}</TableCell>
                    <TableCell>
                      {item.minimum === null
                        ? '—'
                        : `${item.minimum}–${item.maximum} / 4`}
                    </TableCell>
                    <TableCell>
                      {item.needsDiscussion
                        ? 'Discuss rating difference'
                        : item.ratedCount < 2
                          ? 'More ratings needed'
                          : item.minimum === item.maximum
                            ? 'Same rating'
                            : 'One-point difference'}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            {panel.criteria.map((item) => (
              <details key={item.id} className="rounded-xl border p-4">
                <summary className="cursor-pointer font-medium">
                  {item.label} — review rationales and citations
                  {item.needsDiscussion ? ' · discussion needed' : ''}
                </summary>
                <div className="mt-4 grid gap-4 lg:grid-cols-2">
                  {item.assessments.map((assessment) => (
                    <section
                      key={assessment.reviewerId}
                      className="min-w-0 space-y-3 rounded-lg bg-muted/40 p-4"
                    >
                      <h3 className="font-semibold">
                        {assessment.reviewerName} ·{' '}
                        {assessment.rating === null
                          ? 'Unassessed'
                          : `${assessment.rating}/4`}
                      </h3>
                      {assessment.missingCitation && (
                        <p className="text-sm text-red-800">
                          This rating’s saved citation is incomplete and has
                          been excluded. Ask the reviewer to update it.
                        </p>
                      )}
                      <p className="whitespace-pre-wrap break-words">
                        {assessment.rationale}
                      </p>
                      {assessment.sources.map((source) => (
                        <blockquote
                          key={source.id}
                          className="border-l-2 border-primary/30 pl-3"
                        >
                          <p className="text-sm font-medium">
                            {transcriptTime(source.startMs)}–
                            {transcriptTime(source.endMs)} · {source.speaker}
                          </p>
                          <p className="break-words">{source.text}</p>
                        </blockquote>
                      ))}
                    </section>
                  ))}
                </div>
              </details>
            ))}
          </>
        )}
      </CardContent>
    </Card>
  );
}
