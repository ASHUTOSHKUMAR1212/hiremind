'use client';
import { useCallback, useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import {
  downloadEndpoint,
  downloadText,
  toolRequest,
  ToolNotice,
  ToolSelect,
} from './tool-controls';

type Key = {
  id: string;
  label: string;
  scopes: string[];
  expiresAt: number;
  revokedAt: number | null;
  lastUsedAt: number | null;
};
type Interview = {
  id: string;
  candidateName: string;
  jobTitle: string;
  scheduledAt: number | null;
};

export default function EmployerIntegrations({
  canManage,
  canExport,
  canSchedule,
  interviews,
}: {
  canManage: boolean;
  canExport: boolean;
  canSchedule: boolean;
  interviews: Interview[];
}) {
  const [keys, setKeys] = useState<Key[]>([]);
  const [label, setLabel] = useState('');
  const [includeCandidates, setIncludeCandidates] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [token, setToken] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [sessionId, setSessionId] = useState(
    interviews.find((item) => item.scheduledAt)?.id ?? '',
  );
  const [duration, setDuration] = useState('60');
  const [checkedAt, setCheckedAt] = useState(() => Date.now());
  const load = useCallback(async () => {
    if (!canManage) return;
    try {
      const data = await toolRequest<{ items: Key[] }>(
        '/api/company/integration-keys',
      );
      setKeys(data.items);
      setCheckedAt(Date.now());
    } catch (e) {
      setError((e as Error).message);
    }
  }, [canManage]);
  useEffect(() => {
    const timer = window.setTimeout(() => void load(), 0);
    return () => window.clearTimeout(timer);
  }, [load]);
  async function create() {
    setBusy(true);
    setError('');
    setToken('');
    try {
      const data = await toolRequest<{ token: string }>(
        '/api/company/integration-keys',
        'POST',
        {
          label,
          scopes: [
            'jobs:read',
            ...(includeCandidates ? ['applications:read'] : []),
          ],
          candidateDataConfirmed: confirmed,
        },
      );
      setToken(data.token);
      setLabel('');
      await load();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function revoke(id: string) {
    if (
      !window.confirm(
        'Revoke this key? Connected systems using it will immediately lose access.',
      )
    )
      return;
    setBusy(true);
    try {
      await toolRequest(
        `/api/company/integration-keys?id=${encodeURIComponent(id)}`,
        'DELETE',
      );
      setToken('');
      await load();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function download(url: string, name: string) {
    setBusy(true);
    setError('');
    try {
      await downloadEndpoint(url, name);
      setNotice(
        'Export downloaded. Import it in your chosen tool; it is not a live sync.',
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold">Integrations</h1>
        <p className="mt-2 text-[#726979]">
          Exchange recruiting data and interview dates with your existing tools.
        </p>
      </div>
      <ToolNotice message={error} error />
      <ToolNotice message={notice} />
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardContent className="space-y-4 pt-6">
            <h2 className="text-xl font-semibold">Calendar export</h2>
            <p className="text-sm">
              Download an iCalendar file for Google Calendar, Outlook, or Apple
              Calendar. This is a one-time export; reschedules and cancellations
              require a new import. No invitations are sent.
            </p>
            <ToolSelect
              label="Scheduled interview"
              value={sessionId}
              onChange={setSessionId}
              options={interviews
                .filter((item) => item.scheduledAt)
                .map((item) => ({
                  value: item.id,
                  label: `${item.candidateName} · ${item.jobTitle}`,
                }))}
            />
            <ToolSelect
              label="Planning duration · not an enforced interview limit"
              value={duration}
              onChange={setDuration}
              options={[30, 45, 60, 90, 120].map((value) => ({
                value: String(value),
                label: `${value} minutes`,
              }))}
            />
            <Button
              disabled={!canSchedule || !sessionId || busy}
              onClick={() =>
                void download(
                  `/api/interviews/calendar?id=${encodeURIComponent(sessionId)}&duration=${duration}`,
                  'hiremind-interview.ics',
                )
              }
            >
              Download calendar event
            </Button>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="space-y-4 pt-6">
            <h2 className="text-xl font-semibold">Recruiting data export</h2>
            <p className="text-sm">
              Export your company’s applications and screening explanations for
              spreadsheet review or import into another system. The receiving
              system may require column mapping.
            </p>
            <Button
              disabled={!canExport || busy}
              onClick={() =>
                void download(
                  '/api/company/export',
                  'hiremind-applications.csv',
                )
              }
            >
              Download applications CSV
            </Button>
            <p className="text-sm text-[#726979]">
              Dedicated ATS connectors and bidirectional calendar sync are not
              connected. The API below supplies a real read-only integration
              interface, not a claim of a vendor partnership.
            </p>
          </CardContent>
        </Card>
      </div>
      <Card>
        <CardContent className="space-y-4 pt-6">
          <h2 className="text-xl font-semibold">Read-only integration API</h2>
          <p className="text-sm">
            Connect a server-side HTTP step in your automation tool or ATS
            middleware. Keys expire after 90 days, belong to this company, and
            can be revoked. Never place a key in a URL, browser app, screenshot,
            or public repository.
          </p>
          <pre className="overflow-x-auto rounded-xl bg-[#2d2335] p-4 text-sm text-white">
            {
              'GET /api/integrations/export?resource=jobs\nAuthorization: Bearer YOUR_INTEGRATION_KEY\n\nOptional resource: applications (requires scope)\nPagination: pass nextCursor as the after query parameter'
            }
          </pre>
          <p className="text-sm">
            Each response includes schemaVersion, items, and nextCursor. Poll
            full snapshots and reconcile by stable IDs. This is not a change
            feed; records removed by retention/deletion may disappear.
          </p>
          <Button
            variant="outline"
            onClick={() =>
              downloadText(
                JSON.stringify(
                  {
                    baseUrl:
                      'https://hiremind-evidence-first.sharmaaishu84.chatgpt.site',
                    endpoint: '/api/integrations/export',
                    method: 'GET',
                    authorization: 'Bearer <integration key>',
                    resources: ['jobs', 'applications'],
                    pagination: {
                      parameter: 'after',
                      response: 'nextCursor',
                      pageSize: 100,
                    },
                    schemaVersion: 1,
                    mode: 'Read-only full snapshots; no push updates or write-back. Keep keys server-side.',
                  },
                  null,
                  2,
                ),
                'hiremind-integration-contract.json',
              )
            }
          >
            Download connection contract
          </Button>
          {canManage ? (
            <>
              <label
                htmlFor="integration-label"
                className="grid gap-2 text-sm font-medium"
              >
                Connection label
                <Input
                  id="integration-label"
                  value={label}
                  onChange={(e) => setLabel(e.target.value)}
                  maxLength={80}
                  placeholder="e.g. Internal reporting automation"
                />
              </label>
              <label
                htmlFor="integration-candidate-scope"
                className="flex items-center gap-3 text-sm"
              >
                <Checkbox
                  id="integration-candidate-scope"
                  checked={includeCandidates}
                  onCheckedChange={(value) => {
                    setIncludeCandidates(value === true);
                    setConfirmed(false);
                  }}
                />
                Allow application details, including candidate names and email
                addresses
              </label>
              {includeCandidates && (
                <label
                  htmlFor="integration-authorize"
                  className="flex items-center gap-3 text-sm"
                >
                  <Checkbox
                    id="integration-authorize"
                    checked={confirmed}
                    onCheckedChange={(value) => setConfirmed(value === true)}
                  />
                  I authorize the connected system to access this company’s
                  candidate data.
                </label>
              )}
              <Button
                disabled={
                  !label.trim() || busy || (includeCandidates && !confirmed)
                }
                onClick={() => void create()}
              >
                Create scoped key
              </Button>
              {token && (
                <div className="space-y-3 rounded-xl border border-amber-300 bg-amber-50 p-4">
                  <p className="text-sm font-semibold">
                    Copy now. This key is shown once and is not stored in
                    readable form.
                  </p>
                  <Input
                    aria-label="New integration key"
                    type="password"
                    readOnly
                    value={token}
                    autoComplete="off"
                  />
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant="outline"
                      onClick={() => {
                        void navigator.clipboard
                          .writeText(token)
                          .then(() =>
                            setNotice(
                              'Key copied. Store it securely in your server-side connector.',
                            ),
                          )
                          .catch(() =>
                            setError(
                              'Clipboard unavailable. Select and copy the key field manually.',
                            ),
                          );
                      }}
                    >
                      Copy key
                    </Button>
                    <Button variant="outline" onClick={() => setToken('')}>
                      Dismiss secret
                    </Button>
                  </div>
                </div>
              )}
              <h3 className="font-semibold">Connection keys</h3>
              {!keys.length && (
                <p className="text-sm">No integration keys created.</p>
              )}
              {keys.map((key) => (
                <div
                  key={key.id}
                  className="flex flex-wrap items-center justify-between gap-3 rounded-xl border p-3 text-sm"
                >
                  <div>
                    <strong>{key.label}</strong>
                    <p>
                      {key.scopes.join(', ')} ·{' '}
                      {key.revokedAt
                        ? 'Revoked'
                        : key.expiresAt <= checkedAt
                          ? 'Expired'
                          : `Expires ${new Date(key.expiresAt).toLocaleDateString()}`}
                    </p>
                    <p>
                      Last used:{' '}
                      {key.lastUsedAt
                        ? new Date(key.lastUsedAt).toLocaleString()
                        : 'Never'}
                    </p>
                  </div>
                  {!key.revokedAt && (
                    <Button
                      variant="outline"
                      disabled={busy}
                      onClick={() => void revoke(key.id)}
                    >
                      Revoke
                    </Button>
                  )}
                </div>
              ))}
            </>
          ) : (
            <p className="text-sm">
              Only company owners and admins can create or revoke connection
              keys.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
