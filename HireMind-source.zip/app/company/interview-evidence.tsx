'use client';
import { useCallback, useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import PanelComparison from './panel-comparison';
import {
  transcriptTime,
  type TranscriptSegment,
  type ScorecardEntry,
} from '@/lib/interview-transcript';
import {
  downloadText,
  toolRequest,
  ToolNotice,
  ToolSelect,
} from './tool-controls';

type Rubric = {
  id: string;
  label: string;
  requirementClass?: string;
  evidenceDefinition?: string;
};
type Review = {
  reviewerId: string;
  reviewerName: string;
  transcriptRevision: number;
  entries: ScorecardEntry[];
  rubric: Rubric[];
  status: string;
  revision: number;
  stale: boolean;
  sourceSegments: TranscriptSegment[];
};
type Evidence = {
  userId: string;
  rubric: Rubric[];
  transcript: {
    revision: number;
    sourceName: string;
    segments: TranscriptSegment[];
    consentNote: string;
  } | null;
  scorecards: Review[];
};
type Interview = {
  id: string;
  candidateName: string;
  jobTitle: string;
  status: string;
};

export default function InterviewEvidence({
  interviews,
}: {
  interviews: Interview[];
}) {
  const [sessionId, setSessionId] = useState(interviews[0]?.id ?? '');
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold">Interview evidence</h1>
        <p className="mt-2 text-[#726979]">
          Review timestamped transcripts and attach evidence to each job
          criterion.
        </p>
      </div>
      <ToolSelect
        label="Interview"
        value={sessionId}
        onChange={setSessionId}
        options={interviews.map((item) => ({
          value: item.id,
          label: `${item.candidateName} · ${item.jobTitle} · ${item.status}`,
        }))}
      />
      {sessionId ? (
        <EvidenceEditor key={sessionId} sessionId={sessionId} />
      ) : (
        <p>
          No interviews yet. Schedule an interview from an application first.
        </p>
      )}
    </div>
  );
}

function EvidenceEditor({ sessionId }: { sessionId: string }) {
  const [data, setData] = useState<Evidence | null>(null);
  const [entries, setEntries] = useState<ScorecardEntry[]>([]);
  const [file, setFile] = useState<File | null>(null);
  const [consent, setConsent] = useState(false);
  const [consentNote, setConsentNote] = useState('');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const load = useCallback(async () => {
    setLoading(true);
    try {
      const result = await toolRequest<Evidence>(
        `/api/company/interview-evidence?sessionId=${encodeURIComponent(sessionId)}`,
      );
      setData(result);
      const mine = result.scorecards.find(
        (item) => item.reviewerId === result.userId,
      );
      setEntries(
        mine && !mine.stale
          ? mine.entries
          : result.rubric.map((criterion) => ({
              criterionId: criterion.id,
              rating: null,
              rationale: '',
              segmentIds: [],
            })),
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [sessionId]);
  useEffect(() => {
    const timer = window.setTimeout(() => void load(), 0);
    return () => window.clearTimeout(timer);
  }, [load]);
  const mine = data?.scorecards.find((item) => item.reviewerId === data.userId);
  const segments = data?.transcript?.segments ?? [];
  async function importFile() {
    if (!file || !data) return;
    setBusy(true);
    setError('');
    setNotice('');
    try {
      if (file.size > 200_000)
        throw new Error('Use a VTT/SRT transcript under 200 KB.');
      if (
        data.transcript &&
        !window.confirm(
          'Replace this transcript? Existing scorecards will be marked stale and must be reviewed again.',
        )
      )
        return;
      await toolRequest('/api/company/interview-evidence', 'POST', {
        action: 'import',
        sessionId,
        revision: data.transcript?.revision ?? 0,
        sourceName: file.name,
        text: await file.text(),
        consentConfirmed: consent,
        consentNote,
      });
      await load();
      setNotice(
        'Transcript saved. Speaker labels and transcription are source-provided; verify them before rating.',
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function save(status: string) {
    if (!data) return;
    setBusy(true);
    setError('');
    setNotice('');
    try {
      await toolRequest('/api/company/interview-evidence', 'POST', {
        action: 'scorecard',
        sessionId,
        transcriptRevision: data.transcript?.revision,
        rubric: data.rubric,
        revision: mine?.revision ?? 0,
        status,
        entries,
      });
      await load();
      setNotice(
        status === 'submitted'
          ? 'Review submitted to your team. No application decision was changed.'
          : 'Private draft saved.',
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  function update(index: number, value: Partial<ScorecardEntry>) {
    setEntries((previous) =>
      previous.map((item, i) => (i === index ? { ...item, ...value } : item)),
    );
  }
  return (
    <div className="space-y-6">
      <ToolNotice message={error} error />
      <ToolNotice message={notice} />
      <Card>
        <CardContent className="space-y-4 pt-6">
          <h2 className="text-xl font-semibold">Import transcript</h2>
          <p className="text-sm text-[#726979]">
            Upload a VTT or SRT export from your meeting/transcription tool.
            HireMind does not record audio or automatically transcribe calls in
            this release.
          </p>
          <label
            htmlFor="transcript-file"
            className="grid gap-2 text-sm font-medium"
          >
            Transcript file
            <Input
              id="transcript-file"
              type="file"
              accept=".vtt,.srt,text/vtt"
              disabled={busy || loading}
              onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            />
          </label>
          <label
            htmlFor="transcript-consent"
            className="flex items-center gap-3 text-sm"
          >
            <Checkbox
              id="transcript-consent"
              checked={consent}
              onCheckedChange={(value) => setConsent(value === true)}
            />
            Participants agreed to transcription and this hiring review.
          </label>
          <label
            htmlFor="transcript-consent-note"
            className="grid gap-2 text-sm font-medium"
          >
            Consent record
            <Input
              id="transcript-consent-note"
              value={consentNote}
              onChange={(e) => setConsentNote(e.target.value)}
              maxLength={600}
              placeholder="How and when participant consent was obtained"
            />
          </label>
          <Button
            disabled={
              !file ||
              !consent ||
              consentNote.trim().length < 12 ||
              busy ||
              loading ||
              !data
            }
            onClick={() => void importFile()}
          >
            Import transcript
          </Button>
        </CardContent>
      </Card>
      {loading ? (
        <output>Loading interview evidence…</output>
      ) : !data ? (
        <Button onClick={() => void load()}>Retry loading</Button>
      ) : data.transcript ? (
        <>
          {mine?.stale && (
            <ToolNotice message="Your previous review refers to an older transcript or job rubric. Start a fresh review; the old review remains visible below." />
          )}
          <div className="grid gap-6 xl:grid-cols-2">
            <Card>
              <CardContent className="space-y-4 pt-6">
                <h2 className="text-xl font-semibold">
                  Transcript · revision {data.transcript.revision}
                </h2>
                <p className="text-sm">{data.transcript.sourceName}</p>
                <label
                  htmlFor="transcript-search"
                  className="grid gap-2 text-sm"
                >
                  Find in transcript
                  <Input
                    id="transcript-search"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Search words or speaker"
                  />
                </label>
                <div className="max-h-[700px] space-y-3 overflow-y-auto pr-2">
                  {segments
                    .filter((segment) =>
                      `${segment.speaker} ${segment.text}`
                        .toLowerCase()
                        .includes(query.toLowerCase()),
                    )
                    .map((segment) => (
                      <article
                        id={segment.id}
                        key={segment.id}
                        tabIndex={-1}
                        className="scroll-mt-24 rounded-xl border p-3 text-sm target:bg-[#f3edf5]"
                      >
                        <p className="font-semibold">
                          {transcriptTime(segment.startMs)}–
                          {transcriptTime(segment.endMs)} · {segment.speaker}
                        </p>
                        <p className="mt-2 whitespace-pre-wrap">
                          {segment.text}
                        </p>
                        <p className="mt-2 text-[#726979]">{segment.id}</p>
                      </article>
                    ))}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="space-y-5 pt-6">
                <h2 className="text-xl font-semibold">
                  Your criterion scorecard
                </h2>
                <p className="text-sm">
                  1 weak evidence · 2 partial · 3 supported · 4 strong.
                  Unassessed is not a failing score. Ratings are your judgment,
                  not an AI verdict.
                </p>
                {data.rubric.map((criterion, index) => {
                  const entry = entries[index];
                  if (!entry) return null;
                  return (
                    <section
                      key={criterion.id}
                      className="space-y-3 rounded-xl border p-4"
                    >
                      <h3 className="font-semibold">{criterion.label}</h3>
                      {criterion.evidenceDefinition && (
                        <p className="text-sm text-[#726979]">
                          {criterion.evidenceDefinition}
                        </p>
                      )}
                      <ToolSelect
                        label="Assessment"
                        value={
                          entry.rating === null
                            ? 'unassessed'
                            : String(entry.rating)
                        }
                        onChange={(value) =>
                          update(index, {
                            rating:
                              value === 'unassessed' ? null : Number(value),
                          })
                        }
                        options={[
                          {
                            value: 'unassessed',
                            label: 'Unassessed — insufficient evidence',
                          },
                          ...[1, 2, 3, 4].map((value) => ({
                            value: String(value),
                            label: `${value} / 4`,
                          })),
                        ]}
                        disabled={busy}
                      />
                      <label
                        htmlFor={`rationale-${criterion.id}`}
                        className="grid gap-2 text-sm font-medium"
                      >
                        Rationale
                        <Textarea
                          id={`rationale-${criterion.id}`}
                          value={entry.rationale}
                          onChange={(e) =>
                            update(index, { rationale: e.target.value })
                          }
                          maxLength={2000}
                          disabled={busy}
                          placeholder="Explain what the cited answer demonstrates, or why you cannot assess it."
                        />
                      </label>
                      <ToolSelect
                        label="Add a transcript citation"
                        value=""
                        onChange={(id) => {
                          if (id && !entry.segmentIds.includes(id))
                            update(index, {
                              segmentIds: [...entry.segmentIds, id],
                            });
                        }}
                        disabled={busy || entry.segmentIds.length >= 20}
                        options={segments.map((segment) => ({
                          value: segment.id,
                          label: `${transcriptTime(segment.startMs)} · ${segment.speaker}: ${segment.text.slice(0, 80)}`,
                        }))}
                      />
                      {entry.segmentIds.map((id) => {
                        const source = segments.find((item) => item.id === id);
                        return (
                          <div
                            key={id}
                            className="rounded-lg bg-[#f7f3f8] p-3 text-sm"
                          >
                            <a
                              href={`#${id}`}
                              onClick={() => setQuery('')}
                              className="font-semibold underline"
                            >
                              {source ? transcriptTime(source.startMs) : id} ·{' '}
                              {source?.speaker}
                            </a>
                            <blockquote className="my-2">
                              {source?.text}
                            </blockquote>
                            <Button
                              size="sm"
                              variant="outline"
                              disabled={busy}
                              onClick={() =>
                                update(index, {
                                  segmentIds: entry.segmentIds.filter(
                                    (value) => value !== id,
                                  ),
                                })
                              }
                            >
                              Remove citation
                            </Button>
                          </div>
                        );
                      })}
                    </section>
                  );
                })}
                {!data.rubric.length && (
                  <p>Add criteria to this job before reviewing.</p>
                )}
                <div className="flex flex-wrap gap-3">
                  <Button
                    variant="outline"
                    disabled={busy || !entries.length}
                    onClick={() => void save('draft')}
                  >
                    Save private draft
                  </Button>
                  <Button
                    disabled={busy || !entries.length}
                    onClick={() => void save('submitted')}
                  >
                    Submit review to team
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
          <Card>
            <CardContent className="space-y-3 pt-6">
              <h2 className="text-xl font-semibold">Team reviews</h2>
              {!data.scorecards.length && (
                <p className="text-sm">No saved reviews yet.</p>
              )}
              {data.scorecards.map((card) => (
                <details
                  key={card.reviewerId}
                  className="rounded-xl border p-3"
                >
                  <summary className="cursor-pointer">
                    {card.reviewerName || 'Team reviewer'} · {card.status}
                    {card.stale
                      ? ' · stale source — do not use without review'
                      : ''}
                  </summary>
                  {card.entries.map((entry) => (
                    <div key={entry.criterionId} className="mt-3 text-sm">
                      <strong>
                        {
                          card.rubric.find((c) => c.id === entry.criterionId)
                            ?.label
                        }
                        :{' '}
                        {entry.rating === null
                          ? 'Unassessed'
                          : `${entry.rating}/4`}
                      </strong>
                      <p>{entry.rationale}</p>
                      <p>
                        Transcript revision {card.transcriptRevision}:{' '}
                        {entry.segmentIds.join(', ') || 'No citations'}
                      </p>
                      {entry.segmentIds.map((id) => {
                        const source = card.sourceSegments.find(
                          (segment) => segment.id === id,
                        );
                        return source ? (
                          <blockquote
                            key={id}
                            className="my-2 rounded-lg bg-[#f7f3f8] p-3"
                          >
                            <strong>
                              {transcriptTime(source.startMs)} ·{' '}
                              {source.speaker}
                            </strong>
                            <p>{source.text}</p>
                          </blockquote>
                        ) : null;
                      })}
                    </div>
                  ))}
                </details>
              ))}
              <Button
                variant="outline"
                onClick={() =>
                  downloadText(
                    JSON.stringify({ sessionId, ...data }, null, 2),
                    'hiremind-interview-evidence.json',
                  )
                }
              >
                Export transcript and available reviews
              </Button>
            </CardContent>
          </Card>
          <PanelComparison rubric={data.rubric} reviews={data.scorecards} transcriptRevision={data.transcript.revision} />
        </>
      ) : (
        <p className="rounded-xl border border-dashed p-6 text-[#726979]">
          No transcript has been imported. Upload one to create a source-linked
          scorecard.
        </p>
      )}
    </div>
  );
}
