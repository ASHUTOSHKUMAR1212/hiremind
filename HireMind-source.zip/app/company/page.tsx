'use client';

import { useEffect, useState } from 'react';

import { authenticatedFetch, getSupabaseBrowserClient } from '@/lib/supabase/client';

import CompanyWorkspace from './workspace-client';

type CompanyAccount = {
  user: { email: string; fullName: string | null };
  organization: { id: string; name: string; roleKey: string } | null;
};

export default function CompanyPage() {
  const [account, setAccount] = useState<CompanyAccount | null>(null);

  useEffect(() => {
    async function load() {
      const { data } = await getSupabaseBrowserClient().auth.getSession();
      if (!data.session) {
        window.location.replace('/login?next=/company&role=company');
        return;
      }
      const response = await authenticatedFetch('/api/me');
      if (!response.ok) {
        window.location.replace('/login?next=/company&role=company');
        return;
      }
      const nextAccount = await response.json() as CompanyAccount;
      if (!nextAccount.organization) {
        window.location.replace('/onboarding?role=company');
        return;
      }
      setAccount(nextAccount);
    }
    void load();
  }, []);

  if (!account?.organization) {
    return <main className="auth-transition"><span className="candidate-brand-mark">h</span><p>Opening your employer workspace…</p></main>;
  }

  return <CompanyWorkspace userName={account.user.fullName ?? account.user.email} userEmail={account.user.email} organizationName={account.organization.name} organizationRole={account.organization.roleKey} />;
}
