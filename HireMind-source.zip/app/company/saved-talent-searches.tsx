'use client';

import { useEffect, useState } from 'react';
import { authenticatedFetch } from '@/lib/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

type Filters = { jobId: string; q: string; location: string };
type SavedSearch = Filters & { id: string; name: string; jobTitle: string };
const path = '/api/company/saved-talent-searches';

export default function SavedTalentSearches({
  filters,
  jobs,
  disabled,
  canSave,
  onLoad,
}: {
  filters: Filters;
  jobs: Array<{ id: string; title: string }>;
  disabled: boolean;
  canSave: boolean;
  onLoad: (filters: Filters) => void;
}) {
  const [searches, setSearches] = useState<SavedSearch[]>([]);
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [retry, setRetry] = useState(0);
  const [removing, setRemoving] = useState<SavedSearch | null>(null);
  useEffect(() => {
    let active = true;
    const controller = new AbortController();
    void (async () => {
      try {
        const response = await authenticatedFetch(path, {
          signal: controller.signal,
        });
        const data = (await response.json()) as {
          error?: string;
          searches?: SavedSearch[];
        };
        if (!response.ok || !Array.isArray(data.searches))
          throw new Error(data.error || 'Could not load saved searches.');
        if (active) setSearches(data.searches);
      } catch (failure) {
        if (active)
          setError(
            failure instanceof Error
              ? failure.message
              : 'Could not load saved searches.',
          );
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
      controller.abort();
    };
  }, [retry]);

  async function save() {
    if (
      busy ||
      loading ||
      disabled ||
      !canSave ||
      !name.trim() ||
      searches.length >= 20
    )
      return;
    setBusy(true);
    setError('');
    setNotice('');
    try {
      const response = await authenticatedFetch(path, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...filters, name: name.trim() }),
      });
      const data = (await response.json()) as { error?: string; id?: string };
      if (!response.ok || !data.id)
        throw new Error(data.error || 'Could not save this search.');
      const id = data.id;
      setSearches((previous) => [
        {
          ...filters,
          name: name.trim(),
          id,
          jobTitle:
            jobs.find((job) => job.id === filters.jobId)?.title || 'Job',
        },
        ...previous,
      ]);
      setName('');
      setNotice('Search saved. Only you can see it.');
    } catch (failure) {
      setError(
        failure instanceof Error
          ? failure.message
          : 'Could not save this search.',
      );
    } finally {
      setBusy(false);
    }
  }
  async function remove() {
    if (!removing) return;
    setBusy(true);
    setError('');
    setNotice('');
    try {
      const response = await authenticatedFetch(
        `${path}?${new URLSearchParams({ id: removing.id })}`,
        { method: 'DELETE' },
      );
      const data = (await response.json()) as { error?: string };
      if (!response.ok)
        throw new Error(data.error || 'Could not remove this search.');
      setSearches((previous) =>
        previous.filter((search) => search.id !== removing.id),
      );
      setRemoving(null);
      setNotice('Saved search removed. Candidate records are unchanged.');
    } catch (failure) {
      setError(
        failure instanceof Error
          ? failure.message
          : 'Could not remove this search.',
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="rounded-2xl border p-4 space-y-4">
      <div>
        <h2 className="font-semibold">Your saved searches</h2>
        <p className="text-sm text-muted-foreground">
          Save the selected job and applied filters. Loading a search checks
          current consent again.
        </p>
      </div>
      <form
        className="flex flex-wrap items-end gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          void save();
        }}
      >
        <div className="flex-1 min-w-40 space-y-1">
          <label htmlFor="saved-talent-name" className="text-sm">
            Search name
          </label>
          <Input
            id="saved-talent-name"
            value={name}
            onChange={(event) => setName(event.target.value)}
            maxLength={60}
            required
            placeholder="e.g. Pune analysts"
            disabled={busy || loading}
          />
        </div>
        <Button
          type="submit"
          variant="outline"
          disabled={
            busy ||
            loading ||
            disabled ||
            !canSave ||
            !name.trim() ||
            searches.length >= 20
          }
        >
          Save current search
        </Button>
      </form>
      <p className="text-xs text-muted-foreground">
        {searches.length}/20 private searches. Apply any edited filters before
        saving.
      </p>
      {loading ? (
        <output className="block">Loading saved searches…</output>
      ) : searches.length === 0 ? (
        <p className="text-sm text-muted-foreground">No saved searches yet.</p>
      ) : (
        <ul className="space-y-2">
          {searches.map((search) => (
            <li
              key={search.id}
              className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-muted/40 p-3"
            >
              <div className="min-w-0 flex-1 break-words">
                <p className="font-medium">{search.name}</p>
                <p className="text-sm text-muted-foreground">
                  {search.jobTitle} · {search.q || 'All keywords'} ·{' '}
                  {search.location || 'All locations'}
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  disabled={
                    busy ||
                    disabled ||
                    !jobs.some((job) => job.id === search.jobId)
                  }
                  aria-label={`Load ${search.name}`}
                  onClick={() => {
                    onLoad({
                      jobId: search.jobId,
                      q: search.q,
                      location: search.location,
                    });
                    setNotice(
                      `Loaded ${search.name}. Refreshing eligible profiles.`,
                    );
                  }}
                >
                  Load
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  disabled={busy}
                  aria-label={`Remove ${search.name}`}
                  onClick={() => {
                    setError('');
                    setRemoving(search);
                  }}
                >
                  Remove
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}
      {error && !removing && (
        <div role="alert" className="text-sm text-destructive">
          {error}{' '}
          <Button
            variant="link"
            disabled={busy || loading}
            onClick={() => {
              setLoading(true);
              setError('');
              setRetry((value) => value + 1);
            }}
          >
            Reload saved searches
          </Button>
        </div>
      )}
      {notice && <output className="block text-sm">{notice}</output>}
      <AlertDialog
        open={Boolean(removing)}
        onOpenChange={(open) => {
          if (!open && !busy) setRemoving(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove this saved search?</AlertDialogTitle>
            <AlertDialogDescription>
              “{removing?.name}” will be removed from your list. No candidate
              records or applications will be deleted.
            </AlertDialogDescription>
          </AlertDialogHeader>
          {error && (
            <p role="alert" className="text-sm text-destructive">
              {error}
            </p>
          )}
          <AlertDialogFooter>
            <AlertDialogCancel disabled={busy}>Keep search</AlertDialogCancel>
            <AlertDialogAction disabled={busy} onClick={() => void remove()}>
              {busy ? 'Removing…' : 'Remove search'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
