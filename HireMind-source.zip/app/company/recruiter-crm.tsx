'use client';
import { useCallback, useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { CRM_STAGES } from '@/lib/recruiter-crm';
import { toolRequest, ToolNotice, ToolSelect } from './tool-controls';

type Contact = {
  id: string;
  name: string;
  email: string | null;
  stage: string;
  tags: string[];
  notes: string;
  suppressed: number;
  revision: number;
  eligible: number;
};
type Outreach = {
  id: string;
  subject: string;
  body: string;
  status: string;
  dueAt: number | null;
  sentAt: number | null;
};

export default function RecruiterCRM() {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [query, setQuery] = useState('');
  const [submittedQuery, setSubmittedQuery] = useState('');
  const [selected, setSelected] = useState('');
  const [offset, setOffset] = useState(0);
  const [next, setNext] = useState<number | null>(null);
  const [due, setDue] = useState<
    Array<{
      id: string;
      candidateId: string;
      name: string;
      subject: string;
      dueAt: number;
    }>
  >([]);
  const [refresh, setRefresh] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  useEffect(() => {
    let active = true;
    const timer = window.setTimeout(() => {
      setLoading(true);
      setError('');
      void toolRequest<{
        items: Contact[];
        nextOffset: number | null;
        due: typeof due;
      }>(
        `/api/company/crm?q=${encodeURIComponent(submittedQuery)}&offset=${offset}`,
      )
        .then((data) => {
          if (active) {
            setContacts(data.items);
            setNext(data.nextOffset);
            setDue(data.due);
          }
        })
        .catch((e) => {
          if (active) setError(e.message);
        })
        .finally(() => {
          if (active) setLoading(false);
        });
    }, 0);
    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [submittedQuery, offset, refresh]);
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold">Recruiter CRM</h1>
        <p className="mt-2 text-[#726979]">
          Manage candidate relationships, approve messages, and track
          follow-ups.
        </p>
      </div>
      <ToolNotice message={error} error />
      {due.length > 0 && (
        <Card>
          <CardContent className="space-y-3 pt-6">
            <h2 className="text-xl font-semibold">Follow-ups due</h2>
            <p className="text-sm text-[#726979]">
              Tasks for your team, not automatically sent emails. Check replies
              and contact eligibility before following up.
            </p>
            {due.map((item) => (
              <button
                key={item.id}
                className="block w-full rounded-xl border p-3 text-left text-sm"
                onClick={() => setSelected(item.candidateId)}
              >
                <strong>{item.name}</strong> · {item.subject} ·{' '}
                {new Date(item.dueAt).toLocaleString()}
              </button>
            ))}
          </CardContent>
        </Card>
      )}
      <div className="grid gap-6 lg:grid-cols-[300px_1fr]">
        <Card>
          <CardContent className="space-y-3 pt-6">
            <form
              className="flex gap-2"
              onSubmit={(event) => {
                event.preventDefault();
                setOffset(0);
                setSubmittedQuery(query);
                setRefresh((value) => value + 1);
              }}
            >
              <Input
                aria-label="Search contacts by name, email, or tag"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Name, email, tag"
                maxLength={100}
              />
              <Button type="submit" variant="outline">
                Search
              </Button>
            </form>
            {loading ? (
              <output>Loading contacts…</output>
            ) : !contacts.length ? (
              <p className="text-sm">No matching company applicants.</p>
            ) : (
              contacts.map((contact) => (
                <button
                  key={contact.id}
                  onClick={() => setSelected(contact.id)}
                  className={`block w-full rounded-xl border p-3 text-left text-sm ${selected === contact.id ? 'bg-[#f3edf5]' : ''}`}
                >
                  <strong>{contact.name}</strong>
                  <span className="block">
                    {contact.stage.replace('_', ' ')}
                    {contact.suppressed ? ' · do not contact' : ''}
                  </span>
                  <span className="block text-[#726979]">
                    {contact.tags.join(' · ')}
                  </span>
                </button>
              ))
            )}
            <div className="flex gap-2">
              <Button
                variant="outline"
                disabled={offset === 0 || loading}
                onClick={() => setOffset(Math.max(0, offset - 50))}
              >
                Previous
              </Button>
              <Button
                variant="outline"
                disabled={next === null || loading}
                onClick={() => setOffset(next!)}
              >
                Next
              </Button>
            </div>
          </CardContent>
        </Card>
        {selected ? (
          <ContactEditor
            key={selected}
            id={selected}
            onSaved={() => setRefresh((value) => value + 1)}
          />
        ) : (
          <div className="rounded-2xl border border-dashed p-8 text-[#726979]">
            Select a contact to view relationship notes and outreach history.
          </div>
        )}
      </div>
    </div>
  );
}

function ContactEditor({ id, onSaved }: { id: string; onSaved: () => void }) {
  const [contact, setContact] = useState<Contact | null>(null);
  const [outreach, setOutreach] = useState<Outreach[]>([]);
  const [tags, setTags] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [dueAt, setDueAt] = useState('');
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await toolRequest<{
        contact: Contact;
        outreach: Outreach[];
      }>(`/api/company/crm?candidateId=${encodeURIComponent(id)}`);
      setContact(data.contact);
      setTags(data.contact.tags.join(', '));
      setOutreach(data.outreach);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [id]);
  useEffect(() => {
    const timer = window.setTimeout(() => void load(), 0);
    return () => window.clearTimeout(timer);
  }, [load]);
  async function action(payload: Record<string, unknown>, success: string) {
    setBusy(true);
    setError('');
    setNotice('');
    try {
      await toolRequest('/api/company/crm', 'POST', {
        ...payload,
        candidateId: id,
      });
      await load();
      onSaved();
      setNotice(success);
      return true;
    } catch (e) {
      setError((e as Error).message);
      return false;
    } finally {
      setBusy(false);
    }
  }
  async function compose(item: Outreach) {
    setBusy(true);
    setError('');
    try {
      const result = await toolRequest<{ mailto: string }>(
        '/api/company/crm',
        'POST',
        { action: 'compose', candidateId: id, id: item.id },
      );
      window.location.href = result.mailto;
      setNotice(
        'Email draft opened. Send it in your email app, then confirm it below.',
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  const eligible =
    contact?.eligible === 1 && !contact.suppressed && Boolean(contact.email);
  if (!contact)
    return (
      <div>
        <ToolNotice message={error} error />
        {loading ? (
          <p>Loading contact…</p>
        ) : (
          <Button onClick={() => void load()}>Retry</Button>
        )}
      </div>
    );
  return (
    <div className="space-y-6">
      <ToolNotice message={error} error />
      <ToolNotice message={notice} />
      <Card>
        <CardContent className="space-y-4 pt-6">
          <h2 className="text-xl font-semibold">{contact.name}</h2>
          <p className="text-sm">{contact.email || 'No email address'}</p>
          <ToolSelect
            label="Relationship stage"
            value={contact.stage}
            onChange={(stage) => setContact({ ...contact, stage })}
            options={CRM_STAGES.map((stage) => ({
              value: stage,
              label: stage.replace('_', ' '),
            }))}
            disabled={busy || loading}
          />
          <label htmlFor="crm-tags" className="grid gap-2 text-sm font-medium">
            Tags · comma separated
            <Input
              id="crm-tags"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              maxLength={410}
              disabled={busy || loading}
            />
          </label>
          <label htmlFor="crm-notes" className="grid gap-2 text-sm font-medium">
            Team-only relationship notes
            <Textarea
              id="crm-notes"
              value={contact.notes}
              onChange={(e) =>
                setContact({ ...contact, notes: e.target.value })
              }
              maxLength={4000}
              disabled={busy || loading}
            />
          </label>
          <label
            htmlFor="crm-suppressed"
            className="flex items-center gap-3 text-sm"
          >
            <Checkbox
              id="crm-suppressed"
              checked={Boolean(contact.suppressed)}
              disabled={busy || loading}
              onCheckedChange={(value) =>
                setContact({ ...contact, suppressed: value === true ? 1 : 0 })
              }
            />
            Do not contact. Saving cancels pending drafts and approved outreach.
          </label>
          <Button
            disabled={busy || loading}
            onClick={() =>
              void action(
                {
                  action: 'contact',
                  ...contact,
                  tags: tags
                    .split(',')
                    .map((tag) => tag.trim())
                    .filter(Boolean),
                  suppressed: Boolean(contact.suppressed),
                },
                'Relationship saved.',
              )
            }
          >
            Save relationship
          </Button>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="space-y-4 pt-6">
          <h2 className="text-xl font-semibold">Draft outreach</h2>
          <p className="text-sm text-[#726979]">
            No automatic delivery is enabled. Approve a draft, send through your
            email app, then record the actual send. Follow-up dates create a
            task in this CRM.
          </p>
          {!eligible && (
            <ToolNotice message="Outreach is blocked. This contact needs an active application or future-role opt-in, a valid email, and no suppression." />
          )}
          <label
            htmlFor="crm-subject"
            className="grid gap-2 text-sm font-medium"
          >
            Subject
            <Input
              id="crm-subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              maxLength={160}
              disabled={!eligible || busy}
            />
          </label>
          <label htmlFor="crm-body" className="grid gap-2 text-sm font-medium">
            Message
            <Textarea
              id="crm-body"
              value={body}
              onChange={(e) => setBody(e.target.value)}
              maxLength={5000}
              disabled={!eligible || busy}
              placeholder="Explain the relevant role and why you are contacting them. Include how they can decline further contact."
            />
          </label>
          <label htmlFor="crm-due" className="grid gap-2 text-sm font-medium">
            Follow-up task date · optional · your local time
            <Input
              id="crm-due"
              type="datetime-local"
              value={dueAt}
              onChange={(e) => setDueAt(e.target.value)}
              disabled={!eligible || busy}
            />
          </label>
          <Button
            disabled={
              !eligible ||
              busy ||
              loading ||
              !subject.trim() ||
              body.trim().length < 20
            }
            onClick={() => {
              void action(
                {
                  action: 'draft',
                  subject,
                  body,
                  dueAt: dueAt ? new Date(dueAt).getTime() : null,
                },
                'Draft saved for approval. No email sent.',
              ).then((saved) => {
                if (saved) {
                  setSubject('');
                  setBody('');
                  setDueAt('');
                }
              });
            }}
          >
            Save draft
          </Button>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="space-y-4 pt-6">
          <h2 className="text-xl font-semibold">Outreach history</h2>
          {!outreach.length && <p className="text-sm">No outreach yet.</p>}
          {outreach.map((item) => (
            <article key={item.id} className="space-y-3 rounded-xl border p-4">
              <div className="flex flex-wrap justify-between gap-2">
                <h3 className="font-semibold">{item.subject}</h3>
                <span className="text-sm">{item.status}</span>
              </div>
              <p className="whitespace-pre-wrap text-sm">{item.body}</p>
              {item.dueAt && (
                <p className="text-sm">
                  Follow-up: {new Date(item.dueAt).toLocaleString()}
                </p>
              )}
              {item.sentAt && (
                <p className="text-sm">
                  Send recorded by your team:{' '}
                  {new Date(item.sentAt).toLocaleString()}
                </p>
              )}
              <div className="flex flex-wrap gap-2">
                {item.status === 'draft' && (
                  <Button
                    disabled={busy || !eligible}
                    onClick={() =>
                      void action(
                        {
                          action: 'transition',
                          id: item.id,
                          status: 'approved',
                        },
                        'Approved. Ready to open in your email app.',
                      )
                    }
                  >
                    Approve message
                  </Button>
                )}
                {item.status === 'approved' && (
                  <>
                    <Button
                      disabled={busy || !eligible}
                      onClick={() => void compose(item)}
                    >
                      Open email draft
                    </Button>
                    <Button
                      variant="outline"
                      disabled={busy || !eligible}
                      onClick={() => {
                        if (
                          window.confirm(
                            'Have you actually sent this message in your email app? This records your confirmation, not verified delivery.',
                          )
                        )
                          void action(
                            {
                              action: 'transition',
                              id: item.id,
                              status: 'sent',
                              confirmedSent: true,
                            },
                            'Send recorded. Delivery is not independently verified.',
                          );
                      }}
                    >
                      I sent this email
                    </Button>
                  </>
                )}
                {item.status === 'sent' && (
                  <Button
                    disabled={busy}
                    onClick={() =>
                      void action(
                        {
                          action: 'transition',
                          id: item.id,
                          status: 'replied',
                        },
                        'Reply recorded; follow-up task closed.',
                      )
                    }
                  >
                    Record reply
                  </Button>
                )}
                {!['cancelled', 'replied'].includes(item.status) && (
                  <Button
                    variant="outline"
                    disabled={busy}
                    onClick={() =>
                      void action(
                        {
                          action: 'transition',
                          id: item.id,
                          status: 'cancelled',
                        },
                        'Outreach/follow-up cancelled.',
                      )
                    }
                  >
                    Cancel follow-up
                  </Button>
                )}
              </div>
            </article>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
