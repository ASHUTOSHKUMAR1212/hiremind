'use client';
import { useEffect, useState } from 'react';
import { authenticatedFetch } from '@/lib/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import SavedTalentSearches from './saved-talent-searches';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';

type Talent = {
  applicationId: string;
  candidateName: string;
  headline: string;
  location: string;
  previousJob: string;
  submittedAt: number;
  fitScore: number;
  explanation: string;
  criterionResults: Array<{
    id: string;
    label: string;
    score: number;
    explanation: string;
    evidence: Array<{
      source: { key: string; quote: string; sourceLocation: string };
    }>;
  }>;
};

export default function TalentPool({
  jobs,
  canReview,
}: {
  jobs: Array<{ id: string; title: string }>;
  canReview: boolean;
}) {
  const [jobId, setJobId] = useState(jobs[0]?.id ?? '');
  const [items, setItems] = useState<Talent[]>([]);
  const [query, setQuery] = useState('');
  const [location, setLocation] = useState('');
  const [search, setSearch] = useState({ q: '', location: '' });
  const [pages, setPages] = useState<string[]>(['']);
  const cursor = pages.at(-1) ?? '';
  const [selectedId, setSelectedId] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [refresh, setRefresh] = useState(0);
  useEffect(() => {
    if (!jobId || !canReview) return;
    let active = true;
    const abort = new AbortController();
    const timer = window.setTimeout(() => {
      setLoading(true);
      setItems([]);
      setError('');
      setSelectedId('');
      setNextCursor(null);
      void (async () => {
        try {
          const response = await authenticatedFetch(
            `/api/company/talent-pool?${new URLSearchParams({ jobId, q: search.q, location: search.location, cursor })}`,
            { signal: abort.signal },
          );
          const result = (await response.json()) as {
            error?: string;
            items?: Talent[];
            nextCursor?: string | null;
          };
          if (!response.ok)
            throw new Error(result.error || 'Could not load the talent pool.');
          if (!Array.isArray(result.items))
            throw new Error(
              'The talent-pool response was incomplete. Refresh to retry.',
            );
          if (active) {
            setItems(result.items);
            setNextCursor(result.nextCursor ?? null);
          }
        } catch (failure) {
          if (active)
            setError(
              failure instanceof Error
                ? failure.message
                : 'Could not load the talent pool.',
            );
        } finally {
          if (active) setLoading(false);
        }
      })();
    }, 0);
    return () => {
      active = false;
      window.clearTimeout(timer);
      abort.abort();
    };
  }, [jobId, canReview, refresh, search, cursor]);
  const filtered = items;
  function resetPages() {
    setPages(['']);
    setItems([]);
    setSelectedId('');
    setNextCursor(null);
    setLoading(true);
  }
  const selected = filtered.find((item) => item.applicationId === selectedId);
  if (!canReview)
    return <p>Your team role cannot review candidate profiles.</p>;
  if (!jobs.length)
    return (
      <p>Create a job with evidence criteria to search your talent pool.</p>
    );
  return (
    <section className="space-y-6">
      <div className="workspace-view-head">
        <div>
          <span>Talent rediscovery</span>
          <h1>Your talent pool</h1>
          <p>
            Reconsider previous applicants for a new role. Only candidates who
            opted in appear here.
          </p>
        </div>
        <Button
          variant="outline"
          disabled={loading}
          onClick={() => {
            resetPages();
            setRefresh((value) => value + 1);
          }}
        >
          Refresh consent and matches
        </Button>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <div>
          <label id="talent-job-label" htmlFor="talent-job">
            Match against job
          </label>
          <Select
            items={jobs.map((job) => ({ value: job.id, label: job.title }))}
            value={jobId}
            onValueChange={(value) => {
              if (!value || value === jobId) return;
              resetPages();
              setJobId(String(value ?? ''));
            }}
          >
            <SelectTrigger
              id="talent-job"
              aria-labelledby="talent-job-label"
              className="w-full"
            >
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {jobs.map((job) => (
                <SelectItem key={job.id} value={job.id}>
                  {job.title}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <form
          className="space-y-3"
          onSubmit={(event) => {
            event.preventDefault();
            resetPages();
            setSearch({ q: query.trim(), location: location.trim() });
          }}
        >
          <label htmlFor="talent-search">Search eligible profiles</label>
          <Input
            id="talent-search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Name, headline, listed skills, or previous role"
            maxLength={160}
          />
          <label htmlFor="talent-location">Location contains</label>
          <Input
            id="talent-location"
            value={location}
            maxLength={100}
            onChange={(event) => setLocation(event.target.value)}
            placeholder="e.g. Pune"
          />
          <Button type="submit" disabled={loading}>
            Search talent pool
          </Button>
        </form>
      </div>
      <SavedTalentSearches
        jobs={jobs}
        filters={{ jobId, q: search.q, location: search.location }}
        disabled={loading}
        canSave={
          !error &&
          query.trim() === search.q &&
          location.trim() === search.location
        }
        onLoad={(filters) => {
          resetPages();
          setJobId(filters.jobId);
          setQuery(filters.q);
          setLocation(filters.location);
          setSearch({ q: filters.q, location: filters.location });
        }}
      />
      <p className="text-sm text-muted-foreground">
        Based on submitted profiles from the past 12 months, not live profile
        updates. Existing applicants to this job are excluded. Matches are
        rule-based evidence indicators; no one is contacted or applied
        automatically.
      </p>
      <p className="text-sm text-muted-foreground">
        Search uses literal text (up to six words, all required), not inferred
        skills. Each page contains up to 50 profiles ordered by recency before
        ranking evidence within that page. Scores are not a global ranking.
        Suppressed CRM contacts are excluded.
      </p>
      {!loading && !error && (
        <div className="flex flex-wrap items-center gap-3">
          <Button
            variant="outline"
            disabled={pages.length === 1}
            onClick={() => {
              setItems([]);
              setLoading(true);
              setPages((value) => value.slice(0, -1));
            }}
          >
            Previous page
          </Button>
          <output>
            Page {pages.length} · {items.length} profiles
          </output>
          <Button
            variant="outline"
            disabled={!nextCursor}
            onClick={() => {
              if (nextCursor) {
                setItems([]);
                setLoading(true);
                setPages((value) => [...value, nextCursor]);
              }
            }}
          >
            Next page
          </Button>
        </div>
      )}
      {error && <p role="alert">{error} Use Refresh to retry.</p>}
      {loading ? (
        <output>Checking consent and matching evidence…</output>
      ) : !error && !filtered.length ? (
        <Card>
          <CardContent className="p-6">
            {search.q || search.location || pages.length > 1
              ? 'No profiles match this search.'
              : 'No eligible profiles yet. Candidates must opt in from My profile, have a previous application to your company, and not already have applied to this job.'}
          </CardContent>
        </Card>
      ) : null}
      <div className="grid gap-4 lg:grid-cols-2">
        {filtered.map((item) => (
          <Card key={item.applicationId}>
            <CardContent className="space-y-3 p-6">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h2>{item.candidateName}</h2>
                  <p>{item.headline}</p>
                  {item.location && (
                    <p className="text-sm text-muted-foreground">
                      {item.location}
                    </p>
                  )}
                </div>
                <Badge>{item.fitScore}/100 evidence</Badge>
              </div>
              <p className="text-sm text-muted-foreground">
                Applied for {item.previousJob} ·{' '}
                {new Date(item.submittedAt).toLocaleDateString()}
              </p>
              <p>{item.explanation}</p>
              <Button
                variant="outline"
                aria-expanded={selectedId === item.applicationId}
                onClick={() =>
                  setSelectedId(
                    selectedId === item.applicationId ? '' : item.applicationId,
                  )
                }
              >
                {' '}
                {selectedId === item.applicationId
                  ? 'Hide evidence'
                  : 'Review evidence'}{' '}
              </Button>
              {selected?.applicationId === item.applicationId && (
                <div className="space-y-4 border-t pt-4">
                  {item.criterionResults.map((criterion) => (
                    <div key={criterion.id}>
                      <h3>
                        {criterion.label} · {criterion.score}/100
                      </h3>
                      <p>{criterion.explanation}</p>
                      {criterion.evidence.map(({ source }) => (
                        <blockquote
                          className="border-l-2 pl-3 text-sm"
                          key={source.key}
                        >
                          <p>{source.quote}</p>
                          <cite>{source.sourceLocation}</cite>
                        </blockquote>
                      ))}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}
