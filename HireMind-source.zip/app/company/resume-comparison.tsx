'use client';
import { AuthenticatedFileLink } from '@/components/authenticated-file-link';
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell, TableCaption } from '@/components/ui/table';
import { buildRecruiterBrief } from '@/lib/recruiter-brief';
import type { EvidenceReview } from '@/lib/work-evidence';

import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ChangeEvent,
  type DragEvent,
} from 'react';
import {
  ArrowRight,
  CheckCircle2,
  CircleAlert,
  FileStack,
  FileText,
  RefreshCw,
  Scale,
  ShieldCheck,
  Trash2,
  Trophy,
  UploadCloud,
  X,
} from 'lucide-react';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { authenticatedFetch } from '@/lib/supabase/client';
import { extractResumeText } from '@/lib/resume-text';

type ComparisonJob = {
  id: string;
  title: string;
  status: string;
  criteria: Array<{
    id?: string;
    label: string;
    weight: number;
    requirementClass: string;
    evidenceDefinition: string;
  }>;
};
type ComparisonEvidence = {
  source: {
    key: string;
    sourceType: string;
    title: string;
    quote: string;
    sourceLocation: string;
  };
  matchedSignals: string[];
  relevance: number;
};
type ComparisonCriterion = {
  id: string;
  label: string;
  requirementClass: string;
  weight: number;
  score: number;
  confidence: number;
  classification: string;
  explanation: string;
  evidence: ComparisonEvidence[];
  requiresHumanReview: boolean;
  review?: EvidenceReview;
};
type ComparisonItem = {
  id: string;
  fileId: string;
  filename: string;
  candidateName: string;
  headline: string | null;
  fitScore: number;
  rank: number;
  decisionBand: string;
  evidenceCoverage: number;
  uncertainty: number;
  explanation: string;
  criterionResults: ComparisonCriterion[];
  warnings: string[];
};
type ComparisonRun = {
  id: string;
  jobId: string;
  criteriaVersion: number;
  fileCount: number;
  status: string;
  completedAt: number;
  createdAt: number;
  stale: boolean;
  items: ComparisonItem[];
};

export default function ResumeComparison({
  jobs,
  initialJobId,
  canReview,
}: {
  jobs: ComparisonJob[];
  initialJobId: string;
  canReview: boolean;
}) {
  const [jobId, setJobId] = useState(initialJobId || jobs[0]?.id || '');
  const [files, setFiles] = useState<File[]>([]);
  const [run, setRun] = useState<ComparisonRun | null>(null);
  const [selectedId, setSelectedId] = useState('');
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const loadRequestRef = useRef(0);
  const job = jobs.find((item) => item.id === jobId) ?? jobs[0] ?? null;
  const selected =
    run?.items.find((item) => item.id === selectedId) ?? run?.items[0] ?? null;

  function downloadBrief() {
    if (!selected || !job || run?.stale) return;
    const text = buildRecruiterBrief(job.title, selected.candidateName, selected.criterionResults);
    const url = URL.createObjectURL(new Blob([text], { type: 'text/plain;charset=utf-8' }));
    const anchor = document.createElement('a');
    anchor.href = url; anchor.download = 'hiremind-interview-brief.txt';
    document.body.appendChild(anchor); anchor.click(); anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
  }

  const loadLatest = useCallback(
    async (selectedJobId: string) => {
      const requestId = ++loadRequestRef.current;
      if (!selectedJobId || !canReview) {
        setLoading(false);
        return;
      }
      setLoading(true);
      setRun(null);
      setSelectedId('');
      try {
        const response = await authenticatedFetch(
          `/api/company/resume-comparisons?jobId=${encodeURIComponent(selectedJobId)}`,
        );
        const result = (await response.json()) as {
          run?: ComparisonRun | null;
          error?: string;
        };
        if (requestId !== loadRequestRef.current) return;
        if (response.ok) {
          setRun(result.run ?? null);
          setSelectedId(result.run?.items[0]?.id ?? '');
        } else
          setStatus(
            result.error ?? 'The latest comparison could not be loaded.',
          );
      } catch {
        if (requestId !== loadRequestRef.current) return;
        setStatus(
          'Résumé comparisons are temporarily unreachable. Check your connection and retry.',
        );
      } finally {
        if (requestId === loadRequestRef.current) setLoading(false);
      }
    },
    [canReview],
  );

  useEffect(() => {
    const timer = window.setTimeout(() => {
      void loadLatest(jobId);
    }, 0);
    return () => window.clearTimeout(timer);
  }, [jobId, loadLatest]);
  function acceptFiles(incoming: File[]) {
    const supported = incoming
      .filter(
        (file) =>
          /\.(pdf|doc|docx)$/i.test(file.name) && file.size <= 5 * 1024 * 1024,
      )
      .slice(0, 8);
    setFiles(supported);
    setStatus(
      supported.length !== incoming.length
        ? 'Some files were skipped. Use PDF, DOC, or DOCX files up to 5 MB each; maximum 8.'
        : '',
    );
  }
  function selectFiles(event: ChangeEvent<HTMLInputElement>) {
    acceptFiles(Array.from(event.target.files ?? []));
    event.target.value = '';
  }
  function dropFiles(event: DragEvent<HTMLButtonElement>) {
    event.preventDefault();
    acceptFiles(Array.from(event.dataTransfer.files));
  }

  async function compare() {
    if (!job || files.length < 2) {
      setStatus('Choose a job and at least two résumés.');
      return;
    }
    if (!job.criteria.length) {
      setStatus('Add evidence criteria to this job before comparing résumés.');
      return;
    }
    setBusy(true);
    setStatus('Reading résumé 1…');
    const readable: Array<{ file: File; text: string }> = [];
    const skipped: string[] = [];
    for (let index = 0; index < files.length; index += 1) {
      setStatus(
        `Reading résumé ${index + 1} of ${files.length}: ${files[index].name}`,
      );
      try {
        const text = await extractResumeText(files[index]);
        if (text.replace(/[^a-zA-Z0-9]/g, '').length < 40)
          skipped.push(files[index].name);
        else readable.push({ file: files[index], text });
      } catch {
        skipped.push(files[index].name);
      }
    }
    if (readable.length < 2) {
      setBusy(false);
      setStatus(
        `At least two readable résumés are required. Could not parse: ${skipped.join(', ') || 'the selected files'}.`,
      );
      return;
    }
    setStatus(
      `Comparing ${readable.length} résumés against ${job.criteria.length} job criteria…`,
    );
    const form = new FormData();
    form.set('jobId', job.id);
    readable.forEach((item) => {
      form.append('resumes', item.file);
      form.append('extractedText', item.text);
    });
    let response: Response;
    let result: { run?: ComparisonRun; error?: string };
    try {
      response = await authenticatedFetch('/api/company/resume-comparisons', {
        method: 'POST',
        body: form,
      });
      result = (await response.json()) as typeof result;
    } catch {
      setBusy(false);
      setStatus(
        'The comparison service could not be reached. Your selected files remain ready to retry.',
      );
      return;
    }
    setBusy(false);
    if (!response.ok || !result.run) {
      setStatus(result.error ?? 'The comparison could not be completed.');
      return;
    }
    setRun(result.run);
    setSelectedId(result.run.items[0]?.id ?? '');
    setFiles([]);
    setStatus(
      `${result.run.fileCount} résumés compared. Rankings show role evidence, not a hiring decision.${skipped.length ? ` Skipped unreadable files: ${skipped.join(', ')}.` : ''}`,
    );
  }

  async function clearRun() {
    if (
      !run ||
      !window.confirm(
        'Delete this comparison and all résumés uploaded with it?',
      )
    )
      return;
    setBusy(true);
    let response: Response;
    try {
      response = await authenticatedFetch('/api/company/resume-comparisons', {
        method: 'DELETE',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ runId: run.id }),
      });
    } catch {
      setBusy(false);
      setStatus(
        'The comparison could not be deleted because the service is unreachable. Try again.',
      );
      return;
    }
    setBusy(false);
    if (!response.ok) {
      const result = (await response.json()) as { error?: string };
      setStatus(result.error ?? 'The comparison could not be deleted.');
      return;
    }
    setRun(null);
    setSelectedId('');
    setStatus('Comparison and uploaded résumé files deleted.');
  }

  const totalSize = useMemo(
    () => files.reduce((sum, file) => sum + file.size, 0),
    [files],
  );
  if (!canReview)
    return (
      <div className="resume-compare-empty">
        <ShieldCheck />
        <h2>Résumé comparison is restricted</h2>
        <p>Your team role does not include candidate evidence review.</p>
      </div>
    );
  if (!jobs.length)
    return (
      <div className="resume-compare-empty">
        <FileStack />
        <h2>Create a job first</h2>
        <p>The comparison needs a job post and its evidence criteria.</p>
      </div>
    );

  return (
    <>
      <div className="workspace-view-head">
        <div>
          <span>Role-based comparison</span>
          <h1>Compare multiple résumés</h1>
          <p>
            Compare résumés against the same job requirements. Scores are rule-based
            evidence indicators, not verified skills or predictions of job performance.
          </p>
        </div>
        {run ? (
          <Button variant="outline" disabled={busy} onClick={clearRun}>
            <Trash2 /> Clear comparison
          </Button>
        ) : null}
      </div>
      <section className="resume-compare-controls">
        <div className="resume-compare-job">
          <label htmlFor="comparison-job">Job to compare against</label>
          <select
            id="comparison-job"
            value={jobId}
            disabled={busy}
            onChange={(event) => {
              loadRequestRef.current++;
              setRun(null);
              setJobId(event.target.value);
              setFiles([]);
              setStatus('');
            }}
          >
            {jobs.map((item) => (
              <option key={item.id} value={item.id}>
                {item.title} · {item.criteria.length} criteria
              </option>
            ))}
          </select>
          {job ? (
            <div>
              <Badge variant="outline">
                {job.criteria.length} current criteria
              </Badge>
              {job.criteria.map((criterion) => (
                <span key={criterion.id ?? criterion.label}>
                  {criterion.label} <b>{criterion.weight}%</b>
                </span>
              ))}
            </div>
          ) : null}
        </div>
        <button
          type="button"
          className="resume-dropzone"
          onClick={() => fileInputRef.current?.click()}
          onDragOver={(event) => event.preventDefault()}
          onDrop={dropFiles}
        >
          <UploadCloud />
          <strong>Drop résumés here or choose files</strong>
          <span>2–8 files · PDF, DOC, or DOCX · 5 MB each · 25 MB total</span>
          <small>
            Original files stay private to this employer workspace until the
            comparison is cleared.
          </small>
        </button>
        <input
          ref={fileInputRef}
          className="sr-only"
          type="file"
          multiple
          accept=".pdf,.doc,.docx"
          onChange={selectFiles}
        />
        {files.length ? (
          <div className="resume-upload-queue">
            <div>
              <strong>{files.length} selected</strong>
              <span>{formatBytes(totalSize)} combined</span>
            </div>
            {files.map((file, index) => (
              <article key={`${file.name}-${file.lastModified}`}>
                <FileText />
                <span>
                  <strong>{file.name}</strong>
                  <small>{formatBytes(file.size)}</small>
                </span>
                <button
                  type="button"
                  aria-label={`Remove ${file.name}`}
                  onClick={() =>
                    setFiles(
                      files.filter((_, itemIndex) => itemIndex !== index),
                    )
                  }
                >
                  <X />
                </button>
              </article>
            ))}
            <Button
              disabled={
                busy ||
                files.length < 2 ||
                totalSize > 25 * 1024 * 1024 ||
                !job?.criteria.length
              }
              onClick={compare}
              className="bg-[#2b2233] text-white"
            >
              {busy ? (
                <>
                  <RefreshCw className="animate-spin" /> Comparing…
                </>
              ) : (
                <>
                  Compare {files.length} résumés <ArrowRight />
                </>
              )}
            </Button>
          </div>
        ) : null}
        {status ? (
          <output className="resume-compare-status" aria-live="polite">
            <CircleAlert /> {status}
          </output>
        ) : null}
      </section>
      {loading ? (
        <div className="resume-compare-empty">
          <RefreshCw className="animate-spin" />
          <h2>Loading the latest comparison…</h2>
        </div>
      ) : run?.items.length ? (
        <section className="resume-comparison-results">
          <header>
            <div>
              <Trophy />
              <span>
                <strong>Ranked résumé evidence</strong>
                <small>
                  Compared with criteria version {run.criteriaVersion} ·{' '}
                  {new Date(run.completedAt || run.createdAt).toLocaleString()}
                  {run.stale
                    ? ' · Criteria or scoring updated—run a new comparison'
                    : ''}
                </small>
              </span>
            </div>
            <Badge variant="outline">
              {run.stale ? 'Comparison needs refresh' : 'Human decision required'}
            </Badge>
          </header>
          <div className="rounded-xl border bg-card p-4">
            <h2 className="mb-3 text-lg font-semibold">Side-by-side evidence</h2>
            <Table>
              <TableCaption>Same requirements and weights for every résumé. Select a candidate below to inspect the source evidence. Scores are not verified proficiency.</TableCaption>
              <TableHeader><TableRow><TableHead>Job requirement</TableHead>{run.items.map((item) => <TableHead key={item.id}><Button variant="ghost" onClick={() => setSelectedId(item.id)} aria-pressed={selected?.id === item.id}>{item.candidateName}</Button></TableHead>)}</TableRow></TableHeader>
              <TableBody>{run.items[0].criterionResults.map((criterion) => <TableRow key={criterion.id}>
                <TableCell><strong>{criterion.label}</strong><p className="text-sm text-muted-foreground">{criterion.requirementClass} · weight {criterion.weight}</p></TableCell>
                {run.items.map((item) => { const match = item.criterionResults.find((entry) => entry.id === criterion.id); return <TableCell key={item.id}>{match ? <><strong>{match.score}/100</strong><p className="text-sm text-muted-foreground">{match.review?.label ?? (match.score < 50 ? 'Needs clarification' : 'Review evidence')}</p></> : 'Not assessed'}</TableCell>; })}
              </TableRow>)}</TableBody>
            </Table>
          </div>
          <div className="resume-comparison-layout">
            <div className="resume-ranking-list">
              {run.items.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setSelectedId(item.id)}
                  aria-pressed={selected?.id === item.id}
                >
                  <b>#{item.rank}</b>
                  <span>
                    <strong>{item.candidateName}</strong>
                    <small>{item.headline || item.filename}</small>
                  </span>
                  <em>{item.fitScore}</em>
                </button>
              ))}
            </div>
            {selected ? (
              <aside className="resume-comparison-detail">
                <div className="resume-result-title">
                  <div>
                    <Badge>{titleCase(selected.decisionBand)}</Badge>
                    <h2>{selected.candidateName}</h2>
                    <p>{selected.headline || selected.filename}</p>
                  </div>
                  <span>
                    <strong>{selected.fitScore}</strong>
                    <small>/100 role evidence fit</small>
                  </span>
                </div>
                <p className="resume-result-explanation">
                  {selected.explanation}
                </p>
                <Button variant="outline" disabled={run.stale} onClick={downloadBrief}>Download interview brief</Button>
                {selected.criterionResults.some((criterion) => criterion.requirementClass === 'essential' && criterion.score < 50) ? (
                  <div className="resume-result-explanation" role="note">
                    <strong>Essential requirements need confirmation</strong>
                    <p>Missing résumé evidence does not mean the candidate lacks the skill. Verify these before shortlisting:</p>
                    <ul>
                      {selected.criterionResults.filter((criterion) => criterion.requirementClass === 'essential' && criterion.score < 50).map((criterion) => (
                        <li key={criterion.id}>{criterion.label} — {criterion.review?.question ?? 'Ask for a relevant example, their contribution, and the result.'}</li>
                      ))}
                    </ul>
                  </div>
                ) : null}
                <div className="resume-result-metrics">
                  <div>
                    <CheckCircle2 />
                    <strong>{selected.evidenceCoverage}%</strong>
                    <span>Profile section coverage</span>
                  </div>
                  <div>
                    <Scale />
                    <strong>{selected.uncertainty}/100</strong>
                    <span>Evidence uncertainty indicator</span>
                  </div>
                </div>
                <div className="resume-criterion-comparison">
                  <h3>Criterion breakdown</h3>
                  {selected.criterionResults.map((criterion) => (
                    <article key={criterion.id}>
                      <div>
                        <span>{criterion.requirementClass}</span>
                        <strong>{criterion.label}</strong>
                        <b>{criterion.score}/100</b>
                      </div>
                      <Progress value={criterion.score} />
                      {criterion.review?.responsibilities.length ? (
                        <ul className="my-3 space-y-2 text-sm">
                          {criterion.review.responsibilities.map((task) => (
                            <li key={task.id}>
                              <strong>{task.label}</strong>: {task.supported ? 'Relevant work description found — verify ownership and depth.' : 'Work with all required tools not documented — clarify.'}
                            </li>
                          ))}
                        </ul>
                      ) : null}
                      {criterion.review?.relatedWork?.length ? (
                        <section className="my-3 rounded-xl border p-4 text-sm" aria-label="Related task evidence">
                          <h4 className="font-semibold">Related task experience</h4>
                          <p>No extra score or tenure credit. These excerpts do not prove the required tools or establish equivalence.</p>
                          <ul className="space-y-3">
                            {criterion.review.relatedWork.map((source) => (
                              <li key={`${source.sourceKey}:${source.quote}`}>
                                <strong>{source.tasks.map((task) => task.label).join('; ')}</strong>
                                <p>{source.sourceLocation}</p>
                                <blockquote>“{source.quote}”</blockquote>
                                <p>Tools named in affirmative work: {source.namedTools.join(', ') || 'Not specified'}.</p>
                                <p>Still unproven in this excerpt: {source.unprovenToolGroups.map((group) => group.join(' or ')).join(' and ')}.</p>
                              </li>
                            ))}
                          </ul>
                        </section>
                      ) : null}
                      <p>{criterion.explanation}</p>
                      {criterion.evidence?.length ? (
                        <ul>
                          {criterion.evidence.map((match) => (
                            <li key={match.source.key}>
                              <span>{match.source.sourceLocation}</span>
                              <q>{match.source.quote}</q>
                            </li>
                          ))}
                        </ul>
                      ) : null}
                    </article>
                  ))}
                </div>
                {selected.warnings.length ? (
                  <div className="resume-parse-warnings">
                    <CircleAlert />
                    <span>
                      <strong>Parsing notes</strong>
                      {selected.warnings.map((warning) => (
                        <small key={warning}>{warning}</small>
                      ))}
                    </span>
                  </div>
                ) : null}
                <AuthenticatedFileLink
                  className="resume-link"
                  fileId={selected.fileId}
                  filename={selected.filename}
                >
                  Download original résumé <ArrowRight />
                </AuthenticatedFileLink>
              </aside>
            ) : null}
          </div>
        </section>
      ) : (
        <div className="resume-compare-empty">
          <FileStack />
          <h2>No comparison for this job yet</h2>
          <p>
            Select at least two résumés above to see which contains the
            strongest evidence for this role.
          </p>
        </div>
      )}
    </>
  );
}

function formatBytes(value: number) {
  return value < 1024 * 1024
    ? `${Math.max(1, Math.round(value / 1024))} KB`
    : `${(value / (1024 * 1024)).toFixed(1)} MB`;
}
function titleCase(value: string) {
  return value
    .replace(/_/g, ' ')
    .replace(/-/g, ' ')
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}
