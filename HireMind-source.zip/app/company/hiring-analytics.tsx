'use client';
import { useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { authenticatedFetch } from '@/lib/supabase/client';
import { STAGE_LABELS, type HiringSummary } from '@/lib/hiring-analytics';
import { ToolNotice, ToolSelect, downloadEndpoint } from './tool-controls';

type Report = {
  filters: {
    days: number;
    ageDays: number;
    asOf: number;
    since: number;
    jobId: string;
  };
  summary: HiringSummary;
  coverage: Array<{
    criterionId: string;
    jobId: string;
    jobTitle: string;
    label: string;
    requirementClass: string;
    applicants: number;
    assessed: number;
    strong: number;
    partial: number;
    adjacent: number;
    insufficient: number;
    unassessed: number;
  }>;
};
const numberOrDash = (value: number | null, suffix = '') =>
  value === null ? '—' : `${value}${suffix}`;

export default function HiringAnalytics({
  jobs,
  canExport,
  onApplication,
  onJob,
}: {
  jobs: Array<{ id: string; title: string }>;
  canExport: boolean;
  onApplication: (id: string, jobId: string) => void;
  onJob: (jobId: string) => void;
}) {
  const [jobId, setJobId] = useState('all');
  const [days, setDays] = useState('90');
  const [ageDays, setAgeDays] = useState('7');
  const [refresh, setRefresh] = useState(0);
  const [report, setReport] = useState<Report | null>(null);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [error, setError] = useState('');
  const [page, setPage] = useState(0);
  const search = new URLSearchParams({
    days,
    ageDays,
    jobId: jobId === 'all' ? '' : jobId,
  }).toString();
  useEffect(() => {
    const controller = new AbortController();
    let active = true;
    const timer = setTimeout(() => {
      setReport(null);
      setLoading(true);
      setError('');
      setPage(0);
      void (async () => {
        try {
          const response = await authenticatedFetch(
            `/api/company/analytics?${search}`,
            { signal: controller.signal },
          );
          const data = (await response.json()) as Report & { error?: string };
          if (!response.ok)
            throw new Error(data.error || 'Could not load hiring analytics.');
          if (active) setReport(data);
        } catch (failure) {
          if (active)
            setError(
              failure instanceof Error
                ? failure.message
                : 'Could not load hiring analytics.',
            );
        } finally {
          if (active) setLoading(false);
        }
      })();
    }, 0);
    return () => {
      active = false;
      clearTimeout(timer);
      controller.abort();
    };
  }, [search, refresh]);
  // Hide a previous cohort immediately while a changed filter is loading.
  const ready =
    report &&
    !loading &&
    report.filters.days === Number(days) &&
    report.filters.ageDays === Number(ageDays) &&
    report.filters.jobId === (jobId === 'all' ? '' : jobId);
  const summary = ready ? report.summary : null;
  async function exportReport() {
    setExporting(true);
    setError('');
    try {
      await downloadEndpoint(
        `/api/company/analytics?${search}&format=csv`,
        'hiremind-hiring-analytics.csv',
      );
    } catch (failure) {
      setError(failure instanceof Error ? failure.message : 'Export failed.');
    } finally {
      setExporting(false);
    }
  }
  return (
    <section className="space-y-6">
      <div className="workspace-view-head">
        <div>
          <span>Hiring intelligence</span>
          <h1>Where hiring needs attention</h1>
          <p>
            Follow application progress and the evidence behind your pipeline.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            disabled={loading}
            onClick={() => setRefresh((value) => value + 1)}
          >
            Refresh
          </Button>
          {canExport && (
            <Button
              disabled={!ready || exporting}
              onClick={() => void exportReport()}
            >
              {exporting ? 'Exporting…' : 'Export report'}
            </Button>
          )}
        </div>
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        <ToolSelect
          label="Job"
          value={jobId}
          onChange={setJobId}
          options={[
            { value: 'all', label: 'All company jobs' },
            ...jobs.map((job) => ({ value: job.id, label: job.title })),
          ]}
        />
        <ToolSelect
          label="Applications submitted in"
          value={days}
          onChange={setDays}
          options={['30', '90', '365'].map((value) => ({
            value,
            label: `Last ${value} days`,
          }))}
        />
        <ToolSelect
          label="Flag time in current stage"
          value={ageDays}
          onChange={setAgeDays}
          options={['3', '7', '14', '30'].map((value) => ({
            value,
            label: `${value} days or more`,
          }))}
        />
      </div>
      <ToolNotice error message={error} />
      {!ready && !error && <output>Loading the application cohort…</output>}
      {summary && report && (
        <>
          <p className="text-sm text-muted-foreground">
            Applications submitted{' '}
            {new Date(report.filters.since).toLocaleDateString()}–
            {new Date(report.filters.asOf).toLocaleDateString()}, with outcomes
            recorded through {new Date(report.filters.asOf).toLocaleString()}.
            This is an application cohort, not all company activity during that
            period.
          </p>
          {!summary.total && (
            <Card>
              <CardContent className="p-6">
                No applications in this cohort. Choose another job or a longer
                period.
              </CardContent>
            </Card>
          )}
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {[
              [
                'Applications',
                String(summary.total),
                `${summary.active} active · ${summary.current.rejected} rejected · ${summary.current.withdrawn} withdrawn`,
              ],
              [
                'Median days to first review',
                numberOrDash(summary.medianDaysToFirstReview),
                `${summary.firstReviewSample} with a recorded review entry`,
              ],
              [
                'Median days to hire',
                numberOrDash(summary.medianDaysToHire),
                `${summary.hireSample} dated hires · measured from application, not job opening`,
              ],
              [
                'Observed offers → hires',
                numberOrDash(summary.offerToHirePercent, '%'),
                `${summary.offersHired} hires / ${summary.offersObserved} observed offers, including pending offers`,
              ],
            ].map(([label, value, note]) => (
              <Card key={label}>
                <CardContent className="space-y-2 p-5">
                  <h2 className="text-sm font-medium">{label}</h2>
                  <p className="text-3xl font-semibold">{value}</p>
                  <p className="text-sm text-muted-foreground">{note}</p>
                </CardContent>
              </Card>
            ))}
          </div>
          <Card>
            <CardContent className="space-y-4 p-6">
              <h2 className="text-xl font-semibold">Recorded stage reach</h2>
              <p className="text-sm text-muted-foreground">
                Each application counts once per observed stage. Skipped stages
                are not inferred, so these counts need not form a decreasing
                funnel. Missing dates are excluded from medians.
              </p>
              <Table>
                <TableHeader>
                  <TableRow>
                    {[
                      'Stage',
                      'Ever observed',
                      '% of cohort',
                      'Currently here',
                      'Median current age',
                      'Dated active records',
                    ].map((label) => (
                      <TableHead key={label}>{label}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {summary.stages.map((stage) => (
                    <TableRow key={stage.key}>
                      <TableCell>{stage.label}</TableCell>
                      <TableCell>{stage.reached}</TableCell>
                      <TableCell>
                        {numberOrDash(stage.cohortPercent, '%')}
                      </TableCell>
                      <TableCell>{stage.current}</TableCell>
                      <TableCell>
                        {numberOrDash(stage.medianCurrentAgeDays, ' days')}
                      </TableCell>
                      <TableCell>{stage.ageSample}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="space-y-4 p-6">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <h2 className="text-xl font-semibold">
                  Applications to follow up
                </h2>
                <p>
                  {summary.attentionCount} at {ageDays}+ days in their current
                  stage
                </p>
              </div>
              <p className="text-sm text-muted-foreground">
                {summary.unknownAge} active applications have no reliable
                stage-entry date. An age flag is a reminder to review, not a
                recommendation to reject.
              </p>
              {!summary.attentionCount ? (
                <p>No dated active applications meet this threshold.</p>
              ) : (
                <>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Application</TableHead>
                        <TableHead>Job</TableHead>
                        <TableHead>Stage</TableHead>
                        <TableHead>Age</TableHead>
                        <TableHead>Action</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {summary.attention
                        .slice(page * 20, page * 20 + 20)
                        .map((item) => (
                          <TableRow key={item.id}>
                            <TableCell className="font-mono text-sm">
                              {item.id.slice(0, 8)}
                            </TableCell>
                            <TableCell>{item.jobTitle}</TableCell>
                            <TableCell>
                              {STAGE_LABELS[item.status] ?? item.status}
                            </TableCell>
                            <TableCell>{item.ageDays} days</TableCell>
                            <TableCell>
                              <Button
                                variant="outline"
                                onClick={() =>
                                  onApplication(item.id, item.jobId)
                                }
                              >
                                Review application
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                  <div className="flex flex-wrap items-center gap-3">
                    <Button
                      variant="outline"
                      disabled={page === 0}
                      onClick={() => setPage((value) => value - 1)}
                    >
                      Previous
                    </Button>
                    <span>
                      Page {page + 1} of{' '}
                      {Math.ceil(summary.attentionCount / 20)}
                    </span>
                    <Button
                      variant="outline"
                      disabled={(page + 1) * 20 >= summary.attentionCount}
                      onClick={() => setPage((value) => value + 1)}
                    >
                      Next
                    </Button>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
          <Card>
            <CardContent className="space-y-4 p-6">
              <h2 className="text-xl font-semibold">
                Requirement evidence coverage
              </h2>
              <p className="text-sm text-muted-foreground">
                Applicant evidence against each job requirement—not an employee
                skills inventory. Uses the latest completed, current-engine
                screening after the job’s last edit. Unassessed includes new
                applications and stale or absent screening. Insufficient
                evidence does not mean a candidate lacks the skill.
              </p>
              {!report.coverage.length ? (
                <p>No job criteria with applications in this cohort.</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      {[
                        'Job / requirement',
                        'Applicants',
                        'Strong',
                        'Partial',
                        'Adjacent',
                        'Insufficient',
                        'Unassessed',
                        'Action',
                      ].map((label) => (
                        <TableHead key={label}>{label}</TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {report.coverage.map((row) => (
                      <TableRow key={row.criterionId}>
                        <TableCell>
                          <p className="font-medium">{row.label}</p>
                          <p className="text-sm text-muted-foreground">
                            {row.jobTitle} · {row.requirementClass}
                          </p>
                        </TableCell>
                        <TableCell>{row.applicants}</TableCell>
                        <TableCell>{row.strong}</TableCell>
                        <TableCell>{row.partial}</TableCell>
                        <TableCell>{row.adjacent}</TableCell>
                        <TableCell>{row.insufficient}</TableCell>
                        <TableCell>{row.unassessed}</TableCell>
                        <TableCell>
                          <Button
                            variant="outline"
                            onClick={() => onJob(row.jobId)}
                          >
                            Review job
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
          <p className="text-sm text-muted-foreground">
            Small cohorts and incomplete histories can distort comparisons.
            These operational indicators do not measure matching accuracy,
            candidate quality, or fairness. Deleted candidate records are
            excluded. CSV exports recalculate the selected cohort at download
            time.
          </p>
        </>
      )}
    </section>
  );
}
