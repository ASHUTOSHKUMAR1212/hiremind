'use client';
import { useCallback, useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { MATCHING_ENGINE_VERSION } from '@/lib/evidence-screening';
import type { evaluateBenchmark } from '@/lib/matching-benchmark';
import { downloadText, toolRequest, ToolNotice } from './tool-controls';
import ComparisonReport from './benchmark-comparison';

type Report = ReturnType<typeof evaluateBenchmark>;
const template = {
  name: 'Replace with your independently reviewed dataset name',
  labelSource:
    'Describe the reviewers, labeling rubric, and disagreement resolution.',
  heldOut: false,
  consentConfirmed: false,
  cases: [
    {
      id: 'candidate-001',
      jobId: 'job-001',
      relevance: null,
      profile: {
        experiences: [
          {
            title: '',
            description: '',
            startedOn: '2022-01',
            endedOn: '2025-01',
          },
        ],
        metadata: { skills: [] },
      },
      criteria: [
        {
          id: 'sql',
          label: 'SQL',
          weight: 100,
          requirementClass: 'essential',
          evidenceDefinition: 'Demonstrated SQL work',
          equivalentSignalsJson: '[]',
        },
      ],
    },
    {
      id: 'candidate-002',
      jobId: 'job-001',
      relevance: null,
      profile: { experiences: [], metadata: { skills: [] } },
      criteria: [
        {
          id: 'sql',
          label: 'SQL',
          weight: 100,
          requirementClass: 'essential',
          evidenceDefinition: 'Demonstrated SQL work',
          equivalentSignalsJson: '[]',
        },
      ],
    },
  ],
};
const percent = (value: number | null) =>
  value === null ? 'Not defined' : `${(value * 100).toFixed(1)}%`;

const comparisonTemplate = {
  ...template,
  comparison: {
    competitor: 'Eightfold',
    competitorVersion: '',
    outputSource: '',
    capturedAt: '',
    protocolReference: '',
    expectedEngineVersion: MATCHING_ENGINE_VERSION,
    independentBlindLabels: false,
    sameInputsConfirmed: false,
    rankings: [{ jobId: 'job-001', rankGroups: [] }],
  },
};

const comparisonProtocol = `# HireMind head-to-head evaluation protocol

Status: preparation only. No Eightfold results or independent human judgments are supplied by this template.

1. Arrange authorized access to the competitor and permission to evaluate candidate documents. De-identify data. Never upload passwords, access tokens, or protected personal attributes.
2. Before running either system, date and freeze a protocol: named systems/versions/configuration, jobs, original résumé files, sample selection, candidate pools, rubric, reviewer instructions, and analysis. Keep the document in a dated, independently controlled record and enter its reference in protocolReference. Do not change the pool to remove failures.
3. Use representative unseen jobs across employers and seniorities, not hand-picked successes. Reserve enough independent jobs for a power analysis based on a separate pilot and a predeclared worthwhile improvement. The app's 200-case limit is a pilot limit, not a guarantee of a sufficiently powered study.
4. Have at least two independent recruiters grade each job/profile pair without either system's ranking: 0 unsuitable, 1 limited, 2 relevant, 3 strongly relevant. Preserve both judgments, measure agreement, and adjudicate disagreements before unblinding. Enter the final label as relevance and describe the process in labelSource. Mark independentBlindLabels true only if it happened.
5. Give both systems the same original documents and job requirements. Keep parser omissions and failed outputs in a separate failure audit. This app evaluates HireMind structured-profile matching, not end-to-end parser accuracy. Do not give only HireMind manually corrected information when claiming an end-to-end comparison.
6. Record actual authorized competitor results, product/version (or capture date if unavailable), configuration, timestamp with timezone, and export provenance. Retain the original export for review. Do not invent results. For each job list all candidate IDs best to worst in rankGroups, e.g. [["candidate-002"], ["candidate-001"]]. Equal scores belong in one group. Missing candidates are rejected; do not silently assign failed outputs a score.
7. Confirm sameInputsConfirmed and consentConfirmed only when true. Set heldOut only if none of the jobs/candidates informed engine or rubric tuning. Use the current expectedEngineVersion. A changed engine requires a new frozen protocol and fresh held-out evaluation.
8. Primary endpoint: mean per-job nDCG@10, exponential gain 2^relevance-1. Secondary endpoints: precision and recall at 5 (or pool size if smaller), relevant = labels 2 or 3. Ties use expected metrics over all within-tie permutations. Report every job, including losses and jobs with no positive labels. Differences are percentage points, not relative improvement.
9. The report offers exploratory 95% paired job-bootstrap intervals (2,000 deterministic resamples), only for at least 10 eligible jobs. This threshold is not a power calculation. Related jobs or repeated candidates require clustered study design and independent statistical review. Avoid cherry-picking metrics or repeated testing on the same holdout.
10. Export the dataset and report, verify against the original competitor export, audit labels, and replicate on fresh employers. A narrow claim may state the exact observed difference for the named dataset/system versions. Do not claim general superiority, fairness, future employee performance, or Eightfold-wide inferiority from this report.

Missing to conduct a real test: authorized competitor rankings, de-identified identical inputs, independent blinded labels, and a frozen study protocol. Software regression tests are not product accuracy evidence.
`;

export default function MatchingQuality({ canManage }: { canManage: boolean }) {
  const [items, setItems] = useState<Array<{ id: string; report: Report }>>([]);
  const [selected, setSelected] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await toolRequest<{ items: typeof items }>(
        '/api/company/benchmarks',
      );
      setItems(data.items);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    const timer = window.setTimeout(() => void load(), 0);
    return () => window.clearTimeout(timer);
  }, [load]);
  const report = items.find((item) => item.id === selected)?.report;
  async function run() {
    if (!file) return;
    setBusy(true);
    setError('');
    try {
      if (file.size > 2_000_000) throw new Error('Use a JSON file under 2 MB.');
      const uploaded = JSON.parse(await file.text());
      const result = await toolRequest<{ id: string; report: Report }>(
        '/api/company/benchmarks',
        'POST',
        uploaded.dataset ?? uploaded,
      );
      setSelected(result.id);
      await load();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function exportRun(id: string) {
    setBusy(true);
    setError('');
    try {
      const data = await toolRequest(
        `/api/company/benchmarks?id=${encodeURIComponent(id)}`,
      );
      downloadText(JSON.stringify(data, null, 2), 'hiremind-benchmark.json');
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function remove(id: string) {
    if (
      !window.confirm(
        'Delete this benchmark and its uploaded dataset? This cannot be undone.',
      )
    )
      return;
    setBusy(true);
    try {
      await toolRequest(
        `/api/company/benchmarks?id=${encodeURIComponent(id)}`,
        'DELETE',
      );
      setSelected('');
      await load();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold">Matching quality</h1>
        <p className="mt-2 text-[#726979]">
          Evaluate the current matching engine against human-labeled résumé/job
          pairs.
        </p>
      </div>
      <ToolNotice message={error} error />
      <Card>
        <CardContent className="space-y-4 pt-6">
          <h2 className="text-xl font-semibold">Compare with Eightfold or another system</h2>
          <p className="text-sm leading-6">Use the same jobs and candidate pools, independent human judgments, and actual competitor rankings. HireMind calculates both systems’ ranking agreement, per-job differences, and exploratory uncertainty. No competitor account is connected and no competitor results are fabricated.</p>
          <div className="flex flex-wrap gap-3">
            <Button variant="outline" onClick={() => downloadText(JSON.stringify(comparisonTemplate, null, 2), 'hiremind-head-to-head-template.json')}>Download comparison template</Button>
            <Button variant="outline" onClick={() => downloadText(comparisonProtocol, 'hiremind-evaluation-protocol.md')}>Download evaluation protocol</Button>
          </div>
          <p className="text-sm text-[#726979]">Fill the template, then upload it below. Put tied IDs in the same rank group. Blank labels and rankings must be completed with real evidence; the template is not a test result.</p>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="space-y-4 pt-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-xl font-semibold">Run a benchmark</h2>
            <Button
              variant="outline"
              onClick={() =>
                downloadText(
                  JSON.stringify(template, null, 2),
                  'hiremind-benchmark-template.json',
                )
              }
            >
              Download input template
            </Button>
          </div>
          <p className="text-sm leading-6">
            Use authorized, de-identified profiles. Label relevance before
            viewing HireMind’s scores: 0 unsuitable, 1 limited, 2 relevant, 3
            strongly relevant. Use the same criteria for every candidate in a
            job. The template contains no completed labels.
          </p>
          <p className="text-sm">
            For credible results, use independent reviewers and jobs/candidates
            excluded from tuning. Results here do not verify those conditions.
          </p>
          <label
            htmlFor="benchmark-file"
            className="grid gap-2 text-sm font-medium"
          >
            Labeled dataset · JSON · up to 200 cases
            <Input
              id="benchmark-file"
              type="file"
              accept=".json,application/json"
              disabled={!canManage || busy}
              onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            />
          </label>
          <Button
            disabled={!file || busy || !canManage}
            onClick={() => void run()}
          >
            {busy ? 'Working…' : 'Evaluate and save report'}
          </Button>
          <p className="text-sm text-[#726979]">
            Engine: {MATCHING_ENGINE_VERSION}. Separates skill claims from
            performed work, checks required skills and dated experience.
            English-language evidence rules, not a trained semantic model.
          </p>
        </CardContent>
      </Card>
      <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
        <Card>
          <CardContent className="space-y-3 pt-6">
            <h2 className="font-semibold">Saved evaluations</h2>
            <Button
              variant="outline"
              disabled={loading || busy}
              onClick={() => void load()}
            >
              Refresh
            </Button>
            {loading ? (
              <p>Loading…</p>
            ) : !items.length ? (
              <p className="text-sm text-[#726979]">
                No benchmark has been run. No accuracy percentage is
                established.
              </p>
            ) : (
              items.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setSelected(item.id)}
                  className={`block w-full rounded-xl border p-3 text-left text-sm ${selected === item.id ? 'bg-[#f3edf5]' : ''}`}
                >
                  <strong>{item.report.name}</strong>
                  <span className="block">
                    {item.report.caseCount} cases ·{' '}
                    {new Date(item.report.evaluatedAt).toLocaleDateString()}
                  </span>
                </button>
              ))
            )}
          </CardContent>
        </Card>
        {report ? (
          <Card>
            <CardContent className="space-y-5 pt-6">
              <h2 className="text-xl font-semibold">{report.name}</h2>
              <p className="text-sm">{report.labelSource}</p>
              <ToolNotice
                message={`${report.heldOut ? 'Declared held-out evaluation' : 'Development dataset — not held out'}. ${report.engineVersion === MATCHING_ENGINE_VERSION ? 'Current engine.' : 'Older engine; rerun the exported dataset to compare.'}`}
              />
              {report.comparison && <ComparisonReport report={report.comparison} />}
              <h3 className="font-semibold">HireMind-only diagnostics</h3>
              <div className="grid gap-3 sm:grid-cols-3">
                {[
                  ['Precision at top K', report.precisionAtK],
                  ['Recall at top K', report.recallAtK],
                  ['Ranking agreement (nDCG)', report.ndcgAt10],
                ].map(([label, value]) => (
                  <div
                    className="rounded-xl bg-[#f7f3f8] p-4"
                    key={String(label)}
                  >
                    <p className="text-sm">{label}</p>
                    <p className="mt-1 text-2xl font-semibold">
                      {percent(value as number | null)}
                    </p>
                  </div>
                ))}
              </div>
              <p className="text-sm">
                Precision: fraction of selected profiles labeled relevant.
                Recall: fraction of all relevant profiles retrieved. K is 5, or
                the available count if smaller. nDCG measures ranking agreement,
                not prediction accuracy. Metrics average jobs equally.
              </p>
              {report.selectionDiagnostics && (
                <section
                  className="space-y-3 rounded-xl border p-4"
                  aria-label="Strong-match error analysis"
                >
                  <h3 className="font-semibold">Where the engine disagrees</h3>
                  <p className="text-sm text-[#726979]">
                    {report.selectionDiagnostics.rule}
                  </p>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <p className="rounded-lg bg-[#f7f3f8] p-3 text-sm">
                      <strong>
                        {report.selectionDiagnostics.falsePositives}
                      </strong>{' '}
                      strong matches labeled unsuitable or limited
                    </p>
                    <p className="rounded-lg bg-[#f7f3f8] p-3 text-sm">
                      <strong>
                        {report.selectionDiagnostics.falseNegatives}
                      </strong>{' '}
                      relevant profiles below the strong-match threshold
                    </p>
                  </div>
                  <p className="text-sm">
                    Strong-match precision:{' '}
                    {percent(report.selectionDiagnostics.precision)}. Recall:{' '}
                    {percent(report.selectionDiagnostics.recall)}. Pooled across
                    cases. Inspect disagreements below before changing the
                    rubric. These are label disagreements, not hiring decisions.
                  </p>
                </section>
              )}
              {report.jobs.map((job) => (
                <details key={job.jobId} className="rounded-xl border p-3">
                  <summary className="cursor-pointer font-medium">
                    {job.jobId} · {job.count} profiles · top {job.k}
                    {job.ties ? ' · tied scores' : ''}
                  </summary>
                  <ol className="mt-3 space-y-2">
                    {job.ranked.map((item) => (
                      <li key={item.id} className="text-sm">
                        {item.id}: score {item.score}; human relevance{' '}
                        {item.relevance}/3
                        {item.disagreement && (
                          <p className="mt-1 font-medium text-[#78573a]">
                            {item.disagreement === 'strong_match_with_low_label'
                              ? 'Review: strong match conflicts with the human label.'
                              : 'Review: human-labeled relevant, but not a strong match.'}
                          </p>
                        )}
                        {item.criteria?.length > 0 && (
                          <details className="mt-2 rounded-lg bg-[#f7f3f8] p-3">
                            <summary className="cursor-pointer">
                              Why this score?
                            </summary>
                            <ul className="mt-2 space-y-3">
                              {item.criteria.map((criterion, index) => (
                                <li key={index}>
                                  <strong>
                                    {criterion.label} · {criterion.score}
                                  </strong>
                                  <p className="mt-1 text-[#726979]">
                                    {criterion.explanation}
                                  </p>
                                </li>
                              ))}
                            </ul>
                          </details>
                        )}
                      </li>
                    ))}
                  </ol>
                </details>
              ))}
              <ul className="list-disc space-y-2 pl-5 text-sm text-[#726979]">
                {report.limitations.map((text) => (
                  <li key={text}>{text}</li>
                ))}
              </ul>
              <div className="flex flex-wrap gap-3">
                <Button
                  disabled={busy}
                  onClick={() => void exportRun(selected)}
                >
                  Export dataset and report
                </Button>
                {canManage && (
                  <Button
                    variant="outline"
                    disabled={busy}
                    onClick={() => void remove(selected)}
                  >
                    Delete evaluation
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="rounded-2xl border border-dashed p-8 text-[#726979]">
            Select an evaluation to inspect per-job rankings and limitations.
          </div>
        )}
      </div>
    </div>
  );
}
