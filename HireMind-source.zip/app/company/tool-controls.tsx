'use client';
import { authenticatedFetch } from '@/lib/supabase/client';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export async function toolRequest<T>(
  url: string,
  method = 'GET',
  body?: unknown,
): Promise<T> {
  const response = await authenticatedFetch(url, {
    method,
    ...(body === undefined
      ? {}
      : {
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify(body),
        }),
  });
  const data = (await response.json()) as { error?: string };
  if (!response.ok)
    throw new Error(data.error || 'Request failed. Please retry.');
  return data as T;
}
export function downloadText(
  value: string,
  filename: string,
  type = 'application/json',
) {
  const url = URL.createObjectURL(new Blob([value], { type }));
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export async function downloadEndpoint(url: string, filename: string) {
  const response = await authenticatedFetch(url);
  if (!response.ok) {
    const data = (await response.json()) as { error?: string };
    throw new Error(data.error || 'Download failed.');
  }
  downloadText(
    await response.text(),
    filename,
    response.headers.get('content-type') || 'text/plain',
  );
}
export function ToolSelect({
  label,
  value,
  onChange,
  options,
  disabled,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: Array<{ value: string; label: string }>;
  disabled?: boolean;
}) {
  return (
    <label className="grid gap-2 text-sm font-medium">
      {label}
      <Select
        items={options}
        value={value || null}
        onValueChange={(next) => onChange(next ?? '')}
        disabled={disabled}
      >
        <SelectTrigger className="w-full">
          <SelectValue placeholder="Choose…" />
        </SelectTrigger>
        <SelectContent>
          {options.map((option) => (
            <SelectItem key={option.value} value={option.value}>
              {option.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </label>
  );
}
export function ToolNotice({
  message,
  error = false,
}: {
  message: string;
  error?: boolean;
}) {
  return message ? (
    <p
      role={error ? 'alert' : 'status'}
      className={`rounded-xl p-3 text-sm ${error ? 'bg-red-50 text-red-800' : 'bg-[#f3edf5] text-[#56425e]'}`}
    >
      {message}
    </p>
  ) : null;
}
