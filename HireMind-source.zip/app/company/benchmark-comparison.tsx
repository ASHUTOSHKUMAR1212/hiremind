'use client';
import type { compareRankings } from '@/lib/benchmark-comparison';

type Comparison = NonNullable<ReturnType<typeof compareRankings>>;
const percentage = (value: number | null) => value === null ? 'Not defined' : `${(100 * value).toFixed(1)}%`;
const difference = (value: number | null) => value === null ? 'Not defined' : `${value > 0 ? '+' : ''}${(100 * value).toFixed(1)} points`;
const names = { ndcgAt10: 'Ranking agreement · nDCG@10 (primary)', precisionAtK: 'Relevant profiles in top 5 (secondary)', recallAtK: 'Relevant profiles recovered in top 5 (secondary)' };

export default function ComparisonReport({ report }: { report: Comparison }) {
  return <section className="space-y-4 rounded-xl border p-4" aria-label="Head-to-head comparison">
    <h3 className="text-xl font-semibold">HireMind vs {report.competitor}</h3>
    <p className="text-sm font-medium">{report.evidenceStatus}</p>
    <p className="text-sm text-[#726979]">{report.competitorVersion} · captured {new Date(report.capturedAt).toLocaleString()}</p>
    <div className="space-y-3">
      {report.metrics.map((metric) => <div key={metric.metric} className="space-y-2 rounded-xl bg-[#f7f3f8] p-4">
        <h4 className="font-medium">{names[metric.metric]}</h4>
        <dl className="grid gap-3 sm:grid-cols-3">
          <div><dt className="text-sm">HireMind</dt><dd className="text-xl font-semibold">{percentage(metric.hiremind)}</dd></div>
          <div><dt className="text-sm">{report.competitor}</dt><dd className="text-xl font-semibold">{percentage(metric.competitor)}</dd></div>
          <div><dt className="text-sm">HireMind minus competitor</dt><dd className="text-xl font-semibold">{difference(metric.delta)}</dd></div>
        </dl>
        <p className="text-sm">{metric.wins} jobs ahead · {metric.ties} tied · {metric.losses} behind · {metric.excludedJobs} undefined/excluded</p>
        <p className="text-sm">{metric.interval
          ? `Exploratory 95% interval: ${difference(metric.interval.lower)} to ${difference(metric.interval.upper)}. Resamples whole jobs, not individual candidates.`
          : 'Uncertainty interval unavailable: fewer than 10 eligible jobs. Treat this as a small-sample description.'}</p>
      </div>)}
    </div>
    <details className="rounded-lg border p-3">
      <summary className="cursor-pointer font-medium">Per-job comparison and ranking audit</summary>
      <div className="mt-3 space-y-4">
        {report.jobs.map((job) => <div key={job.jobId} className="space-y-1 text-sm">
          <strong>{job.jobId} · {job.count} profiles · top {job.k}</strong>
          <p>nDCG: HireMind {percentage(job.hiremind.ndcgAt10)} · {report.competitor} {percentage(job.competitor.ndcgAt10)}</p>
          <p className="break-words">HireMind: {job.hiremindRankGroups.map((group) => `[${group.join(', ')}]`).join(' → ')}</p>
          <p className="break-words">{report.competitor}: {job.competitorRankGroups.map((group) => `[${group.join(', ')}]`).join(' → ')}</p>
        </div>)}
        <p className="text-sm">IDs in the same brackets are tied; brackets run from best to worst.</p>
      </div>
    </details>
    <details className="rounded-lg border p-3">
      <summary className="cursor-pointer font-medium">Provenance and limits</summary>
      <p className="mt-3 break-words text-sm">Protocol: {report.protocolReference}</p>
      <p className="mt-2 break-words text-sm">Result source: {report.outputSource}</p>
      <ul className="mt-3 list-disc space-y-2 pl-5 text-sm text-[#726979]">{report.limitations.map((text) => <li key={text}>{text}</li>)}</ul>
    </details>
    <p className="text-sm font-medium">This is evidence about these rankings—not certification that HireMind is superior.</p>
  </section>;
}
