'use client';
import {
  isUpcomingInterview,
  isOverdueInterview,
} from '@/lib/interview-status';
import { AuthenticatedFileLink } from '@/components/authenticated-file-link';

import {
  useCallback,
  useEffect,
  useMemo,
  useState,
  type SyntheticEvent,
} from 'react';
import { StableLink as Link } from '@/components/stable-link';
import {
  Activity,
  ArrowRight,
  BriefcaseBusiness,
  CalendarDays,
  Check,
  CheckCircle2,
  CircleAlert,
  Clock3,
  Download,
  FileSearch,
  Files,
  GraduationCap,
  ListFilter,
  MessageSquareText,
  Plus,
  Search,
  Settings2,
  ShieldCheck,
  Sparkles,
  Trash2,
  Trophy,
  UserPlus,
  UserRoundCheck,
  Users,
  XCircle,
} from 'lucide-react';

import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { SignOutButton } from '@/components/sign-out-button';
import { Textarea } from '@/components/ui/textarea';
import { authenticatedFetch } from '@/lib/supabase/client';
import { canOrganizationRole } from '@/lib/organization-permissions';
import ResumeComparison from './resume-comparison';
import TalentPool from './talent-pool';
import MatchingQuality from './matching-quality';
import InterviewEvidence from './interview-evidence';
import RecruiterCRM from './recruiter-crm';
import EmployerIntegrations from './employer-integrations';
import HiringAnalytics from './hiring-analytics';

type Criterion = {
  id?: string;
  label: string;
  requirementClass: string;
  weight: number;
  evidenceDefinition: string;
  equivalentSignals?: string[];
  sourceHint?: string;
};
type EvidenceCitation = {
  id: string;
  sourceType: string;
  category: string;
  summary: string;
  evidenceQuote: string | null;
  sourceLocation: string;
  confidence: number;
  verificationStatus: string;
};
type CriterionAssessment = {
  criterionId: string;
  label: string;
  requirementClass: string;
  classification: string;
  score: number | null;
  confidence: number;
  explanation: string;
  requiresHumanReview: number;
  evidence: EvidenceCitation[];
};
type EmployerJob = {
  id: string;
  title: string;
  status: string;
  description: string;
  location: string | null;
  workplaceType: string | null;
  employmentType: string | null;
  publishedAt: number | null;
  applicantCount: number;
  criteria: Criterion[];
};
type EmployerApplication = {
  id: string;
  jobId: string;
  status: string;
  currentStage: string | null;
  submittedAt: number;
  candidateName: string;
  profileType: string | null;
  headline: string | null;
  location: string | null;
  summary: string | null;
  skills: string[];
  fitScore: number | null;
  decisionBand: string | null;
  evidenceCoverage: number | null;
  uncertainty: number | null;
  screeningExplanation: string | null;
  resumeFileId: string | null;
  criterionAssessments: CriterionAssessment[];
  timeline: ApplicationEvent[];
};
type ApplicationEvent = {
  id: string;
  eventType: string;
  fromStatus: string | null;
  toStatus: string | null;
  note: string | null;
  visibleToCandidate: number;
  occurredAt: number;
};
type Interview = {
  id: string;
  applicationId: string;
  mode: string;
  status: string;
  scheduledAt: number | null;
  startedAt: number | null;
  completedAt: number | null;
  stageName: string;
  candidateName: string;
  jobTitle: string;
  changeRequest?: { note?: string };
};
type ActivityItem = {
  activityType: string;
  entityId: string;
  occurredAt: number;
  subject: string;
  context: string;
};
type TeamMember = {
  userId: string;
  fullName: string | null;
  email: string;
  roleKey: string;
  status: string;
  joinedAt: number;
};
type DashboardData = {
  jobs: EmployerJob[];
  applications: EmployerApplication[];
  interviews: Interview[];
  activity: ActivityItem[];
};
type View =
  | 'overview'
  | 'analytics'
  | 'jobs'
  | 'candidates'
  | 'compare'
  | 'talent'
  | 'interviews'
  | 'quality'
  | 'interview_evidence'
  | 'crm'
  | 'integrations'
  | 'settings';

const navigation = [
  { id: 'overview' as const, label: 'Overview', icon: Sparkles },
  { id: 'analytics' as const, label: 'Hiring analytics', icon: Activity },
  { id: 'jobs' as const, label: 'Jobs', icon: BriefcaseBusiness },
  { id: 'candidates' as const, label: 'Candidates', icon: Users },
  { id: 'compare' as const, label: 'Compare résumés', icon: Files },
  { id: 'talent' as const, label: 'Talent pool', icon: UserRoundCheck },
  { id: 'interviews' as const, label: 'Interviews', icon: CalendarDays },
  { id: 'quality' as const, label: 'Matching quality', icon: Activity },
  {
    id: 'interview_evidence' as const,
    label: 'Interview evidence',
    icon: MessageSquareText,
  },
  { id: 'crm' as const, label: 'Recruiter CRM', icon: Users },
  { id: 'integrations' as const, label: 'Integrations', icon: Settings2 },
  { id: 'settings' as const, label: 'Team', icon: Settings2 },
];

type Props = {
  userName: string;
  userEmail: string;
  organizationName: string;
  organizationRole: string;
};

export default function CompanyWorkspace({
  userName,
  userEmail,
  organizationName,
  organizationRole,
}: Props) {
  const [dashboard, setDashboard] = useState<DashboardData>({
    jobs: [],
    applications: [],
    interviews: [],
    activity: [],
  });
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<View>('overview');
  const [activeJobId, setActiveJobId] = useState('');
  const [selectedApplicationId, setSelectedApplicationId] = useState('');
  const [query, setQuery] = useState('');
  const [createJobOpen, setCreateJobOpen] = useState(false);
  const [scheduleOpen, setScheduleOpen] = useState(false);
  const [editingInterviewId, setEditingInterviewId] = useState<string | null>(
    null,
  );
  const [interviewScheduledAt, setInterviewScheduledAt] = useState('');
  const [interviewMode, setInterviewMode] = useState('live_video');
  const [cancelInterview, setCancelInterview] = useState<Interview | null>(
    null,
  );
  const [decisionOpen, setDecisionOpen] = useState(false);
  const [decisionStatus, setDecisionStatus] = useState<
    'offer' | 'hired' | 'rejected'
  >('offer');
  const [statusMessage, setStatusMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [draftingCriteria, setDraftingCriteria] = useState(false);
  const [criteriaStatus, setCriteriaStatus] = useState('');
  const [criteriaReviewItems, setCriteriaReviewItems] = useState<
    Array<{ source: string; reason: string }>
  >([]);
  const [hasAutomaticDraft, setHasAutomaticDraft] = useState(false);
  const [criteriaReviewed, setCriteriaReviewed] = useState(false);
  const [editingJobId, setEditingJobId] = useState<string | null>(null);
  const [jobTitle, setJobTitle] = useState('');
  const [jobDescription, setJobDescription] = useState('');
  const [jobLocation, setJobLocation] = useState('');
  const [jobWorkplaceType, setJobWorkplaceType] = useState('hybrid');
  const [jobEmploymentType, setJobEmploymentType] = useState('full-time');
  const [earliestInterviewTime] = useState(() =>
    toLocalDateTime(Date.now() + 60_000),
  );
  const [criteria, setCriteria] = useState<Criterion[]>([
    blankCriterion('essential', 40),
    blankCriterion('essential', 35),
    blankCriterion('preferred', 25),
  ]);

  useEffect(() => {
    setCriteriaReviewed(false);
  }, [criteria, jobDescription, jobTitle]);

  const loadDashboard = useCallback(async () => {
    try {
      const response = await authenticatedFetch('/api/company/dashboard');
      if (!response.ok) {
        const result = (await response.json().catch(() => ({}))) as {
          error?: string;
        };
        setStatusMessage(
          result.error ??
            'The hiring workspace could not be loaded. Check your connection and retry.',
        );
        return;
      }
      const data = (await response.json()) as DashboardData;
      setDashboard({
        jobs: data.jobs ?? [],
        applications: data.applications ?? [],
        interviews: data.interviews ?? [],
        activity: data.activity ?? [],
      });
      setActiveJobId((current) => current || data.jobs?.[0]?.id || '');
      return data;
    } catch {
      setStatusMessage(
        'The hiring workspace is temporarily unreachable. Check your connection and retry.',
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      void loadDashboard();
    }, 0);
    return () => window.clearTimeout(timer);
  }, [loadDashboard]);

  const activeJob =
    dashboard.jobs.find((job) => job.id === activeJobId) ??
    dashboard.jobs[0] ??
    null;
  const visibleApplications = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return dashboard.applications
      .filter((application) => {
        const belongs =
          view === 'candidates' || !activeJob
            ? true
            : application.jobId === activeJob.id;
        return (
          belongs &&
          (!normalized ||
            `${application.candidateName} ${application.headline ?? ''} ${application.skills.join(' ')}`
              .toLowerCase()
              .includes(normalized))
        );
      })
      .sort((a, b) => {
        if (a.fitScore == null && b.fitScore == null)
          return b.submittedAt - a.submittedAt;
        if (a.fitScore == null) return 1;
        if (b.fitScore == null) return -1;
        return (
          b.fitScore - a.fitScore ||
          (a.uncertainty ?? 100) - (b.uncertainty ?? 100)
        );
      });
  }, [activeJob, dashboard.applications, query, view]);
  const selectedApplication =
    dashboard.applications.find((item) => item.id === selectedApplicationId) ??
    visibleApplications[0] ??
    null;
  const pendingCount = dashboard.applications.filter((item) =>
    ['submitted', 'in_review'].includes(item.status),
  ).length;
  const upcomingInterviews = dashboard.interviews.filter((item) =>
    isUpcomingInterview(item),
  );
  const canManageJobs = canOrganizationRole(organizationRole, 'manage_jobs');
  const canReviewCandidates = canOrganizationRole(
    organizationRole,
    'review_candidates',
  );
  const canManageCandidates = canOrganizationRole(
    organizationRole,
    'manage_candidates',
  );
  const canScheduleInterviews = canOrganizationRole(
    organizationRole,
    'schedule_interviews',
  );
  const canExportData = canOrganizationRole(organizationRole, 'export_data');
  const canManageTeam = canOrganizationRole(organizationRole, 'manage_team');
  const readiness = [
    {
      label: 'Role published',
      done: dashboard.jobs.some((job) => job.status === 'published'),
    },
    {
      label: 'Criteria defined',
      done: dashboard.jobs.some((job) => job.criteria.length > 0),
    },
    { label: 'Applicant received', done: dashboard.applications.length > 0 },
    {
      label: 'Evidence reviewed',
      done: dashboard.applications.some((item) => item.fitScore != null),
    },
    {
      label: 'Interview completed',
      done: dashboard.interviews.some((item) => item.status === 'completed'),
    },
    {
      label: 'Decision recorded',
      done: dashboard.applications.some((item) =>
        ['offer', 'hired', 'rejected'].includes(item.status),
      ),
    },
  ];

  function openInterviewScheduler() {
    setEditingInterviewId(null);
    setInterviewMode('live_video');
    setInterviewScheduledAt(toLocalDateTime(Date.now() + 5 * 60_000));
    setScheduleOpen(true);
  }

  function openInterviewRescheduler(interview: Interview) {
    setEditingInterviewId(interview.id);
    setInterviewMode(interview.mode);
    setInterviewScheduledAt(
      toLocalDateTime(interview.scheduledAt ?? Date.now() + 5 * 60_000),
    );
    setScheduleOpen(true);
  }

  function openDecision(status: 'offer' | 'hired' | 'rejected') {
    setDecisionStatus(status);
    setDecisionOpen(true);
  }

  function resetJobEditor() {
    setEditingJobId(null);
    setJobTitle('');
    setJobDescription('');
    setJobLocation('');
    setJobWorkplaceType('hybrid');
    setJobEmploymentType('full-time');
    setCriteria([
      blankCriterion('essential', 40),
      blankCriterion('essential', 35),
      blankCriterion('preferred', 25),
    ]);
    setCriteriaStatus('');
    setCriteriaReviewItems([]);
    setHasAutomaticDraft(false);
    setCriteriaReviewed(false);
  }

  function openJobCreator() {
    resetJobEditor();
    setCreateJobOpen(true);
  }

  function openJobEditor(job: EmployerJob) {
    setCriteriaReviewItems([]);
    setHasAutomaticDraft(false);
    setCriteriaReviewed(false);
    setEditingJobId(job.id);
    setJobTitle(job.title);
    setJobDescription(job.description);
    setJobLocation(job.location ?? '');
    setJobWorkplaceType(job.workplaceType ?? 'hybrid');
    setJobEmploymentType(job.employmentType ?? 'full-time');
    setCriteria(
      job.criteria.map((criterion) => ({
        ...criterion,
        equivalentSignals: [...(criterion.equivalentSignals ?? [])],
      })),
    );
    setCriteriaStatus(
      'Editing creates a new criteria version. Earlier candidate assessments remain preserved for audit.',
    );
    setCreateJobOpen(true);
  }

  async function createJob(event: SyntheticEvent<HTMLFormElement>) {
    event.preventDefault();
    if (hasAutomaticDraft && !criteriaReviewed) {
      setCriteriaStatus(
        'Review the source requirements and criteria, then confirm before publishing.',
      );
      return;
    }
    setBusy(true);
    setStatusMessage(
      editingJobId ? 'Saving the revised role…' : 'Publishing role…',
    );
    const form = new FormData(event.currentTarget);
    const payload = {
      ...Object.fromEntries(form),
      ...(editingJobId ? { id: editingJobId } : {}),
      criteria: criteria.filter((item) => item.label.trim()),
    };
    const response = await authenticatedFetch('/api/jobs', {
      method: editingJobId ? 'PATCH' : 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const result = (await response.json()) as { error?: string; id?: string };
    setBusy(false);
    if (!response.ok) {
      setStatusMessage(
        result.error ??
          `This role could not be ${editingJobId ? 'updated' : 'published'}.`,
      );
      return;
    }
    const savedJobId = result.id ?? editingJobId;
    setStatusMessage(
      editingJobId
        ? 'Role updated. Run evidence review again when you want scores based on the new criteria.'
        : 'Role published and visible to candidates.',
    );
    await loadDashboard();
    if (savedJobId) setActiveJobId(savedJobId);
    window.setTimeout(() => {
      setCreateJobOpen(false);
      resetJobEditor();
      setView('jobs');
    }, 700);
  }

  async function draftCriteriaFromDescription() {
    if (jobDescription.trim().length < 40) {
      setCriteriaStatus(
        'Add a fuller job description first—at least 40 characters.',
      );
      return;
    }
    setDraftingCriteria(true);
    setCriteriaStatus(
      'Turning the job description into reviewable evidence criteria…',
    );
    try {
      const response = await authenticatedFetch('/api/jobs/criteria-draft', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ title: jobTitle, description: jobDescription }),
      });
      const result = (await response.json()) as {
        error?: string;
        criteria?: Criterion[];
        cautions?: string[];
        reviewItems?: Array<{ source: string; reason: string }>;
      };
      if (!response.ok || !result.criteria?.length) {
        setCriteriaStatus(
          result.error ??
            result.cautions?.join(' ') ??
            'No useful criteria could be drafted from this description.',
        );
        return;
      }
      setCriteria(result.criteria);
      setCriteriaReviewItems(result.reviewItems ?? []);
      setHasAutomaticDraft(true);
      setCriteriaReviewed(false);
      setCriteriaStatus(
        `${result.criteria.length} editable criteria drafted. ${result.cautions?.join(' ') || 'Review the evidence definitions and weights before publishing.'}`,
      );
    } catch {
      setCriteriaStatus(
        'Could not draft criteria. Your description and existing criteria are unchanged. Please retry.',
      );
    } finally {
      setDraftingCriteria(false);
    }
  }

  async function runScreening() {
    if (!activeJob) return;
    setBusy(true);
    setStatusMessage('Reviewing submitted evidence against the role criteria…');
    const response = await authenticatedFetch('/api/company/screening', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ jobId: activeJob.id }),
    });
    const result = (await response.json()) as {
      error?: string;
      screened?: number;
    };
    setBusy(false);
    if (!response.ok) {
      setStatusMessage(
        result.error ?? 'Evidence review could not be completed.',
      );
      return;
    }
    setStatusMessage(
      `${result.screened ?? 0} candidate profiles reviewed. Human decision is still required.`,
    );
    await loadDashboard();
  }

  async function updateJobStatus(status: 'published' | 'paused' | 'closed') {
    if (!activeJob) return;
    if (
      status === 'closed' &&
      !window.confirm(
        'Close this role? Candidates will no longer be able to apply.',
      )
    )
      return;
    setBusy(true);
    const response = await authenticatedFetch('/api/jobs', {
      method: 'PATCH',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ id: activeJob.id, status }),
    });
    setBusy(false);
    if (!response.ok) {
      const result = (await response.json()) as { error?: string };
      setStatusMessage(result.error ?? 'Role status could not be changed.');
      return;
    }
    setStatusMessage(
      status === 'published'
        ? 'Role is published and visible to candidates.'
        : status === 'paused'
          ? 'Role paused. Existing applications remain available.'
          : 'Role closed. Existing applications remain in your pipeline.',
    );
    await loadDashboard();
  }

  async function updateApplication(status: string, note = '') {
    if (!selectedApplication) return false;
    setBusy(true);
    const response = await authenticatedFetch('/api/applications', {
      method: 'PATCH',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        applicationId: selectedApplication.id,
        status,
        note,
      }),
    });
    setBusy(false);
    if (!response.ok) {
      const result = (await response.json()) as { error?: string };
      setStatusMessage(
        result.error ?? 'Candidate status could not be updated.',
      );
      return false;
    }
    setStatusMessage(
      status === 'rejected'
        ? 'Candidate moved to not progressing.'
        : `Candidate marked ${titleCase(status)}.`,
    );
    await loadDashboard();
    return true;
  }

  async function submitDecision(event: SyntheticEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const noteValue = form.get('note');
    const note = typeof noteValue === 'string' ? noteValue.trim() : '';
    if (await updateApplication(decisionStatus, note)) setDecisionOpen(false);
  }

  async function scheduleInterview(event: SyntheticEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selectedApplication && !editingInterviewId) return;
    const form = new FormData(event.currentTarget);
    const mode =
      interviewMode === 'structured_screening'
        ? 'structured_screening'
        : 'live_video';
    const scheduledValue = form.get('scheduledAt');
    const scheduledAt =
      typeof scheduledValue === 'string' && scheduledValue
        ? new Date(scheduledValue).toISOString()
        : '';
    setBusy(true);
    const response = await authenticatedFetch('/api/interviews', {
      method: editingInterviewId ? 'PATCH' : 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        ...(editingInterviewId
          ? { sessionId: editingInterviewId, action: 'reschedule' }
          : { applicationId: selectedApplication?.id }),
        scheduledAt,
        mode,
      }),
    });
    const result = (await response.json()) as { error?: string };
    setBusy(false);
    if (!response.ok) {
      setStatusMessage(result.error ?? 'Interview could not be scheduled.');
      return;
    }
    setStatusMessage(
      editingInterviewId
        ? 'Interview rescheduled. The updated time is visible in the candidate timeline.'
        : mode === 'live_video'
          ? 'Live video interview scheduled. The secure room is now visible to the candidate.'
          : 'Structured screening scheduled. It is now visible to the candidate.',
    );
    setScheduleOpen(false);
    setEditingInterviewId(null);
    await loadDashboard();
  }

  async function cancelScheduledInterview(
    event: SyntheticEvent<HTMLFormElement>,
  ) {
    event.preventDefault();
    if (!cancelInterview) return;
    const form = new FormData(event.currentTarget);
    setBusy(true);
    const response = await authenticatedFetch('/api/interviews', {
      method: 'PATCH',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        sessionId: cancelInterview.id,
        action: 'cancel',
        note: form.get('note'),
      }),
    });
    const result = (await response.json()) as { error?: string };
    setBusy(false);
    if (!response.ok) {
      setStatusMessage(result.error ?? 'Interview could not be cancelled.');
      return;
    }
    setCancelInterview(null);
    setStatusMessage(
      'Interview cancelled. The candidate timeline has been updated.',
    );
    await loadDashboard();
  }

  async function exportApplications(jobId?: string) {
    setBusy(true);
    setStatusMessage('Preparing an auditable CSV export…');
    const response = await authenticatedFetch(
      `/api/company/export${jobId ? `?jobId=${encodeURIComponent(jobId)}` : ''}`,
    );
    setBusy(false);
    if (!response.ok) {
      const result = (await response.json()) as { error?: string };
      setStatusMessage(result.error ?? 'The export could not be prepared.');
      return;
    }
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download =
      filenameFromDisposition(response.headers.get('content-disposition')) ||
      'hiremind-applications.csv';
    anchor.click();
    URL.revokeObjectURL(url);
    setStatusMessage(
      'Export downloaded. Scores remain accompanied by uncertainty and evidence fields.',
    );
  }

  function selectView(next: View) {
    setView(next);
    setStatusMessage('');
  }

  return (
    <main className="min-h-screen bg-background text-foreground">
      <div className="app-shell">
        <aside className="sidebar-shell">
          <div className="brand-lockup">
            <div className="brand-mark" aria-hidden="true">
              <span />
              <span />
              <span />
            </div>
            <span>hiremind</span>
          </div>
          <span className="sidebar-role-label">
            <BriefcaseBusiness /> Employer workspace
          </span>
          <nav aria-label="Employer workspace" className="mt-10 space-y-1.5">
            {navigation
              .filter((item) => item.id !== 'settings' || canManageTeam)
              .map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => selectView(item.id)}
                  className={`nav-item ${view === item.id ? 'nav-item-active' : ''}`}
                >
                  <item.icon />
                  <span>{item.label}</span>
                  {item.id === 'candidates' && pendingCount ? (
                    <span className="nav-count">{pendingCount}</span>
                  ) : item.id === 'jobs' && dashboard.jobs.length ? (
                    <span className="nav-count">{dashboard.jobs.length}</span>
                  ) : null}
                </button>
              ))}
          </nav>
          <section
            className="sidebar-checklist"
            aria-label="Hiring workflow readiness"
          >
            <div>
              <strong>Workflow readiness</strong>
              <span>
                {readiness.filter((item) => item.done).length}/
                {readiness.length}
              </span>
            </div>
            <ul>
              {readiness.map((item) => (
                <li key={item.label} className={item.done ? 'is-done' : ''}>
                  <Check /> {item.label}
                </li>
              ))}
            </ul>
          </section>
          <div className="sidebar-insight">
            <div className="flex items-center gap-2 text-[12px] font-semibold text-[#dccfe2]">
              <ShieldCheck className="size-4" /> Private employer data
            </div>
            <p className="mt-3 text-sm leading-6 text-white/70">
              Only {organizationName} members can access this hiring pipeline.
            </p>
          </div>
          <div className="profile-switcher">
            <Avatar>
              <AvatarFallback className="bg-[#eee5f1] font-semibold text-[#2b2233]">
                {initials(organizationName)}
              </AvatarFallback>
            </Avatar>
            <span className="min-w-0 flex-1 text-left">
              <strong className="block truncate text-sm font-medium text-white">
                {organizationName}
              </strong>
              <span className="block truncate text-xs text-white/50">
                {userEmail}
              </span>
            </span>
          </div>
          <Link href="/candidate" className="sidebar-workspace-switch">
            <GraduationCap /> Switch to Candidate
          </Link>
        </aside>

        <section className="min-w-0">
          <header className="workspace-header">
            <label className="search-shell">
              <Search />
              <input
                aria-label="Search candidates or skills"
                value={query}
                onChange={(event) => {
                  setQuery(event.target.value);
                  if (event.target.value.trim()) setView('candidates');
                }}
                placeholder="Search candidates or skills"
              />
            </label>
            <div className="flex items-center gap-2">
              <SignOutButton className="hidden rounded-full px-3 py-2 text-xs font-medium text-muted-foreground hover:bg-white disabled:opacity-60 sm:block" />
              {canManageJobs ? (
                <Button
                  onClick={openJobCreator}
                  className="rounded-full bg-[#2b2233] px-4 text-white hover:bg-[#40344a]"
                >
                  <Plus /> Create job
                </Button>
              ) : null}
            </div>
          </header>
          <nav
            className="employer-mobile-nav"
            aria-label="Employer mobile navigation"
          >
            {navigation
              .filter((item) => item.id !== 'settings' || canManageTeam)
              .map((item) => (
                <button
                  key={item.id}
                  onClick={() => selectView(item.id)}
                  aria-pressed={view === item.id}
                >
                  <item.icon />
                  <span>{item.label}</span>
                </button>
              ))}
          </nav>
          <div className="workspace-content">
            {statusMessage ? (
              <output className="workspace-status">
                <CircleAlert />
                {statusMessage}
              </output>
            ) : null}
            {loading ? (
              <WorkspaceEmpty
                icon={Sparkles}
                title="Opening your hiring workspace…"
                text="Loading roles, candidates, and interviews."
              />
            ) : view === 'overview' ? (
              <Overview
                name={userName}
                organization={organizationName}
                jobs={dashboard.jobs}
                applications={dashboard.applications}
                interviews={upcomingInterviews}
                activity={dashboard.activity}
                canCreate={canManageJobs}
                canExport={canExportData}
                onCreate={openJobCreator}
                onNavigate={selectView}
                onExport={() => exportApplications()}
              />
            ) : view === 'analytics' ? (
              <HiringAnalytics
                jobs={dashboard.jobs}
                canExport={canExportData}
                onApplication={(id, jobId) => {
                  void loadDashboard().then((data) => {
                    if (
                      !data?.applications.some(
                        (application) => application.id === id,
                      )
                    ) {
                      setStatusMessage(
                        'This application is no longer available. Refresh the report before reviewing another application.',
                      );
                      return;
                    }
                    setQuery('');
                    setActiveJobId(jobId);
                    setSelectedApplicationId(id);
                    selectView('jobs');
                  });
                }}
                onJob={(jobId) => {
                  setQuery('');
                  setActiveJobId(jobId);
                  setSelectedApplicationId('');
                  selectView('jobs');
                }}
              />
            ) : view === 'jobs' ? (
              <JobsView
                jobs={dashboard.jobs}
                activeJob={activeJob}
                applications={visibleApplications}
                selected={selectedApplication}
                busy={busy}
                canManageJobs={canManageJobs}
                canReviewCandidates={canReviewCandidates}
                canManageCandidates={canManageCandidates}
                canScheduleInterviews={canScheduleInterviews}
                canExport={canExportData}
                onJob={(id) => {
                  setActiveJobId(id);
                  setSelectedApplicationId('');
                }}
                onApplicant={setSelectedApplicationId}
                onCreate={openJobCreator}
                onEdit={openJobEditor}
                onExport={() => exportApplications(activeJob?.id)}
                onScreen={runScreening}
                onJobStatus={updateJobStatus}
                onUpdate={updateApplication}
                onSchedule={openInterviewScheduler}
                onDecision={openDecision}
              />
            ) : view === 'candidates' ? (
              <CandidatesView
                applications={visibleApplications}
                selected={selectedApplication}
                busy={busy}
                canManageCandidates={canManageCandidates}
                canScheduleInterviews={canScheduleInterviews}
                onApplicant={setSelectedApplicationId}
                onUpdate={updateApplication}
                onSchedule={openInterviewScheduler}
                onDecision={openDecision}
              />
            ) : view === 'compare' ? (
              <ResumeComparison
                jobs={dashboard.jobs}
                initialJobId={activeJobId}
                canReview={canReviewCandidates}
              />
            ) : view === 'talent' ? (
              <TalentPool
                jobs={dashboard.jobs}
                canReview={canReviewCandidates}
              />
            ) : view === 'quality' ? (
              <MatchingQuality
                canManage={canOrganizationRole(organizationRole, 'manage_jobs')}
              />
            ) : view === 'interview_evidence' ? (
              <InterviewEvidence interviews={dashboard.interviews} />
            ) : view === 'crm' ? (
              <RecruiterCRM />
            ) : view === 'integrations' ? (
              <EmployerIntegrations
                interviews={dashboard.interviews}
                canManage={canOrganizationRole(organizationRole, 'manage_team')}
                canExport={canOrganizationRole(organizationRole, 'export_data')}
                canSchedule={canScheduleInterviews}
              />
            ) : view === 'interviews' ? (
              <InterviewsView
                interviews={dashboard.interviews}
                canManage={canScheduleInterviews}
                onReschedule={openInterviewRescheduler}
                onCancel={setCancelInterview}
              />
            ) : (
              <TeamSettings organizationName={organizationName} />
            )}
          </div>
        </section>
      </div>

      <Dialog
        open={createJobOpen}
        onOpenChange={(open) => {
          setCreateJobOpen(open);
          if (!open) resetJobEditor();
        }}
      >
        <DialogContent className="max-h-[92vh] max-w-2xl overflow-y-auto border-[#d9ceda] bg-[#fffdf9] sm:rounded-[24px]">
          <DialogHeader>
            <DialogTitle className="text-2xl tracking-[-0.035em]">
              {editingJobId
                ? 'Edit the role and its evidence criteria'
                : 'Create a role with clear evidence criteria'}
            </DialogTitle>
            <DialogDescription>
              {editingJobId
                ? 'Changes create a new criteria version without erasing the evidence behind earlier assessments.'
                : 'Candidates see the role. HireMind uses the criteria to explain fit without inventing credentials or auto-rejecting people.'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={createJob} className="space-y-5">
            <label
              htmlFor="job-title"
              className="grid gap-1.5 text-sm font-medium"
            >
              Job title
              <Input
                id="job-title"
                name="title"
                required
                minLength={3}
                maxLength={120}
                value={jobTitle}
                onChange={(event) => setJobTitle(event.target.value)}
                placeholder="e.g. Product designer"
              />
            </label>
            <label
              htmlFor="job-description"
              className="grid gap-1.5 text-sm font-medium"
            >
              Job description
              <Textarea
                id="job-description"
                name="description"
                required
                minLength={20}
                maxLength={5000}
                rows={7}
                value={jobDescription}
                onChange={(event) => setJobDescription(event.target.value)}
                placeholder="Responsibilities, outcomes, team context, tools, and what success looks like…"
              />
            </label>
            <div className="grid gap-4 sm:grid-cols-3">
              <label
                htmlFor="job-location"
                className="grid gap-1.5 text-sm font-medium"
              >
                Location
                <Input
                  id="job-location"
                  name="location"
                  value={jobLocation}
                  onChange={(event) => setJobLocation(event.target.value)}
                  placeholder="Bengaluru"
                />
              </label>
              <SelectField
                name="workplaceType"
                label="Workplace"
                options={['hybrid', 'remote', 'on-site']}
                value={jobWorkplaceType}
                onChange={setJobWorkplaceType}
              />
              <SelectField
                name="employmentType"
                label="Employment"
                options={['full-time', 'part-time', 'contract', 'internship']}
                value={jobEmploymentType}
                onChange={setJobEmploymentType}
              />
            </div>
            <div className="criteria-builder">
              <div className="criteria-builder-head">
                <div>
                  <strong>Evidence criteria</strong>
                  <p>
                    Describe proof, not pedigree. Projects, coursework,
                    internships, freelance work, and equivalent outcomes can all
                    count.
                  </p>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  disabled={
                    draftingCriteria || jobDescription.trim().length < 40
                  }
                  onClick={draftCriteriaFromDescription}
                >
                  <Sparkles />{' '}
                  {draftingCriteria ? 'Drafting…' : 'Draft from description'}
                </Button>
              </div>
              {criteriaStatus ? (
                <output className="criteria-draft-status">
                  <CircleAlert />
                  {criteriaStatus}
                </output>
              ) : null}
              {criteriaReviewItems.length ? (
                <section
                  className="space-y-3 rounded-xl border border-[#d9ceda] bg-white p-4 text-sm"
                  aria-label="Requirements needing manual review"
                >
                  <strong>Requirements needing your review</strong>
                  <p>
                    These source clauses are not fully represented in the draft.
                    Add or revise criteria where relevant.
                  </p>
                  <ul className="list-disc space-y-3 pl-5">
                    {criteriaReviewItems.map((item, index) => (
                      <li key={index}>
                        <blockquote>{item.source}</blockquote>
                        <p className="text-[#746b7c]">{item.reason}</p>
                      </li>
                    ))}
                  </ul>
                </section>
              ) : null}
              {criteria.map((item, index) => (
                <div className="criterion-editor" key={index}>
                  <Input
                    value={item.label}
                    onChange={(event) =>
                      setCriteria(
                        updateAt(criteria, index, {
                          ...item,
                          label: event.target.value,
                        }),
                      )
                    }
                    placeholder="Criterion, e.g. User research"
                    aria-label={`Criterion ${index + 1} name`}
                  />
                  <select
                    value={item.requirementClass}
                    onChange={(event) =>
                      setCriteria(
                        updateAt(criteria, index, {
                          ...item,
                          requirementClass: event.target.value,
                        }),
                      )
                    }
                    aria-label={`Criterion ${index + 1} requirement`}
                  >
                    <option value="essential">Essential</option>
                    <option value="preferred">Preferred</option>
                  </select>
                  <Input
                    type="number"
                    min="1"
                    max="100"
                    value={item.weight}
                    onChange={(event) =>
                      setCriteria(
                        updateAt(criteria, index, {
                          ...item,
                          weight: Number(event.target.value),
                        }),
                      )
                    }
                    aria-label={`Criterion ${index + 1} weight`}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="criterion-remove"
                    disabled={criteria.length <= 1}
                    onClick={() =>
                      setCriteria(
                        criteria.filter((_, itemIndex) => itemIndex !== index),
                      )
                    }
                    aria-label={`Remove ${item.label || `criterion ${index + 1}`}`}
                  >
                    <Trash2 />
                  </Button>
                  <Textarea
                    value={item.evidenceDefinition}
                    onChange={(event) =>
                      setCriteria(
                        updateAt(criteria, index, {
                          ...item,
                          evidenceDefinition: event.target.value,
                        }),
                      )
                    }
                    placeholder="What observable evidence demonstrates this capability?"
                  />
                  <Input
                    className="criterion-equivalents"
                    value={(item.equivalentSignals ?? []).join(', ')}
                    onChange={(event) =>
                      setCriteria(
                        updateAt(criteria, index, {
                          ...item,
                          equivalentSignals: event.target.value
                            .split(',')
                            .map((value) => value.trim())
                            .filter(Boolean),
                        }),
                      )
                    }
                    placeholder="Equivalent signals, comma separated: projects, coursework, internships"
                    aria-label={`Criterion ${index + 1} equivalent evidence`}
                  />
                  {item.sourceHint ? (
                    <small className="criterion-source">
                      <Sparkles /> Drafted from: {item.sourceHint}
                    </small>
                  ) : null}
                </div>
              ))}
              <Button
                type="button"
                variant="outline"
                onClick={() =>
                  setCriteria([...criteria, blankCriterion('preferred', 15)])
                }
              >
                <Plus /> Add criterion
              </Button>
            </div>
            {hasAutomaticDraft ? (
              <label className="flex items-start gap-3 text-sm">
                <input
                  type="checkbox"
                  required
                  checked={criteriaReviewed}
                  onChange={(event) =>
                    setCriteriaReviewed(event.target.checked)
                  }
                  className="mt-1"
                />
                I reviewed the original requirements, omitted clauses, criteria
                and weights. This is my hiring rubric, not an automatic
                qualification decision.
              </label>
            ) : null}
            <div className="flex justify-end gap-2">
              <Button
                type="button"
                variant="ghost"
                onClick={() => setCreateJobOpen(false)}
              >
                Cancel
              </Button>
              <Button
                disabled={busy}
                type="submit"
                className="bg-[#2b2233] text-white"
              >
                {busy
                  ? editingJobId
                    ? 'Saving…'
                    : 'Publishing…'
                  : editingJobId
                    ? 'Save changes'
                    : 'Publish role'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
      <Dialog
        open={scheduleOpen}
        onOpenChange={(open) => {
          setScheduleOpen(open);
          if (!open) setEditingInterviewId(null);
        }}
      >
        <DialogContent className="max-w-md border-[#d9ceda] bg-[#fffdf9] sm:rounded-[24px]">
          <DialogHeader>
            <DialogTitle>
              {editingInterviewId
                ? 'Reschedule interview'
                : 'Schedule interview'}
            </DialogTitle>
            <DialogDescription>
              {editingInterviewId
                ? 'Choose the new time. The candidate timeline updates immediately.'
                : selectedApplication
                  ? `${selectedApplication.candidateName} will receive the invitation in their candidate workspace.`
                  : ''}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={scheduleInterview} className="space-y-5">
            <label
              htmlFor="interview-mode"
              className="grid gap-2 text-sm font-medium"
            >
              Interview format
              <select
                id="interview-mode"
                name="mode"
                value={interviewMode}
                disabled={Boolean(editingInterviewId)}
                onChange={(event) => setInterviewMode(event.target.value)}
                className="h-11 rounded-xl border border-[#d7cdd9] bg-white px-3 text-sm outline-none focus:border-[#876d87] focus:ring-2 focus:ring-[#876d87]/15"
              >
                <option value="live_video">Live video interview</option>
                <option value="structured_screening">
                  Self-paced structured screening
                </option>
              </select>
            </label>
            <label
              htmlFor="interview-scheduled-at"
              className="grid gap-2 text-sm font-medium"
            >
              Date and time
              <Input
                id="interview-scheduled-at"
                name="scheduledAt"
                type="datetime-local"
                required
                min={earliestInterviewTime}
                value={interviewScheduledAt}
                onChange={(event) =>
                  setInterviewScheduledAt(event.target.value)
                }
              />
            </label>
            <div className="interview-consent-note">
              <ShieldCheck />
              <p>
                <strong>Live video</strong> places candidate and interviewer in
                the same private 1:1 room. Recording is off.{' '}
                <strong>Structured screening</strong> lets the candidate answer
                role-linked questions independently.
              </p>
            </div>
            <Button
              disabled={busy}
              type="submit"
              className="w-full bg-[#2b2233] text-white"
            >
              {busy
                ? editingInterviewId
                  ? 'Rescheduling…'
                  : 'Scheduling…'
                : editingInterviewId
                  ? 'Save new time'
                  : 'Schedule interview'}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
      <Dialog open={decisionOpen} onOpenChange={setDecisionOpen}>
        <DialogContent className="max-w-md border-[#d9ceda] bg-[#fffdf9] sm:rounded-[24px]">
          <DialogHeader>
            <DialogTitle>{decisionDialogTitle(decisionStatus)}</DialogTitle>
            <DialogDescription>
              This updates the shared application timeline. It does not claim
              that a separate email or contract was sent.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={submitDecision} className="space-y-4">
            <label
              htmlFor="decision-note"
              className="grid gap-2 text-sm font-medium"
            >
              Candidate-visible note
              <Textarea
                id="decision-note"
                name="note"
                required
                minLength={3}
                maxLength={1000}
                rows={5}
                placeholder={decisionNotePlaceholder(decisionStatus)}
              />
            </label>
            <Button disabled={busy} className="w-full bg-[#2b2233] text-white">
              {busy ? 'Saving decision…' : decisionDialogAction(decisionStatus)}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
      <Dialog
        open={Boolean(cancelInterview)}
        onOpenChange={(open) => !open && setCancelInterview(null)}
      >
        <DialogContent className="max-w-md border-[#d9ceda] bg-[#fffdf9] sm:rounded-[24px]">
          <DialogHeader>
            <DialogTitle>Cancel this interview?</DialogTitle>
            <DialogDescription>
              {cancelInterview
                ? `${cancelInterview.candidateName} will see the cancellation and your note in their application timeline.`
                : ''}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={cancelScheduledInterview} className="space-y-4">
            <label
              htmlFor="cancel-interview-note"
              className="grid gap-2 text-sm font-medium"
            >
              Candidate-visible reason
              <Textarea
                id="cancel-interview-note"
                name="note"
                required
                minLength={3}
                maxLength={700}
                rows={4}
                placeholder="Explain the cancellation and what happens next."
              />
            </label>
            <Button disabled={busy} variant="destructive" className="w-full">
              {busy ? 'Cancelling…' : 'Cancel interview'}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </main>
  );
}

function Overview({
  name,
  organization,
  jobs,
  applications,
  interviews,
  activity,
  canCreate,
  canExport,
  onCreate,
  onNavigate,
  onExport,
}: {
  name: string;
  organization: string;
  jobs: EmployerJob[];
  applications: EmployerApplication[];
  interviews: Interview[];
  activity: ActivityItem[];
  canCreate: boolean;
  canExport: boolean;
  onCreate: () => void;
  onNavigate: (view: View) => void;
  onExport: () => void;
}) {
  const shortlisted = applications.filter((item) =>
    ['shortlisted', 'interview', 'hired'].includes(item.status),
  ).length;
  const reviewed = applications.filter((item) => item.fitScore != null).length;
  const needsDecision = applications.filter((item) =>
    ['submitted', 'in_review'].includes(item.status),
  ).length;
  return (
    <>
      <div className="employer-console-heading">
        <div>
          <Badge
            variant="outline"
            className="border-[#cfc4d1] bg-white/70 text-[#5b4863]"
          >
            {organization}
          </Badge>
          <h1>Good to see you, {name.split(' ')[0]}.</h1>
          <p>Here is what needs attention across your hiring workspace.</p>
        </div>
        <div className="flex gap-2">
          {canExport ? (
            <Button
              onClick={onExport}
              variant="outline"
              className="rounded-full"
            >
              <Download /> Export
            </Button>
          ) : null}
          {canCreate ? (
            <Button
              onClick={onCreate}
              className="rounded-full bg-[#2b2233] text-white"
            >
              <Plus /> Create role
            </Button>
          ) : null}
        </div>
      </div>
      <div className="employer-overview-metrics">
        <button onClick={() => onNavigate('jobs')}>
          <BriefcaseBusiness />
          <strong>
            {jobs.filter((job) => job.status === 'published').length}
          </strong>
          <span>Published roles</span>
          <ArrowRight />
        </button>
        <button onClick={() => onNavigate('candidates')}>
          <Users />
          <strong>{applications.length}</strong>
          <span>Total applicants</span>
          <ArrowRight />
        </button>
        <button onClick={() => onNavigate('candidates')}>
          <FileSearch />
          <strong>{reviewed}</strong>
          <span>Evidence-reviewed</span>
          <ArrowRight />
        </button>
        <button onClick={() => onNavigate('interviews')}>
          <CalendarDays />
          <strong>{interviews.length}</strong>
          <span>Upcoming interviews</span>
          <ArrowRight />
        </button>
      </div>
      {applications.length ? (
        <>
          <div className="employer-attention">
            <div>
              <ListFilter />
              <span>
                <strong>{needsDecision} profiles need a decision</strong>
                <small>
                  Review evidence, shortlist, or close the loop with candidates.
                </small>
              </span>
            </div>
            <Button variant="outline" onClick={() => onNavigate('candidates')}>
              Review candidates
            </Button>
          </div>
          <div className="employer-insight-grid">
            <section className="pipeline-health">
              <div>
                <Activity />
                <span>
                  <strong>Pipeline health</strong>
                  <small>Transparent stage movement, not vanity metrics.</small>
                </span>
              </div>
              <div className="pipeline-health-bars">
                <article>
                  <span>Applicants</span>
                  <b>{applications.length}</b>
                  <i style={{ width: '100%' }} />
                </article>
                <article>
                  <span>Evidence reviewed</span>
                  <b>{reviewed}</b>
                  <i
                    style={{
                      width: `${percentage(reviewed, applications.length)}%`,
                    }}
                  />
                </article>
                <article>
                  <span>Shortlisted or beyond</span>
                  <b>{shortlisted}</b>
                  <i
                    style={{
                      width: `${percentage(shortlisted, applications.length)}%`,
                    }}
                  />
                </article>
                <article>
                  <span>Interviews</span>
                  <b>{interviews.length}</b>
                  <i
                    style={{
                      width: `${percentage(interviews.length, applications.length)}%`,
                    }}
                  />
                </article>
              </div>
            </section>
            <section className="recent-activity">
              <div>
                <strong>Recent activity</strong>
                <small>Latest movement across roles</small>
              </div>
              {activity.length ? (
                activity.slice(0, 6).map((item) => (
                  <article
                    key={`${item.activityType}-${item.entityId}-${item.occurredAt}`}
                  >
                    <span>{activityLabel(item.activityType)}</span>
                    <p>
                      <strong>{item.subject}</strong> · {item.context}
                    </p>
                    <time>{relativeTime(item.occurredAt)}</time>
                  </article>
                ))
              ) : (
                <p>No hiring activity yet.</p>
              )}
            </section>
          </div>
        </>
      ) : (
        <WorkspaceEmpty
          icon={Users}
          title="Your applicant pipeline is ready"
          text="Publish a role and applications will appear here—never demo candidates or fabricated scores."
          action={canCreate ? 'Create first role' : undefined}
          onAction={canCreate ? onCreate : undefined}
        />
      )}
    </>
  );
}

function JobsView({
  jobs,
  activeJob,
  applications,
  selected,
  busy,
  canManageJobs,
  canReviewCandidates,
  canManageCandidates,
  canScheduleInterviews,
  canExport,
  onJob,
  onApplicant,
  onCreate,
  onEdit,
  onExport,
  onScreen,
  onJobStatus,
  onUpdate,
  onSchedule,
  onDecision,
}: {
  jobs: EmployerJob[];
  activeJob: EmployerJob | null;
  applications: EmployerApplication[];
  selected: EmployerApplication | null;
  busy: boolean;
  canManageJobs: boolean;
  canReviewCandidates: boolean;
  canManageCandidates: boolean;
  canScheduleInterviews: boolean;
  canExport: boolean;
  onJob: (id: string) => void;
  onApplicant: (id: string) => void;
  onCreate: () => void;
  onEdit: (job: EmployerJob) => void;
  onExport: () => void;
  onScreen: () => void;
  onJobStatus: (status: 'published' | 'paused' | 'closed') => void;
  onUpdate: (status: string) => void;
  onSchedule: () => void;
  onDecision: (status: 'offer' | 'hired' | 'rejected') => void;
}) {
  if (!jobs.length)
    return (
      <WorkspaceEmpty
        icon={BriefcaseBusiness}
        title="No roles in this workspace"
        text={
          canManageJobs
            ? 'Start with the outcomes and evidence your team actually values.'
            : 'An owner, admin, or recruiter can publish the first role.'
        }
        action={canManageJobs ? 'Create role' : undefined}
        onAction={canManageJobs ? onCreate : undefined}
      />
    );
  return (
    <>
      <div className="workspace-view-head">
        <div>
          <span>Roles</span>
          <h1>Jobs and evidence criteria</h1>
          <p>
            Each role has an auditable brief and its own applicant pipeline.
          </p>
        </div>
        <div className="flex gap-2">
          {canExport ? (
            <Button onClick={onExport} variant="outline" disabled={!activeJob}>
              <Download /> Export
            </Button>
          ) : null}
          {canManageJobs ? (
            <Button onClick={onCreate} variant="outline">
              <Plus /> New role
            </Button>
          ) : null}
        </div>
      </div>
      <div className="employer-console-grid">
        <Card className="employer-role-list py-0 ring-0">
          <CardContent className="p-0">
            <div className="employer-panel-title">
              <div>
                <strong>All roles</strong>
                <small>{jobs.length} total</small>
              </div>
            </div>
            <div className="employer-role-items">
              {jobs.map((job) => (
                <button
                  key={job.id}
                  onClick={() => onJob(job.id)}
                  aria-pressed={activeJob?.id === job.id}
                >
                  <span className="company-monogram">
                    <BriefcaseBusiness />
                  </span>
                  <span>
                    <strong>{job.title}</strong>
                    <small>
                      {job.location || 'Flexible'} · {titleCase(job.status)}
                    </small>
                  </span>
                  <Badge variant="secondary">{job.applicantCount}</Badge>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
        <div className="space-y-5">
          {activeJob ? (
            <Card className="job-brief-card py-0">
              <CardContent className="p-0">
                <div className="employer-panel-title">
                  <div>
                    <strong>{activeJob.title}</strong>
                    <small>
                      {activeJob.criteria.length} evidence criteria ·{' '}
                      {activeJob.applicantCount} applicants
                    </small>
                  </div>
                  <div className="job-lifecycle-actions">
                    <Badge variant="outline">
                      {titleCase(activeJob.status)}
                    </Badge>
                    {canManageJobs ? (
                      <>
                        <Button
                          disabled={busy}
                          variant="outline"
                          onClick={() => onEdit(activeJob)}
                        >
                          Edit
                        </Button>
                        {activeJob.status === 'published' ? (
                          <Button
                            disabled={busy}
                            variant="outline"
                            onClick={() => onJobStatus('paused')}
                          >
                            Pause
                          </Button>
                        ) : (
                          <Button
                            disabled={busy}
                            variant="outline"
                            onClick={() => onJobStatus('published')}
                          >
                            {activeJob.status === 'closed'
                              ? 'Reopen'
                              : 'Publish'}
                          </Button>
                        )}
                        <Button
                          disabled={busy || activeJob.status === 'closed'}
                          variant="ghost"
                          onClick={() => onJobStatus('closed')}
                        >
                          Close
                        </Button>
                      </>
                    ) : null}
                    {canReviewCandidates ? (
                      <Button
                        disabled={busy || !applications.length}
                        onClick={onScreen}
                        className="bg-[#2b2233] text-white"
                      >
                        <FileSearch /> Review evidence
                      </Button>
                    ) : null}
                  </div>
                </div>
                <div className="criteria-summary">
                  {activeJob.criteria.map((item) => (
                    <article key={item.id ?? item.label}>
                      <span>
                        {item.requirementClass === 'essential'
                          ? 'Essential'
                          : 'Preferred'}
                      </span>
                      <strong>{item.label}</strong>
                      <p>{item.evidenceDefinition}</p>
                      <b>{item.weight}% weight</b>
                    </article>
                  ))}
                </div>
              </CardContent>
            </Card>
          ) : null}
          <ApplicantPanel
            applications={applications}
            selected={selected}
            busy={busy}
            canManageCandidates={canManageCandidates}
            canScheduleInterviews={canScheduleInterviews}
            onApplicant={onApplicant}
            onUpdate={onUpdate}
            onSchedule={onSchedule}
            onDecision={onDecision}
          />
        </div>
      </div>
    </>
  );
}

function CandidatesView({
  applications,
  selected,
  busy,
  canManageCandidates,
  canScheduleInterviews,
  onApplicant,
  onUpdate,
  onSchedule,
  onDecision,
}: {
  applications: EmployerApplication[];
  selected: EmployerApplication | null;
  busy: boolean;
  canManageCandidates: boolean;
  canScheduleInterviews: boolean;
  onApplicant: (id: string) => void;
  onUpdate: (status: string) => void;
  onSchedule: () => void;
  onDecision: (status: 'offer' | 'hired' | 'rejected') => void;
}) {
  return (
    <>
      <div className="workspace-view-head">
        <div>
          <span>Candidate pipeline</span>
          <h1>Every applicant, one clear decision</h1>
          <p>
            Evidence explains the recommendation. Your team remains accountable
            for the outcome.
          </p>
        </div>
      </div>
      <ApplicantPanel
        applications={applications}
        selected={selected}
        busy={busy}
        canManageCandidates={canManageCandidates}
        canScheduleInterviews={canScheduleInterviews}
        onApplicant={onApplicant}
        onUpdate={onUpdate}
        onSchedule={onSchedule}
        onDecision={onDecision}
      />
    </>
  );
}

function ApplicantPanel({
  applications,
  selected,
  busy,
  canManageCandidates,
  canScheduleInterviews,
  onApplicant,
  onUpdate,
  onSchedule,
  onDecision,
}: {
  applications: EmployerApplication[];
  selected: EmployerApplication | null;
  busy: boolean;
  canManageCandidates: boolean;
  canScheduleInterviews: boolean;
  onApplicant: (id: string) => void;
  onUpdate: (status: string) => void;
  onSchedule: () => void;
  onDecision: (status: 'offer' | 'hired' | 'rejected') => void;
}) {
  if (!applications.length)
    return (
      <WorkspaceEmpty
        icon={Users}
        title="No applicants here yet"
        text="Candidate profiles appear only after they apply to one of your roles."
      />
    );
  return (
    <Card className="employer-applicant-panel py-0 ring-0">
      <CardContent className="p-0">
        <div className="employer-panel-title">
          <div>
            <strong>Applicant review</strong>
            <small>{applications.length} candidates</small>
          </div>
          <Badge variant="outline">Human decision required</Badge>
        </div>
        <div className="employer-applicant-layout">
          <div className="employer-applicant-list">
            {applications.map((application) => (
              <button
                key={application.id}
                onClick={() => onApplicant(application.id)}
                aria-pressed={selected?.id === application.id}
              >
                <Avatar>
                  <AvatarFallback className="bg-[#2b2233] text-white">
                    {initials(application.candidateName)}
                  </AvatarFallback>
                </Avatar>
                <span>
                  <strong>{application.candidateName}</strong>
                  <small>
                    {application.headline ||
                      titleCase(application.profileType || 'candidate')}{' '}
                    · {application.location || 'Location not added'}
                  </small>
                </span>
                {application.fitScore != null ? (
                  <b className="fit-pill">{application.fitScore}</b>
                ) : (
                  <Badge variant="secondary">
                    {titleCase(application.status)}
                  </Badge>
                )}
              </button>
            ))}
          </div>
          {selected ? (
            <EvidenceReview
              application={selected}
              busy={busy}
              canManageCandidates={canManageCandidates}
              canScheduleInterviews={canScheduleInterviews}
              onUpdate={onUpdate}
              onSchedule={onSchedule}
              onDecision={onDecision}
            />
          ) : null}
        </div>
      </CardContent>
    </Card>
  );
}

function EvidenceReview({
  application,
  busy,
  canManageCandidates,
  canScheduleInterviews,
  onUpdate,
  onSchedule,
  onDecision,
}: {
  application: EmployerApplication;
  busy: boolean;
  canManageCandidates: boolean;
  canScheduleInterviews: boolean;
  onUpdate: (status: string) => void;
  onSchedule: () => void;
  onDecision: (status: 'offer' | 'hired' | 'rejected') => void;
}) {
  return (
    <aside className="employer-evidence-review">
      <div className="flex items-center justify-between">
        <Badge className="bg-[#eee6f0] text-[#3d3048]">
          {application.fitScore == null
            ? 'Awaiting evidence review'
            : titleCase(application.decisionBand || 'review')}
        </Badge>
        <Badge variant="outline">{titleCase(application.status)}</Badge>
      </div>
      <h2>{application.candidateName}</h2>
      <p>
        {application.summary ||
          'This candidate has not added a profile summary yet.'}
      </p>
      {application.skills.length ? (
        <div className="candidate-skill-row">
          {application.skills.slice(0, 8).map((skill) => (
            <span key={skill}>{skill}</span>
          ))}
        </div>
      ) : null}
      <div className="employer-review-status">
        {application.fitScore == null ? <FileSearch /> : <CheckCircle2 />}
        <div>
          <strong>
            {application.fitScore == null
              ? 'No score until evidence is reviewed'
              : `${application.fitScore}/100 transparent fit estimate`}
          </strong>
          <small>
            {application.screeningExplanation ||
              'Run evidence review for this job. HireMind does not fabricate a ranking before candidate evidence is assessed.'}
          </small>
        </div>
      </div>
      {application.fitScore != null ? (
        <>
          <div className="grid grid-cols-2 gap-3">
            <div className="evidence-mini-card">
              <CheckCircle2 />
              <strong>{application.evidenceCoverage ?? 0}%</strong>
              <span>Evidence coverage</span>
            </div>
            <div className="evidence-mini-card">
              <CircleAlert />
              <strong>{application.uncertainty ?? 0}%</strong>
              <span>Uncertainty to review</span>
            </div>
          </div>
          <div className="criterion-assessment-list">
            <h3>Criterion evidence</h3>
            {application.criterionAssessments.map((assessment) => (
              <article key={assessment.criterionId}>
                <div>
                  <span>{assessment.requirementClass}</span>
                  <strong>{assessment.label}</strong>
                  <b>{assessment.score ?? 0}/100</b>
                </div>
                <div className="criterion-score-bar">
                  <i style={{ width: `${assessment.score ?? 0}%` }} />
                </div>
                <p>{assessment.explanation}</p>
                {assessment.evidence?.length ? (
                  <div className="criterion-citations">
                    {assessment.evidence.map((evidence) => (
                      <div key={evidence.id}>
                        <span>{evidence.sourceLocation}</span>
                        <strong>{evidence.summary}</strong>
                        <q>{evidence.evidenceQuote}</q>
                      </div>
                    ))}
                  </div>
                ) : null}
                {assessment.requiresHumanReview ? (
                  <small>
                    <CircleAlert /> Human confirmation required
                  </small>
                ) : null}
              </article>
            ))}
          </div>
        </>
      ) : null}
      {application.timeline?.length ? (
        <div className="application-audit-trail">
          <h3>
            <Clock3 /> Decision timeline
          </h3>
          {application.timeline.slice(0, 5).map((event) => (
            <article key={event.id}>
              <i />
              <span>
                <strong>
                  {applicationEventLabel(event.eventType, event.toStatus)}
                </strong>
                {event.note ? <small>{event.note}</small> : null}
              </span>
              <time>{new Date(event.occurredAt).toLocaleString()}</time>
            </article>
          ))}
        </div>
      ) : null}
      <div className="candidate-decision-actions">
        {application.resumeFileId ? (
          <AuthenticatedFileLink
            className="resume-link"
            fileId={application.resumeFileId}
            filename="resume.pdf"
          >
            Download résumé <ArrowRight />
          </AuthenticatedFileLink>
        ) : null}
        {canManageCandidates || canScheduleInterviews ? (
          <div>
            {canManageCandidates ? (
              <>
                {!['hired', 'rejected', 'withdrawn'].includes(
                  application.status,
                ) ? (
                  <Button
                    disabled={busy}
                    variant="outline"
                    onClick={() => onDecision('rejected')}
                  >
                    <XCircle /> Not progressing
                  </Button>
                ) : null}
                {['submitted', 'in_review'].includes(application.status) ? (
                  <Button
                    disabled={busy}
                    variant="outline"
                    onClick={() => onUpdate('shortlisted')}
                  >
                    <UserRoundCheck /> Shortlist
                  </Button>
                ) : null}
                {['in_review', 'shortlisted', 'interview'].includes(
                  application.status,
                ) ? (
                  <Button
                    disabled={busy}
                    variant="outline"
                    onClick={() => onDecision('offer')}
                  >
                    <MessageSquareText /> Record offer
                  </Button>
                ) : null}
                {application.status === 'offer' ? (
                  <Button
                    disabled={busy}
                    variant="outline"
                    onClick={() => onDecision('hired')}
                  >
                    <Trophy /> Mark hired
                  </Button>
                ) : null}
              </>
            ) : null}
            {canScheduleInterviews &&
            !['offer', 'hired', 'rejected', 'withdrawn'].includes(
              application.status,
            ) ? (
              <Button
                disabled={busy}
                onClick={onSchedule}
                className="bg-[#2b2233] text-white"
              >
                <CalendarDays /> Interview
              </Button>
            ) : null}
          </div>
        ) : null}
      </div>
    </aside>
  );
}

function TeamSettings({ organizationName }: { organizationName: string }) {
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [canManage, setCanManage] = useState(false);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState('');
  const loadTeam = useCallback(async () => {
    const response = await authenticatedFetch('/api/company/team');
    const result = (await response.json()) as {
      members?: TeamMember[];
      canManage?: boolean;
      error?: string;
    };
    if (response.ok) {
      setMembers(result.members ?? []);
      setCanManage(Boolean(result.canManage));
    } else setStatus(result.error ?? 'Team access could not be loaded.');
    setLoading(false);
  }, []);
  useEffect(() => {
    const timer = window.setTimeout(() => {
      void loadTeam();
    }, 0);
    return () => window.clearTimeout(timer);
  }, [loadTeam]);
  async function addMember(event: SyntheticEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    setBusy(true);
    setStatus('Adding secure team access…');
    const form = new FormData(formElement);
    const response = await authenticatedFetch('/api/company/team', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(Object.fromEntries(form)),
    });
    const result = (await response.json()) as { error?: string };
    setBusy(false);
    if (!response.ok) {
      setStatus(result.error ?? 'The team member could not be added.');
      return;
    }
    formElement.reset();
    setStatus('Team member added. Their access is recorded in the audit log.');
    await loadTeam();
  }
  async function changeMember(
    member: TeamMember,
    updates: Partial<Pick<TeamMember, 'roleKey' | 'status'>>,
  ) {
    setBusy(true);
    setStatus('Updating access…');
    const response = await authenticatedFetch('/api/company/team', {
      method: 'PATCH',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        userId: member.userId,
        roleKey: updates.roleKey ?? member.roleKey,
        status: updates.status ?? member.status,
      }),
    });
    const result = (await response.json()) as { error?: string };
    setBusy(false);
    if (!response.ok) {
      setStatus(result.error ?? 'Access could not be changed.');
      return;
    }
    setStatus('Team access updated and written to the audit trail.');
    await loadTeam();
  }
  return (
    <>
      <div className="workspace-view-head">
        <div>
          <span>Workspace administration</span>
          <h1>Team access for {organizationName}</h1>
          <p>
            Give each person the smallest role they need. Candidate data stays
            inside this organization.
          </p>
        </div>
      </div>
      <div className="team-settings-grid">
        <section>
          <div className="team-section-head">
            <div>
              <Users />
              <span>
                <strong>Team members</strong>
                <small>
                  {
                    members.filter((member) => member.status === 'active')
                      .length
                  }{' '}
                  active
                </small>
              </span>
            </div>
            <Badge variant="outline">Role-based access</Badge>
          </div>
          {loading ? (
            <p className="team-loading">Loading team access…</p>
          ) : (
            <div className="team-member-list">
              {members.map((member) => (
                <article key={member.userId}>
                  <Avatar>
                    <AvatarFallback>
                      {initials(member.fullName || member.email)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <strong>{member.fullName || 'HireMind member'}</strong>
                    <span>{member.email}</span>
                  </div>
                  <select
                    aria-label={`Role for ${member.email}`}
                    value={member.roleKey}
                    disabled={
                      !canManage ||
                      member.roleKey === 'owner' ||
                      member.roleKey === 'interviewer' ||
                      busy
                    }
                    onChange={(event) =>
                      changeMember(member, { roleKey: event.target.value })
                    }
                  >
                    <option value="owner">Owner</option>
                    <option value="admin">Admin</option>
                    <option value="recruiter">Recruiter</option>
                    <option value="hiring_manager">Hiring manager</option>
                    {member.roleKey === 'interviewer' ? (
                      <option value="interviewer">Interviewer (legacy)</option>
                    ) : null}
                  </select>
                  <Badge
                    variant={
                      member.status === 'active' ? 'secondary' : 'outline'
                    }
                  >
                    {titleCase(member.status)}
                  </Badge>
                  {canManage && member.roleKey !== 'owner' ? (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() =>
                        changeMember(member, {
                          status:
                            member.status === 'active' ? 'inactive' : 'active',
                        })
                      }
                    >
                      {member.status === 'active'
                        ? 'Remove access'
                        : 'Reactivate'}
                    </button>
                  ) : null}
                </article>
              ))}
            </div>
          )}
        </section>
        <aside>
          <div className="team-section-head">
            <div>
              <UserPlus />
              <span>
                <strong>Add an existing account</strong>
                <small>No company-domain verification required</small>
              </span>
            </div>
          </div>
          <p>
            The person must first create a HireMind account with this email.
            HireMind will not claim that an invitation was sent when email
            delivery is not configured.
          </p>
          <form onSubmit={addMember}>
            <label htmlFor="team-email">Account email</label>
            <Input
              id="team-email"
              name="email"
              type="email"
              required
              placeholder="teammate@company.com"
              disabled={!canManage || busy}
            />
            <label htmlFor="team-role">Access role</label>
            <select
              id="team-role"
              name="roleKey"
              disabled={!canManage || busy}
              defaultValue="recruiter"
            >
              <option value="admin">Admin</option>
              <option value="recruiter">Recruiter</option>
              <option value="hiring_manager">Hiring manager</option>
            </select>
            <Button
              disabled={!canManage || busy}
              className="bg-[#2b2233] text-white"
            >
              <UserPlus /> {busy ? 'Adding…' : 'Add team member'}
            </Button>
          </form>
          <p className="team-permission-note">
            <ShieldCheck /> Recruiters and hiring managers can run interviews;
            only owners and admins can change team access.
          </p>
          {!canManage ? (
            <p className="team-permission-note">
              <ShieldCheck /> Only the workspace owner or an admin can change
              access.
            </p>
          ) : null}
          {status ? <output>{status}</output> : null}
        </aside>
      </div>
    </>
  );
}

function InterviewsView({
  interviews,
  canManage,
  onReschedule,
  onCancel,
}: {
  interviews: Interview[];
  canManage: boolean;
  onReschedule: (interview: Interview) => void;
  onCancel: (interview: Interview) => void;
}) {
  return (
    <>
      <div className="workspace-view-head">
        <div>
          <span>Interviews</span>
          <h1>Live conversations and structured screening</h1>
          <p>
            Choose a secure 1:1 video room or an independent, role-linked
            screening for each candidate.
          </p>
        </div>
      </div>
      {interviews.length ? (
        <div className="interview-list">
          {interviews.map((interview) => {
            const live = interview.mode === 'live_video';
            return (
              <article key={interview.id}>
                <span className="interview-date">
                  <strong>
                    {interview.scheduledAt
                      ? new Date(interview.scheduledAt).toLocaleDateString(
                          undefined,
                          { day: '2-digit', month: 'short' },
                        )
                      : 'TBD'}
                  </strong>
                  <small>
                    {interview.scheduledAt
                      ? new Date(interview.scheduledAt).toLocaleTimeString(
                          undefined,
                          { hour: '2-digit', minute: '2-digit' },
                        )
                      : ''}
                  </small>
                </span>
                <div>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="outline">
                      {isOverdueInterview(interview)
                        ? 'Past scheduled time'
                        : titleCase(interview.status)}
                    </Badge>
                    <Badge variant="secondary">
                      {live ? 'Live video' : 'Structured screening'}
                    </Badge>
                  </div>
                  <h2>{interview.candidateName}</h2>
                  <p>
                    {interview.jobTitle} ·{' '}
                    {live ? 'Private 1:1 room' : interview.stageName}
                  </p>
                  {interview.changeRequest?.note ? (
                    <p className="interview-change-request">
                      <MessageSquareText /> Candidate requested a new time:{' '}
                      {interview.changeRequest.note}
                    </p>
                  ) : null}
                </div>
                <div className="interview-row-actions">
                  {canManage && interview.status === 'scheduled' ? (
                    <>
                      <button
                        type="button"
                        onClick={() => onReschedule(interview)}
                      >
                        Reschedule
                      </button>
                      <button type="button" onClick={() => onCancel(interview)}>
                        Cancel
                      </button>
                    </>
                  ) : null}
                  <Link
                    href={`/interview?id=${encodeURIComponent(interview.id)}&view=employer`}
                  >
                    {live &&
                    ['scheduled', 'in_progress'].includes(interview.status)
                      ? 'Open live room'
                      : live
                        ? 'View summary'
                        : 'Open review'}{' '}
                    <ArrowRight />
                  </Link>
                </div>
              </article>
            );
          })}
        </div>
      ) : (
        <WorkspaceEmpty
          icon={CalendarDays}
          title="No interviews scheduled"
          text="Choose Interview from a candidate record to schedule a live call or structured screening."
        />
      )}
    </>
  );
}

function WorkspaceEmpty({
  icon: Icon,
  title,
  text,
  action,
  onAction,
}: {
  icon: typeof Sparkles;
  title: string;
  text: string;
  action?: string;
  onAction?: () => void;
}) {
  return (
    <div className="employer-empty-state">
      <span>
        <Icon />
      </span>
      <h2>{title}</h2>
      <p>{text}</p>
      {action && onAction ? (
        <Button
          onClick={onAction}
          className="rounded-full bg-[#2b2233] text-white"
        >
          {action} <ArrowRight />
        </Button>
      ) : null}
    </div>
  );
}
function SelectField({
  name,
  label,
  options,
  value,
  onChange,
}: {
  name: string;
  label: string;
  options: string[];
  value?: string;
  onChange?: (value: string) => void;
}) {
  return (
    <label htmlFor={`job-${name}`} className="grid gap-1.5 text-sm font-medium">
      {label}
      <select
        id={`job-${name}`}
        name={name}
        value={value}
        onChange={
          onChange ? (event) => onChange(event.target.value) : undefined
        }
        className="h-9 rounded-lg border bg-transparent px-3 text-sm"
      >
        {options.map((option) => (
          <option key={option} value={option}>
            {titleCase(option)}
          </option>
        ))}
      </select>
    </label>
  );
}
function blankCriterion(requirementClass: string, weight: number): Criterion {
  return {
    label: '',
    requirementClass,
    weight,
    evidenceDefinition: '',
    equivalentSignals: [],
  };
}
function updateAt<T>(items: T[], index: number, value: T) {
  return items.map((item, itemIndex) => (itemIndex === index ? value : item));
}
function percentage(value: number, total: number) {
  return total ? Math.min(100, Math.round((value / total) * 100)) : 0;
}
function activityLabel(value: string) {
  const labels: Record<string, string> = {
    application_received: 'New application',
    application_submitted: 'New application',
    application_stage_changed: 'Candidate stage changed',
    application_rejected: 'Decision recorded',
    application_withdrawn: 'Application withdrawn',
    evidence_review_completed: 'Evidence review completed',
    offer_recorded: 'Offer stage recorded',
    candidate_hired: 'Candidate hired',
    interview_scheduled: 'Interview scheduled',
    interview_rescheduled: 'Interview rescheduled',
    interview_cancelled: 'Interview cancelled',
    interview_change_requested: 'Candidate requested a new time',
    structured_interview_completed: 'Screening completed',
    live_interview_completed: 'Live interview completed',
    role_created: 'Role created',
  };
  return labels[value] ?? titleCase(value);
}
function applicationEventLabel(eventType: string, toStatus: string | null) {
  if (toStatus) return `${titleCase(toStatus)} · ${activityLabel(eventType)}`;
  return activityLabel(eventType);
}
function decisionDialogTitle(status: 'offer' | 'hired' | 'rejected') {
  return status === 'offer'
    ? 'Record the offer stage'
    : status === 'hired'
      ? 'Confirm the hiring decision'
      : 'Close this application';
}
function decisionDialogAction(status: 'offer' | 'hired' | 'rejected') {
  return status === 'offer'
    ? 'Record offer stage'
    : status === 'hired'
      ? 'Mark candidate hired'
      : 'Mark not progressing';
}
function decisionNotePlaceholder(status: 'offer' | 'hired' | 'rejected') {
  return status === 'offer'
    ? 'Share the next step, contact person, or expected timing. Do not paste sensitive contract terms.'
    : status === 'hired'
      ? 'Confirm the outcome and explain who will contact the candidate next.'
      : 'Give a concise, respectful update and any useful next step.';
}
function relativeTime(value: number) {
  const minutes = Math.max(0, Math.round((Date.now() - value) / 60_000));
  return minutes < 1
    ? 'Just now'
    : minutes < 60
      ? `${minutes}m ago`
      : minutes < 1440
        ? `${Math.round(minutes / 60)}h ago`
        : `${Math.round(minutes / 1440)}d ago`;
}
function filenameFromDisposition(value: string | null) {
  return value?.match(/filename="?([^";]+)"?/i)?.[1] ?? '';
}
function initials(value: string) {
  return (
    value
      .split(/\s+/)
      .slice(0, 2)
      .map((part) => part[0])
      .join('')
      .toUpperCase() || 'HM'
  );
}
function titleCase(value: string) {
  return value
    .replace(/_/g, ' ')
    .replace(/-/g, ' ')
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}
function toLocalDateTime(value: number) {
  const date = new Date(value - new Date(value).getTimezoneOffset() * 60_000);
  return date.toISOString().slice(0, 16);
}
