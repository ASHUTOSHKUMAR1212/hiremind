'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { StableLink as Link } from '@/components/stable-link';
import {
  ArrowLeft,
  ArrowRight,
  CalendarClock,
  Camera,
  CheckCircle2,
  ListChecks,
  Maximize,
  ShieldCheck,
  Sparkles,
  TriangleAlert,
} from 'lucide-react';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Textarea } from '@/components/ui/textarea';
import type {
  AnswerAssessment,
  InterviewQuestion,
} from '@/lib/interview-engine';
import { getInterviewStartAvailability, getSessionContextChoice } from '@/lib/interview-status';
import {
  authenticatedFetch,
  getSupabaseBrowserClient,
} from '@/lib/supabase/client';
import LiveInterviewRoom from './live-interview-room';

type InterviewEvaluation = {
  overallEvidenceStrength?: number;
  classification?: string;
  answeredQuestions?: number;
  summary?: string;
  humanReviewRequired?: boolean;
  criterionRubric?: Array<{
    criterionId: string | null;
    label: string;
    score: number;
    answerCount: number;
  }>;
  limitations?: string[];
};
type Session = {
  id: string;
  applicationId: string;
  mode: string;
  status: string;
  scheduledAt: number | null;
  startedAt: number | null;
  completedAt: number | null;
  stageName: string;
  jobTitle: string;
  companyName: string;
  candidateName: string;
  questions: InterviewQuestion[];
  currentQuestion: InterviewQuestion | null;
  answeredCount: number;
  acceptedSignals: string[];
  evaluation?: InterviewEvaluation;
  liveNotes?: Array<{ notes: string; updatedAt: number; authorName: string }>;
};
type SessionEvent = {
  id: string;
  eventType: string;
  occurredAt: number;
  payload: Record<string, unknown>;
  candidateExplanation?: string | null;
};
type SessionData = {
  session: Session;
  events: SessionEvent[];
  viewerRole: 'candidate' | 'employer';
};
type ActionResult = {
  ok: boolean;
  error?: string;
  status?: string;
  saved?: boolean;
  nextQuestion?: InterviewQuestion | null;
  answeredCount?: number;
  totalQuestions?: number;
  shouldComplete?: boolean;
  availableAt?: number | null;
};

export default function InterviewPage() {
  const [data, setData] = useState<SessionData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [consented, setConsented] = useState(false);
  const [shareSessionSignals, setShareSessionSignals] = useState(false);
  const [cameraStatus, setCameraStatus] = useState<
    'available' | 'unavailable' | ''
  >('');
  const [currentQuestion, setCurrentQuestion] =
    useState<InterviewQuestion | null>(null);
  const [answeredCount, setAnsweredCount] = useState(0);
  const [answer, setAnswer] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [clock, setClock] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const sessionIdRef = useRef('');

  const load = useCallback(async () => {
    try {
      const sessionId =
        new URL(window.location.href).searchParams.get('id') ?? '';
      const view = new URL(window.location.href).searchParams.get('view');
      const interviewPath = `/interview?id=${encodeURIComponent(sessionId)}${view ? `&view=${encodeURIComponent(view)}` : ''}`;
      sessionIdRef.current = sessionId;
      const { data: auth } = await getSupabaseBrowserClient().auth.getSession();
      if (!auth.session) {
        window.location.replace(
          `/login?next=${encodeURIComponent(interviewPath)}`,
        );
        return;
      }
      if (!sessionId) {
        setError('This interview link is incomplete.');
        return;
      }
      const response = await authenticatedFetch(
        `/api/interviews/session?id=${encodeURIComponent(sessionId)}${view ? `&view=${encodeURIComponent(view)}` : ''}`,
      );
      const result = (await response.json()) as SessionData & {
        error?: string;
      };
      if (!response.ok) setError(result.error ?? 'Interview not found.');
      else {
        setData(result);
        setCurrentQuestion(result.session.currentQuestion);
        setAnsweredCount(result.session.answeredCount ?? 0);
        setShareSessionSignals(
          result.session.acceptedSignals?.includes('tab_visibility') ?? false,
        );
      }
    } catch {
      setError(
        'The interview service is temporarily unreachable. Check your connection and retry from your workspace.',
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      void load();
    }, 0);
    return () => {
      window.clearTimeout(timer);
      streamRef.current?.getTracks().forEach((track) => track.stop());
    };
  }, [load]);

  useEffect(() => {
    const updateClock = () => setClock(Date.now());
    const initialTimer = window.setTimeout(updateClock, 0);
    if (
      data?.session.status !== 'scheduled' ||
      data?.session.mode === 'live_video'
    )
      return () => window.clearTimeout(initialTimer);
    const interval = window.setInterval(updateClock, 1_000);
    return () => {
      window.clearTimeout(initialTimer);
      window.clearInterval(interval);
    };
  }, [data?.session.mode, data?.session.status]);

  const sendAction = useCallback(
    async (
      action: string,
      extra: Record<string, unknown> = {},
    ): Promise<ActionResult> => {
      if (!sessionIdRef.current)
        return { ok: false, error: 'Interview session is missing.' };
      try {
        const response = await authenticatedFetch('/api/interviews/session', {
          method: 'PATCH',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            sessionId: sessionIdRef.current,
            action,
            ...extra,
          }),
        });
        const result = (await response.json().catch(() => ({}))) as Omit<
          ActionResult,
          'ok'
        >;
        return { ...result, ok: response.ok };
      } catch {
        return {
          ok: false,
          error:
            'The interview service could not be reached. Check your connection and try again.',
        };
      }
    },
    [],
  );

  useEffect(() => {
    if (
      data?.viewerRole !== 'candidate' ||
      data.session.status !== 'in_progress' ||
      !shareSessionSignals
    )
      return;
    const visibility = () => {
      void sendAction(document.hidden ? 'tab_hidden' : 'tab_visible');
    };
    const fullscreen = () => {
      if (!document.fullscreenElement) void sendAction('fullscreen_exit');
    };
    document.addEventListener('visibilitychange', visibility);
    document.addEventListener('fullscreenchange', fullscreen);
    return () => {
      document.removeEventListener('visibilitychange', visibility);
      document.removeEventListener('fullscreenchange', fullscreen);
    };
  }, [data?.session.status, data?.viewerRole, sendAction, shareSessionSignals]);

  useEffect(() => {
    if (
      data?.viewerRole !== 'employer' ||
      data.session.mode === 'live_video' ||
      !['scheduled', 'in_progress'].includes(data.session.status)
    )
      return;
    const timer = window.setInterval(() => {
      void load();
    }, 5000);
    return () => window.clearInterval(timer);
  }, [data?.session.mode, data?.session.status, data?.viewerRole, load]);

  async function testCamera() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) videoRef.current.srcObject = stream;
      setCameraStatus('available');
      setMessage(
        'Camera is available. Video remains on this device in this release.',
      );
    } catch {
      setCameraStatus('unavailable');
      setMessage(
        'Camera is unavailable. You may still continue; the employer sees only that the check was unavailable.',
      );
    }
  }

  async function startInterview() {
    const availability = getInterviewStartAvailability(
      data?.session.status ?? null,
      data?.session.scheduledAt ?? null,
      clock || Date.now(),
    );
    if (!availability.canBegin) {
      setMessage(
        availability.availableAt
          ? `This screening opens at ${new Date(availability.availableAt).toLocaleString()}.`
          : 'This screening is not ready yet.',
      );
      return;
    }
    if (!consented) {
      setMessage('Read the session notice and confirm before starting.');
      return;
    }
    setBusy(true);
    const optionalSignals = shareSessionSignals
      ? ['tab_visibility', 'fullscreen_exit', 'camera_availability']
      : [];
    const result = await sendAction('start', {
      acceptedSignals: ['answer_transcript', ...optionalSignals],
      cameraStatus,
    });
    setBusy(false);
    if (!result.ok) {
      setMessage(
        result.availableAt
          ? `This screening opens at ${new Date(result.availableAt).toLocaleString()}.`
          : (result.error ?? 'The screening could not be started. Try again.'),
      );
      return;
    }
    setData((current) =>
      current
        ? { ...current, session: { ...current.session, status: 'in_progress' } }
        : current,
    );
    setCurrentQuestion(
      (current) =>
        current ?? result.nextQuestion ?? data?.session.questions[0] ?? null,
    );
    try {
      await document.documentElement.requestFullscreen();
    } catch {
      /* Fullscreen is helpful, not required. */
    }
  }

  async function saveAnswer() {
    if (!currentQuestion || answer.trim().length < 2) {
      setMessage('Add your answer before continuing.');
      return;
    }
    setBusy(true);
    setMessage('Saving your answer…');
    const questionIndex =
      data?.session.questions.findIndex(
        (question) => question.id === currentQuestion.id,
      ) ?? 0;
    const result = await sendAction('answer', {
      questionId: currentQuestion.id,
      questionIndex: Math.max(0, questionIndex),
      answer,
    });
    setBusy(false);
    if (!result.ok) {
      setMessage(result.error ?? 'Your answer could not be saved. Try again.');
      return;
    }
    setAnswer('');
    setAnsweredCount(result.answeredCount ?? answeredCount + 1);
    if (result.nextQuestion) {
      const nextQuestion = result.nextQuestion;
      setCurrentQuestion(nextQuestion);
      setData((current) =>
        current
          ? {
              ...current,
              session: {
                ...current.session,
                questions: current.session.questions.some(
                  (question) => question.id === nextQuestion.id,
                )
                  ? current.session.questions
                  : insertAfterParent(current.session.questions, nextQuestion),
              },
            }
          : current,
      );
      setMessage(
        nextQuestion.kind === 'follow_up'
          ? 'Answer saved. One focused follow-up will help clarify your evidence.'
          : 'Answer saved.',
      );
      return;
    }
    await completeInterview();
  }

  async function completeInterview() {
    setBusy(true);
    const result = await sendAction('complete');
    setBusy(false);
    if (!result.ok) {
      if (result.nextQuestion) setCurrentQuestion(result.nextQuestion);
      setMessage(
        result.error ?? 'The interview could not be completed. Try again.',
      );
      return;
    }
    if (document.fullscreenElement)
      await document.exitFullscreen().catch(() => undefined);
    streamRef.current?.getTracks().forEach((track) => track.stop());
    await load();
  }

  if (loading)
    return (
      <main className="interview-loading">
        <span className="candidate-brand-mark">h</span>
        <p>Opening your secure interview…</p>
      </main>
    );
  if (error || !data)
    return (
      <main className="interview-error">
        <TriangleAlert />
        <h1>Interview unavailable</h1>
        <p>{error || 'This session could not be loaded.'}</p>
        <Link href="/login">Return to HireMind</Link>
      </main>
    );
  if (data.session.mode === 'live_video')
    return (
      <LiveInterviewRoom session={data.session} viewerRole={data.viewerRole} />
    );
  if (data.viewerRole === 'employer') return <EmployerReview data={data} />;
  const session = data.session;
  const startAvailability = getInterviewStartAvailability(
    session.status,
    session.scheduledAt,
    clock,
  );
  if (session.status === 'completed')
    return (
      <CandidateComplete
        session={session}
        events={data.events}
        onExplain={async (eventId, explanation) => {
          const result = await sendAction('explain_event', {
            eventId,
            explanation,
          });
          if (result.ok)
            setData((current) =>
              current
                ? {
                    ...current,
                    events: current.events.map((event) =>
                      event.id === eventId
                        ? { ...event, candidateExplanation: explanation }
                        : event,
                    ),
                  }
                : current,
            );
          return result;
        }}
      />
    );
  if (session.status === 'cancelled')
    return (
      <main className="interview-error">
        <CalendarClock />
        <h1>Screening cancelled</h1>
        <p>
          This screening is no longer available. Contact the employer if you
          believe this is a mistake.
        </p>
        <Link href="/candidate">Return to applications</Link>
      </main>
    );
  if (session.status !== 'in_progress')
    return (
      <main className="interview-page">
        <InterviewHeader session={session} />
        <section className="interview-welcome">
          <div>
            <Badge variant="outline">{session.stageName}</Badge>
            <h1>A consistent screening that follows your evidence.</h1>
            <p>
              This is a <strong>self-paced structured screening</strong>, not a
              live video meeting. You will answer {session.questions.length}{' '}
              role-linked questions for <strong>{session.jobTitle}</strong> at{' '}
              <strong>{session.companyName}</strong>. HireMind may ask one
              focused follow-up when an answer needs clarification.
            </p>
            {session.scheduledAt ? (
              <p className="interview-scheduled-time">
                <CalendarClock /> Scheduled for{' '}
                <strong>
                  {new Date(session.scheduledAt).toLocaleString()}
                </strong>
              </p>
            ) : null}
            <div className="interview-principles">
              <article>
                <ListChecks />
                <strong>Same core rubric</strong>
                <span>Every candidate starts from the same role criteria.</span>
              </article>
              <article>
                <Sparkles />
                <strong>Focused follow-ups</strong>
                <span>
                  Clarification targets missing evidence, never personality.
                </span>
              </article>
              <article>
                <ShieldCheck />
                <strong>Human-reviewed</strong>
                <span>
                  No automatic rejection from answer or session indicators.
                </span>
              </article>
            </div>
          </div>
          <aside>
            <div className="camera-preview">
              <video ref={videoRef} autoPlay muted playsInline />
              <Camera />
            </div>
            <Button variant="outline" onClick={testCamera}>
              <Camera /> Test camera locally
            </Button>
            <label className="interview-consent">
              <input
                type="checkbox"
                checked={consented}
                onChange={(event) => {
                  setConsented(event.target.checked);
                  if (event.target.checked) setMessage('');
                }}
              />
              <span>
                <strong>Required to start:</strong> I consent to saving my
                answers for this employer to review.
              </span>
            </label>
            <label className="interview-consent interview-optional-consent">
              <input
                type="checkbox"
                checked={shareSessionSignals}
                onChange={(event) =>
                  setShareSessionSignals(event.target.checked)
                }
              />
              <span>
                Optional: share tab visibility, fullscreen exits, and camera
                availability as context. These never affect answer scoring. Eye
                movement and facial characteristics are not analyzed.
              </span>
            </label>
            {!startAvailability.canBegin && startAvailability.availableAt ? (
              <output aria-live="polite">
                Available from{' '}
                {new Date(startAvailability.availableAt).toLocaleString()} — 15
                minutes before the scheduled time.
              </output>
            ) : message ? (
              <output aria-live="polite">{message}</output>
            ) : null}
            <Button
              disabled={busy || !startAvailability.canBegin}
              onClick={startInterview}
              className="w-full bg-[#2b2233] text-white"
            >
              {busy
                ? 'Starting…'
                : startAvailability.canBegin
                  ? 'Begin screening'
                  : 'Not open yet'}{' '}
              <ArrowRight />
            </Button>
          </aside>
        </section>
      </main>
    );

  const question =
    currentQuestion ??
    session.questions.find((item) => item.kind !== 'follow_up') ??
    null;
  if (!question)
    return (
      <main className="interview-error">
        <TriangleAlert />
        <h1>Question plan unavailable</h1>
        <p>The employer needs to create a valid interview plan.</p>
        <Link href="/candidate">Return to applications</Link>
      </main>
    );
  const totalQuestions = Math.max(session.questions.length, answeredCount + 1);
  return (
    <main className="interview-page">
      <InterviewHeader session={session} />
      <section className="interview-question-shell">
        <div className="interview-question-progress">
          <span>
            {question.kind === 'follow_up'
              ? 'Focused follow-up'
              : `Question ${answeredCount + 1}`}{' '}
            · {question.criterionLabel}
          </span>
          <Progress
            value={(answeredCount / Math.max(1, totalQuestions)) * 100}
          />
        </div>
        <div
          className={`interview-question-card ${question.kind === 'follow_up' ? 'interview-follow-up-card' : ''}`}
        >
          <span>
            {question.kind === 'follow_up'
              ? 'Clarify one part of your evidence'
              : 'Take a moment to think'}
          </span>
          <h1>{question.prompt}</h1>
          <p>
            {question.guidance ||
              'Use a specific example. Explain the situation, what you did, and the result or learning.'}
          </p>
          <Textarea
            rows={10}
            value={answer}
            onChange={(event) => setAnswer(event.target.value)}
            maxLength={5000}
            placeholder="Write your answer here…"
          />
          <div className="interview-answer-footer">
            <small>{answer.length}/5000</small>
            {message ? <output>{message}</output> : null}
            <Button
              disabled={busy || answer.trim().length < 2}
              onClick={saveAnswer}
              className="bg-[#2b2233] text-white"
            >
              {busy ? 'Saving…' : 'Save and continue'} <ArrowRight />
            </Button>
          </div>
        </div>
        <div className="interview-live-note">
          <Maximize />
          <span>
            Tab and fullscreen events are context only. They never change your
            answer-evidence indicator.
          </span>
        </div>
      </section>
    </main>
  );
}

function InterviewHeader({ session }: { session: Session }) {
  return (
    <header className="interview-header">
      <Link href="/candidate" aria-label="Back to candidate workspace">
        <ArrowLeft />
      </Link>
      <div className="candidate-brand">
        <span className="candidate-brand-mark">h</span>
        <span>hiremind</span>
      </div>
      <div>
        <strong>{session.companyName}</strong>
        <span>{session.jobTitle}</span>
      </div>
    </header>
  );
}

function CandidateComplete({
  session,
  events,
  onExplain,
}: {
  session: Session;
  events: SessionEvent[];
  onExplain: (eventId: string, explanation: string) => Promise<ActionResult>;
}) {
  const [selectedEventId, setSelectedEventId] = useState('');
  const [explanation, setExplanation] = useState('');
  const [saving, setSaving] = useState(false);
  const [status, setStatus] = useState('');
  const sharedEvents = events.filter((event) =>
    ['tab_hidden', 'fullscreen_exit', 'camera_unavailable'].includes(
      event.eventType,
    ),
  );
  async function submitExplanation(eventId: string) {
    if (explanation.trim().length < 2) return;
    setSaving(true);
    const result = await onExplain(eventId, explanation.trim());
    setSaving(false);
    if (!result.ok) {
      setStatus(result.error ?? 'The explanation could not be saved.');
      return;
    }
    setSelectedEventId('');
    setExplanation('');
    setStatus('Context saved with this event.');
  }
  return (
    <main className="candidate-complete-page">
      <section>
        <div className="interview-complete-mark">
          <CheckCircle2 />
          <span>Interview submitted</span>
        </div>
        <h1>Thank you, {session.candidateName.split(' ')[0]}.</h1>
        <p>
          Your answers have been saved for {session.companyName}. A person—not a
          session signal—reviews the evidence and makes the next decision.
        </p>
        {sharedEvents.length ? (
          <div className="candidate-event-review">
            <h2>Your shared session context</h2>
            <p>
              You can add context to an interruption. The employer sees your
              explanation beside the event.
            </p>
            {sharedEvents.map((event) => (
              <article key={event.id}>
                <div>
                  <strong>
                    {event.eventType === 'tab_hidden'
                      ? 'Tab was not visible'
                      : event.eventType === 'fullscreen_exit'
                        ? 'Fullscreen ended'
                        : 'Camera check unavailable'}
                  </strong>
                  <span>
                    {new Date(event.occurredAt).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
                {event.candidateExplanation ? (
                  <p>“{event.candidateExplanation}”</p>
                ) : selectedEventId === event.id ? (
                  <div className="candidate-event-explanation">
                    <Textarea
                      rows={2}
                      maxLength={500}
                      value={explanation}
                      onChange={(change) => setExplanation(change.target.value)}
                      placeholder="Optional context, e.g. a system notification opened…"
                    />
                    <Button
                      disabled={saving || explanation.trim().length < 2}
                      onClick={() => submitExplanation(event.id)}
                    >
                      {saving ? 'Saving…' : 'Save context'}
                    </Button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedEventId(event.id);
                      setStatus('');
                    }}
                  >
                    Add context
                  </button>
                )}
              </article>
            ))}
            {status ? <output>{status}</output> : null}
          </div>
        ) : null}
        <Link href="/candidate">
          Return to applications <ArrowRight />
        </Link>
      </section>
    </main>
  );
}

function EmployerReview({ data }: { data: SessionData }) {
  const answers = data.events.filter(
    (event) => event.eventType === 'answer_submitted',
  );
  const tabs = data.events.filter(
    (event) => event.eventType === 'tab_hidden',
  ).length;
  const fullscreenExits = data.events.filter(
    (event) => event.eventType === 'fullscreen_exit',
  ).length;
  const camera = data.events.find(
    (event) =>
      event.eventType === 'camera_available' ||
      event.eventType === 'camera_unavailable',
  );
  const contextualEvents = data.events.filter((event) =>
    ['tab_hidden', 'fullscreen_exit', 'camera_unavailable'].includes(
      event.eventType,
    ),
  );
  const contextChoice = getSessionContextChoice(
    data.events.some((event) => event.eventType === 'consent_recorded'),
    data.session.acceptedSignals ?? [],
  );
  const optionalContextShared = contextChoice.shared;
  const evaluation = data.session.evaluation;
  return (
    <main className="interview-review-page">
      <header>
        <Link href="/company">
          <ArrowLeft /> Employer workspace
        </Link>
        <div className="flex items-center gap-2">
          {['scheduled', 'in_progress'].includes(data.session.status) ? (
            <span className="interview-live-status">
              <i /> Live · refreshes every 5s
            </span>
          ) : null}
          <Badge variant="outline">{titleCase(data.session.status)}</Badge>
        </div>
      </header>
      <section className="interview-review-head">
        <span>Structured interview review</span>
        <h1>{data.session.candidateName}</h1>
        <p>
          {data.session.jobTitle} · {data.session.companyName}
        </p>
      </section>
      <div className="interview-review-grid">
        <section>
          <div className="interview-review-section-head">
            <div>
              <h2>Transcript and rubric</h2>
              <p>
                Each indicator links to the answer below. It supports review and
                is not a hiring decision.
              </p>
            </div>
            {evaluation?.overallEvidenceStrength != null ? (
              <span>
                <strong>{evaluation.overallEvidenceStrength}</strong>/100
                evidence strength
              </span>
            ) : null}
          </div>
          {answers.length ? (
            answers.map((event, index) => {
              const questionId = text(event.payload.questionId);
              const question = data.session.questions.find(
                (item) => item.id === questionId,
              );
              const answerText = text(event.payload.answer);
              const assessment = asAssessment(event.payload.assessment);
              return (
                <article key={event.id}>
                  <span>
                    {question?.kind === 'follow_up'
                      ? 'Focused follow-up'
                      : `Question ${index + 1}`}{' '}
                    · {question?.criterionLabel ?? 'Role evidence'}
                  </span>
                  <h3>{question?.prompt ?? 'Interview question'}</h3>
                  <p>{answerText}</p>
                  {assessment ? (
                    <div className="answer-rubric">
                      <b>{assessment.evidenceStrength}/100 evidence</b>
                      <span>Relevance {assessment.dimensions.relevance}</span>
                      <span>
                        Specificity {assessment.dimensions.specificity}
                      </span>
                      <span>Ownership {assessment.dimensions.ownership}</span>
                      <span>Outcome {assessment.dimensions.outcome}</span>
                      <small>{assessment.summary}</small>
                    </div>
                  ) : null}
                </article>
              );
            })
          ) : (
            <div className="candidate-empty">
              No answers have been submitted yet.
            </div>
          )}
        </section>
        <aside>
          {evaluation?.criterionRubric?.length ? (
            <>
              <h2>Criterion coverage</h2>
              <div className="interview-criterion-rubric">
                {evaluation.criterionRubric.map((item) => (
                  <section key={item.criterionId ?? item.label}>
                    <span>{item.label}</span>
                    <strong>{item.score}/100</strong>
                    <Progress value={item.score} />
                  </section>
                ))}
              </div>
            </>
          ) : null}
          <h2>Session context</h2>
          {optionalContextShared ? (
            <>
              <div>
                <strong>{tabs}</strong>
                <span>Tab exits</span>
              </div>
              <div>
                <strong>{fullscreenExits}</strong>
                <span>Fullscreen exits</span>
              </div>
              <div>
                <strong>
                  {camera?.eventType === 'camera_available'
                    ? 'Available'
                    : camera
                      ? 'Unavailable'
                      : 'Not tested'}
                </strong>
                <span>Camera check</span>
              </div>
              {contextualEvents.some((event) => event.candidateExplanation) ? (
                <div className="employer-event-context">
                  <strong>Candidate context</strong>
                  {contextualEvents
                    .filter((event) => event.candidateExplanation)
                    .map((event) => (
                      <p key={event.id}>
                        <span>{titleCase(event.eventType)}</span>
                        {event.candidateExplanation}
                      </p>
                    ))}
                </div>
              ) : null}
            </>
          ) : (
            <div>
              <strong>{contextChoice.title}</strong>
              <span>{contextChoice.detail}</span>
            </div>
          )}
          <p>
            <ShieldCheck /> These signals require human interpretation and are
            excluded from answer scoring. HireMind does not analyze eye movement
            or facial characteristics.
          </p>
        </aside>
      </div>
    </main>
  );
}

function insertAfterParent(
  questions: InterviewQuestion[],
  question: InterviewQuestion,
) {
  const index = questions.findIndex(
    (item) => item.id === question.parentQuestionId,
  );
  return index < 0
    ? [...questions, question]
    : [
        ...questions.slice(0, index + 1),
        question,
        ...questions.slice(index + 1),
      ];
}
function asAssessment(value: unknown) {
  return typeof value === 'object' && value !== null
    ? (value as AnswerAssessment)
    : null;
}
function text(value: unknown) {
  return typeof value === 'string' || typeof value === 'number'
    ? `${value}`
    : '';
}
function titleCase(value: string) {
  return value
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}
