'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { StableLink as Link } from '@/components/stable-link';
import {
  ArrowLeft,
  Camera,
  CameraOff,
  CheckCircle2,
  ClipboardCheck,
  Laptop,
  Maximize2,
  Mic,
  MicOff,
  MonitorUp,
  PhoneOff,
  RefreshCw,
  ShieldCheck,
  Users,
} from 'lucide-react';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import type { InterviewQuestion } from '@/lib/interview-engine';
import { authenticatedFetch } from '@/lib/supabase/client';

type LiveSession = {
  id: string;
  status: string;
  scheduledAt: number | null;
  startedAt?: number | null;
  completedAt?: number | null;
  candidateName: string;
  companyName: string;
  jobTitle: string;
  questions: InterviewQuestion[];
  liveNotes?: Array<{ notes: string; updatedAt: number; authorName: string }>;
};

type Participant = {
  userId: string;
  role: 'candidate' | 'employer';
  displayName: string;
  peerId: string;
  mediaState: { microphone?: boolean; camera?: boolean; screen?: boolean };
  lastSeenAt: number;
};

type Signal = {
  id: string;
  senderUserId: string;
  signalType: 'description' | 'candidate' | 'renegotiate';
  payload: Record<string, unknown>;
  createdAt: number;
};

type RoomSnapshot = {
  role: 'candidate' | 'employer';
  session: Omit<LiveSession, 'questions'>;
  participants: Participant[];
  signals: Signal[];
  cursor: number;
  note?: { notes: string; updatedAt: number | null };
  error?: string;
};

type JoinResult = {
  role?: 'candidate' | 'employer';
  userId?: string;
  iceServers?: RTCIceServer[];
  availableAt?: number;
  error?: string;
};

export default function LiveInterviewRoom({
  session,
  viewerRole,
}: {
  session: LiveSession;
  viewerRole: 'candidate' | 'employer';
}) {
  const [phase, setPhase] = useState<
    'preview' | 'joining' | 'waiting' | 'live' | 'ended'
  >('preview');
  const [microphoneOn, setMicrophoneOn] = useState(true);
  const [cameraOn, setCameraOn] = useState(true);
  const [sharingScreen, setSharingScreen] = useState(false);
  const [mediaReady, setMediaReady] = useState(false);
  const [joined, setJoined] = useState(false);
  const [ownUserId, setOwnUserId] = useState('');
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [connectionState, setConnectionState] = useState<
    RTCPeerConnectionState | 'idle'
  >('idle');
  const [message, setMessage] = useState('');
  const [notes, setNotes] = useState('');
  const [notesDirty, setNotesDirty] = useState(false);
  const [noteStatus, setNoteStatus] = useState('');
  const [activeQuestion, setActiveQuestion] = useState(0);
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const cameraStreamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const targetUserIdRef = useRef('');
  const ownUserIdRef = useRef('');
  const iceServersRef = useRef<RTCIceServer[]>([]);
  const cursorRef = useRef(0);
  const seenSignalsRef = useRef(new Set<string>());
  const pendingIceCandidatesRef = useRef<RTCIceCandidateInit[]>([]);
  const joinedRef = useRef(false);
  const connectingRef = useRef(false);

  const postAction = useCallback(
    async (action: string, extra: Record<string, unknown> = {}) => {
      try {
        const response = await authenticatedFetch(`/api/interviews/live?view=${viewerRole}`, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ sessionId: session.id, action, ...extra }),
        });
        const result = (await response.json().catch(() => ({}))) as
          | (JoinResult & Record<string, unknown>)
          | undefined;
        return { ok: response.ok, ...result };
      } catch {
        return {
          ok: false,
          error:
            'The live room could not reach the interview service. Check your connection and reconnect.',
        };
      }
    },
    [session.id, viewerRole],
  );

  const sendSignal = useCallback(
    async (
      targetUserId: string,
      signalType: Signal['signalType'],
      payload: unknown,
    ) => {
      if (!joinedRef.current || !targetUserId) return;
      const result = await postAction('signal', {
        targetUserId,
        signalType,
        payload,
      });
      if (!result.ok && result.error)
        setMessage(`Connection update failed: ${result.error}`);
    },
    [postAction],
  );

  const resetPeer = useCallback(() => {
    peerConnectionRef.current?.close();
    peerConnectionRef.current = null;
    targetUserIdRef.current = '';
    connectingRef.current = false;
    pendingIceCandidatesRef.current = [];
    if (remoteVideoRef.current) remoteVideoRef.current.srcObject = null;
  }, []);

  const stopMedia = useCallback(() => {
    resetPeer();
    screenStreamRef.current?.getTracks().forEach((track) => track.stop());
    cameraStreamRef.current?.getTracks().forEach((track) => track.stop());
    screenStreamRef.current = null;
    cameraStreamRef.current = null;
    localStreamRef.current = null;
    setMediaReady(false);
  }, [resetPeer]);

  const createPeerConnection = useCallback(
    (targetUserId: string) => {
      if (peerConnectionRef.current && targetUserIdRef.current === targetUserId)
        return peerConnectionRef.current;
      resetPeer();
      targetUserIdRef.current = targetUserId;
      const peer = new RTCPeerConnection({ iceServers: iceServersRef.current });
      peerConnectionRef.current = peer;
      const localStream = localStreamRef.current;
      localStream
        ?.getTracks()
        .forEach((track) => peer.addTrack(track, localStream));
      const remoteStream = new MediaStream();
      if (remoteVideoRef.current)
        remoteVideoRef.current.srcObject = remoteStream;
      peer.ontrack = (event) => {
        event.streams[0]?.getTracks().forEach((track) => {
          if (!remoteStream.getTrackById(track.id))
            remoteStream.addTrack(track);
        });
      };
      peer.onicecandidate = (event) => {
        if (event.candidate)
          void sendSignal(targetUserId, 'candidate', event.candidate.toJSON());
      };
      peer.onconnectionstatechange = () => {
        setConnectionState(peer.connectionState);
        if (peer.connectionState === 'connected') {
          setPhase('live');
          setMessage('');
        }
        if (['failed', 'disconnected'].includes(peer.connectionState))
          setMessage(
            'The media connection was interrupted. Reconnect to establish a fresh secure connection.',
          );
      };
      return peer;
    },
    [resetPeer, sendSignal],
  );

  const createOffer = useCallback(
    async (targetUserId: string) => {
      if (connectingRef.current) return;
      connectingRef.current = true;
      try {
        const peer = createPeerConnection(targetUserId);
        await peer.setLocalDescription(await peer.createOffer());
        if (peer.localDescription)
          await sendSignal(
            targetUserId,
            'description',
            peer.localDescription.toJSON(),
          );
        setPhase('waiting');
      } catch {
        setMessage(
          'The secure connection could not be prepared. Check camera permissions and try reconnecting.',
        );
      } finally {
        connectingRef.current = false;
      }
    },
    [createPeerConnection, sendSignal],
  );

  const processSignal = useCallback(
    async (signal: Signal) => {
      if (seenSignalsRef.current.has(signal.id)) return;
      seenSignalsRef.current.add(signal.id);
      try {
        if (signal.signalType === 'description') {
          const description =
            signal.payload as unknown as RTCSessionDescriptionInit;
          const peer = createPeerConnection(signal.senderUserId);
          await peer.setRemoteDescription(description);
          for (const candidate of pendingIceCandidatesRef.current.splice(0))
            await peer.addIceCandidate(candidate);
          if (description.type === 'offer') {
            await peer.setLocalDescription(await peer.createAnswer());
            if (peer.localDescription)
              await sendSignal(
                signal.senderUserId,
                'description',
                peer.localDescription.toJSON(),
              );
          }
        } else if (signal.signalType === 'candidate') {
          const peer = createPeerConnection(signal.senderUserId);
          const candidate = signal.payload as unknown as RTCIceCandidateInit;
          if (peer.remoteDescription) await peer.addIceCandidate(candidate);
          else pendingIceCandidatesRef.current.push(candidate);
        } else if (
          signal.signalType === 'renegotiate' &&
          viewerRole === 'employer'
        ) {
          await createOffer(signal.senderUserId);
        }
      } catch {
        setMessage(
          'A connection update was missed. Use Reconnect to retry without leaving the interview.',
        );
      }
    },
    [createOffer, createPeerConnection, sendSignal, viewerRole],
  );

  const pollRoom = useCallback(async () => {
    if (!joinedRef.current) return;
    const response = await authenticatedFetch(
      `/api/interviews/live?id=${encodeURIComponent(session.id)}&since=${cursorRef.current}&view=${viewerRole}`,
    );
    const result = (await response.json().catch(() => ({}))) as RoomSnapshot;
    if (!response.ok) {
      setMessage(result.error ?? 'Room presence could not be refreshed.');
      return;
    }
    cursorRef.current = Math.max(cursorRef.current, result.cursor || 0);
    setParticipants(result.participants ?? []);
    if (viewerRole === 'employer' && result.note && !noteStatus)
      setNotes((current) => current || result.note?.notes || '');
    for (const signal of result.signals ?? []) await processSignal(signal);
    if (
      result.session.status === 'completed' ||
      result.session.status === 'cancelled'
    ) {
      joinedRef.current = false;
      setJoined(false);
      setPhase('ended');
      stopMedia();
      return;
    }
    const other = result.participants.find(
      (participant) => participant.userId !== ownUserIdRef.current,
    );
    if (!other) {
      setPhase((current) => (current === 'live' ? current : 'waiting'));
      return;
    }
    if (targetUserIdRef.current && targetUserIdRef.current !== other.userId)
      resetPeer();
    if (viewerRole === 'employer' && !peerConnectionRef.current)
      await createOffer(other.userId);
  }, [
    createOffer,
    noteStatus,
    processSignal,
    resetPeer,
    session.id,
    stopMedia,
    viewerRole,
  ]);

  useEffect(() => {
    if (!joined) return;
    const pollTimer = window.setInterval(() => {
      void pollRoom();
    }, 1_000);
    const heartbeatTimer = window.setInterval(() => {
      void postAction('heartbeat', {
        mediaState: {
          microphone: microphoneOn,
          camera: cameraOn,
          screen: sharingScreen,
        },
      });
    }, 5_000);
    return () => {
      window.clearInterval(pollTimer);
      window.clearInterval(heartbeatTimer);
    };
  }, [cameraOn, joined, microphoneOn, pollRoom, postAction, sharingScreen]);

  useEffect(
    () => () => {
      if (joinedRef.current) void postAction('leave');
      stopMedia();
    },
    [postAction, stopMedia],
  );

  useEffect(() => {
    if (viewerRole !== 'employer' || !joined || !notesDirty) return;
    const timer = window.setTimeout(async () => {
      setNoteStatus('Saving…');
      const result = await postAction('save_note', { notes });
      if (result.ok) {
        setNotesDirty(false);
        setNoteStatus('Private notes saved automatically');
      } else {
        setNoteStatus(result.error ?? 'Notes could not be saved');
      }
    }, 1_200);
    return () => window.clearTimeout(timer);
  }, [joined, notes, notesDirty, postAction, viewerRole]);

  async function prepareMedia() {
    setMessage('');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'user',
        },
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
      // Rechecking must not silently enable devices the participant muted.
      stream.getAudioTracks().forEach((track) => { track.enabled = microphoneOn; });
      stream.getVideoTracks().forEach((track) => { track.enabled = cameraOn; });
      const previousStreams = new Set([cameraStreamRef.current, localStreamRef.current]);
      previousStreams.forEach((previous) => previous?.getTracks().forEach((track) => track.stop()));
      cameraStreamRef.current = stream;
      localStreamRef.current = stream;
      if (localVideoRef.current) localVideoRef.current.srcObject = stream;
      setMediaReady(true);
      return stream;
    } catch {
      setMessage(
        'Camera or microphone permission was blocked. Allow both in the browser address bar, then try again.',
      );
      return null;
    }
  }

  async function joinRoom() {
    setPhase('joining');
    const stream = localStreamRef.current ?? (await prepareMedia());
    if (!stream) {
      setPhase('preview');
      return;
    }
    const result = await postAction('join', {
      peerId: crypto.randomUUID(),
      mediaState: { microphone: microphoneOn, camera: cameraOn, screen: false },
    });
    if (!result.ok || !result.userId) {
      setPhase('preview');
      setMessage(
        result.availableAt
          ? `The room opens at ${new Date(result.availableAt).toLocaleString()}.`
          : (result.error ?? 'The room could not be opened.'),
      );
      return;
    }
    ownUserIdRef.current = result.userId;
    setOwnUserId(result.userId);
    iceServersRef.current = result.iceServers?.length
      ? result.iceServers
      : [{ urls: 'stun:stun.cloudflare.com:3478' }];
    joinedRef.current = true;
    setJoined(true);
    setPhase('waiting');
    await pollRoom();
  }

  function toggleMicrophone() {
    const enabled = !microphoneOn;
    localStreamRef.current?.getAudioTracks().forEach((track) => {
      track.enabled = enabled;
    });
    setMicrophoneOn(enabled);
  }

  function toggleCamera() {
    const enabled = !cameraOn;
    cameraStreamRef.current?.getVideoTracks().forEach((track) => {
      track.enabled = enabled;
    });
    setCameraOn(enabled);
  }

  async function toggleScreenShare() {
    if (sharingScreen) {
      await stopScreenShare();
      return;
    }
    try {
      const screen = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: false,
      });
      const track = screen.getVideoTracks()[0];
      screenStreamRef.current = screen;
      const sender = peerConnectionRef.current
        ?.getSenders()
        .find((item) => item.track?.kind === 'video');
      await sender?.replaceTrack(track);
      if (localVideoRef.current) localVideoRef.current.srcObject = screen;
      setSharingScreen(true);
      track.onended = () => {
        void stopScreenShare();
      };
    } catch {
      setMessage(
        'Screen sharing was cancelled or is not supported by this browser.',
      );
    }
  }

  async function stopScreenShare() {
    screenStreamRef.current?.getTracks().forEach((track) => track.stop());
    screenStreamRef.current = null;
    const cameraTrack = cameraStreamRef.current?.getVideoTracks()[0] ?? null;
    const sender = peerConnectionRef.current
      ?.getSenders()
      .find((item) => item.track?.kind === 'video');
    await sender?.replaceTrack(cameraTrack);
    if (localVideoRef.current)
      localVideoRef.current.srcObject = cameraStreamRef.current;
    setSharingScreen(false);
  }

  async function reconnect() {
    resetPeer();
    setConnectionState('connecting');
    setMessage('Reconnecting securely…');
    await pollRoom();
    const other = participants.find(
      (participant) => participant.userId !== ownUserIdRef.current,
    );
    if (other && viewerRole === 'candidate')
      await sendSignal(other.userId, 'renegotiate', {});
  }

  async function saveNotes() {
    setNoteStatus('Saving…');
    const result = await postAction('save_note', { notes });
    setNoteStatus(
      result.ok
        ? 'Private notes saved'
        : (result.error ?? 'Notes could not be saved'),
    );
    if (result.ok) setNotesDirty(false);
  }

  async function leaveRoom(endForEveryone = false) {
    if (endForEveryone) {
      setMessage('Ending the interview for both participants…');
      if (viewerRole === 'employer' && notes.trim()) {
        const noteResult = await postAction('save_note', { notes });
        if (!noteResult.ok) {
          setMessage(
            noteResult.error ??
              'Private notes could not be saved. Save them before ending the call.',
          );
          return;
        }
      }
      const result = await postAction('end');
      if (!result.ok) {
        setMessage(
          result.error ?? 'The interview could not be ended. Try again.',
        );
        return;
      }
    } else {
      await postAction('leave');
    }
    joinedRef.current = false;
    setJoined(false);
    setPhase('ended');
    stopMedia();
  }

  const otherParticipant = participants.find(
    (participant) => participant.userId !== ownUserId,
  );
  const remoteVideoUnavailable =
    !otherParticipant ||
    phase !== 'live' ||
    otherParticipant.mediaState.camera === false;
  const returnPath = viewerRole === 'employer' ? '/company' : '/candidate';

  if (phase === 'ended' || ['completed', 'cancelled'].includes(session.status))
    return (
      <main className="live-ended">
        <section>
          <CheckCircle2 />
          <Badge variant="outline">
            {session.status === 'cancelled'
              ? 'Live interview cancelled'
              : 'Live interview ended'}
          </Badge>
          <h1>
            {session.status === 'cancelled'
              ? 'This interview is no longer active.'
              : 'The conversation is complete.'}
          </h1>
          <p>
            {viewerRole === 'employer'
              ? 'Your private notes remain in the interview record for the hiring team.'
              : `Thank you. ${session.companyName} will continue the hiring process from here.`}
          </p>
          {viewerRole === 'employer' &&
          (notes.trim() || session.liveNotes?.length) ? (
            <div className="live-ended-notes">
              <strong>Private hiring-team notes</strong>
              {(notes.trim()
                ? [
                    {
                      notes,
                      authorName: 'You',
                      updatedAt:
                        session.completedAt ??
                        session.startedAt ??
                        session.scheduledAt ??
                        0,
                    },
                  ]
                : (session.liveNotes ?? [])
              ).map((note, index) => (
                <article key={`${note.authorName}-${note.updatedAt}-${index}`}>
                  <span>
                    {note.authorName} ·{' '}
                    {new Date(note.updatedAt).toLocaleString()}
                  </span>
                  <p>{note.notes}</p>
                </article>
              ))}
            </div>
          ) : null}
          <Link href={returnPath}>Return to workspace</Link>
        </section>
      </main>
    );

  return (
    <main className="live-room-page">
      <header className="live-room-header">
        <Link href={returnPath} aria-label="Leave interview room">
          <ArrowLeft />
        </Link>
        <div>
          <span className="candidate-brand-mark">h</span>
          <strong>{session.companyName}</strong>
          <small>{session.jobTitle} · Live interview</small>
        </div>
        <Badge
          className={
            phase === 'live' ? 'live-room-badge is-live' : 'live-room-badge'
          }
        >
          <i />
          {phase === 'live'
            ? 'Connected'
            : phase === 'joining'
              ? 'Joining…'
              : phase === 'waiting'
                ? 'Waiting for participant'
                : 'Private preview'}
        </Badge>
      </header>

      <section className="live-room-layout">
        <div className="live-stage">
          <div className="live-remote-tile">
            {/* oxlint-disable-next-line jsx-a11y/media-has-caption -- This is a real-time peer call, not prerecorded media with a caption track. */}
            <video ref={remoteVideoRef} autoPlay playsInline />
            {remoteVideoUnavailable ? (
              <div className="live-video-placeholder">
                {otherParticipant?.mediaState.camera === false &&
                phase === 'live' ? (
                  <CameraOff />
                ) : (
                  <Users />
                )}
                <strong>
                  {otherParticipant?.mediaState.camera === false &&
                  phase === 'live'
                    ? `${otherParticipant.displayName}'s camera is off`
                    : otherParticipant
                      ? `Connecting to ${otherParticipant.displayName}…`
                      : `Waiting for ${viewerRole === 'employer' ? session.candidateName : 'the interviewer'}…`}
                </strong>
                <span>
                  {otherParticipant?.mediaState.camera === false &&
                  phase === 'live'
                    ? 'Audio remains connected.'
                    : 'Keep this tab open. The call connects automatically when both people join.'}
                </span>
              </div>
            ) : null}
            {otherParticipant ? (
              <span className="live-video-name">
                {otherParticipant.displayName}
                {otherParticipant.mediaState.microphone === false ? (
                  <MicOff />
                ) : null}
              </span>
            ) : null}
          </div>
          <div className="live-local-tile">
            {/* oxlint-disable-next-line jsx-a11y/media-has-caption -- This is the user's real-time local preview. */}
            <video ref={localVideoRef} autoPlay muted playsInline />
            {!mediaReady || (!cameraOn && !sharingScreen) ? (
              <CameraOff />
            ) : null}
            <span>You{sharingScreen ? ' · presenting' : ''}</span>
          </div>
          {message ? (
            <output className="live-room-message" aria-live="polite">
              {message}
            </output>
          ) : null}
          <div className="live-controls" aria-label="Call controls">
            <button
              type="button"
              disabled={!mediaReady}
              onClick={toggleMicrophone}
              className={!microphoneOn ? 'is-off' : ''}
              aria-label={
                microphoneOn ? 'Mute microphone' : 'Unmute microphone'
              }
            >
              {microphoneOn ? <Mic /> : <MicOff />}
              <span>{microphoneOn ? 'Mute' : 'Unmute'}</span>
            </button>
            <button
              type="button"
              disabled={!mediaReady}
              onClick={toggleCamera}
              className={!cameraOn ? 'is-off' : ''}
              aria-label={cameraOn ? 'Turn camera off' : 'Turn camera on'}
            >
              {cameraOn ? <Camera /> : <CameraOff />}
              <span>Camera</span>
            </button>
            <button
              type="button"
              disabled={!mediaReady || !joined}
              onClick={toggleScreenShare}
              className={sharingScreen ? 'is-active' : ''}
            >
              <MonitorUp />
              <span>{sharingScreen ? 'Stop share' : 'Share screen'}</span>
            </button>
            {joined ? (
              <button type="button" onClick={reconnect}>
                <RefreshCw />
                <span>Reconnect</span>
              </button>
            ) : null}
            {joined ? (
              <button
                type="button"
                className="is-leave"
                onClick={() => leaveRoom(viewerRole === 'employer')}
              >
                <PhoneOff />
                <span>{viewerRole === 'employer' ? 'End call' : 'Leave'}</span>
              </button>
            ) : null}
          </div>
        </div>

        <aside className="live-side-panel">
          {phase === 'preview' || phase === 'joining' ? (
            <section className="live-preflight">
              <Badge variant="outline">
                <ShieldCheck /> Encrypted 1:1 room
              </Badge>
              <h1>Ready to join?</h1>
              <p>
                Check your camera and microphone before entering. HireMind does
                not record this call.
              </p>
              <ul>
                <li>
                  <Camera /> Camera and microphone permissions
                </li>
                <li>
                  <Laptop /> Stable internet and a quiet space
                </li>
                <li>
                  <Maximize2 /> Keep this tab open during the interview
                </li>
              </ul>
              <Button variant="outline" onClick={prepareMedia}>
                <Camera /> Check camera and microphone
              </Button>
              <Button
                disabled={phase === 'joining'}
                onClick={joinRoom}
                className="bg-[#2b2233] text-white"
              >
                {phase === 'joining'
                  ? 'Joining securely…'
                  : 'Join live interview'}
              </Button>
              <small>
                By joining, both participants share live audio and video.
                Recording is off.
              </small>
            </section>
          ) : viewerRole === 'employer' ? (
            <section className="live-interviewer-panel">
              <div>
                <Badge variant="outline">
                  <ClipboardCheck /> Interviewer workspace
                </Badge>
                <h2>Role-linked guide</h2>
                <p>
                  Use the same evidence areas for every candidate. Notes are
                  private to your company.
                </p>
              </div>
              {session.questions.length ? (
                <div className="live-question-guide">
                  <span>
                    {activeQuestion + 1} of {session.questions.length}
                  </span>
                  <strong>
                    {session.questions[activeQuestion]?.criterionLabel}
                  </strong>
                  <p>{session.questions[activeQuestion]?.prompt}</p>
                  <div>
                    <Button
                      variant="outline"
                      disabled={activeQuestion === 0}
                      onClick={() =>
                        setActiveQuestion((value) => Math.max(0, value - 1))
                      }
                    >
                      Previous
                    </Button>
                    <Button
                      variant="outline"
                      disabled={activeQuestion >= session.questions.length - 1}
                      onClick={() =>
                        setActiveQuestion((value) =>
                          Math.min(session.questions.length - 1, value + 1),
                        )
                      }
                    >
                      Next
                    </Button>
                  </div>
                </div>
              ) : null}
              <label htmlFor="live-interview-notes">
                Private interview notes
                <Textarea
                  id="live-interview-notes"
                  rows={8}
                  value={notes}
                  onChange={(event) => {
                    setNotes(event.target.value);
                    setNotesDirty(true);
                    setNoteStatus('Unsaved changes');
                  }}
                  placeholder="Capture evidence, follow-ups, and open questions…"
                  maxLength={12_000}
                />
              </label>
              <Button variant="outline" onClick={saveNotes}>
                Save private notes
              </Button>
              {noteStatus ? <output>{noteStatus}</output> : null}
            </section>
          ) : (
            <section className="live-candidate-panel">
              <Badge variant="outline">
                <ShieldCheck /> Candidate privacy
              </Badge>
              <h2>Your conversation is not recorded.</h2>
              <p>
                The interviewer may take private notes. Camera, microphone, and
                screen sharing remain under your control.
              </p>
              <div>
                <strong>
                  {session.scheduledAt
                    ? new Date(session.scheduledAt).toLocaleString()
                    : 'Scheduled interview'}
                </strong>
                <span>
                  {session.companyName} · {session.jobTitle}
                </span>
              </div>
            </section>
          )}
          {joined ? (
            <div className="live-connection-card">
              <i className={connectionState === 'connected' ? 'is-good' : ''} />
              <span>
                <strong>
                  {connectionState === 'connected'
                    ? 'Secure media connected'
                    : 'Establishing secure media'}
                </strong>
                <small>
                  {connectionState === 'failed'
                    ? 'The current network may block peer video. Try Reconnect or another network.'
                    : 'Audio and video are encrypted in transit.'}
                </small>
              </span>
            </div>
          ) : null}
        </aside>
      </section>
    </main>
  );
}
