'use client';

import { useEffect, useState } from 'react';
import { StableLink as Link } from '@/components/stable-link';

import { getSupabaseBrowserClient } from '@/lib/supabase/client';

export default function AuthCallbackPage() {
  const [message, setMessage] = useState('Securing your HireMind session…');

  useEffect(() => {
    async function completeSignIn() {
      const params = new URLSearchParams(window.location.search);
      const nextValue = params.get('next');
      const next = nextValue?.startsWith('/') && !nextValue.startsWith('//') ? nextValue : '/onboarding';
      const code = params.get('code');
      const supabase = getSupabaseBrowserClient();
      if (code) {
        const { error } = await supabase.auth.exchangeCodeForSession(code);
        if (error) {
          setMessage('This sign-in link is invalid or expired. Please request a new email.');
          return;
        }
      }
      const { data } = await supabase.auth.getSession();
      if (!data.session) {
        setMessage('We could not verify this session. Please return to sign in.');
        return;
      }
      window.location.replace(next);
    }
    void completeSignIn();
  }, []);

  return <main className="auth-transition"><span className="candidate-brand-mark">h</span><p>{message}</p><Link href="/login">Return to sign in</Link></main>;
}
