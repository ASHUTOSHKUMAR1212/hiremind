'use client';

import { useEffect, useState } from 'react';

import { authenticatedFetch, getSupabaseBrowserClient } from '@/lib/supabase/client';

import CandidateWorkspace from './candidate-workspace';

type CandidateAccount = {
  user: { email: string; fullName: string | null };
  candidate: { id: string; fullName: string; profileType: string } | null;
};

export default function CandidatePage() {
  const [account, setAccount] = useState<CandidateAccount | null>(null);

  useEffect(() => {
    async function load() {
      const { data } = await getSupabaseBrowserClient().auth.getSession();
      if (!data.session) {
        window.location.replace('/login?next=/candidate&role=candidate');
        return;
      }
      const response = await authenticatedFetch('/api/me');
      if (!response.ok) {
        window.location.replace('/login?next=/candidate&role=candidate');
        return;
      }
      const nextAccount = await response.json() as CandidateAccount;
      if (!nextAccount.candidate) {
        window.location.replace('/onboarding?role=candidate');
        return;
      }
      setAccount(nextAccount);
    }
    void load();
  }, []);

  if (!account?.candidate) {
    return <main className="auth-transition"><span className="candidate-brand-mark">h</span><p>Opening your candidate workspace…</p></main>;
  }

  return <CandidateWorkspace userName={account.candidate.fullName} userEmail={account.user.email} initialProfileType={account.candidate.profileType} />;
}
