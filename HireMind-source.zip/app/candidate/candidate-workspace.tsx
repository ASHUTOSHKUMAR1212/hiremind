'use client';
import { InterviewCalendarDownload } from '@/components/interview-calendar-download';

import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ChangeEvent,
  type SyntheticEvent,
} from 'react';
import { StableLink as Link } from '@/components/stable-link';
import { AuthenticatedFileLink } from '@/components/authenticated-file-link';
import { Checkbox } from '@/components/ui/checkbox';
import {
  ArrowRight,
  BriefcaseBusiness,
  Building2,
  CalendarClock,
  Check,
  ChevronRight,
  Clock3,
  CircleCheck,
  FileText,
  GraduationCap,
  MapPin,
  MessageSquareText,
  Plus,
  Save,
  Search,
  Sparkles,
  Trash2,
  UploadCloud,
  UserRound,
} from 'lucide-react';

import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button, buttonVariants } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { SignOutButton } from '@/components/sign-out-button';
import { Textarea } from '@/components/ui/textarea';
import { authenticatedFetch } from '@/lib/supabase/client';
import { getCandidateInterviewPresentation } from '@/lib/interview-status';
import { extractResumeText, parseResumeProfile } from '@/lib/resume-text';
import { cn } from '@/lib/utils';

type Criterion = {
  id: string;
  label: string;
  requirementClass: string;
  weight: number;
  evidenceDefinition: string;
  equivalentSignals?: string[];
};

type Job = {
  id: string;
  company: string;
  initials: string;
  title: string;
  location: string;
  type: string;
  mode: string;
  posted: string;
  summary: string;
  criteria: Criterion[];
  match: number | null;
  matchedCriteria: string[];
  missingCriteria: string[];
};

type CandidateApplication = {
  id: string;
  jobId: string;
  jobTitle: string;
  companyName: string;
  status: string;
  currentStage: string | null;
  submittedAt: number;
  fitScore: number | null;
  decisionBand: string | null;
  screeningExplanation: string | null;
  interviewSessionId: string | null;
  interviewStatus: string | null;
  interviewMode: string | null;
  interviewScheduledAt: number | null;
  timeline: CandidateApplicationEvent[];
};
type CandidateApplicationEvent = {
  id: string;
  eventType: string;
  fromStatus: string | null;
  toStatus: string | null;
  note: string | null;
  occurredAt: number;
};

type Experience = {
  title: string;
  organizationName: string;
  description: string;
  startedOn: string;
  endedOn: string;
  isCurrent: boolean;
};
type Education = {
  institution: string;
  qualification: string;
  fieldOfStudy: string;
  startedOn: string;
  endedOn: string;
};
type Project = {
  title: string;
  description: string;
  projectUrl: string;
  repositoryUrl: string;
  skills: string[];
};
type Profile = {
  fullName: string;
  profileType: string;
  phone: string;
  headline: string;
  summary: string;
  location: string;
  workAuthorization: string;
  availability: string;
  skills: string[];
  resumeText: string;
  resumeTextExtracted: boolean;
  futureRoleConsent: boolean;
};

type ProfilePayload = {
  profile: Profile;
  experiences: Experience[];
  education: Education[];
  projects: Project[];
  resume: { id: string; filename: string; sizeBytes: number } | null;
  completion: number;
  qualityWarnings?: string[];
};

type ResumeImportReport = {
  fields: number;
  skills: number;
  experiences: number;
  education: number;
  projects: number;
  warnings: string[];
};

type CandidateWorkspaceProps = {
  userName: string;
  userEmail: string;
  initialProfileType: string;
};

const emptyExperience = (): Experience => ({
  title: '',
  organizationName: '',
  description: '',
  startedOn: '',
  endedOn: '',
  isCurrent: false,
});
const emptyEducation = (): Education => ({
  institution: '',
  qualification: '',
  fieldOfStudy: '',
  startedOn: '',
  endedOn: '',
});
const emptyProject = (): Project => ({
  title: '',
  description: '',
  projectUrl: '',
  repositoryUrl: '',
  skills: [],
});

export default function CandidateWorkspace({
  userName,
  userEmail,
  initialProfileType,
}: CandidateWorkspaceProps) {
  const [activeView, setActiveView] = useState<
    'jobs' | 'applications' | 'profile'
  >('jobs');
  const [profile, setProfile] = useState<Profile>({
    fullName: userName,
    profileType: initialProfileType,
    phone: '',
    headline: '',
    summary: '',
    location: '',
    workAuthorization: '',
    availability: '',
    skills: [],
    resumeText: '',
    resumeTextExtracted: false,
    futureRoleConsent: false,
  });
  const [experiences, setExperiences] = useState<Experience[]>([]);
  const [education, setEducation] = useState<Education[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [resume, setResume] = useState<ProfilePayload['resume']>(null);
  const [completion, setCompletion] = useState(11);
  const [qualityWarnings, setQualityWarnings] = useState<string[]>([]);
  const [skillsInput, setSkillsInput] = useState('');
  const [profileStatus, setProfileStatus] = useState('');
  const [profileReady, setProfileReady] = useState(false);
  const [profileSaving, setProfileSaving] = useState(false);
  const profileSavingRef = useRef(false);
  const [resumeImporting, setResumeImporting] = useState(false);
  const [resumeImportReport, setResumeImportReport] =
    useState<ResumeImportReport | null>(null);
  const [availableJobs, setAvailableJobs] = useState<Job[]>([]);
  const [selectedId, setSelectedId] = useState('');
  const [query, setQuery] = useState('');
  const [locationQuery, setLocationQuery] = useState('');
  const [applications, setApplications] = useState<CandidateApplication[]>([]);
  const [applicationStatus, setApplicationStatus] = useState('');
  const [changeRequestApplication, setChangeRequestApplication] =
    useState<CandidateApplication | null>(null);
  const [changeRequestBusy, setChangeRequestBusy] = useState(false);
  const [loadingJobs, setLoadingJobs] = useState(true);
  const resumeInput = useRef<HTMLInputElement>(null);
  const profileRequest = useRef(0);

  const loadProfile = useCallback(async () => {
    const requestId = ++profileRequest.current;
    try {
      const response = await authenticatedFetch('/api/candidate/profile');
      if (!response.ok || requestId !== profileRequest.current) {
        if (requestId === profileRequest.current) {
          const result = (await response.json().catch(() => ({}))) as {
            error?: string;
          };
          setProfileStatus(
            result.error ??
              'Your profile could not be loaded. Check your connection and retry.',
          );
          setProfileReady(false);
        }
        return null;
      }
      const data = (await response.json()) as ProfilePayload;
      if (requestId !== profileRequest.current) return null;
      setProfile({
        fullName: String(data.profile.fullName ?? userName),
        profileType: String(data.profile.profileType ?? initialProfileType),
        phone: String(data.profile.phone ?? ''),
        headline: String(data.profile.headline ?? ''),
        summary: String(data.profile.summary ?? ''),
        location: String(data.profile.location ?? ''),
        workAuthorization: String(data.profile.workAuthorization ?? ''),
        availability: String(data.profile.availability ?? ''),
        skills: Array.isArray(data.profile.skills)
          ? data.profile.skills.map(String)
          : [],
        resumeText: String(data.profile.resumeText ?? ''),
        resumeTextExtracted: data.profile.resumeTextExtracted === true,
        futureRoleConsent: data.profile.futureRoleConsent === true,
      });
      setSkillsInput((data.profile.skills ?? []).join(', '));
      setExperiences(
        (data.experiences ?? []).map((item) => ({
          title: String(item.title ?? ''),
          organizationName: String(item.organizationName ?? ''),
          description: String(item.description ?? ''),
          startedOn: String(item.startedOn ?? ''),
          endedOn: String(item.endedOn ?? ''),
          isCurrent: Boolean(item.isCurrent),
        })),
      );
      setEducation(
        (data.education ?? []).map((item) => ({
          institution: String(item.institution ?? ''),
          qualification: String(item.qualification ?? ''),
          fieldOfStudy: String(item.fieldOfStudy ?? ''),
          startedOn: String(item.startedOn ?? ''),
          endedOn: String(item.endedOn ?? ''),
        })),
      );
      setProjects(
        (data.projects ?? []).map((item) => ({
          title: String(item.title ?? ''),
          description: String(item.description ?? ''),
          projectUrl: String(item.projectUrl ?? ''),
          repositoryUrl: String(item.repositoryUrl ?? ''),
          skills: Array.isArray(item.skills) ? item.skills.map(String) : [],
        })),
      );
      setResume(data.resume);
      setCompletion(data.completion);
      setQualityWarnings(data.qualityWarnings ?? []);
      setProfileReady(true);
      return data;
    } catch {
      if (requestId === profileRequest.current) {
        setProfileReady(false);
        setProfileStatus(
          'Your profile is temporarily unreachable. Check your connection and retry.',
        );
      }
      return null;
    }
  }, [initialProfileType, userName]);

  const loadJobs = useCallback(async () => {
    try {
      const response = await fetch('/api/jobs');
      if (!response.ok) {
        setApplicationStatus(
          'Open roles could not be loaded. Check your connection and retry.',
        );
        return;
      }
      const data = (await response.json()) as {
        jobs?: Array<Record<string, unknown>>;
      };
      const evidenceText = buildEvidenceText(
        profile,
        experiences,
        education,
        projects,
      );
      const jobs = (data.jobs ?? []).map((job): Job => {
        const criteria = Array.isArray(job.criteria)
          ? (job.criteria as Criterion[])
          : [];
        const fit = calculateFit(criteria, evidenceText);
        const companyName = readText(job.companyName, 'HireMind company');
        return {
          id: readText(job.id),
          company: companyName,
          initials: initials(companyName),
          title: readText(job.title, 'Open role'),
          location: readText(job.location, 'Flexible'),
          type: titleCase(readText(job.employmentType, 'full-time')),
          mode: titleCase(readText(job.workplaceType, 'hybrid')),
          posted: formatRelative(Number(job.publishedAt)),
          summary: readText(job.description),
          criteria,
          ...fit,
        };
      });
      setAvailableJobs(jobs);
      setSelectedId((current) => current || jobs[0]?.id || '');
    } catch {
      setApplicationStatus(
        'Open roles are temporarily unreachable. Check your connection and retry.',
      );
    } finally {
      setLoadingJobs(false);
    }
  }, [education, experiences, profile, projects]);

  const loadApplications = useCallback(async () => {
    try {
      const response = await authenticatedFetch('/api/applications');
      if (!response.ok) {
        setApplicationStatus(
          'Your applications could not be loaded. Check your connection and retry.',
        );
        return;
      }
      const data = (await response.json()) as {
        applications?: CandidateApplication[];
      };
      setApplications(data.applications ?? []);
    } catch {
      setApplicationStatus(
        'Your applications are temporarily unreachable. Check your connection and retry.',
      );
    }
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      void Promise.all([loadProfile(), loadApplications()]);
    }, 0);
    return () => window.clearTimeout(timer);
  }, [loadApplications, loadProfile]);
  useEffect(() => {
    const timer = window.setTimeout(() => {
      void loadJobs();
    }, 0);
    return () => window.clearTimeout(timer);
  }, [loadJobs]);

  const visibleJobs = useMemo(
    () =>
      availableJobs.filter((job) => {
        const terms = query.trim().toLowerCase();
        const place = locationQuery.trim().toLowerCase();
        return (
          (!terms ||
            `${job.title} ${job.company} ${job.criteria.map((criterion) => criterion.label).join(' ')}`
              .toLowerCase()
              .includes(terms)) &&
          (!place ||
            `${job.location} ${job.mode}`.toLowerCase().includes(place))
        );
      }),
    [availableJobs, locationQuery, query],
  );
  const selected =
    availableJobs.find((job) => job.id === selectedId) ??
    availableJobs[0] ??
    null;
  const appliedJobIds = useMemo(
    () => new Set(applications.map((application) => application.jobId)),
    [applications],
  );

  async function applyForSelectedJob() {
    if (!selected || appliedJobIds.has(selected.id)) return;
    setApplicationStatus('Submitting your profile…');
    try {
    const response = await authenticatedFetch('/api/applications', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ jobId: selected.id }),
    });
    const result = (await response.json()) as { error?: string };
    if (!response.ok) {
      setApplicationStatus(
        result.error ?? 'We could not submit this application.',
      );
      return;
    }
    await loadApplications();
    setApplicationStatus(
      'Application submitted. You can track it in My applications.',
    );
    } catch {
      setApplicationStatus('The application service could not be reached. Check My applications before retrying.');
    }
  }

  async function withdrawApplication(applicationId: string) {
    if (
      !window.confirm(
        'Withdraw this application? The employer will see that you are no longer participating.',
      )
    )
      return;
    setApplicationStatus('Withdrawing application…');
    try {
    const response = await authenticatedFetch('/api/applications', {
      method: 'PATCH',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ applicationId, status: 'withdrawn' }),
    });
    const result = (await response.json()) as { error?: string };
    if (!response.ok) {
      setApplicationStatus(
        result.error ?? 'This application could not be withdrawn.',
      );
      return;
    }
    await loadApplications();
    setApplicationStatus('Application withdrawn.');
    } catch {
      setApplicationStatus('The withdrawal could not be confirmed. Check your connection and retry.');
    }
  }

  async function requestInterviewChange(
    event: SyntheticEvent<HTMLFormElement>,
  ) {
    event.preventDefault();
    if (!changeRequestApplication?.interviewSessionId) return;
    const form = new FormData(event.currentTarget);
    setChangeRequestBusy(true);
    try {
    const response = await authenticatedFetch('/api/interviews', {
      method: 'PATCH',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        sessionId: changeRequestApplication.interviewSessionId,
        action: 'request_reschedule',
        note: form.get('note'),
      }),
    });
    const result = (await response.json()) as { error?: string };
    setChangeRequestBusy(false);
    if (!response.ok) {
      setApplicationStatus(result.error ?? 'Your request could not be sent.');
      return;
    }
    setChangeRequestApplication(null);
    await loadApplications();
    setApplicationStatus(
      'Your interview time-change request is now visible to the employer.',
    );
    } catch {
      setApplicationStatus('Your request could not be sent. Check your connection and retry.');
    } finally {
      setChangeRequestBusy(false);
    }
  }

  async function saveProfile() {
    if (!profileReady || resumeImporting || profileSavingRef.current) return;
    profileSavingRef.current = true;
    setProfileSaving(true);
    try {
    setProfileStatus('Saving your evidence profile…');
    const normalizedSkills = skillsInput
      .split(',')
      .map((value) => value.trim())
      .filter(Boolean)
      .slice(0, 30);
    const result = await persistProfile(
      { ...profile, skills: normalizedSkills },
      experiences,
      education,
      projects,
    );
    if (!result.ok) {
      setProfileStatus(result.error);
      return;
    }
    setProfile((current) => ({ ...current, skills: normalizedSkills }));
    await loadProfile();
    setProfileStatus(
      'Profile saved. Your job fit explanations have been refreshed.',
    );
    } finally {
      profileSavingRef.current = false;
      setProfileSaving(false);
    }
  }

  async function persistProfile(
    nextProfile: Profile,
    nextExperiences: Experience[],
    nextEducation: Education[],
    nextProjects: Project[],
  ) {
    try {
      const response = await authenticatedFetch('/api/candidate/profile', {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          ...nextProfile,
          experiences: nextExperiences,
          education: nextEducation,
          projects: nextProjects,
        }),
      });
      const result = (await response.json().catch(() => ({}))) as {
        error?: string;
      };
      return {
        ok: response.ok,
        error: result.error ?? 'Could not save your profile.',
      };
    } catch {
      return {
        ok: false,
        error:
          'The profile service could not be reached. Your résumé file is safe; retry the import when the connection returns.',
      };
    }
  }

  async function uploadResume(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!profileReady || resumeImporting || profileSavingRef.current) {
      event.target.value = '';
      setProfileStatus(
        'Your profile is still loading. Please try the upload again in a moment.',
      );
      return;
    }
    setResumeImporting(true);
    setProfileStatus('Reading and uploading your résumé securely…');
    let extractedText = '';
    try {
      extractedText = await extractResumeText(file);
    } catch {
      setProfileStatus(
        'The résumé can be stored, but its text could not be read. Try a text-based PDF or DOCX file.',
      );
    }
    const imported = parseResumeProfile(extractedText);
    const form = new FormData();
    form.set('resume', file);
    form.set('extractedText', extractedText);
    let response: Response;
    let result: {
      error?: string;
      id?: string;
      filename?: string;
      sizeBytes?: number;
      textExtracted?: boolean;
      textLength?: number;
    };
    try {
      response = await authenticatedFetch('/api/candidate/resume', {
        method: 'POST',
        body: form,
      });
      result = (await response.json().catch(() => ({}))) as typeof result;
    } catch {
      event.target.value = '';
      setProfileStatus(
        'Your résumé could not be uploaded because the service is unreachable. Check your connection and try again.',
      );
      setResumeImporting(false);
      return;
    }
    event.target.value = '';
    if (!response.ok) {
      setProfileStatus(result.error ?? 'Could not upload your résumé.');
      setResumeImporting(false);
      return;
    }
    setResume({
      id: String(result.id),
      filename: String(result.filename),
      sizeBytes: Number(result.sizeBytes),
    });
    const nextProfile: Profile = {
      ...profile,
      fullName: imported.fullName || profile.fullName,
      phone: imported.phone || profile.phone,
      headline: imported.headline || profile.headline,
      summary: imported.summary || profile.summary,
      location: imported.location || profile.location,
      skills: imported.skills.length
        ? uniqueSkills(imported.skills)
        : profile.skills,
      resumeText: result.textExtracted ? extractedText : '',
      resumeTextExtracted: result.textExtracted === true,
    };
    const nextSkills = nextProfile.skills.slice(0, 30);
    const nextExperiences =
      imported.detectedSections.experience && imported.experiences.length
        ? imported.experiences
        : experiences;
    const nextEducation =
      imported.detectedSections.education && imported.education.length
        ? imported.education
        : education;
    const nextProjects =
      imported.detectedSections.projects && imported.projects.length
        ? imported.projects
        : projects;
    setProfile(nextProfile);
    setSkillsInput(nextSkills.join(', '));
    setExperiences(nextExperiences);
    setEducation(nextEducation);
    setProjects(nextProjects);
    setActiveView('profile');
    const importedFields = [
      imported.fullName,
      imported.phone,
      imported.headline,
      imported.summary,
      imported.location,
    ].filter(Boolean).length;
    setResumeImportReport(
      result.textExtracted
        ? {
            fields: importedFields,
            skills: imported.skills.length,
            experiences: imported.experiences.length,
            education: imported.education.length,
            projects: imported.projects.length,
            warnings: imported.warnings,
          }
        : null,
    );
    const importedCount =
      importedFields +
      nextSkills.length +
      imported.experiences.length +
      imported.education.length +
      imported.projects.length;
    if (!result.textExtracted) {
      setProfileStatus(
        'Résumé uploaded, but readable text was not found. If it is a scanned file, add the important evidence to your profile.',
      );
      setResumeImporting(false);
      return;
    }
    setProfileStatus(
      `Résumé parsed into ${importedCount} structured profile items. Saving the imported sections…`,
    );
    const saved = await persistProfile(
      { ...nextProfile, skills: nextSkills },
      nextExperiences,
      nextEducation,
      nextProjects,
    );
    if (!saved.ok) {
      setProfileStatus(
        `Your résumé was uploaded, but the imported sections were not saved: ${saved.error}`,
      );
      setResumeImporting(false);
      return;
    }
    const verified = await loadProfile();
    const workSaved =
      !imported.detectedSections.experience ||
      (verified?.experiences.length ?? 0) === nextExperiences.length;
    const educationSaved =
      !imported.detectedSections.education ||
      (verified?.education.length ?? 0) === nextEducation.length;
    const projectsSaved =
      !imported.detectedSections.projects ||
      (verified?.projects.length ?? 0) === nextProjects.length;
    setProfileStatus(
      workSaved && educationSaved && projectsSaved
        ? `Résumé imported and saved: ${imported.experiences.length} work, ${imported.education.length} education, ${imported.projects.length} project entries, and ${nextSkills.length} skills.`
        : 'The résumé was parsed, but one or more sections did not pass the save verification. Please replace the résumé and try again.',
    );
    setResumeImporting(false);
  }

  return (
    <main className="candidate-page min-h-screen">
      <header className="candidate-header">
        <div className="flex items-center gap-3">
          <Link href="/" className="candidate-brand">
            <span className="candidate-brand-mark">h</span>
            <span>hiremind</span>
          </Link>
          <span className="candidate-role-label">
            <GraduationCap /> Candidate portal
          </span>
        </div>
        <nav className="candidate-nav" aria-label="Candidate navigation">
          <button
            onClick={() => setActiveView('jobs')}
            aria-pressed={activeView === 'jobs'}
          >
            Discover jobs
          </button>
          <button
            onClick={() => setActiveView('applications')}
            aria-pressed={activeView === 'applications'}
          >
            My applications{' '}
            {applications.length ? <b>{applications.length}</b> : null}
          </button>
          <button
            onClick={() => setActiveView('profile')}
            aria-pressed={activeView === 'profile'}
          >
            My profile
          </button>
        </nav>
        <div className="flex items-center gap-2">
          <Link href="/company" className="candidate-workspace-switch">
            <Building2 /> Employer workspace
          </Link>
          <SignOutButton
            title={`${userEmail} · Sign out`}
            className="candidate-account-chip"
          >
            <Avatar size="sm">
              <AvatarFallback>{initials(profile.fullName)}</AvatarFallback>
            </Avatar>
            <span>Sign out</span>
          </SignOutButton>
        </div>
      </header>

      <div className="candidate-content">
        <section className="candidate-profile-progress">
          <div>
            <span>
              <UserRound />
            </span>
            <div>
              <strong>Your evidence profile is {completion}% complete</strong>
              <small>
                Complete profiles produce clearer, more defensible matches.
              </small>
            </div>
          </div>
          <Progress
            value={completion}
            className="[&_[data-slot=progress-indicator]]:bg-[#866a81]"
          />
          <Button variant="outline" onClick={() => setActiveView('profile')}>
            {completion < 100 ? 'Complete profile' : 'Review profile'}{' '}
            <ArrowRight />
          </Button>
        </section>

        {activeView === 'jobs' ? (
          <>
            <section className="candidate-welcome">
              <div>
                <Badge variant="outline">
                  <Sparkles /> Evidence-based discovery
                </Badge>
                <h1>Find work that sees what you can do.</h1>
                <p>
                  Matches are explained using your skills, projects, education,
                  and work—not job-title keywords alone.
                </p>
              </div>
              <Card className="profile-mode-card py-0 ring-0">
                <CardContent className="p-5">
                  <p className="text-xs font-semibold uppercase tracking-[.08em] text-muted-foreground">
                    Profile lens
                  </p>
                  <strong className="mt-3 block text-lg">
                    {titleCase(profile.profileType)}
                  </strong>
                  <p className="mt-2 text-xs leading-5 text-muted-foreground">
                    {profile.profileType === 'fresher'
                      ? 'Projects, education, internships, and transferable skills are prioritized.'
                      : profile.profileType === 'returner'
                        ? 'Career gaps are not penalties; recent evidence and transferable capability matter.'
                        : 'Work outcomes, projects, and demonstrated skills are connected to each criterion.'}
                  </p>
                </CardContent>
              </Card>
            </section>
            <section className="candidate-search-row">
              <Search />
              <input
                aria-label="Search by role, skill, or company"
                placeholder="Role, skill or company"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
              />
              <MapPin />
              <input
                aria-label="Search by city or remote"
                placeholder="City or remote"
                value={locationQuery}
                onChange={(event) => setLocationQuery(event.target.value)}
              />
            </section>
            <div className="candidate-jobs-layout">
              <section>
                <div className="candidate-section-heading">
                  <div>
                    <strong>Open opportunities</strong>
                    <small>
                      {visibleJobs.length} roles · ranked only when criteria are
                      available
                    </small>
                  </div>
                </div>
                <div className="space-y-3">
                  {loadingJobs ? (
                    <div className="candidate-empty">Loading open roles…</div>
                  ) : (
                    visibleJobs.map((job) => (
                      <button
                        key={job.id}
                        className={`job-result ${selected?.id === job.id ? 'job-result-active' : ''}`}
                        onClick={() => setSelectedId(job.id)}
                      >
                        <span className="company-monogram bg-[#eee6f0] text-[#5b4863]">
                          {job.initials}
                        </span>
                        <span className="min-w-0 flex-1 text-left">
                          <strong>{job.title}</strong>
                          <small>
                            {job.company} · {job.location}
                          </small>
                          <em>
                            {job.type} · {job.mode} · {job.posted}
                          </em>
                        </span>
                        <span className="job-match">
                          {job.match === null ? (
                            <>
                              <strong>—</strong>
                              <small>criteria pending</small>
                            </>
                          ) : (
                            <>
                              <strong>{job.match}%</strong>
                              <small>profile evidence</small>
                            </>
                          )}
                        </span>
                        <ChevronRight />
                      </button>
                    ))
                  )}
                  {!loadingJobs && visibleJobs.length === 0 ? (
                    <div className="candidate-empty">
                      No roles match this search yet.
                    </div>
                  ) : null}
                </div>
              </section>
              {selected ? (
                <aside className="job-detail-panel">
                  <div className="flex items-start gap-3">
                    <span className="company-monogram size-12 bg-[#eee6f0] text-[#5b4863]">
                      {selected.initials}
                    </span>
                    <div>
                      <h2>{selected.title}</h2>
                      <p>{selected.company}</p>
                    </div>
                  </div>
                  <div className="mt-5 flex flex-wrap gap-2">
                    <Badge variant="outline">
                      <MapPin /> {selected.location}
                    </Badge>
                    <Badge variant="outline">
                      <Building2 /> {selected.mode}
                    </Badge>
                    <Badge variant="outline">
                      <BriefcaseBusiness /> {selected.type}
                    </Badge>
                  </div>
                  <p className="mt-6 text-sm leading-6 text-muted-foreground">
                    {selected.summary}
                  </p>
                  <div className="match-explanation">
                    <div className="flex items-center justify-between">
                      <div>
                        <strong>Why this may fit</strong>
                        <small>Transparent evidence comparison</small>
                      </div>
                      <b>
                        {selected.match === null
                          ? 'Not scored'
                          : `${selected.match}%`}
                      </b>
                    </div>
                    {selected.match !== null ? (
                      <Progress
                        value={selected.match}
                        className="mt-4 [&_[data-slot=progress-indicator]]:bg-[#9a7c8f]"
                      />
                    ) : null}
                    <div className="candidate-criteria-list">
                      {selected.criteria.length ? (
                        selected.criteria.map((criterion) => (
                          <div key={criterion.id}>
                            <span
                              className={
                                selected.matchedCriteria.includes(
                                  criterion.label,
                                )
                                  ? 'is-match'
                                  : ''
                              }
                            >
                              {selected.matchedCriteria.includes(
                                criterion.label,
                              ) ? (
                                <Check />
                              ) : (
                                <Sparkles />
                              )}
                            </span>
                            <div>
                              <strong>{criterion.label}</strong>
                              <small>{criterion.evidenceDefinition}</small>
                            </div>
                          </div>
                        ))
                      ) : (
                        <p>
                          The employer has not published detailed evidence
                          criteria for this role, so HireMind will not invent a
                          fit score.
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="mt-6 border-t pt-5">
                    <Button
                      className="w-full bg-[#2b2233] text-white"
                      onClick={applyForSelectedJob}
                      disabled={appliedJobIds.has(selected.id)}
                    >
                      {appliedJobIds.has(selected.id)
                        ? 'Already applied'
                        : 'Apply with evidence profile'}{' '}
                      <ArrowRight />
                    </Button>
                    {applicationStatus ? (
                      <p className="login-status">{applicationStatus}</p>
                    ) : null}
                    <p className="mt-3 text-center text-[11px] text-muted-foreground">
                      <CircleCheck className="mr-1 inline size-3" /> Your
                      current profile is snapshotted for a fair audit trail.
                    </p>
                  </div>
                </aside>
              ) : null}
            </div>
          </>
        ) : null}

        {activeView === 'applications' ? (
          <section className="candidate-view-section">
            <div className="candidate-page-title">
              <Badge variant="outline">Private to you</Badge>
              <h1>My applications</h1>
              <p>
                Track decisions, screening explanations, and interviews without
                chasing email threads.
              </p>
            </div>
            <div className="candidate-application-grid">
              {applications.map((application) => {
                const interview = getCandidateInterviewPresentation(
                  application.interviewStatus,
                  application.interviewScheduledAt,
                  application.interviewMode ?? 'structured_screening',
                );
                return (
                  <article
                    key={application.id}
                    className="candidate-application-card"
                  >
                    <div className="flex items-start gap-3">
                      <span className="company-monogram bg-[#eee6f0] text-[#5b4863]">
                        {initials(application.companyName)}
                      </span>
                      <div className="min-w-0 flex-1">
                        <h2>{application.jobTitle}</h2>
                        <p>{application.companyName}</p>
                      </div>
                      <Badge>{titleCase(application.status)}</Badge>
                    </div>
                    <div className="candidate-stage-track">
                      {[
                        'Submitted',
                        'Review',
                        'Shortlist',
                        'Interview',
                        'Decision',
                      ].map((stage, index) => (
                        <span
                          key={stage}
                          className={
                            stageReached(application, index) ? 'is-reached' : ''
                          }
                        >
                          <i />
                          {stage}
                        </span>
                      ))}
                    </div>
                    {application.screeningExplanation ? (
                      <div className="candidate-screening-note">
                        <Sparkles />
                        <div>
                          <strong>
                            {application.fitScore}% evidence fit ·{' '}
                            {titleCase(application.decisionBand ?? '')}
                          </strong>
                          <p>{application.screeningExplanation}</p>
                        </div>
                      </div>
                    ) : (
                      <div className="candidate-screening-note">
                        <FileText />
                        <div>
                          <strong>Evidence review pending</strong>
                          <p>
                            No score is shown until the employer runs a
                            criteria-based review.
                          </p>
                        </div>
                      </div>
                    )}
                    {application.interviewSessionId ? (
                      <div className="candidate-interview-callout">
                        <CalendarClock />
                        <div>
                          <strong>{interview.title}</strong>
                          <p>
                            {application.interviewScheduledAt
                              ? new Date(
                                  application.interviewScheduledAt,
                                ).toLocaleString()
                              : 'Ready when the employer confirms the time'}
                          </p>
                          {application.interviewScheduledAt ? <InterviewCalendarDownload sessionId={application.interviewSessionId} /> : null}
                          {application.interviewStatus === 'scheduled' ? (
                            <small>
                              {application.interviewMode === 'live_video'
                                ? '1:1 live video · preparation can be opened now'
                                : 'Self-paced structured screening · preparation can be opened now'}
                            </small>
                          ) : null}
                        </div>
                        {interview.actionLabel ? (
                          <a
                            className={cn(
                              buttonVariants({ size: 'sm' }),
                              'candidate-interview-action',
                            )}
                            href={`/interview?id=${encodeURIComponent(application.interviewSessionId)}&view=candidate`}
                          >
                            {interview.actionLabel} <ArrowRight />
                          </a>
                        ) : null}
                        {application.interviewStatus === 'scheduled' ? (
                          <button
                            type="button"
                            className="candidate-interview-change"
                            onClick={() =>
                              setChangeRequestApplication(application)
                            }
                          >
                            Request another time
                          </button>
                        ) : null}
                      </div>
                    ) : null}
                    {application.timeline?.length ? (
                      <div className="candidate-application-timeline">
                        <h3>
                          <Clock3 /> Application timeline
                        </h3>
                        {application.timeline
                          .slice(-6)
                          .reverse()
                          .map((event) => (
                            <article key={event.id}>
                              <i />
                              <span>
                                <strong>{candidateEventLabel(event)}</strong>
                                {event.note ? (
                                  <small>{event.note}</small>
                                ) : null}
                              </span>
                              <time>
                                {new Date(event.occurredAt).toLocaleString()}
                              </time>
                            </article>
                          ))}
                      </div>
                    ) : null}
                    {!['rejected', 'withdrawn', 'hired'].includes(
                      application.status,
                    ) ? (
                      <div className="candidate-application-actions">
                        <Button
                          variant="ghost"
                          onClick={() => withdrawApplication(application.id)}
                        >
                          Withdraw application
                        </Button>
                      </div>
                    ) : null}
                  </article>
                );
              })}
              {!applications.length ? (
                <div className="candidate-empty">
                  No applications yet. Discover a role and apply with your
                  profile.
                </div>
              ) : null}
            </div>
            {applicationStatus ? (
              <p className="login-status">{applicationStatus}</p>
            ) : null}
          </section>
        ) : null}

        {activeView === 'profile' ? (
          <section className="candidate-view-section">
            <div className="candidate-page-title">
              <Badge variant="outline">Reusable evidence profile</Badge>
              <h1>Tell the full story of your capability.</h1>
              <p>
                Enter information once. HireMind reuses it across applications
                while preserving a dated snapshot.
              </p>
            </div>
            <div className="candidate-profile-layout">
              <div className="candidate-profile-form">
                <ProfileSection
                  title="About you"
                  description="The essentials employers need to understand your direction."
                >
                  <div className="candidate-form-grid">
                    <Field label="Full name">
                      <Input
                        value={profile.fullName}
                        onChange={(event) =>
                          setProfile({
                            ...profile,
                            fullName: event.target.value,
                          })
                        }
                      />
                    </Field>
                    <Field label="Profile type">
                      <select
                        value={profile.profileType}
                        onChange={(event) =>
                          setProfile({
                            ...profile,
                            profileType: event.target.value,
                          })
                        }
                      >
                        <option value="fresher">Fresher / student</option>
                        <option value="experienced">Experienced</option>
                        <option value="returner">Returning to work</option>
                      </select>
                    </Field>
                    <Field label="Professional headline">
                      <Input
                        value={profile.headline}
                        onChange={(event) =>
                          setProfile({
                            ...profile,
                            headline: event.target.value,
                          })
                        }
                        placeholder="Product analyst · SQL · customer insights"
                      />
                    </Field>
                    <Field label="Location">
                      <Input
                        value={profile.location}
                        onChange={(event) =>
                          setProfile({
                            ...profile,
                            location: event.target.value,
                          })
                        }
                      />
                    </Field>
                    <Field label="Phone">
                      <Input
                        value={profile.phone}
                        onChange={(event) =>
                          setProfile({ ...profile, phone: event.target.value })
                        }
                      />
                    </Field>
                    <Field label="Availability">
                      <Input
                        value={profile.availability}
                        onChange={(event) =>
                          setProfile({
                            ...profile,
                            availability: event.target.value,
                          })
                        }
                        placeholder="Immediate / 30 days"
                      />
                    </Field>
                    <Field label="Work authorization">
                      <Input
                        value={profile.workAuthorization}
                        onChange={(event) =>
                          setProfile({
                            ...profile,
                            workAuthorization: event.target.value,
                          })
                        }
                        placeholder="e.g. Authorized to work in India"
                      />
                    </Field>
                  </div>
                  <Field label="Profile summary">
                    <Textarea
                      rows={5}
                      value={profile.summary}
                      onChange={(event) =>
                        setProfile({ ...profile, summary: event.target.value })
                      }
                      placeholder="Focus on outcomes, strengths, and the kind of problems you want to solve."
                    />
                  </Field>
                  <Field label="Skills (comma separated)">
                    <Input
                      value={skillsInput}
                      onChange={(event) => setSkillsInput(event.target.value)}
                      placeholder="SQL, research, Figma, stakeholder communication"
                    />
                  </Field>
                </ProfileSection>

                <ProfileSection
                  title="Work history"
                  description={
                    profile.profileType === 'fresher'
                      ? 'Optional for freshers. Internships and volunteering count.'
                      : 'Describe outcomes, not only responsibilities.'
                  }
                  action={
                    <Button
                      variant="outline"
                      onClick={() =>
                        setExperiences([...experiences, emptyExperience()])
                      }
                    >
                      <Plus /> Add experience
                    </Button>
                  }
                >
                  {experiences.map((item, index) => (
                    <EvidenceEditor
                      key={index}
                      onRemove={() =>
                        setExperiences(
                          experiences.filter(
                            (_, itemIndex) => itemIndex !== index,
                          ),
                        )
                      }
                    >
                      <div className="candidate-form-grid">
                        <Field label="Role">
                          <Input
                            value={item.title}
                            onChange={(event) =>
                              setExperiences(
                                updateAt(experiences, index, {
                                  ...item,
                                  title: event.target.value,
                                }),
                              )
                            }
                          />
                        </Field>
                        <Field label="Organization">
                          <Input
                            value={item.organizationName}
                            onChange={(event) =>
                              setExperiences(
                                updateAt(experiences, index, {
                                  ...item,
                                  organizationName: event.target.value,
                                }),
                              )
                            }
                          />
                        </Field>
                        <Field label="Started">
                          <Input
                            type="month"
                            value={item.startedOn}
                            onChange={(event) =>
                              setExperiences(
                                updateAt(experiences, index, {
                                  ...item,
                                  startedOn: event.target.value,
                                }),
                              )
                            }
                          />
                        </Field>
                        <Field label="Ended">
                          <Input
                            type="month"
                            value={item.endedOn}
                            disabled={item.isCurrent}
                            onChange={(event) =>
                              setExperiences(
                                updateAt(experiences, index, {
                                  ...item,
                                  endedOn: event.target.value,
                                }),
                              )
                            }
                          />
                        </Field>
                      </div>
                      <label className="candidate-checkbox">
                        <input
                          type="checkbox"
                          checked={item.isCurrent}
                          onChange={(event) =>
                            setExperiences(
                              updateAt(experiences, index, {
                                ...item,
                                isCurrent: event.target.checked,
                                endedOn: event.target.checked
                                  ? ''
                                  : item.endedOn,
                              }),
                            )
                          }
                        />{' '}
                        I currently work here
                      </label>
                      <Field label="What did you achieve?">
                        <Textarea
                          rows={3}
                          value={item.description}
                          onChange={(event) =>
                            setExperiences(
                              updateAt(experiences, index, {
                                ...item,
                                description: event.target.value,
                              }),
                            )
                          }
                        />
                      </Field>
                    </EvidenceEditor>
                  ))}
                  {!experiences.length ? (
                    <EmptyEvidence text="No work history added. This will not block a fresher profile." />
                  ) : null}
                </ProfileSection>

                <ProfileSection
                  title="Education"
                  description="Degrees, diplomas, bootcamps, and substantial learning programs."
                  action={
                    <Button
                      variant="outline"
                      onClick={() =>
                        setEducation([...education, emptyEducation()])
                      }
                    >
                      <Plus /> Add education
                    </Button>
                  }
                >
                  {education.map((item, index) => (
                    <EvidenceEditor
                      key={index}
                      onRemove={() =>
                        setEducation(
                          education.filter(
                            (_, itemIndex) => itemIndex !== index,
                          ),
                        )
                      }
                    >
                      <div className="candidate-form-grid">
                        <Field label="Institution">
                          <Input
                            value={item.institution}
                            onChange={(event) =>
                              setEducation(
                                updateAt(education, index, {
                                  ...item,
                                  institution: event.target.value,
                                }),
                              )
                            }
                          />
                        </Field>
                        <Field label="Qualification">
                          <Input
                            value={item.qualification}
                            onChange={(event) =>
                              setEducation(
                                updateAt(education, index, {
                                  ...item,
                                  qualification: event.target.value,
                                }),
                              )
                            }
                          />
                        </Field>
                        <Field label="Field of study">
                          <Input
                            value={item.fieldOfStudy}
                            onChange={(event) =>
                              setEducation(
                                updateAt(education, index, {
                                  ...item,
                                  fieldOfStudy: event.target.value,
                                }),
                              )
                            }
                          />
                        </Field>
                        <Field label="Started">
                          <Input
                            type="month"
                            value={item.startedOn}
                            onChange={(event) =>
                              setEducation(
                                updateAt(education, index, {
                                  ...item,
                                  startedOn: event.target.value,
                                }),
                              )
                            }
                          />
                        </Field>
                        <Field label="Completed / expected">
                          <Input
                            type="month"
                            value={item.endedOn}
                            onChange={(event) =>
                              setEducation(
                                updateAt(education, index, {
                                  ...item,
                                  endedOn: event.target.value,
                                }),
                              )
                            }
                          />
                        </Field>
                      </div>
                    </EvidenceEditor>
                  ))}
                  {!education.length ? (
                    <EmptyEvidence text="No education added yet." />
                  ) : null}
                </ProfileSection>

                <ProfileSection
                  title="Projects and proof of work"
                  description="Especially valuable for freshers and career changers."
                  action={
                    <Button
                      variant="outline"
                      onClick={() => setProjects([...projects, emptyProject()])}
                    >
                      <Plus /> Add project
                    </Button>
                  }
                >
                  {projects.map((item, index) => (
                    <EvidenceEditor
                      key={index}
                      onRemove={() =>
                        setProjects(
                          projects.filter(
                            (_, itemIndex) => itemIndex !== index,
                          ),
                        )
                      }
                    >
                      <Field label="Project title">
                        <Input
                          value={item.title}
                          onChange={(event) =>
                            setProjects(
                              updateAt(projects, index, {
                                ...item,
                                title: event.target.value,
                              }),
                            )
                          }
                        />
                      </Field>
                      <Field label="Problem, contribution, and outcome">
                        <Textarea
                          rows={4}
                          value={item.description}
                          onChange={(event) =>
                            setProjects(
                              updateAt(projects, index, {
                                ...item,
                                description: event.target.value,
                              }),
                            )
                          }
                        />
                      </Field>
                      <div className="candidate-form-grid">
                        <Field label="Project link">
                          <Input
                            value={item.projectUrl}
                            onChange={(event) =>
                              setProjects(
                                updateAt(projects, index, {
                                  ...item,
                                  projectUrl: event.target.value,
                                }),
                              )
                            }
                          />
                        </Field>
                        <Field label="Repository link">
                          <Input
                            value={item.repositoryUrl}
                            onChange={(event) =>
                              setProjects(
                                updateAt(projects, index, {
                                  ...item,
                                  repositoryUrl: event.target.value,
                                }),
                              )
                            }
                          />
                        </Field>
                        <Field label="Skills used">
                          <Input
                            value={item.skills.join(', ')}
                            onChange={(event) =>
                              setProjects(
                                updateAt(projects, index, {
                                  ...item,
                                  skills: event.target.value
                                    .split(',')
                                    .map((value) => value.trim())
                                    .filter(Boolean),
                                }),
                              )
                            }
                          />
                        </Field>
                      </div>
                    </EvidenceEditor>
                  ))}
                  {!projects.length ? (
                    <EmptyEvidence text="No projects added yet." />
                  ) : null}
                </ProfileSection>
              </div>
              <aside className="candidate-profile-side">
                <Card className="py-0">
                  <CardContent className="p-5">
                    <div className="flex items-center justify-between">
                      <strong>Profile completion</strong>
                      <b>{completion}%</b>
                    </div>
                    <Progress
                      value={completion}
                      className="mt-4 [&_[data-slot=progress-indicator]]:bg-[#866a81]"
                    />
                    <p className="mt-3 text-xs leading-5 text-muted-foreground">
                      Completion measures evidence coverage, not candidate
                      quality.
                    </p>
                    {qualityWarnings.length > 0 && (
                      <section aria-label="Imported profile details needing review" className="mt-3 rounded-xl bg-amber-50 p-3 text-sm text-amber-950">
                        <strong>Review imported details</strong>
                        <ul className="mt-2 list-disc space-y-2 pl-4">
                          {qualityWarnings.map((warning) => <li key={warning}>{warning}</li>)}
                        </ul>
                        <p className="mt-2">Your saved details have not been changed. Correct these fields, or replace and parse your résumé again, then review before saving.</p>
                      </section>
                    )}
                  </CardContent>
                </Card>
                <Card className="py-0">
                  <CardContent className="p-5">
                    <span className="profile-side-icon">
                      <UploadCloud />
                    </span>
                    <h2>Résumé</h2>
                    <p>PDF, DOC, or DOCX · maximum 5 MB</p>
                    {resume ? (
                      <AuthenticatedFileLink
                        className="candidate-resume-file"
                        fileId={resume.id}
                        filename={resume.filename}
                      >
                        <FileText />
                        <span>
                          <strong>{resume.filename}</strong>
                          <small>{formatBytes(resume.sizeBytes)}</small>
                        </span>
                      </AuthenticatedFileLink>
                    ) : (
                      <div className="candidate-resume-empty">
                        No résumé uploaded
                      </div>
                    )}
                    {resume ? (
                      <div
                        className={`candidate-resume-extraction ${profile.resumeTextExtracted ? 'is-ready' : ''}`}
                      >
                        {profile.resumeTextExtracted ? <Check /> : <Sparkles />}
                        <span>
                          {profile.resumeTextExtracted
                            ? 'Structured résumé text is ready'
                            : 'No readable text—add evidence manually or upload a text-based file'}
                        </span>
                      </div>
                    ) : null}
                    {resumeImportReport ? (
                      <ResumeImportSummary report={resumeImportReport} />
                    ) : null}
                    <input
                      ref={resumeInput}
                      type="file"
                      className="sr-only"
                      accept=".pdf,.doc,.docx"
                      onChange={uploadResume}
                    />
                    <Button
                      variant="outline"
                      className="mt-3 w-full"
                      disabled={!profileReady || resumeImporting || profileSaving}
                      onClick={() => resumeInput.current?.click()}
                    >
                      {resumeImporting
                        ? 'Importing and saving…'
                        : resume
                          ? 'Replace and parse résumé'
                          : 'Upload and parse résumé'}
                    </Button>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="space-y-3 p-6">
                    <h3>Future opportunities</h3>
                    <label className="flex items-start gap-3 text-sm" htmlFor="future-role-consent">
                      <Checkbox id="future-role-consent" checked={profile.futureRoleConsent}
                        disabled={!profileReady || profileSaving || resumeImporting}
                        onCheckedChange={(checked) => setProfile((current) => ({ ...current, futureRoleConsent: checked === true }))} />
                      Let employers I have applied to consider my submitted profile for other roles.
                    </label>
                    <p className="text-sm text-muted-foreground">Only applications from the past 12 months are included. No new application is created. Turn this off and save to leave future-role searches; existing applications stay unchanged.</p>
                  </CardContent>
                </Card>
                <Button
                  className="w-full bg-[#2b2233] text-white"
                  onClick={saveProfile}
                  disabled={!profileReady || resumeImporting || profileSaving}
                >
                  <Save /> {profileSaving ? 'Saving…' : 'Save profile'}
                </Button>
                {profileStatus ? (
                  <p className="login-status">{profileStatus}</p>
                ) : null}
                {!profileReady && <Button variant="outline" onClick={() => void loadProfile()}>Retry loading profile</Button>}
              </aside>
            </div>
          </section>
        ) : null}
      </div>
      <Dialog
        open={Boolean(changeRequestApplication)}
        onOpenChange={(open) => !open && setChangeRequestApplication(null)}
      >
        <DialogContent className="max-w-md border-[#d9ceda] bg-[#fffdf9] sm:rounded-[24px]">
          <DialogHeader>
            <DialogTitle>Request another interview time</DialogTitle>
            <DialogDescription>
              Share your availability clearly. The interview stays scheduled
              until the employer confirms a new time.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={requestInterviewChange} className="space-y-4">
            <label
              htmlFor="candidate-change-request"
              className="grid gap-2 text-sm font-medium"
            >
              Timing note
              <Textarea
                id="candidate-change-request"
                name="note"
                required
                minLength={5}
                maxLength={700}
                rows={5}
                placeholder="Share two or three time windows and your time zone."
              />
            </label>
            <Button
              disabled={changeRequestBusy}
              className="w-full bg-[#2b2233] text-white"
            >
              <MessageSquareText />{' '}
              {changeRequestBusy
                ? 'Sending request…'
                : 'Send time-change request'}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </main>
  );
}

function ProfileSection({
  title,
  description,
  action,
  children,
}: {
  title: string;
  description: string;
  action?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section className="candidate-profile-section">
      <div className="candidate-profile-section-head">
        <div>
          <h2>{title}</h2>
          <p>{description}</p>
        </div>
        {action}
      </div>
      <div className="space-y-4">{children}</div>
    </section>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="candidate-field">
      <span>{label}</span>
      {children}
    </label>
  );
}
function EvidenceEditor({
  onRemove,
  children,
}: {
  onRemove: () => void;
  children: React.ReactNode;
}) {
  return (
    <div className="candidate-evidence-editor">
      <Button
        variant="ghost"
        size="icon"
        onClick={onRemove}
        aria-label="Remove entry"
      >
        <Trash2 />
      </Button>
      {children}
    </div>
  );
}
function EmptyEvidence({ text }: { text: string }) {
  return <div className="candidate-evidence-empty">{text}</div>;
}
function ResumeImportSummary({ report }: { report: ResumeImportReport }) {
  const items = [
    { label: 'Profile fields', value: report.fields },
    { label: 'Skills', value: report.skills },
    { label: 'Work entries', value: report.experiences },
    { label: 'Education', value: report.education },
    { label: 'Projects', value: report.projects },
  ];
  return (
    <div className="resume-import-summary">
      <strong>Imported from this résumé</strong>
      <div>
        {items.map((item) => (
          <span key={item.label}>
            <b>{item.value}</b>
            {item.label}
          </span>
        ))}
      </div>
      {report.warnings.length ? (
        <ul>
          {report.warnings.map((warning) => (
            <li key={warning}>{warning}</li>
          ))}
        </ul>
      ) : (
        <em>
          <Check /> All detected sections were structured successfully.
        </em>
      )}
      <small>
        The imported fields are saved automatically. Review and edit them before
        applying; résumé evidence remains self-attested until verified.
      </small>
    </div>
  );
}

function updateAt<T>(items: T[], index: number, value: T) {
  return items.map((item, itemIndex) => (itemIndex === index ? value : item));
}
function buildEvidenceText(
  profile: Profile,
  experiences: Experience[],
  education: Education[],
  projects: Project[],
) {
  return [
    profile.headline,
    profile.summary,
    profile.location,
    profile.resumeText,
    ...profile.skills,
    ...experiences.flatMap((item) => [
      item.title,
      item.organizationName,
      item.description,
    ]),
    ...education.flatMap((item) => [
      item.institution,
      item.qualification,
      item.fieldOfStudy,
    ]),
    ...projects.flatMap((item) => [
      item.title,
      item.description,
      ...item.skills,
    ]),
  ]
    .filter(Boolean)
    .join(' ')
    .toLowerCase();
}
function calculateFit(criteria: Criterion[], evidenceText: string) {
  if (!criteria.length)
    return { match: null, matchedCriteria: [], missingCriteria: [] };
  const evidenceTokens = new Set(tokenize(evidenceText));
  const matchedCriteria: string[] = [];
  const missingCriteria: string[] = [];
  let weightedScore = 0;
  const totalWeight =
    criteria.reduce(
      (sum, criterion) => sum + Number(criterion.weight || 1),
      0,
    ) || 1;
  criteria.forEach((criterion) => {
    const equivalents = Array.isArray(criterion.equivalentSignals)
      ? criterion.equivalentSignals
      : [];
    const terms = [
      ...new Set(
        tokenize(
          `${criterion.label} ${criterion.evidenceDefinition} ${equivalents.join(' ')}`,
        ),
      ),
    ];
    const matchedTerms = terms.filter((term) =>
      evidenceTokens.has(term),
    ).length;
    const denominator = Math.max(2, Math.min(8, terms.length));
    const phraseBonus = equivalents.some((signal) =>
      evidenceText.includes(signal.toLowerCase()),
    )
      ? 0.2
      : 0;
    const criterionScore = Math.min(
      1,
      matchedTerms / denominator + phraseBonus,
    );
    weightedScore += criterionScore * Number(criterion.weight || 1);
    if (criterionScore >= 0.45) matchedCriteria.push(criterion.label);
    else missingCriteria.push(criterion.label);
  });
  return {
    match: Math.round((weightedScore / totalWeight) * 100),
    matchedCriteria,
    missingCriteria,
  };
}
function tokenize(value: string) {
  const stopWords = new Set([
    'and',
    'the',
    'with',
    'for',
    'from',
    'that',
    'this',
    'your',
    'role',
    'work',
    'ability',
    'clear',
    'evidence',
  ]);
  return value
    .toLowerCase()
    .split(/[^a-z0-9+#.]+/)
    .filter((term) => term.length > 2 && !stopWords.has(term));
}
function stageReached(application: CandidateApplication, index: number) {
  const order: Record<string, number> = {
    submitted: 0,
    in_review: 1,
    shortlisted: 2,
    interview: 3,
    offer: 4,
    hired: 4,
    rejected: 1,
  };
  return index <= (order[application.status] ?? 0);
}
function candidateEventLabel(event: CandidateApplicationEvent) {
  const labels: Record<string, string> = {
    application_submitted: 'Application submitted',
    application_stage_changed: event.toStatus
      ? `Moved to ${titleCase(event.toStatus)}`
      : 'Application updated',
    application_rejected: 'Application closed',
    application_withdrawn: 'Application withdrawn',
    evidence_review_completed: 'Evidence review completed',
    offer_recorded: 'Offer stage recorded',
    candidate_hired: 'Hiring decision confirmed',
    interview_scheduled: 'Interview scheduled',
    interview_rescheduled: 'Interview rescheduled',
    interview_cancelled: 'Interview cancelled',
    interview_change_requested: 'New interview time requested',
    structured_interview_completed: 'Structured screening completed',
    live_interview_completed: 'Live interview completed',
  };
  return labels[event.eventType] ?? titleCase(event.eventType);
}
function initials(value: string) {
  return (
    value
      .split(/\s+/)
      .slice(0, 2)
      .map((part) => part[0])
      .join('')
      .toUpperCase() || 'HM'
  );
}
function titleCase(value: string) {
  return value
    .replace(/_/g, ' ')
    .replace(/-/g, ' ')
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}
function uniqueSkills(values: string[]) {
  const seen = new Set<string>();
  return values
    .map((value) => value.trim())
    .filter((value) => {
      const key = value.toLowerCase();
      if (!value || seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .slice(0, 30);
}
function formatBytes(value: number) {
  return value > 1024 * 1024
    ? `${(value / 1024 / 1024).toFixed(1)} MB`
    : `${Math.max(1, Math.round(value / 1024))} KB`;
}
function formatRelative(value: number) {
  if (!Number.isFinite(value)) return 'Recently';
  const hours = Math.max(1, Math.round((Date.now() - value) / 3_600_000));
  return hours < 24 ? `${hours}h ago` : `${Math.round(hours / 24)}d ago`;
}
function readText(value: unknown, fallback = '') {
  return typeof value === 'string' || typeof value === 'number'
    ? `${value}`
    : fallback;
}
