'use client';

import { useEffect } from 'react';

import { signOutAndRedirect } from '@/lib/supabase/client';

export default function LogoutPage() {
  useEffect(() => {
    void signOutAndRedirect();
  }, []);
  return <main className="auth-transition"><span className="candidate-brand-mark">h</span><p>Signing out securely…</p></main>;
}
