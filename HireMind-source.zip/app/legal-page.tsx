import { StableLink as Link } from '@/components/stable-link';
import { ArrowLeft, ShieldCheck } from 'lucide-react';

export function LegalPage({
  eyebrow,
  title,
  updated,
  children,
}: {
  eyebrow: string;
  title: string;
  updated: string;
  children: React.ReactNode;
}) {
  return (
    <main className="min-h-screen bg-[#f8f4ef] px-5 py-8 text-[#2b2233] sm:px-8 sm:py-12">
      <article className="mx-auto max-w-3xl rounded-[28px] border border-[#ded5df] bg-white p-7 shadow-[0_28px_80px_rgba(51,38,57,0.08)] sm:p-12">
        <Link
          href="/"
          className="mb-10 inline-flex items-center gap-2 text-sm font-semibold text-[#6f5871]"
        >
          <ArrowLeft className="size-4" /> Back to HireMind
        </Link>
        <header className="border-b border-[#e5dde6] pb-8">
          <span className="text-xs font-semibold uppercase tracking-[0.16em] text-[#816882]">
            {eyebrow}
          </span>
          <h1 className="mt-3 text-4xl font-semibold tracking-[-0.045em] sm:text-5xl">
            {title}
          </h1>
          <p className="mt-4 text-sm text-muted-foreground">
            Effective {updated}
          </p>
        </header>
        <div className="legal-copy mt-8 space-y-8 text-sm leading-7 text-[#5d5361]">
          {children}
        </div>
        <footer className="mt-10 flex items-start gap-3 rounded-2xl bg-[#f3edf4] p-4 text-xs leading-5 text-[#5e4b63]">
          <ShieldCheck className="mt-0.5 size-4 shrink-0" /> HireMind is an
          evidence-organization tool. Employers remain responsible for lawful,
          fair, and human-reviewed hiring decisions.
        </footer>
      </article>
    </main>
  );
}

export function LegalSection({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section>
      <h2 className="mb-2 text-lg font-semibold text-[#33283b]">{title}</h2>
      <div className="space-y-2">{children}</div>
    </section>
  );
}
