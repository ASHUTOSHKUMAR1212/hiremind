# HireMind — Eightfold gap checklist

Updated 15 September 2026. This compares inspected HireMind source with Eightfold's published product descriptions, not a hands-on Eightfold evaluation. Vendor feature claims do not prove matching accuracy. No head-to-head accuracy result is available.

## This implementation

- [x] Employer Hiring analytics navigation and job/application-cohort filters (30, 90, 365 days).
- [x] Recorded stage reach, current-stage counts, first-review and application-to-hire medians with actual sample sizes.
- [x] Offer-to-hire ratio with pending offers explicitly included; no invented acceptance rate.
- [x] Application attention queue with adjustable stage-age thresholds and links back to the existing application workflow.
- [x] Job-requirement evidence coverage; missing or stale screening is unassessed, never treated as missing skills.
- [x] Company-scoped, spreadsheet-safe CSV report with cohort boundaries and methodology.
- [x] Interview panel comparison of current submitted reviews, rating differences, reviewer rationales, and exact transcript citations.
- [x] Private drafts, stale reviews, and incomplete citations excluded from panel comparisons; no automated hiring decision or overall panel score.
- [x] Search the eligible talent pool before pagination, with literal text and location filters, 50-profile pages, stable timestamp/ID cursors, and live consent/suppression checks.
- [x] Explain that evidence ranking is within each page, not a global ranking; no automatic outreach or applications.
- [x] Previous analytics, panel comparison and paginated talent-search batch deployed successfully (version 33).
- [x] Private recruiter saved searches: selected job, applied keyword/location filters, durable storage, reload and confirmed removal. Up to 20 definitions per recruiter per company; no candidate snapshots or cursors stored.
- [x] Reload begins a fresh search and rechecks current consent and suppression. Unsaved filter edits must be applied before saving.
- [ ] Confirm production deployment of saved searches. The deployment receipt, not local test success, establishes what is live.
- [ ] Signed-in browser acceptance test of the new views and navigation. Automated route tests simulate external identity and do not replace browser testing.

## Useful remaining gaps, in priority order

| Priority | Capability described by Eightfold | HireMind today | Work still needed |
| --- | --- | --- | --- |
| 1 | Skills/capability intelligence, adjacent and learnable skills ([Talent Acquisition](https://eightfold.ai/products/talent-acquisition/)) | Transparent evidence rules, curated synonyms, relevant tenure, source citations, benchmark-upload tooling | Representative consented résumé/job dataset; independent labels; held-out evaluation by role/seniority; expert-reviewed skill taxonomy and semantic retrieval; calibrated uncertainty; measured false positives/negatives. No unsupported inference that someone has a skill merely because it is adjacent. |
| 2 | Recruiting analytics ([Talent Acquisition datasheet](https://eightfold.ai/wp-content/uploads/eightfold_talent_acquisition_datasheet.pdf)) | New operational cohort, aging and requirement-coverage reports | Source-of-hire tracking, recruiter workload ownership, vacancy-level time-to-fill, trend comparisons, reliable hired/declined reasons and HRIS outcome data. Current medians are application-to-hire, not vacancy time-to-fill. |
| 3 | Interview assistance and structured evaluations ([AI Interview Companion](https://eightfold.ai/products/ai-interview-companion/)) | VTT/SRT imports, source-linked scorecards, new panel comparison | Consented audio capture/transcription, retention/deletion controls for recordings, correction workflow, meeting integrations, and real two-device/TURN verification. Requires a chosen provider and authorized credentials/budget for external processing. |
| 4 | Targeted CRM campaigns ([Candidate relationship management](https://eightfold.ai/use-case/candidate-relationship-management/)) | Applicant contacts, notes, tags, suppression, approved drafts, manual-send recording and follow-up tasks | Saved audiences/talent lists, assigned owners, deliverable email sequences, unsubscribe links, bounce/webhook handling, rate limits and response attribution. Requires verified sender/provider. No automatic sending currently. |
| 5 | ATS/HRIS connectivity ([API documentation](https://apidocs.eightfold.ai/docs/getting-started)) | Scoped read-only API, CSV export and one-time interview calendar files | First customer-selected ATS/HRIS adapter, OAuth or scoped credentials, field mapping, sync cursors, idempotency, conflict handling, retry queue and audit trails. No dedicated connector is currently configured or tested. |
| 6 | Broad sourcing/rediscovery ([Talent Acquisition](https://eightfold.ai/products/talent-acquisition/)) | Same-company, opted-in prior applicants; searchable paginated pool beyond the previous first-100 cap; location filters and within-page evidence comparison | Representative load testing, semantic retrieval, global evidence ranking, saved talent pools, duplicate resolution, authorized sourcing imports and attribution. Do not scrape private profiles or reuse candidate data without permission. |
| 7 | Internal mobility, career planning, skills development and succession ([Talent Management](https://eightfold.ai/products/talent-management/)) | Candidate/job recruitment workflows only | A separate employee access model, employee skills inventory, internal vacancies/projects, interest and manager-review workflows, learning links and succession governance. Keep this separate from candidate hiring data. |
| 8 | Enterprise governance/security ([Eightfold trust center](https://trust.eightfold.ai/)) | Company isolation, role checks, private exports and application audit events | Independent security/privacy/fairness/accessibility assessments, retention automation, enterprise SSO/provisioning, operational monitoring, disaster-recovery checks and representative load tests. Certifications cannot be implemented or claimed by adding UI. |

## No-new-paid-service work queue

- [x] Private saved talent-search definitions (this batch). This is not a campaign audience or manually curated candidate list.
- [ ] Recruiter-owned follow-up queues and workload reporting.
- [ ] Vacancy-level time-to-fill and period comparisons, with reliable underlying events and sample sizes.
- [ ] Benchmark error-analysis views using genuinely labeled, consented datasets. The interface can be built without a paid API; collecting reliable labels still requires work.
- [ ] Transcript correction/review workflow preserving original source and reviewer history. Automatic transcription and meeting-provider connectivity remain separate.
- [ ] Authorized CSV import mapping and duplicate-resolution previews. Do not overwrite candidate records without review.
- [ ] Retention-policy controls, recovery drills and accessibility testing.

“No-new-paid-service” means implementation on the current stack without buying another API. Existing hosting, database, storage, email and traffic quotas still apply. It is not a lifetime-free guarantee.

## Deliberate boundaries

- Prioritize employer hiring decisions and recruiter productivity before building a full workforce-management suite.
- Do not copy vendor data-scale claims or claim superiority without a controlled comparison.
- Do not rank on names, protected traits, school prestige, or inferred sensitive characteristics.
- Scores support human review; missing evidence is not a reason for automatic rejection.
- No new paid provider, external candidate-data transfer, recruiting campaign, or third-party account connection was enabled in this change.

## Release verification

- [x] New analytics calculation and panel-comparison unit tests.
- [x] Analytics API tests: permissions, tenant isolation, data minimization, cohort limits by time, soft deletion, stale screening, current engine and safe CSV export.
- [x] 73 unit/regression tests, 140 existing route integration checks, 28 employer-tool checks, 12 analytics route checks, 7 talent-search route checks and 9 saved-search route checks passed (269 distinct checks). These include simulated external identity, not real email, media or signed-in browser E2E.
- [x] Talent-search fixture traverses 121 profiles including tied timestamps; finds older profiles beyond the previous limit; validates filters and tenant access; excludes live opt-outs, withdrawn applications and suppressed CRM contacts.
- [x] Previous release type checking, lint and production build passed. Saved searches add one inspected, additive migration and no new dependency.

Primary product pages for Talent Acquisition, CRM, Interview Companion and Talent Management were rechecked 15 September 2026; other sources were checked 10–11 September. These are capability comparisons, not a claim that every Eightfold product is included in every customer plan.
