# HireMind capability map

This is the product scope ledger. It tracks the enterprise capability level HireMind must cover without copying a competitor's layouts, artwork, wording, or implementation.

Status keys: **Now** = first product slice, **Next** = core hiring release, **Later** = platform expansion.

## Differentiating core

| Capability | Release | HireMind standard |
| --- | --- | --- |
| Evidence-first resume shortlisting | Now | Every score traces to source evidence; missing evidence is not treated as a mismatch. |
| Hidden-fit recovery | Now | Surface qualified candidates lost by title, keyword, career-gap, or formatting filters. |
| Criteria calibration and ranking audit | Next | Recruiters test weight changes, compare review passes, and retain a complete decision record. |
| Candidate clarification loop | Next | Ask the smallest useful follow-up question before rejecting an uncertain profile. |
| Fresher evidence passport | Now | Projects, internships, coursework, certifications, hackathons, and open-source work can replace employment evidence. |
| Quality measurement | Next | Measure precision, recall, calibration, reviewer agreement, adverse-impact signals, and post-hire outcomes by role. |

## Talent acquisition

| Capability | Release | Scope |
| --- | --- | --- |
| Job and requisition management | Next | Structured JD builder, approvals, version history, reusable criteria, locations, headcount, and hiring team. |
| Career site and job discovery | Now | Search, explainable recommendations, save/share, accessible job detail, and low-friction application. |
| Candidate CRM and talent pools | Next | Prospecting, rediscovery, campaigns, consent, notes, tags, duplicate resolution, and relationship history. |
| Applications and configurable pipeline | Next | Stage templates, automation, bulk actions, SLA alerts, rejection reasons, and complete audit trail. |
| Referrals, events, and agencies | Later | Source-specific portals, ownership rules, attribution, event check-in, and conversion analytics. |
| Scheduling and communications | Next | Availability, panels, time zones, reminders, templates, rescheduling, and candidate communication history. |
| Offers and approvals | Later | Offer templates, approval routing, e-sign handoff, exceptions, and acceptance analytics. |

## Interviews and assessment

| Capability | Release | Scope |
| --- | --- | --- |
| AI screening interview | Next | Job-specific questions, adaptive probes, transcript, evidence clips, structured rubric, and human decision. |
| Multi-format interview | Later | Screening, coding, functional cases, presentations, and language assessment in a configurable plan. |
| Human interview companion | Later | Interview guide, note capture, evidence mapping, question coverage, and debrief preparation. |
| Integrity events | Next | Transparent tab/fullscreen/paste/network/camera events with instant notices and human review; no gaze, emotion, or personality inference. |
| Interview operations | Next | Panel kits, scorecards, reminders, conflicts, accessibility accommodations, and structured debrief. |

## Candidate experience

| Capability | Release | Scope |
| --- | --- | --- |
| Candidate identity and profile | Now | Fresher, experienced, returner, and student paths with import and granular privacy controls. |
| Application centre | Next | Status timeline, actions, messages, scheduling, interview preparation, withdrawal, and data controls. |
| Candidate agent | Later | Job discovery, application guidance, FAQs, status answers, and interview preparation with clear AI disclosure. |
| Skills and career guidance | Later | Evidence-backed skills profile, gaps, internal/external opportunities, learning suggestions, and career paths. |

## Talent management and workforce intelligence

| Capability | Release | Scope |
| --- | --- | --- |
| Internal mobility marketplace | Later | Internal roles, gigs, projects, mentorship, career paths, manager workflows, and mobility analytics. |
| Skills intelligence | Later | Versioned skills graph, aliases, proficiency evidence, decay, transferability, and organization-specific taxonomy. |
| Workforce planning | Later | Supply/demand scenarios, skill gaps, location strategy, redeploy/build/buy comparisons, and plan tracking. |
| Succession and talent reviews | Later | Talent pools, readiness, evidence, calibration, development plans, and access controls. |

## Enterprise platform

| Capability | Release | Scope |
| --- | --- | --- |
| Multi-tenant permissions | Next | Organization isolation, role-based access, field visibility, delegated administration, and audit logs. |
| Extensible data model | Now | Versioned records, application snapshots, custom fields, events, external IDs, and additive migrations. |
| Integrations | Next | ATS/HRIS, calendars, email, video, assessments, SSO/SCIM, webhooks, imports, and export APIs. |
| Analytics | Next | Funnel, source, speed, quality, fairness, interviewer, candidate-experience, and model-performance views. |
| Trust and governance | Next | Consent, retention, deletion, data residency options, accessibility, explainability, model/version audit, and incident controls. |
| Global readiness | Later | Localization, time zones, regional workflows, currencies, translated content, and accessible responsive interfaces. |

## Experience-quality bar for every release

- Original Porcelain Nocturne visual system: warm porcelain, midnight aubergine, muted lilac, champagne, and ink-blue accents.
- Layered hover feedback, smooth state transitions, useful motion, skeleton/loading states, and reduced-motion support.
- Responsive layouts, keyboard navigation, clear focus states, semantic structure, and WCAG-minded contrast.
- Helpful empty, error, permission, offline, and recovery states—not decorative dead ends.
- No unexplained AI output: confidence, evidence, missing information, version, and human action stay visible.

