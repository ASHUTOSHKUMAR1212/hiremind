# Matching intelligence: current v9 related task review

Related task work is now surfaced separately when a résumé describes a requested responsibility but does not establish all named tools in the same clause. Recruiters see the original excerpt, source location, affirmative named tools, still-unproven tool groups, and a targeted follow-up question. The comparison detail, ordinary screening explanation, and downloadable interview brief carry this information.

This is a review aid, not an equivalence classifier: it adds no score, rank boost, or credited tenure. Existing exact-tool scoring and all requirement caps remain unchanged. AND/OR tool groups, ownership, future/negative statements, and stated-gap priority are preserved. Already-supported tasks do not produce redundant related-work leads. At most five original excerpts are included per criterion. Unknown skill names outside the curated vocabulary are not inferred. The scope remains six English responsibility families, not general semantic matching.

Earlier results are historical; rerun screening or résumé comparison to obtain v9 review details. Development regression tests are not independent matching-accuracy measurements. No Eightfold comparison or signed-in production end-to-end validation was performed for this release.

## Historical v8 responsibility evidence

The current release adds a bounded responsibility layer, not a trained general semantic model. Six English task families are supported: data ingestion/transformation, production incident response, controlled experiments, business requirements discovery, manual process automation and mentoring. A performed action and work object must occur together; related wording can supply evidence even without the rubric's exact keywords.

- Job drafting retains recognized responsibilities and their named tools in the same criterion. Source text and additional scope/qualification warnings remain available for employer review. Existing job criteria are not automatically rewritten.
- Named tools still need their own evidence in the task clause. Unknown technology, industry, scale and seniority qualifiers are not silently waived. Unmapped qualifiers and missing tasks limit strong-match credit and require clarification.
- Comparisons distinguish work evidence, partial evidence, claims, absence, direct candidate-stated gaps and conflicting statements. Absence never means inability; gaps are candidate statements, not verified facts. Conflicts cannot produce a strong match.
- Every task match retains its original résumé quote. Interview briefs and comparison details ask task-specific follow-ups or ask the candidate to reconcile conflicting statements. Submitted applications get the same assessment explanation through the shared matching engine.
- Scores remain heuristic, not calibrated success probabilities. Responsibility mappings are incomplete, English-only and may miss valid wording. They do not infer personality, protected traits or overall seniority. Humans make hiring decisions.
- Earlier engine results remain historical and require a new review to use v8.

New development tests cover paraphrases, missing work despite exact keywords, observation/future/team claims, tool-task binding, unsupported qualifications, current versus historical denials, OR alternatives, conflicting statements, job drafting and JSON/brief round trips. The measured v7-to-v8 examples are maintained outside production in the task's `outputs/hiremind-pilot/work-evidence-v8` report. They are not an independent accuracy benchmark.

## Historical v5 release notes

This release improves a deterministic, English-language evidence matcher. It is not a trained semantic model, and its scores are not probabilities of job success or independently measured accuracy.

## What changed

- Work and project descriptions must contain a performed-work clause with context before receiving demonstrated-work credit. A bare skill list, future learning plan, title, or project tag is not equivalent to a contribution.
- A skill claim in another sentence cannot borrow the action from an unrelated sentence.
- Curated, explicit named-skill requirements distinguish AND from directly connected OR alternatives. Missing or claim-only required skills cap a criterion at 44 and are explained.
- Explicit employer-approved full-phrase equivalents may support a single named requirement. They do not silently waive multiple AND requirements.
- Existing interval-aware tenure checks remain conservative about missing and overlapping dates.
- Original candidate quotations are preserved. Candidate-provided claims are not independently verified.
- Historical results remain stored, but current dashboard, candidate and CSV views no longer present earlier-engine results as current. Resume-comparison results use existing version-staleness handling. Employers must rerun evidence review for active applications.
- Benchmark reports now show strong-match label disagreements in both directions and criterion-level reasons, alongside existing ranking metrics. Older reports remain readable.

## Regression examples

For the same essential “SQL and Python” criterion and pipeline evidence definition:

| Synthetic work description | Previous score | v5 score |
| --- | ---: | ---: |
| SQL and Python | 88 | 44 |
| Planning to learn SQL and Python next year. | 88 | 0 |
| Built SQL data pipelines to reconcile orders. | 45 | 44 |
| Built SQL and Python pipelines to reconcile orders. | 88 | 88 |

These are developer-authored regression examples, not an accuracy benchmark. Zero means no supported evidence was found by these rules, not that the person lacks ability. No automatic rejection or hiring decision is made.

## Honest next evaluation

### Job-description integrity

The next matching layer now drafts criteria only from explicit description text, not the job title. Required/preferred headings carry through their bullets; benefits and explicitly non-required clauses are excluded. Named AND skills become separate criteria; direct OR alternatives remain one criterion. JavaScript does not invent a TypeScript requirement.

Drafts cite the source clause, retain unambiguous single-skill duration requirements, warn on conflicts or omitted criteria, and do not pre-approve generic substitutes. Unclear descriptions return a manual-review caution. Publishing or replacing a role requires at least one non-empty employer-reviewed criterion; the server no longer silently inserts the same generic rubric into every role.

Existing published roles are not automatically rewritten. Employers must review their own rubric before rescreening. This is a bounded, English-language extractor, not complete natural-language understanding.

1. Collect authorized, de-identified résumé/job pairs across the target roles. Keep a separate, untouched evaluation set.
2. Have independent recruiters label relevance before seeing HireMind scores, using the same job criteria. Resolve disagreements and retain the rationale.
3. Run Matching quality, inspect false positives and relevant profiles missed by the strong-match threshold, and examine source evidence.
4. Tune on development examples only. Report held-out results, sample size, role coverage and disagreements; do not claim superiority to another product without comparable evidence.

## Known limitations

The skill dictionary and English action rules are incomplete. Concise, passive, multilingual or unusual résumé wording can be under-scored. Related skills are not automatically treated as interchangeable. Compound or optional requirements should be expressed as separate, explicit criteria. Scores remain heuristic and need human review; confidence is not statistically calibrated.

The new error-analysis threshold is the existing strong-match rule: aggregate score at least 75 and no essential criterion below 45. Human relevance is label 2 or 3. Diagnostics pool cases; top-K and nDCG metrics average jobs equally. Undefined precision or recall is displayed as undefined.
# Head-to-head evaluation (paired-ranking-v1)

Matching quality now accepts an optional `comparison` alongside the existing labeled dataset. The downloadable template and protocol deliberately contain no completed human labels or competitor rankings. No Eightfold connection, competitor output, independent reviewer study, or superiority result is supplied by this implementation.

The comparator requires the current HireMind engine version, a competitor product/version description, capture time with timezone, export provenance, a frozen protocol reference, an identical-input attestation, and a declaration of blinded independent labeling. These declarations are not authenticated. Every job must have at least two profiles. Every competitor ranking must cover exactly the same case IDs once each, grouped by ties from best to worst. Missing, duplicated, foreign, or extra IDs fail validation before persistence. Existing organization access and export/deletion isolation remain unchanged.

Primary endpoint is mean job-level nDCG@10 with exponential gain `2^relevance - 1`. Secondary endpoints are top-5 precision/recall (or full pool for smaller jobs), with labels 2–3 considered relevant. Both systems use expected metrics over all within-tie permutations, including groups crossing cutoffs. This prevents favorable input ordering. This tie-aware convention differs from the historical HireMind-only diagnostics, which are retained and explicitly separated in the interface. Tie handling follows the principle documented in [scikit-learn's nDCG reference](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.ndcg_score.html); this implementation explicitly uses exponential gains.

Report metrics use identical eligible jobs for both systems, report undefined/excluded job counts, and average jobs equally. Differences are percentage points. Win/tie/loss counts and both rank-group lists are exported and shown. The exploratory 95% percentile interval resamples paired whole-job differences 2,000 times with fixed seed 19840719, using sorted order statistics 49 and 1949 (zero-based). It is withheld below 10 eligible jobs. This is a display floor, **not** a power calculation, independence guarantee, or certification of superiority. Repeated candidates/related jobs require a clustered study design beyond this pilot tool.

Before making a comparative claim: pre-register representative held-out pools and a meaningful improvement threshold; commission at least two blinded independent reviewers; preserve judgments and adjudication; run authorized competitors on identical original documents; retain failures and parser-error audits; independently review analysis; replicate on fresh employers. This module tests structured-profile matching, not résumé parser quality or hiring outcomes. Do not silently repair only HireMind's parser output when claiming end-to-end performance. The current 200-case upload limit is for pilot comparisons.

Verification: 119 unit tests and 144 isolated route checks passed after this addition. Synthetic tests verify metric arithmetic, ties crossing cutoffs, loss reporting, missing/duplicate/foreign ranking rejection, undefined outcomes, reproducible intervals, legacy datasets, saved provenance, and tenant access. These are software regression results, not recruitment accuracy evidence.
