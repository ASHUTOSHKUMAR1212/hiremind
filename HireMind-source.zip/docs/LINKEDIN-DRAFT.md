# LinkedIn post draft

I've been building **HireMind**, an evidence-first hiring platform focused on helping employers understand the evidence behind a candidate match.

It brings together job criteria, multi-résumé comparison, candidate profiles, recruiter workflows and interview evidence. The goal is not just a ranking—it is a clearer explanation of what supports a match, what is still unproven, and what to ask next.

Built with TypeScript, React, Vinext/Vite, Cloudflare Workers, D1, R2 and Supabase Auth.

This is an actively developed project. Its matching scores are heuristic, and I am not claiming independently proven accuracy or superiority over established platforms. I would value feedback from recruiters, hiring managers and engineers on practical hiring workflows and explainability.

Live product: https://hiremind-evidence-first.sharmaaishu84.chatgpt.site/

GitHub: https://github.com/ASHUTOSHKUMAR1212/hiremind

#HiringTechnology #Recruitment #TypeScript #React #BuildInPublic
