# HireMind

### Evidence-first hiring, built around the employer's workflow.

HireMind brings job criteria, résumé comparison, candidate applications and interview evidence into one hiring workspace. Its central idea is simple: show the evidence behind a recommendation, make uncertainty visible, and leave the hiring decision with people.

[Explore the live product](https://hiremind-evidence-first.sharmaaishu84.chatgpt.site/)

## Product capabilities

- **Employer workspace:** job posts, weighted requirements, application stages, talent search and recruiter CRM.
- **Résumé comparison:** upload multiple résumés for a job, compare evidence against criteria, inspect source excerpts and download interview briefs.
- **Explainable matching:** distinguish demonstrated work, claims, missing information, candidate-stated gaps and conflicting statements.
- **Related-work review:** surface relevant task experience when exact required tools are unproven, without silently treating tools as equivalent or increasing the score.
- **Candidate portal:** email-code sign-in, résumé/profile intake, job discovery and application tracking.
- **Interview workflow:** scheduling, calendar export, live-call implementation, transcript import and source-linked scorecards.
- **Employer tools:** team permissions, analytics, saved talent searches, export and integration-key endpoints.

These are implemented capabilities, not a claim that every production workflow has passed end-to-end testing. Browser authentication, email delivery and live calls depend on configured external services.

## Architecture

| Layer | Technology |
| --- | --- |
| Language | TypeScript, SQL, CSS |
| Interface | React 19, Tailwind CSS 4, shadcn/Base UI |
| Application runtime | Vinext, Vite, Next-style app routing |
| API and hosting target | Cloudflare Workers through Sites |
| Application database | Cloudflare D1 (SQLite), Drizzle schema/migrations |
| File storage | Cloudflare R2 |
| Authentication | Supabase Auth with email codes |
| Live interviews | WebRTC with server-side signaling and optional TURN configuration |
| Checks | Node test runner, TypeScript, production build |

Supabase handles authentication here; the application database is D1. This is not a drop-in static GitHub Pages website.

## Matching approach and limits

The current matcher is deterministic and evidence-based. It uses curated skill aliases, job requirement groups, dated work evidence and six bounded English responsibility families. Scores are heuristics—not probabilities of job success. Submitted claims are not independently verified.

No independently audited accuracy figure or superiority over another vendor is claimed. Related-work excerpts are recruiter review leads, not exact-tool proof. See [matching documentation](docs/matching-intelligence.md).

## Source setup

1. Install Node.js 22.13 or later and npm.
2. Clone this repository and run `npm ci`.
3. Configure **your own** Supabase URL and browser-safe publishable key in `lib/supabase/config.ts`. The public source contains placeholders, not the live project's configuration. Never place a service-role key or SMTP password in browser code.
4. Configure email authentication, email delivery and allowed redirects for your own domain in Supabase.
5. Provision runtime bindings `DB` (D1) and `FILES` (R2). Apply the SQL migrations in `drizzle/` in order to your own database. Review `0001_seed_demo_jobs.sql` before using it: it contains demonstration jobs.
6. Run `npm run dev` for the local Vinext preview. Full authenticated workflows also require the database, storage and authentication configuration above.

```sh
npm test
npx tsc --noEmit
npm run build
```

The existing Vite configuration targets the Sites/Cloudflare runtime. `.openai/hosting.json` retains binding names but intentionally omits the original deployment identity. Publishing a fork requires its own hosting setup; running these commands alone does not provision production resources. `npm start` uses the generated Worker configuration after a build.

For reliable live calls across restrictive networks, configure TURN on the server. The implementation reads `TURN_KEY_ID` and `TURN_KEY_API_TOKEN`; these are secrets and must not be committed. Provider accounts and usage can incur charges.

## Repository layout

```text
app/           Pages, employer/candidate workspaces and API routes
components/    Shared interface components
lib/           Matching, parsing, authentication and workflow logic
db/            Schema and runtime database access
drizzle/       Database migrations and schema snapshots
tests/         Automated development regression checks
docs/          Architecture-related notes, matching limits and roadmap
public/        Brand assets
```

## Verification snapshot

The upstream v9 application passed 174 automated development tests, TypeScript checking and a production build on 25 September 2026. These results describe that source snapshot, not independent matching accuracy or full production end-to-end coverage. This repository export replaces deployment/authentication identifiers with placeholders and has not been separately exercised against a new backend.

## Privacy and security

This repository does not include production databases, candidate uploads, mailbox contents, `.env` files, runtime storage or deployment credentials. Use only documents you are authorized to process. Keep candidate information out of issues and pull requests. See [SECURITY.md](SECURITY.md).

## Project status and licensing

HireMind is actively developed. Roadmap documents describe planned work as well as implementation history; they are not guarantees of verified production behavior.

No open-source license has been selected for this repository. Public visibility does not by itself grant a general license to reuse or redistribute the project. Third-party dependencies retain their respective licenses.
