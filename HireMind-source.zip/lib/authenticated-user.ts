import { env } from 'cloudflare:workers';

import type { HireMindIdentity } from '@/lib/supabase/server';

export async function ensureAuthenticatedUser(identity: HireMindIdentity) {
  const existingIdentity = await env.DB.prepare(
    `SELECT user_id AS userId
     FROM auth_identities
     WHERE provider = 'supabase' AND provider_subject = ?
     LIMIT 1`,
  )
    .bind(identity.userId)
    .first<{ userId: string }>();

  const now = Date.now();
  if (existingIdentity) {
    await env.DB.batch([
      env.DB.prepare(
        `UPDATE users
         SET email = ?, full_name = COALESCE(?, full_name), updated_at = ?
         WHERE id = ?`,
      ).bind(identity.email, identity.fullName, now, existingIdentity.userId),
      env.DB.prepare(
        `UPDATE auth_identities
         SET last_seen_at = ?, email_at_link = ?
         WHERE provider = 'supabase' AND provider_subject = ?`,
      ).bind(now, identity.email, identity.userId),
    ]);
    return existingIdentity.userId;
  }

  const existingUser = await env.DB.prepare(
    `SELECT id FROM users WHERE email = ? LIMIT 1`,
  )
    .bind(identity.email)
    .first<{ id: string }>();
  const appUserId = existingUser?.id ?? `user_${crypto.randomUUID()}`;

  await env.DB.batch([
    env.DB.prepare(
      `INSERT INTO users (id, email, full_name, status, created_at, updated_at)
       VALUES (?, ?, ?, 'active', ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         email = excluded.email,
         full_name = COALESCE(excluded.full_name, users.full_name),
         updated_at = excluded.updated_at`,
    ).bind(appUserId, identity.email, identity.fullName, now, now),
    env.DB.prepare(
      `INSERT OR IGNORE INTO auth_identities
       (provider, provider_subject, user_id, email_at_link, linked_at, last_seen_at)
       VALUES ('supabase', ?, ?, ?, ?, ?)`,
    ).bind(identity.userId, appUserId, identity.email, now, now),
  ]);

  const linked = await env.DB.prepare(
    `SELECT user_id AS userId
     FROM auth_identities
     WHERE provider = 'supabase' AND provider_subject = ?
     LIMIT 1`,
  )
    .bind(identity.userId)
    .first<{ userId: string }>();
  return linked?.userId ?? appUserId;
}
