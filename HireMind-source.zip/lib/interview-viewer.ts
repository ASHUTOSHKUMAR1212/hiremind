/** A requested workspace selects a role; it never grants that role. */
export function resolveInterviewViewer(requested: string | null, candidate: boolean, employer: boolean): 'candidate' | 'employer' | null {
  if (requested === 'employer') return employer ? 'employer' : null;
  if (requested === 'candidate') return candidate ? 'candidate' : null;
  if (requested) return null;
  // Preserve existing candidate invitation links without a workspace parameter.
  return candidate ? 'candidate' : employer ? 'employer' : null;
}
