import type { BenchmarkDataset } from './matching-benchmark.ts';
import { MATCHING_ENGINE_VERSION } from './evidence-screening.ts';

export type BenchmarkComparison = {
  competitor: string;
  competitorVersion: string;
  outputSource: string;
  capturedAt: string;
  protocolReference: string;
  expectedEngineVersion: string;
  independentBlindLabels: boolean;
  sameInputsConfirmed: boolean;
  rankings: Array<{ jobId: string; rankGroups: string[][] }>;
};

export function validateComparison(data: BenchmarkDataset) {
  const c = data.comparison;
  if (c === undefined) return;
  if (!c || typeof c !== 'object') throw new Error('Invalid comparison object.');
  for (const field of ['competitor', 'competitorVersion', 'outputSource', 'protocolReference'] as const) {
    if (typeof c[field] !== 'string' || c[field].trim().length < 3 || c[field].length > 600)
      throw new Error(`Provide comparison ${field} (3–600 characters).`);
  }
  if (c.expectedEngineVersion !== MATCHING_ENGINE_VERSION)
    throw new Error('The comparison must name the current HireMind engine. Freeze a new protocol before evaluating a changed engine.');
  if (typeof c.capturedAt !== 'string' || !/^\d{4}-\d{2}-\d{2}T.*(?:Z|[+-]\d{2}:\d{2})$/.test(c.capturedAt) || !Number.isFinite(Date.parse(c.capturedAt)) || Date.parse(c.capturedAt) > Date.now())
    throw new Error('Provide a past competitor capture timestamp with a timezone.');
  if (c.sameInputsConfirmed !== true || typeof c.independentBlindLabels !== 'boolean')
    throw new Error('Confirm identical input documents and job requirements; declare whether labels were independently assigned without seeing either system’s rankings.');
  const pools = new Map<string, Set<string>>();
  for (const item of data.cases) {
    const pool = pools.get(item.jobId) ?? new Set<string>();
    pool.add(item.id);
    pools.set(item.jobId, pool);
  }
  if (!Array.isArray(c.rankings) || c.rankings.length !== pools.size)
    throw new Error('Provide exactly one competitor ranking for every benchmark job.');
  const seenJobs = new Set<string>();
  for (const ranking of c.rankings) {
    const pool = ranking && pools.get(ranking.jobId);
    if (!pool || pool.size < 2 || seenJobs.has(ranking.jobId) || !Array.isArray(ranking.rankGroups) || !ranking.rankGroups.length)
      throw new Error('Each comparison job needs at least two candidates and one complete ranking.');
    seenJobs.add(ranking.jobId);
    const seen = new Set<string>();
    for (const group of ranking.rankGroups) {
      if (!Array.isArray(group) || !group.length) throw new Error('Rank groups cannot be empty. Put tied candidate IDs in the same group.');
      for (const id of group) {
        if (typeof id !== 'string' || !pool.has(id) || seen.has(id))
          throw new Error('Competitor rankings must contain each candidate exactly once, in the correct job.');
        seen.add(id);
      }
    }
    if (seen.size !== pool.size) throw new Error('Incomplete competitor ranking: both systems must rank the entire identical candidate pool.');
  }
}

// Expected metric over every permutation within a tied group. No label-aware
// tie breaking, truncation bias, or dependence on the uploaded case order.
export function tieAveragedMetrics(groups: number[][]) {
  const labels = groups.flat();
  const k = Math.min(5, labels.length);
  const relevant = labels.filter((label) => label >= 2).length;
  let position = 0, dcg = 0, retrieved = 0;
  for (const group of groups) {
    const gain = group.reduce((sum, label) => sum + 2 ** label - 1, 0) / group.length;
    const qualified = group.filter((label) => label >= 2).length / group.length;
    for (let i = 0; i < group.length; i++, position++) {
      if (position < 10) dcg += gain / Math.log2(position + 2);
      if (position < k) retrieved += qualified;
    }
  }
  const ideal = [...labels].sort((a, b) => b - a).slice(0, 10)
    .reduce((sum, label, index) => sum + (2 ** label - 1) / Math.log2(index + 2), 0);
  return { ndcgAt10: ideal ? dcg / ideal : null, precisionAtK: k ? retrieved / k : null, recallAtK: relevant ? retrieved / relevant : null };
}

const average = (values: number[]) => values.length ? values.reduce((a, b) => a + b, 0) / values.length : null;

// Reproducible, job-level paired percentile bootstrap. Exploratory uncertainty,
// not a certification, p-value, or a guarantee about unseen employers.
export function pairedInterval(deltas: number[]) {
  if (deltas.length < 10) return null;
  let seed = 19840719;
  const samples: number[] = [];
  for (let b = 0; b < 2000; b++) {
    let sum = 0;
    for (let i = 0; i < deltas.length; i++) {
      seed = (Math.imul(1664525, seed) + 1013904223) >>> 0;
      sum += deltas[Math.floor((seed / 4294967296) * deltas.length)];
    }
    samples.push(sum / deltas.length);
  }
  samples.sort((a, b) => a - b);
  return { lower: samples[49], upper: samples[1949], resamples: 2000, seed: 19840719 };
}

export function compareRankings(data: BenchmarkDataset, jobs: Array<{ jobId: string; ranked: Array<{ id: string; score: number; relevance: number }> }>) {
  if (!data.comparison) return null;
  validateComparison(data);
  const c = data.comparison;
  const pairedJobs = jobs.map((job) => {
    const groups: string[][] = [];
    const ordered = [...job.ranked].sort((a, b) => b.score - a.score);
    ordered.forEach((item, index) => {
      if (index && item.score === ordered[index - 1].score) groups[groups.length - 1].push(item.id);
      else groups.push([item.id]);
    });
    const labels = new Map(job.ranked.map((item) => [item.id, item.relevance]));
    const competitorGroups = c.rankings.find((ranking) => ranking.jobId === job.jobId)!.rankGroups;
    const measure = (ranks: string[][]) => tieAveragedMetrics(ranks.map((group) => group.map((id) => labels.get(id)!)));
    const hiremind = measure(groups), competitor = measure(competitorGroups);
    return { jobId: job.jobId, count: ordered.length, k: Math.min(5, ordered.length), hiremind, competitor, hiremindRankGroups: groups, competitorRankGroups: competitorGroups };
  });
  const metrics = (['ndcgAt10', 'precisionAtK', 'recallAtK'] as const).map((metric) => {
    const eligible = pairedJobs.filter((job) => job.hiremind[metric] !== null && job.competitor[metric] !== null);
    const deltas = eligible.map((job) => job.hiremind[metric]! - job.competitor[metric]!);
    return { metric, eligibleJobs: eligible.length, excludedJobs: pairedJobs.length - eligible.length,
      hiremind: average(eligible.map((job) => job.hiremind[metric]!)), competitor: average(eligible.map((job) => job.competitor[metric]!)),
      delta: average(deltas), interval: pairedInterval(deltas), wins: deltas.filter((d) => d > 1e-10).length,
      ties: deltas.filter((d) => Math.abs(d) <= 1e-10).length, losses: deltas.filter((d) => d < -1e-10).length };
  });
  return {
    methodologyVersion: 'paired-ranking-v1', primaryMetric: 'ndcgAt10',
    competitor: c.competitor, competitorVersion: c.competitorVersion, outputSource: c.outputSource,
    capturedAt: c.capturedAt, protocolReference: c.protocolReference,
    evidenceStatus: data.heldOut && c.independentBlindLabels ? 'Declared held-out, independently labeled comparison — not independently audited' : 'Exploratory comparison — not independent held-out evidence',
    metrics, jobs: pairedJobs,
    limitations: [
      'Uploaded competitor results and identical input documents are declared, not authenticated or independently verified. No competitor service is called.',
      'Primary metric is nDCG@10 using exponential gains (2^label − 1). Precision/recall at top 5 are secondary; all metrics average jobs equally. Ties are averaged, unlike the legacy single-engine report.',
      'Undefined metrics exclude the same jobs from both systems and are counted explicitly. With five or fewer profiles, top-5 precision/recall cannot distinguish rankings.',
      'Intervals are exploratory 95% paired job-bootstrap percentile intervals (2,000 resamples), shown only with at least 10 eligible jobs. Ten jobs is a display floor, not proof of adequate statistical power. Repeated candidates or related jobs can invalidate independence assumptions.',
      'A positive difference or interval does not prove general superiority, fairness, job performance, résumé parsing quality, or the quality of the entire product. Publish losses and exclusions alongside wins; replicate on fresh employers and unseen jobs.',
    ],
  };
}
