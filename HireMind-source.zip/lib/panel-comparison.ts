import type {
  ScorecardEntry,
  TranscriptSegment,
} from './interview-transcript.ts';

export type PanelReview = {
  reviewerId: string;
  reviewerName: string;
  status: string;
  stale: boolean;
  transcriptRevision: number;
  entries: ScorecardEntry[];
  sourceSegments: TranscriptSegment[];
};

export function comparePanel(
  rubric: Array<{ id: string; label: string }>,
  reviews: PanelReview[],
  transcriptRevision: number,
) {
  // Private drafts and older transcript/rubric assessments never influence the
  // panel view. The API independently limits access to another reviewer's draft.
  const current = reviews.filter(
    (review) =>
      review.status === 'submitted' &&
      !review.stale &&
      review.transcriptRevision === transcriptRevision,
  );
  const reviewers = [
    ...new Map(current.map((review) => [review.reviewerId, review])).values(),
  ];
  return {
    reviewerCount: reviewers.length,
    excludedSubmitted: reviews.filter(
      (review) =>
        review.status === 'submitted' &&
        (review.stale || review.transcriptRevision !== transcriptRevision),
    ).length,
    criteria: rubric.map((criterion) => {
      const assessments = reviewers.map((review) => {
        const entry = review.entries.find(
          (item) => item.criterionId === criterion.id,
        );
        const sources =
          entry?.segmentIds
            .map((id) =>
              review.sourceSegments.find((segment) => segment.id === id),
            )
            .filter((segment): segment is TranscriptSegment =>
              Boolean(segment),
            ) ?? [];
        const sourceComplete = Boolean(
          entry &&
          entry.segmentIds.length > 0 &&
          sources.length === entry.segmentIds.length,
        );
        const rating =
          entry &&
          sourceComplete &&
          Number.isInteger(entry.rating) &&
          entry.rating! >= 1 &&
          entry.rating! <= 4
            ? entry.rating
            : null;
        return {
          reviewerId: review.reviewerId,
          reviewerName: review.reviewerName || 'Team reviewer',
          rating,
          rationale:
            entry?.rationale ?? 'No assessment submitted for this criterion.',
          sources,
          missingCitation: entry?.rating != null && !sourceComplete,
        };
      });
      const values = assessments.flatMap((item) =>
        item.rating === null ? [] : [item.rating],
      );
      const minimum = values.length ? Math.min(...values) : null;
      const maximum = values.length ? Math.max(...values) : null;
      return {
        ...criterion,
        assessments,
        ratedCount: values.length,
        unassessedCount: reviewers.length - values.length,
        minimum,
        maximum,
        needsDiscussion: values.length >= 2 && maximum! - minimum! >= 2,
      };
    }),
  };
}
