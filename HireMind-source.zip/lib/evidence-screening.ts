import {
  affirmativeEvidenceClauses,
  describesPerformedWork,
  namedSkillSpans,
  requiredSkillGroups,
} from './matching-signals.ts';
import {
  normalizeSkillPhrases,
  relevantTenure,
  requiredMonths,
} from './skills-context.ts';

import { buildEvidenceReview, responsibilityRequirements, responsibilitySupport, hasUnmappedWorkConstraint, type EvidenceReview, type ResponsibilitySupport } from './work-evidence.ts';

export const MATCHING_ENGINE_VERSION = 'structured-evidence-v9';

export function usesCurrentMatchingEngine(criteria: unknown[]) {
  return (
    criteria.length > 0 &&
    criteria.every(
      (criterion) =>
        typeof criterion === 'object' &&
        criterion !== null &&
        'engineVersion' in criterion &&
        criterion.engineVersion === MATCHING_ENGINE_VERSION,
    )
  );
}

export type ScreeningCriterion = {
  id: string;
  label: string;
  weight: number;
  requirementClass: string;
  evidenceDefinition: string | null;
  equivalentSignalsJson: string | null;
};

export type EvidenceSource = {
  key: string;
  sourceType: string;
  category: string;
  title: string;
  quote: string;
  sourceLocation: string;
  confidence: number;
  text: string;
};

export type CriterionEvidenceMatch = {
  source: EvidenceSource;
  matchedSignals: string[];
  relevance: number;
  evidenceLevel: 'demonstrated' | 'claimed';
  demonstratedSkills: string[];
  claimedSkills: string[];
  responsibilityMatches: ResponsibilitySupport[];
};

export type CriterionResult = ScreeningCriterion & {
  engineVersion: string;
  score: number;
  confidence: number;
  classification: string;
  explanation: string;
  evidence: CriterionEvidenceMatch[];
  requiresHumanReview: boolean;
  review: EvidenceReview;
  tenure?: {
    requiredMonths: number;
    supportedMonths: number;
    unresolvedEntries: number;
  };
  skillCoverage: Array<{
    requirement: string;
    status: 'demonstrated' | 'claimed' | 'not_found';
  }>;
};

export function assessCandidateEvidence(
  profile: Record<string, unknown>,
  criteria: ScreeningCriterion[],
) {
  const sources = buildEvidenceSources(profile);
  const criterionResults = criteria.map((criterion) =>
    assessCriterion(criterion, sources, profile),
  );
  const totalWeight =
    criterionResults.reduce((sum, criterion) => sum + criterion.weight, 0) || 1;
  const fitScore = Math.round(
    criterionResults.reduce(
      (sum, criterion) => sum + criterion.score * criterion.weight,
      0,
    ) / totalWeight,
  );
  const averageConfidence = criterionResults.length
    ? Math.round(
        criterionResults.reduce(
          (sum, criterion) => sum + criterion.confidence,
          0,
        ) / criterionResults.length,
      )
    : 0;
  const essentialGap = criterionResults.some(
    (criterion) =>
      criterion.requirementClass === 'essential' && criterion.score < 45,
  );
  const decisionBand = essentialGap
    ? 'needs_review'
    : fitScore >= 75
      ? 'strong_match'
      : fitScore >= 55
        ? 'possible_match'
        : 'needs_review';
  return {
    fitScore,
    evidenceCoverage: calculateSectionCoverage(profile),
    uncertainty: Math.max(8, 100 - averageConfidence),
    decisionBand,
    criterionResults,
  };
}

export function buildRankingExplanation(
  criteria: CriterionResult[],
  coverage: number,
) {
  const supported = criteria
    .filter((criterion) => criterion.score >= 55)
    .sort((a, b) => b.score - a.score)
    .slice(0, 2)
    .map((criterion) => criterion.label);
  const gaps = criteria
    .filter((criterion) => criterion.score < 45)
    .slice(0, 2)
    .map((criterion) => criterion.label);
  const sourceCount = new Set(
    criteria.flatMap((criterion) =>
      criterion.evidence.map((match) => match.source.key),
    ),
  ).size;
  return `Evidence coverage is ${coverage}% across ${sourceCount} cited source${sourceCount === 1 ? '' : 's'}. ${supported.length ? `Strongest support: ${supported.join(', ')}.` : 'No criterion has strong structured support yet.'} ${gaps.length ? `Human review needed for: ${gaps.join(', ')}.` : 'No essential evidence gap was detected.'}`;
}

function assessCriterion(
  criterion: ScreeningCriterion,
  sources: EvidenceSource[],
  profile: Record<string, unknown>,
): CriterionResult {
  const withoutDuration = criterion.label
    .replace(/\b\d+(?:\.\d+)?\s*\+?\s*(?:years?|months?)\b/gi, '')
    .trim();
  const labelSignals = tokenize(withoutDuration);
  const definitionSignals = tokenize(criterion.evidenceDefinition ?? '');
  const equivalents = safeArray(criterion.equivalentSignalsJson)
    .map(String)
    .map((value) => ({ label: value, tokens: tokenize(value) }))
    .filter((value) => value.tokens.size);
  const labelText = normalizeText(normalizeSkillPhrases(withoutDuration));
  const monthsRequired = requiredMonths(
    `${criterion.label} ${criterion.evidenceDefinition ?? ''}`,
  );
  const skillGroups = requiredSkillGroups(withoutDuration);
  const workRequirements = responsibilityRequirements(withoutDuration);
  const taskSupport = (clause: string) => {
    const skills = new Set(namedSkillSpans(clause).map((item) => item.skill));
    // Work using another tool cannot prove a named tool+responsibility requirement.
    return skillGroups.every((group) => group.some((skill) => skills.has(skill)))
      ? responsibilitySupport(withoutDuration, clause) : [];
  };
  const matches = sources
    .map((source): CriterionEvidenceMatch => {
      const clauses = affirmativeEvidenceClauses(source.text);
      const canDemonstrate = ['work_history', 'project'].includes(
        source.sourceType,
      );
      // Score performed work separately: an action elsewhere cannot validate a skill list.
      const demonstrated = canDemonstrate
        ? clauses.filter((clause) => describesPerformedWork(clause) || taskSupport(clause).length > 0)
        : [];
      const relevantWork = demonstrated.filter((clause) => {
        const signals = tokenize(clause);
        return (
          taskSupport(clause).length > 0 ||
          intersect(labelSignals, signals).length > 0 ||
          equivalents.some(
            (signal) =>
              intersect(signal.tokens, signals).length === signal.tokens.size,
          )
        );
      });
      const evidenceLevel = relevantWork.length ? 'demonstrated' : 'claimed';
      const affirmativeText = (
        relevantWork.length ? relevantWork : clauses
      ).join('. ');
      const sourceSignals = tokenize(affirmativeText);
      const responsibilityMatches = canDemonstrate
        ? [...new Map(relevantWork.flatMap(taskSupport).map((item) => [item.id, item])).values()]
        : [];
      const primary = intersect(labelSignals, sourceSignals);
      const supporting = intersect(definitionSignals, sourceSignals);
      const equivalent = equivalents
        .map((signal) => ({
          ...signal,
          matches: intersect(signal.tokens, sourceSignals),
        }))
        .sort(
          (first, second) => second.matches.length - first.matches.length,
        )[0];
      const sourceSkills = new Set(
        namedSkillSpans(affirmativeText).map((span) => span.skill),
      );
      const alternativeTokens = new Set(
        skillGroups
          .filter((group) => group.length > 1)
          .flatMap((group) => group.flatMap((skill) => [...tokenize(skill)])),
      );
      const ordinaryLabelSignals = new Set(
        [...labelSignals].filter(
          (signal) => !alternativeTokens.has(signal) && signal !== 'or',
        ),
      );
      const alternativeGroups = skillGroups.filter((group) => group.length > 1);
      const primaryCoverage =
        (intersect(ordinaryLabelSignals, sourceSignals).length +
          alternativeGroups.filter((group) =>
            group.some((skill) => sourceSkills.has(skill)),
          ).length) /
        Math.max(1, ordinaryLabelSignals.size + alternativeGroups.length);
      const supportingCoverage =
        supporting.length / Math.max(2, Math.min(8, definitionSignals.size));
      const equivalentCoverage =
        equivalent && equivalent.matches.length === equivalent.tokens.size
          ? 1
          : 0;
      const exactLabel =
        labelText.length > 2 &&
        ` ${normalizeText(normalizeSkillPhrases(affirmativeText))} `.includes(
          ` ${labelText} `,
        );
      const rawRelevance = Math.max(
        exactLabel ? 88 : 0,
        primaryCoverage * 68 + supportingCoverage * 18,
        equivalentCoverage ? 68 : 0,
        responsibilityMatches.length ? 78 * responsibilityMatches.length / Math.max(1, workRequirements.length) : 0,
      );
      // A listed skill, title, or summary is a claim, not demonstrated proficiency.
      // Dates and relevant tenure require a separate interval-aware assessment.
      const claimOnly =
        evidenceLevel === 'claimed' && source.sourceType !== 'education';
      const relevance =
        primary.length || equivalentCoverage || responsibilityMatches.length
          ? Math.min(
              claimOnly ? 44 : 100,
              Math.round(rawRelevance * sourceWeight(source.sourceType)),
            )
          : 0;
      const matchedSignals = unique([
        ...primary,
        ...supporting,
        ...(equivalentCoverage ? (equivalent?.matches ?? []) : []),
        ...responsibilityMatches.map((item) => item.label),
      ]).slice(0, 7);
      return {
        // Keep the original quote: persisted citations share a source across criteria.
        source: { ...source, text: affirmativeText },
        matchedSignals,
        relevance,
        evidenceLevel,
        responsibilityMatches,
        demonstratedSkills: relevantWork.length ? [...sourceSkills] : [],
        claimedSkills: unique(
          clauses.flatMap((clause) =>
            namedSkillSpans(clause).map((span) => span.skill),
          ),
        ),
      };
    })
    .filter((match) => match.relevance >= 18 && match.matchedSignals.length)
    .sort((first, second) => second.relevance - first.relevance);

  const skillCoverage: CriterionResult['skillCoverage'] = skillGroups.map(
    (group) => ({
      requirement: group.join(' or '),
      status: matches.some((match) =>
        group.some((skill) => match.demonstratedSkills.includes(skill)),
      )
        ? 'demonstrated'
        : matches.some((match) =>
              group.some((skill) => match.claimedSkills.includes(skill)),
            )
          ? 'claimed'
          : 'not_found',
    }),
  );
  // Explicit employer-approved equivalents may support a single requirement, never
  // silently waive multiple AND requirements.
  const approvedEquivalent =
    skillGroups.length === 1 &&
    matches.some(
      (match) =>
        match.evidenceLevel === 'demonstrated' &&
        equivalents.some(
          (signal) =>
            intersect(signal.tokens, tokenize(match.source.text)).length ===
            signal.tokens.size,
        ),
    );
  const missingSkills = skillCoverage.filter(
    (item) => item.status !== 'demonstrated',
  );
  const skillsNeedReview = missingSkills.length > 0 && !approvedEquivalent;
  const experiences = records(profile.experiences);
  const tenure = relevantTenure(
    matches
      .filter(
        (match) =>
          match.source.sourceType === 'work_history' && match.relevance >= 50,
      )
      .map((match) => experiences[Number(match.source.key.split(':')[1])])
      .filter(Boolean),
  );
  const durationNeedsReview =
    monthsRequired !== null && tenure.months < monthsRequired;
  if (durationNeedsReview)
    for (const match of matches)
      match.relevance = Math.min(44, match.relevance);
  matches.splice(3);

  const best = matches[0]?.relevance ?? 0;
  const corroboration = matches
    .slice(1)
    .filter((match) => match.relevance >= 50)
    .reduce(
      (sum, match) => sum + Math.min(6, Math.round(match.relevance * 0.08)),
      0,
    );
  const missingWork = workRequirements.filter((requirement) => !matches.some((match) =>
    match.responsibilityMatches.some((item) => item.id === requirement.id)));
  const unmappedConstraint = hasUnmappedWorkConstraint(withoutDuration);
  let score = Math.min(skillsNeedReview || missingWork.length || unmappedConstraint ? 44 : 100, best + corroboration);
  const review = buildEvidenceReview(criterion.label, sources, matches, score);
  // Conflicting claims are a clarification task, not strong evidence or an automatic rejection.
  if (review.statedGaps.length) score = Math.min(44, score);
  const confidence = matches.length
    ? Math.min(94, Math.round(42 + score * 0.35 + matches.length * 7))
    : 30;
  const classification =
    score >= 75
      ? 'strong_evidence'
      : score >= 50
        ? 'partial_evidence'
        : score >= 28
          ? 'adjacent_evidence'
          : 'insufficient_evidence';
  const citedSources = matches.map((match) => match.source.sourceLocation);
  const matchedSignals = unique(
    matches.flatMap((match) => match.matchedSignals),
  );
  const explanation =
    (matches.length
      ? `Supported by ${citedSources.join(', ')}. Matched signals: ${matchedSignals.slice(0, 6).join(', ')}. ${score < 55 ? 'The evidence is adjacent or limited and needs human confirmation.' : 'Review the cited evidence for depth and recency.'}`
      : 'No structured work, project, education, or skill evidence matched this criterion. This is an uncertainty flag, never an automatic rejection.') +
    (monthsRequired !== null
      ? ` Relevant dated work supports ${tenure.months} non-overlapping months against ${monthsRequired} required. ${tenure.unresolved ? `${tenure.unresolved} relevant entries have unresolved dates. ` : ''}${durationNeedsReview ? 'Required experience duration is not verified; review missing dates and relevance.' : 'Dates and work are candidate-provided, not independently verified.'}`
      : '');
  const skillExplanation = missingSkills.length
    ? ' Required skill evidence: ' +
      missingSkills
        .map(
          (item) =>
            item.requirement +
            ' (' +
            (item.status === 'claimed'
              ? 'claimed, no performed work found'
              : 'not found in matched evidence') +
            ')',
        )
        .join('; ') +
      '.' +
      (approvedEquivalent
        ? ' An employer-approved equivalent supports this criterion; confirm that substitution during review.'
        : ' Confirm these requirements with the candidate; missing evidence is not proof of inability.')
    : '';
  return {
    ...criterion,
    engineVersion: MATCHING_ENGINE_VERSION,
    score,
    confidence,
    classification,
    explanation: `${review.label}. ${explanation}${skillExplanation}` +
      (missingWork.length ? ` Work with all required tools not demonstrated: ${missingWork.map((item) => item.label).join('; ')}.` : '') +
      (review.relatedWork?.length ? ` Related task evidence (no additional score or tenure credit): ${review.relatedWork.map((item) => `“${item.quote}” [${item.sourceLocation}]; required tools unproven in this excerpt: ${item.unprovenToolGroups.map((group) => group.join(' or ')).join(' and ')}`).join('; ')}. This does not establish tool equivalence or proficiency.` : '') +
      (unmappedConstraint ? ' Additional scope or qualification wording needs manual review; a responsibility match does not establish it.' : '') +
      (review.statedGaps.length ? ` Candidate-stated gap: ${review.statedGaps.map((item) => `“${item.quote}” [${item.sourceLocation}]`).join('; ')}. Confirm current context; this is not independently verified.` : '') +
      ` Ask: ${review.question}`,
    evidence: matches,
    skillCoverage,
    requiresHumanReview: true,
    review,
    ...(monthsRequired !== null
      ? {
          tenure: {
            requiredMonths: monthsRequired,
            supportedMonths: tenure.months,
            unresolvedEntries: tenure.unresolved,
          },
        }
      : {}),
  };
}

function buildEvidenceSources(
  profile: Record<string, unknown>,
): EvidenceSource[] {
  const sources: EvidenceSource[] = [];
  const metadata = safeJson(profile.metadata);
  safeArray(metadata.skills)
    .map(String)
    .filter(Boolean)
    .forEach((skill, index) => {
      sources.push(
        source(
          `skill:${index}`,
          'profile_skill',
          'skill',
          skill,
          skill,
          'Skills',
          60,
        ),
      );
    });
  records(profile.experiences).forEach((item, index) => {
    const title = text(item.title) || 'Work experience';
    const organization = text(item.organizationName);
    const description = text(item.description);
    sources.push(
      source(
        `experience:${index}`,
        description ? 'work_history' : 'work_title',
        'experience',
        [title, organization].filter(Boolean).join(' · '),
        description || title,
        `Work history: ${organization || title}`,
        78,
        description || title,
      ),
    );
  });
  records(profile.projects).forEach((item, index) => {
    const title = text(item.title) || 'Project';
    const description = text(item.description);
    const skills = safeArray(item.skills).map(String).join(' ');
    if (description)
      sources.push(
        source(
          `project:${index}`,
          'project',
          'project',
          title,
          description,
          `Project: ${title}`,
          75,
          description,
        ),
      );
    const claims = [title, skills].filter(Boolean).join(' · ');
    sources.push(
      source(
        `project-claim:${index}`,
        'project_claim',
        'project',
        title,
        claims,
        `Project details: ${title}`,
        45,
        claims,
      ),
    );
  });
  records(profile.education).forEach((item, index) => {
    const institution = text(item.institution);
    const qualification = text(item.qualification);
    const field = text(item.fieldOfStudy);
    const title =
      [qualification, field].filter(Boolean).join(' · ') ||
      institution ||
      'Education';
    sources.push(
      source(
        `education:${index}`,
        'education',
        'education',
        title,
        [institution, qualification, field].filter(Boolean).join(' · '),
        `Education: ${institution || title}`,
        68,
        `${qualification} ${field}`,
      ),
    );
  });
  const summary = text(profile.summary);
  if (summary)
    sources.push(
      source(
        'summary',
        'profile_summary',
        'summary',
        'Candidate summary',
        summary,
        'Profile summary',
        45,
      ),
    );
  const seen = new Set<string>();
  return sources.filter((item) => {
    const key = normalizeText(item.text);
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function source(
  key: string,
  sourceType: string,
  category: string,
  title: string,
  quote: string,
  sourceLocation: string,
  confidence: number,
  searchableText?: string,
): EvidenceSource {
  return {
    key,
    sourceType,
    category,
    title: title.slice(0, 180),
    quote: quote.slice(0, 1800),
    sourceLocation,
    confidence,
    text: (searchableText ?? `${title} ${quote}`).slice(0, 1800),
  };
}

function calculateSectionCoverage(profile: Record<string, unknown>) {
  const metadata = safeJson(profile.metadata);
  const checks = [
    profile.headline,
    profile.summary,
    profile.location,
    safeArray(metadata.skills).length,
    records(profile.experiences).length,
    records(profile.education).length,
    records(profile.projects).length,
    profile.resume,
  ];
  return Math.round((checks.filter(Boolean).length / checks.length) * 100);
}

function tokenize(value: string) {
  const normalized = normalizeText(normalizeSkillPhrases(value))
    .replace(/artificial intelligence/g, ' ai ')
    .replace(/machine learning/g, ' ml ')
    .replace(/natural language processing/g, ' nlp ')
    .replace(/sage maker/g, ' sagemaker ')
    .replace(/power bi/g, ' powerbi ')
    .replace(/scikit[ -]?learn/g, ' scikitlearn ');
  const tokens = normalized
    .split(/[^a-z0-9_+#.]+/)
    .map((token) => token.replace(/^\.+|\.+$/g, ''))
    .map(canonicalToken)
    .filter(
      (token) =>
        token.length > 1 &&
        !STOP_WORDS.has(token) &&
        !['of', 'at', 'least', 'minimum', 'or'].includes(token),
    );
  return new Set(tokens);
}

function canonicalToken(value: string) {
  // Multiword named skills are indivisible, not a bag of ordinary words.
  if (value.includes('_')) return value;
  const aliases: Record<string, string> = {
    aiml: 'ml',
    ai: 'ai',
    analytics: 'analysis',
    analyzed: 'analysis',
    analysing: 'analysis',
    analyzing: 'analysis',
    annotation: 'annotation',
    annotate: 'annotation',
    annotated: 'annotation',
    labelling: 'annotation',
    labeling: 'annotation',
    communicate: 'communication',
    communications: 'communication',
    developed: 'develop',
    developer: 'develop',
    development: 'develop',
    managed: 'manage',
    manager: 'manage',
    management: 'manage',
    modelling: 'model',
    modeling: 'model',
    models: 'model',
    datasets: 'dataset',
    javascript: 'javascript',
    js: 'javascript',
    typescript: 'typescript',
    ts: 'typescript',
  };
  return (
    aliases[value] ??
    (value.length > 4 && value.endsWith('s') ? value.slice(0, -1) : value)
  );
}

function normalizeText(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9_+#.]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}
function intersect(first: Set<string>, second: Set<string>) {
  return [...first].filter((value) => second.has(value));
}
function sourceWeight(sourceType: string) {
  return sourceType === 'work_history'
    ? 1
    : sourceType === 'project'
      ? 0.95
      : sourceType === 'education'
        ? 0.82
        : sourceType === 'profile_skill'
          ? 0.72
          : 0.5;
}
function records(value: unknown) {
  return Array.isArray(value)
    ? value.filter(
        (item): item is Record<string, unknown> =>
          typeof item === 'object' && item !== null,
      )
    : [];
}
function text(value: unknown) {
  return typeof value === 'string' ? value.trim() : '';
}
function unique(values: string[]) {
  return [...new Set(values)];
}
function safeJson(value: unknown): Record<string, unknown> {
  if (typeof value === 'object' && value !== null)
    return value as Record<string, unknown>;
  if (typeof value !== 'string') return {};
  try {
    return JSON.parse(value) as Record<string, unknown>;
  } catch {
    return {};
  }
}
function safeArray(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  if (typeof value !== 'string') return [];
  try {
    const parsed = JSON.parse(value) as unknown;
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

const STOP_WORDS = new Set([
  'ability',
  'and',
  'candidate',
  'clear',
  'demonstrate',
  'demonstrates',
  'evidence',
  'experience',
  'for',
  'from',
  'have',
  'including',
  'into',
  'job',
  'must',
  'on',
  'outcome',
  'preferred',
  'relevant',
  'required',
  'role',
  'show',
  'shows',
  'that',
  'the',
  'their',
  'this',
  'through',
  'using',
  'with',
  'work',
  'years',
  'your',
]);
