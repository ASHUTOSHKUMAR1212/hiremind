import { env } from 'cloudflare:workers';

export function applicationAllowsInterview(status: string) {
  return ['submitted', 'in_review', 'shortlisted', 'interview'].includes(status);
}

// Used in the SAME D1 batch as the application decision/withdrawal.
export function closeApplicationInterviews(applicationId: string, now: number) {
  return [
    env.DB.prepare(`UPDATE interview_room_participants SET left_at = ?, last_seen_at = ?
      WHERE interview_session_id IN (SELECT id FROM interview_sessions WHERE application_id = ?)`)
      .bind(now, now, applicationId),
    env.DB.prepare(`DELETE FROM interview_room_signals WHERE interview_session_id IN
      (SELECT id FROM interview_sessions WHERE application_id = ?)`)
      .bind(applicationId),
    env.DB.prepare(`UPDATE interview_sessions SET status = 'cancelled', updated_at = ?
      WHERE application_id = ? AND status IN ('scheduled', 'in_progress')`)
      .bind(now, applicationId),
  ];
}
