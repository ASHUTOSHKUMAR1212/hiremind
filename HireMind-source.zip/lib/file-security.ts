export function hasExpectedDocumentSignature(bytes: Uint8Array, extension: string) {
  if (extension === 'pdf') return bytes.length >= 5 && String.fromCharCode(...bytes.slice(0, 5)) === '%PDF-';
  if (extension === 'docx') return bytes.length >= 4 && bytes[0] === 0x50 && bytes[1] === 0x4b && bytes[2] === 0x03 && bytes[3] === 0x04;
  if (extension === 'doc') return bytes.length >= 8 && [0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1].every((value, index) => bytes[index] === value);
  return false;
}

export function hasValidDocxContainer(bytes: Uint8Array) {
  if (!hasExpectedDocumentSignature(bytes, 'docx') || bytes.length < 22) return false;
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let end = -1;
  for (let cursor = bytes.length - 22; cursor >= Math.max(0, bytes.length - 65557); cursor--) {
    if (view.getUint32(cursor, true) === 0x06054b50) { end = cursor; break; }
  }
  if (end < 0 || view.getUint16(end + 4, true) !== 0 || view.getUint16(end + 6, true) !== 0) return false;
  const count = view.getUint16(end + 10, true);
  let cursor = view.getUint32(end + 16, true);
  if (!count || count > 10000 || cursor >= end) return false;
  const names = new Set<string>();
  let expanded = 0;
  for (let index = 0; index < count; index++) {
    if (cursor + 46 > end || view.getUint32(cursor, true) !== 0x02014b50) return false;
    const flags = view.getUint16(cursor + 8, true), method = view.getUint16(cursor + 10, true);
    const packed = view.getUint32(cursor + 20, true), size = view.getUint32(cursor + 24, true);
    const nameLength = view.getUint16(cursor + 28, true), extra = view.getUint16(cursor + 30, true), comment = view.getUint16(cursor + 32, true);
    const local = view.getUint32(cursor + 42, true);
    if (flags & 1 || ![0, 8].includes(method) || cursor + 46 + nameLength + extra + comment > end || local + 30 > bytes.length) return false;
    if (view.getUint32(local, true) !== 0x04034b50) return false;
    const dataStart = local + 30 + view.getUint16(local + 26, true) + view.getUint16(local + 28, true);
    if (dataStart + packed > bytes.length) return false;
    expanded += size;
    if (expanded > 32 * 1024 * 1024) return false;
    const name = new TextDecoder().decode(bytes.subarray(cursor + 46, cursor + 46 + nameLength));
    if (name === 'word/document.xml' && (!size || size > 16 * 1024 * 1024)) return false;
    names.add(name);
    cursor += 46 + nameLength + extra + comment;
  }
  return names.has('[Content_Types].xml') && names.has('word/document.xml');
}
