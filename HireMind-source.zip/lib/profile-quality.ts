const text = (value: unknown) => typeof value === 'string' ? value.trim() : '';
const rows = (value: unknown): Record<string, unknown>[] => Array.isArray(value) ? value : [];

export function hasLayoutNumbers(value: unknown) {
  return /(?:^|\s)-?\d{4,}\s+-?\d{4,}\s+0\s+0(?:\s|$)/.test(text(value));
}

export function isProfileName(value: unknown) {
  const name = text(value);
  return Boolean(name) && !/^(portfolio|resume|curriculumvitae|contact|personaldetails)$/i.test(name.replace(/\s/g, '')) && !hasLayoutNumbers(name);
}

export function isProfilePhone(value: unknown) {
  const phone = text(value);
  const digits = phone.replace(/\D/g, '');
  return /^\+?[\d\s().-]+$/.test(phone) && digits.length >= 10 && digits.length <= 15 && !hasLayoutNumbers(phone);
}

export function getProfileQualityWarnings(value: Record<string, unknown>) {
  const warnings: string[] = [];
  if (text(value.fullName) && !isProfileName(value.fullName)) warnings.push('Full name looks like a résumé heading. Please check your name.');
  if (text(value.phone) && !isProfilePhone(value.phone)) warnings.push('Phone contains an unreadable or invalid number. Please check it against your résumé.');
  if (rows(value.education).some((entry) => hasLayoutNumbers(entry.institution) || hasLayoutNumbers(entry.qualification))) warnings.push('Education contains document-layout numbers. Please review the institution and qualification.');
  if (rows(value.projects).some((entry) => /^(tools|skills|technologies)\s*:/i.test(text(entry.title)))) warnings.push('A project title contains a tools list. Please replace it with the project name.');
  return warnings;
}

export function calculateProfileCompletion(value: Record<string, unknown>) {
  const validRows = (key: string) => rows(value[key]).filter((row) => !Object.values(row).some(hasLayoutNumbers));
  const hasExperience = validRows('experiences').length > 0;
  const hasEducation = validRows('education').length > 0;
  const hasProjects = validRows('projects').some((row) => !/^(tools|skills|technologies)\s*:/i.test(text(row.title)));
  const profileEvidence = value.profileType === 'experienced' ? hasExperience
    : value.profileType === 'returner' ? hasExperience || hasProjects : hasEducation || hasProjects;
  const checks = [isProfileName(value.fullName), value.headline, value.summary, value.location,
    Array.isArray(value.skills) && value.skills.length > 0, profileEvidence,
    hasEducation || hasExperience, hasProjects || hasExperience, value.resume];
  const completion = Math.round(checks.filter(Boolean).length / checks.length * 100);
  // Optional fields can still need correction: never call a flagged profile complete.
  return getProfileQualityWarnings(value).length ? Math.min(completion, 89) : completion;
}
