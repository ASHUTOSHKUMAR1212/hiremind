export type TranscriptSegment = {
  id: string;
  startMs: number;
  endMs: number;
  speaker: string;
  text: string;
};
export type ScorecardEntry = {
  criterionId: string;
  rating: number | null;
  rationale: string;
  segmentIds: string[];
};

function timestamp(value: string) {
  const parts = value.replace(',', '.').split(':').map(Number);
  if (
    (parts.length !== 2 && parts.length !== 3) ||
    parts.some((x) => !Number.isFinite(x) || x < 0) ||
    parts.at(-1)! >= 60 ||
    (parts.length === 3 && parts[1] >= 60)
  )
    throw new Error('Invalid transcript timestamp.');
  return Math.round(
    (parts.length === 3
      ? parts[0] * 3600 + parts[1] * 60 + parts[2]
      : parts[0] * 60 + parts[1]) * 1000,
  );
}

export function parseTranscript(value: string): TranscriptSegment[] {
  if (typeof value !== 'string' || value.length > 200_000)
    throw new Error('Transcript must be text under 200,000 characters.');
  const normalized = value
    .replace(/\r/g, '')
    .replace(/^\uFEFF/, '')
    .trim();
  const segments: TranscriptSegment[] = [];
  for (const block of normalized.split(/\n\s*\n/)) {
    const lines = block.split('\n');
    if (/^(WEBVTT|NOTE|STYLE|REGION)\b/.test(lines[0])) continue;
    const index = lines.findIndex((line) => line.includes('-->'));
    if (index < 0) continue;
    const match = lines[index].match(
      /^\s*([\d:.,]+)\s+-->\s+([\d:.,]+)(?:\s.*)?$/,
    );
    if (!match) throw new Error('Invalid VTT/SRT timing line.');
    const startMs = timestamp(match[1]),
      endMs = timestamp(match[2]);
    if (endMs <= startMs || endMs > 8 * 3600_000)
      throw new Error(
        'Transcript timestamps must be positive intervals within 8 hours.',
      );
    const raw = lines
      .slice(index + 1)
      .join(' ')
      .trim();
    const voice = raw.match(/^<v\s+([^>]+)>/i)?.[1];
    const text = raw
      .replace(/<[^>]*>/g, '')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .trim();
    const labeled = text.match(/^([^:]{1,60}):\s+(.+)$/);
    if (!text || text.length > 4000)
      throw new Error('Each transcript segment needs 1–4,000 characters.');
    segments.push({
      id: `segment-${segments.length + 1}`,
      startMs,
      endMs,
      speaker: (voice || labeled?.[1] || 'Unspecified speaker').slice(0, 80),
      text: labeled && !voice ? labeled[2] : text,
    });
  }
  if (!segments.length || segments.length > 1500)
    throw new Error(
      'Upload a timestamped VTT or SRT transcript with 1–1,500 segments.',
    );
  if (
    segments.some(
      (item, index) => index > 0 && item.startMs < segments[index - 1].startMs,
    )
  )
    throw new Error('Transcript segments must be in chronological order.');
  return segments;
}

export function validateScorecard(
  value: unknown,
  criterionIds: string[],
  segments: TranscriptSegment[],
  submit: boolean,
): ScorecardEntry[] {
  if (!Array.isArray(value) || value.length !== criterionIds.length)
    throw new Error('Include each job criterion exactly once.');
  const segmentIds = new Set(segments.map((item) => item.id));
  const seen = new Set<string>();
  return value.map((item) => {
    if (
      !item ||
      typeof item !== 'object' ||
      !criterionIds.includes(item.criterionId) ||
      seen.has(item.criterionId)
    )
      throw new Error('Unknown or duplicated scorecard criterion.');
    seen.add(item.criterionId);
    if (
      item.rating !== null &&
      (!Number.isInteger(item.rating) || item.rating < 1 || item.rating > 4)
    )
      throw new Error(
        'Use a rating from 1 to 4, or leave the criterion unassessed.',
      );
    if (
      typeof item.rationale !== 'string' ||
      item.rationale.length > 2000 ||
      !Array.isArray(item.segmentIds) ||
      item.segmentIds.length > 20 ||
      item.segmentIds.some(
        (id: unknown) => typeof id !== 'string' || !segmentIds.has(id),
      )
    )
      throw new Error(
        'Use valid transcript citations and a rationale under 2,000 characters.',
      );
    if (
      submit &&
      (item.rationale.trim().length < 12 ||
        (item.rating !== null && !item.segmentIds.length))
    )
      throw new Error(
        'Explain every assessment. Each rating needs a transcript citation; use unassessed when evidence is missing.',
      );
    return {
      criterionId: item.criterionId,
      rating: item.rating,
      rationale: item.rationale.trim(),
      segmentIds: [...new Set<string>(item.segmentIds)],
    };
  });
}

export function transcriptTime(milliseconds: number) {
  const seconds = Math.floor(milliseconds / 1000);
  return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`;
}
