import { INTERVIEW_EARLY_ACCESS_MS } from './interview-status.ts';

export const LIVE_EMPLOYER_EARLY_ACCESS_MS = 30 * 60_000;

export function getLiveRoomAvailability(
  role: 'candidate' | 'employer',
  status: string,
  scheduledAt: number | null,
  now: number,
) {
  if (!['scheduled', 'in_progress'].includes(status)) {
    return { canJoin: false, availableAt: null, reason: 'closed' as const };
  }

  const earlyAccess =
    role === 'candidate'
      ? INTERVIEW_EARLY_ACCESS_MS
      : LIVE_EMPLOYER_EARLY_ACCESS_MS;
  const availableAt = scheduledAt ? scheduledAt - earlyAccess : null;
  if (availableAt && now < availableAt) {
    return { canJoin: false, availableAt, reason: 'too_early' as const };
  }

  return { canJoin: true, availableAt, reason: null };
}

export function isAllowedLiveSignal(
  signalType: string,
  serializedPayload: string,
) {
  return (
    ['description', 'candidate', 'renegotiate'].includes(signalType) &&
    serializedPayload.length <= 50_000
  );
}
