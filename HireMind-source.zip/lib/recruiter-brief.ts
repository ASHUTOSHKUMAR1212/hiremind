import type { EvidenceReview } from './work-evidence.ts';

type BriefCriterion = {
  label: string;
  requirementClass: string;
  weight: number;
  score: number;
  evidence: Array<{ source: { quote: string; sourceLocation: string } }>;
  review?: EvidenceReview;
};

export function buildRecruiterBrief(
  jobTitle: string,
  candidateName: string,
  criteria: BriefCriterion[],
) {
  const ordered = [...criteria].sort(
    (a, b) =>
      Number(b.requirementClass === 'essential') -
        Number(a.requirementClass === 'essential') ||
      a.score - b.score ||
      b.weight - a.weight,
  );
  return [
    `HireMind interview brief: ${jobTitle}`,
    `Candidate: ${candidateName}`,
    'Preparation aid based on submitted evidence. Claims are not independently verified; the interviewer makes the assessment.',
    'Use the same job-related standard for every candidate. Offer reasonable ways to clarify or demonstrate missing evidence.',
    '',
    ...ordered.flatMap((criterion, index) => [
      `${index + 1}. ${criterion.label} (${criterion.requirementClass}, weight ${criterion.weight})`,
      criterion.review?.label ?? (criterion.score < 50
        ? 'Evidence needs clarification; this is not proof of inability.'
        : 'Evidence is present; verify depth, context, and ownership.'),
      ...criterion.evidence.map(
        ({ source }) =>
          `Submitted evidence [${source.sourceLocation}]: "${source.quote}"`,
      ),
      ...(criterion.review?.statedGaps ?? []).map((source) => `Candidate-stated gap [${source.sourceLocation}]: "${source.quote}"`),
      ...(criterion.review?.relatedWork ?? []).map((source) => `Related task evidence — not exact-tool proof [${source.sourceLocation}]: "${source.quote}". Required tools unproven in this excerpt: ${source.unprovenToolGroups.map((group) => group.join(' or ')).join(' and ')}. No additional score or tenure credit.`),
      `Ask: ${criterion.review?.question ?? `Walk me through a specific example of ${criterion.label}. What was the problem, what did you personally do, and what changed?`}`,
      'Follow up: What trade-off did you make? How was the result measured? What would you do differently?',
      'Reviewer notes: ',
      'Assessment: not assessed / needs clarification / partially demonstrated / demonstrated',
      'Evidence supporting this assessment: ',
      '',
    ]),
    'Overall recommendation: ',
    'Unresolved essential requirements: ',
    'Reviewer and date: ',
  ].join('\n');
}
