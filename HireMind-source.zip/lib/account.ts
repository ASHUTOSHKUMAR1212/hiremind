import { env } from 'cloudflare:workers';

export type AccountContext = {
  candidate: {
    id: string;
    fullName: string;
    profileType: string;
  } | null;
  organization: {
    id: string;
    name: string;
    roleKey: string;
  } | null;
};

export async function getAccountContext(userId: string): Promise<AccountContext> {
  const candidate = await env.DB.prepare(
    `SELECT id, full_name AS fullName, profile_type AS profileType
     FROM candidate_profiles
     WHERE owner_user_id = ?
     LIMIT 1`,
  )
    .bind(userId)
    .first<{ id: string; fullName: string; profileType: string }>();

  const organization = await env.DB.prepare(
    `SELECT o.id, o.name, m.role_key AS roleKey
     FROM organization_members m
     JOIN organizations o ON o.id = m.organization_id
     WHERE m.user_id = ? AND m.status = 'active'
     ORDER BY m.joined_at ASC
     LIMIT 1`,
  )
    .bind(userId)
    .first<{ id: string; name: string; roleKey: string }>();

  return {
    candidate: candidate ?? null,
    organization: organization ?? null,
  };
}
