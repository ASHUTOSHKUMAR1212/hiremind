import { env } from 'cloudflare:workers';
import { getAccountContext } from '@/lib/account';
import { ensureAuthenticatedUser } from '@/lib/authenticated-user';
import { getHireMindIdentity } from '@/lib/supabase/server';
import {
  canOrganizationRole,
  type OrganizationPermission,
} from '@/lib/organization-permissions';

export async function employerAccess(
  request: Request,
  permission: OrganizationPermission = 'review_candidates',
) {
  const identity = await getHireMindIdentity(request);
  if (!identity)
    return { error: json({ error: 'Sign in required.' }, 401) } as const;
  const userId = await ensureAuthenticatedUser(identity);
  const account = await getAccountContext(userId);
  if (
    !account.organization ||
    !canOrganizationRole(account.organization.roleKey, permission)
  )
    return {
      error: json({ error: 'Your team role cannot use this feature.' }, 403),
    } as const;
  return { userId, organization: account.organization } as const;
}

export function json(value: unknown, status = 200) {
  return Response.json(value, {
    status,
    headers: { 'cache-control': 'private, no-store' },
  });
}

export async function readPayload(
  request: Request,
  maxBytes = 300_000,
): Promise<Record<string, unknown>> {
  if (Number(request.headers.get('content-length')) > maxBytes)
    throw new Error('Request is too large.');
  const reader = request.body?.getReader();
  if (!reader) throw new Error('Request body required.');
  const chunks: Uint8Array[] = [];
  let size = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    size += value.byteLength;
    if (size > maxBytes) {
      await reader.cancel();
      throw new Error('Request is too large.');
    }
    chunks.push(value);
  }
  const bytes = new Uint8Array(size);
  let position = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, position);
    position += chunk.length;
  }
  const payload = JSON.parse(new TextDecoder().decode(bytes));
  if (!payload || typeof payload !== 'object' || Array.isArray(payload))
    throw new Error('Expected a JSON object.');
  return payload;
}

export function auditStatement(
  organizationId: string,
  userId: string,
  action: string,
  entityId: string,
) {
  return env.DB.prepare(
    'INSERT INTO audit_events (id, organization_id, actor_user_id, action, entity_type, entity_id, occurred_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
  ).bind(
    crypto.randomUUID(),
    organizationId,
    userId,
    action,
    'employer_tools',
    entityId,
    Date.now(),
  );
}

export function failure(error: unknown) {
  return json(
    {
      error:
        error instanceof Error
          ? error.message
          : 'Could not save. Please retry.',
    },
    400,
  );
}
