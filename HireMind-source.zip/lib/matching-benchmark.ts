import {
  assessCandidateEvidence,
  MATCHING_ENGINE_VERSION,
  type ScreeningCriterion,
} from './evidence-screening.ts';
import { compareRankings, validateComparison, type BenchmarkComparison } from './benchmark-comparison.ts';

export type BenchmarkCase = {
  id: string;
  jobId: string;
  profile: Record<string, unknown>;
  criteria: ScreeningCriterion[];
  relevance: number;
};
export type BenchmarkDataset = {
  name: string;
  labelSource: string;
  heldOut: boolean;
  consentConfirmed: boolean;
  cases: BenchmarkCase[];
  comparison?: BenchmarkComparison;
};

export function validateBenchmark(value: unknown): BenchmarkDataset {
  if (!value || typeof value !== 'object')
    throw new Error('Upload a benchmark JSON object.');
  const data = value as BenchmarkDataset;
  if (
    typeof data.name !== 'string' ||
    !data.name.trim() ||
    data.name.length > 120 ||
    typeof data.labelSource !== 'string' ||
    data.labelSource.trim().length < 12 ||
    data.labelSource.length > 600
  )
    throw new Error('Provide a dataset name and describe who labeled it.');
  if (data.consentConfirmed !== true || typeof data.heldOut !== 'boolean')
    throw new Error(
      'Confirm authorization to use these profiles and declare whether they were held out from tuning.',
    );
  if (
    !Array.isArray(data.cases) ||
    data.cases.length < 2 ||
    data.cases.length > 200
  )
    throw new Error('Use between 2 and 200 labeled résumé/job cases.');
  const ids = new Set<string>();
  const rubrics = new Map<string, string>();
  for (const item of data.cases) {
    if (
      !item ||
      typeof item.id !== 'string' ||
      !item.id.trim() ||
      item.id.length > 100 ||
      ids.has(item.id) ||
      typeof item.jobId !== 'string' ||
      !item.jobId.trim() ||
      item.jobId.length > 100
    )
      throw new Error('Each case needs a unique ID and a job ID.');
    ids.add(item.id);
    if (
      !Number.isInteger(item.relevance) ||
      item.relevance < 0 ||
      item.relevance > 3
    )
      throw new Error(
        'Human relevance labels must be integers: 0 unsuitable, 1 limited, 2 relevant, 3 strongly relevant.',
      );
    if (
      !item.profile ||
      typeof item.profile !== 'object' ||
      Array.isArray(item.profile) ||
      !Array.isArray(item.criteria) ||
      !item.criteria.length ||
      item.criteria.length > 20
    )
      throw new Error(
        'Each case needs a structured profile and 1–20 criteria.',
      );
    const criterionIds = new Set<string>();
    for (const criterion of item.criteria) {
      if (
        !criterion ||
        typeof criterion.id !== 'string' ||
        criterionIds.has(criterion.id) ||
        typeof criterion.label !== 'string' ||
        !criterion.label.trim() ||
        criterion.label.length > 500 ||
        !Number.isFinite(criterion.weight) ||
        criterion.weight <= 0 ||
        criterion.weight > 100 ||
        !['essential', 'preferred'].includes(criterion.requirementClass) ||
        (criterion.evidenceDefinition !== null &&
          typeof criterion.evidenceDefinition !== 'string') ||
        (criterion.equivalentSignalsJson !== null &&
          typeof criterion.equivalentSignalsJson !== 'string')
      )
        throw new Error(
          'Invalid criterion: provide a unique ID, label, positive weight, essential/preferred class, and nullable text definitions/signals.',
        );
      criterionIds.add(criterion.id);
    }
    const rubric = JSON.stringify(item.criteria);
    if (rubrics.has(item.jobId) && rubrics.get(item.jobId) !== rubric)
      throw new Error(
        'All candidates for the same job must use the same ordered rubric.',
      );
    rubrics.set(item.jobId, rubric);
  }
  validateComparison(data);
  return data;
}

type BenchmarkResult = {
  id: string;
  score: number;
  relevance: number;
  decisionBand: string;
  disagreement: 'strong_match_with_low_label' | 'relevant_not_strong' | null;
  criteria: Array<{ label: string; score: number; explanation: string }>;
};

export function evaluateBenchmark(data: BenchmarkDataset) {
  const groups = new Map<string, BenchmarkResult[]>();
  for (const item of data.cases) {
    const group = groups.get(item.jobId) ?? [];
    const assessment = assessCandidateEvidence(item.profile, item.criteria);
    const selected = assessment.decisionBand === 'strong_match';
    group.push({
      id: item.id,
      score: assessment.fitScore,
      relevance: item.relevance,
      decisionBand: assessment.decisionBand,
      disagreement:
        selected && item.relevance < 2
          ? 'strong_match_with_low_label'
          : !selected && item.relevance >= 2
            ? 'relevant_not_strong'
            : null,
      criteria: assessment.criterionResults.map(
        ({ label, score, explanation }) => ({ label, score, explanation }),
      ),
    });
    groups.set(item.jobId, group);
  }
  const jobs = [...groups].map(([jobId, items]) => {
    const ranked = [...items].sort((a, b) => b.score - a.score);
    const k = Math.min(5, ranked.length);
    const qualified = items.filter((item) => item.relevance >= 2).length;
    const retrieved = ranked
      .slice(0, k)
      .filter((item) => item.relevance >= 2).length;
    const dcg = (list: typeof items) =>
      list
        .slice(0, 10)
        .reduce(
          (sum, item, index) =>
            sum + (2 ** item.relevance - 1) / Math.log2(index + 2),
          0,
        );
    const ideal = dcg([...items].sort((a, b) => b.relevance - a.relevance));
    const ties = items.length !== new Set(items.map((item) => item.score)).size;
    return {
      jobId,
      count: items.length,
      k,
      precisionAtK: retrieved / k,
      recallAtK: qualified ? retrieved / qualified : null,
      ndcgAt10: ideal ? dcg(ranked) / ideal : null,
      ties,
      ranked,
    };
  });
  const mean = (key: 'precisionAtK' | 'recallAtK' | 'ndcgAt10') => {
    const values = jobs
      .map((job) => job[key])
      .filter((value): value is number => value !== null);
    return values.length
      ? values.reduce((sum, value) => sum + value, 0) / values.length
      : null;
  };
  const evaluated = [...groups.values()].flat();
  const strong = evaluated.filter(
    (item) => item.decisionBand === 'strong_match',
  );
  const relevant = evaluated.filter((item) => item.relevance >= 2);
  const truePositives = strong.filter((item) => item.relevance >= 2).length;
  const selectionDiagnostics = {
    rule: 'Strong match: score at least 75 with no essential criterion below 45. Relevant human label: 2 or 3.',
    truePositives,
    falsePositives: strong.length - truePositives,
    falseNegatives: relevant.length - truePositives,
    trueNegatives:
      evaluated.length - strong.length - relevant.length + truePositives,
    precision: strong.length ? truePositives / strong.length : null,
    recall: relevant.length ? truePositives / relevant.length : null,
  };
  return {
    engineVersion: MATCHING_ENGINE_VERSION,
    evaluatedAt: Date.now(),
    name: data.name.trim(),
    labelSource: data.labelSource.trim(),
    heldOut: data.heldOut,
    caseCount: data.cases.length,
    jobCount: jobs.length,
    precisionAtK: mean('precisionAtK'),
    recallAtK: mean('recallAtK'),
    ndcgAt10: mean('ndcgAt10'),
    selectionDiagnostics,
    comparison: compareRankings(data, jobs),
    jobs,
    limitations: [
      'Measures agreement with supplied human labels, not future job performance.',
      'Strong-match diagnostics are pooled across cases, unlike per-job ranking metrics. A relevant profile below the strong-match threshold still receives human review, not automatic rejection.',
      'Label independence, consent, and held-out status are declared by the uploader, not independently verified.',
      'Precision/recall use the top 5 or all candidates when fewer than 5. Ties preserve input order.',
      'Small or unrepresentative datasets cannot establish general accuracy or competitor superiority.',
    ],
  };
}
