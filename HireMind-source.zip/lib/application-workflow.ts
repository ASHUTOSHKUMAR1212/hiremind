export const APPLICATION_STATUSES = [
  'submitted',
  'in_review',
  'shortlisted',
  'interview',
  'offer',
  'hired',
  'rejected',
  'withdrawn',
] as const;

export type ApplicationStatus = (typeof APPLICATION_STATUSES)[number];

const TRANSITIONS: Record<ApplicationStatus, ReadonlySet<ApplicationStatus>> = {
  submitted: new Set([
    'in_review',
    'shortlisted',
    'interview',
    'rejected',
    'withdrawn',
  ]),
  in_review: new Set([
    'shortlisted',
    'interview',
    'offer',
    'rejected',
    'withdrawn',
  ]),
  shortlisted: new Set([
    'in_review',
    'interview',
    'offer',
    'rejected',
    'withdrawn',
  ]),
  interview: new Set(['in_review', 'offer', 'rejected', 'withdrawn']),
  offer: new Set(['hired', 'rejected', 'withdrawn']),
  hired: new Set(),
  rejected: new Set(),
  withdrawn: new Set(),
};

export function isApplicationStatus(
  value: unknown,
): value is ApplicationStatus {
  return (
    typeof value === 'string' &&
    APPLICATION_STATUSES.includes(value as ApplicationStatus)
  );
}

export function canTransitionApplication(from: string, to: string) {
  return (
    isApplicationStatus(from) &&
    isApplicationStatus(to) &&
    TRANSITIONS[from].has(to)
  );
}

export function applicationStage(status: ApplicationStatus) {
  if (status === 'shortlisted') return 'shortlist';
  if (status === 'in_review') return 'review';
  if (status === 'offer' || status === 'hired') return 'decision';
  return status;
}

export function applicationEventType(status: ApplicationStatus) {
  if (status === 'offer') return 'offer_recorded';
  if (status === 'hired') return 'candidate_hired';
  if (status === 'rejected') return 'application_rejected';
  if (status === 'withdrawn') return 'application_withdrawn';
  return 'application_stage_changed';
}
