import {
  hasExplicitDenial,
  positiveEvidenceText,
} from './evidence-language.ts';
import { hasValidDocxContainer } from './file-security.ts';
import { isProfileName, isProfilePhone } from './profile-quality.ts';
import { findSkillSpans, SKILL_SYNONYM_GROUPS } from './skills-context.ts';

const textDecoder = new TextDecoder('latin1');

export type ResumeProfileImport = {
  fullName: string;
  phone: string;
  headline: string;
  summary: string;
  location: string;
  skills: string[];
  experiences: Array<{
    title: string;
    organizationName: string;
    description: string;
    startedOn: string;
    endedOn: string;
    isCurrent: boolean;
  }>;
  education: Array<{
    institution: string;
    qualification: string;
    fieldOfStudy: string;
    startedOn: string;
    endedOn: string;
  }>;
  projects: Array<{
    title: string;
    description: string;
    projectUrl: string;
    repositoryUrl: string;
    skills: string[];
  }>;
  detectedSections: {
    summary: boolean;
    skills: boolean;
    experience: boolean;
    education: boolean;
    projects: boolean;
  };
  warnings: string[];
};

export async function extractResumeText(file: File) {
  const name = file.name.toLowerCase();
  const bytes = new Uint8Array(await file.arrayBuffer());
  let text = '';
  if (file.type === 'application/pdf' || name.endsWith('.pdf'))
    text = await extractPdf(bytes);
  else if (name.endsWith('.docx')) text = await extractDocx(bytes);
  else text = extractPrintableText(bytes);
  return normalize(text).slice(0, 50_000);
}

async function extractDocx(bytes: Uint8Array) {
  if (!hasValidDocxContainer(bytes))
    throw new Error('Invalid or unsupported Word document.');
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const eocd = findSignature(
    view,
    0x06054b50,
    bytes.length - 22,
    Math.max(0, bytes.length - 65_557),
  );
  if (eocd < 0) return '';
  const centralOffset = view.getUint32(eocd + 16, true);
  const entries = view.getUint16(eocd + 10, true);
  let cursor = centralOffset;
  for (
    let index = 0;
    index < entries && cursor + 46 <= bytes.length;
    index += 1
  ) {
    if (view.getUint32(cursor, true) !== 0x02014b50) break;
    const method = view.getUint16(cursor + 10, true);
    const compressedSize = view.getUint32(cursor + 20, true);
    const nameLength = view.getUint16(cursor + 28, true);
    const extraLength = view.getUint16(cursor + 30, true);
    const commentLength = view.getUint16(cursor + 32, true);
    const localOffset = view.getUint32(cursor + 42, true);
    const filename = new TextDecoder().decode(
      bytes.subarray(cursor + 46, cursor + 46 + nameLength),
    );
    if (filename === 'word/document.xml') {
      const localNameLength = view.getUint16(localOffset + 26, true);
      const localExtraLength = view.getUint16(localOffset + 28, true);
      const start = localOffset + 30 + localNameLength + localExtraLength;
      const compressed = bytes.subarray(start, start + compressedSize);
      const xmlBytes =
        method === 0
          ? compressed
          : method === 8
            ? await inflate(compressed, 'deflate-raw')
            : new Uint8Array();
      const xml = new TextDecoder().decode(xmlBytes);
      return extractWordXmlText(xml);
    }
    cursor += 46 + nameLength + extraLength + commentLength;
  }
  return '';
}

/** Word splits words across styled runs. Only text nodes carry visible content;
 * position offsets, proofing metadata and drawing coordinates are not résumé text. */
export function extractWordXmlText(xml: string) {
  const visible = xml.replace(/<w:del\b[^>]*>[\s\S]*?<\/w:del>/g, '');
  return [
    ...visible.matchAll(
      /<w:t\b[^>]*>([\s\S]*?)<\/w:t>|<w:(?:tab|br|cr)\b[^>]*\/>|<\/w:p>/g,
    ),
  ]
    .map((match) =>
      match[1] !== undefined
        ? decodeEntities(match[1])
        : /<w:tab\b/.test(match[0])
          ? ' '
          : '\n',
    )
    .join('');
}

async function extractPdf(bytes: Uint8Array) {
  try {
    const pdfjs = await import('pdfjs-dist');
    pdfjs.GlobalWorkerOptions.workerSrc = new URL(
      '../node_modules/pdfjs-dist/build/pdf.worker.min.mjs',
      import.meta.url,
    ).toString();
    const loadingTask = pdfjs.getDocument({ data: new Uint8Array(bytes) });
    const document = await loadingTask.promise;
    const pages: string[] = [];

    for (let pageNumber = 1; pageNumber <= document.numPages; pageNumber += 1) {
      const page = await document.getPage(pageNumber);
      const content = await page.getTextContent();
      const textItems = content.items
        .filter(
          (
            item,
          ): item is Extract<(typeof content.items)[number], { str: string }> =>
            'str' in item && Boolean(item.str.trim()),
        )
        .map((item) => ({
          text: repairPdfToken(item.str.trim()),
          x: item.transform[4],
          y: item.transform[5],
          width: item.width,
        }));
      const lines: string[] = [];
      let line = '';
      let lineY = Number.NaN;
      let previousEnd = 0;
      textItems.forEach((item) => {
        const continuesLine =
          line && Math.abs(item.y - lineY) <= 5 && item.x >= previousEnd - 4;
        if (!continuesLine) {
          if (line.trim()) lines.push(line.trim());
          line = item.text;
          lineY = item.y;
          previousEnd = item.x + item.width;
          return;
        }
        const gap = item.x - previousEnd;
        const separator =
          gap <= 2 || /^[,.;:!?%)\]}]/.test(item.text) ? '' : ' ';
        line += `${separator}${item.text}`;
        previousEnd = item.x + item.width;
      });
      if (line.trim()) lines.push(line.trim());
      pages.push(lines.join('\n'));
    }

    await loadingTask.destroy();
    return pages.join('\n\n');
  } catch {
    return extractPdfFallback(bytes);
  }
}

async function extractPdfFallback(bytes: Uint8Array) {
  const source = textDecoder.decode(bytes);
  const blocks: string[] = [source];
  const streamPattern = /stream\r?\n([\s\S]*?)\r?\nendstream/g;
  for (const match of source.matchAll(streamPattern)) {
    const dictionary = source.slice(
      Math.max(0, (match.index ?? 0) - 700),
      match.index,
    );
    if (!/FlateDecode/.test(dictionary)) continue;
    const binary = latin1Bytes(match[1]);
    try {
      blocks.push(textDecoder.decode(await inflate(binary, 'deflate')));
    } catch {
      try {
        blocks.push(textDecoder.decode(await inflate(binary, 'deflate-raw')));
      } catch {
        /* Unsupported stream. */
      }
    }
  }
  return blocks.map(extractPdfOperators).join('\n');
}

export function parseResumeProfile(text: string): ResumeProfileImport {
  const normalizedText = normalize(text);
  const lines = normalizedText
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean);
  const sections = collectSections(lines);
  const firstSection = lines.findIndex(
    (line) => classifyHeading(line) || splitInlineHeading(line),
  );
  const contactLines = lines.slice(
    0,
    firstSection < 0 ? 14 : Math.min(14, firstSection),
  );
  const fullName = contactLines.find(isLikelyName) ?? '';
  const phone = extractPhone(contactLines);
  const headline =
    contactLines.find((line) => line !== fullName && isLikelyHeadline(line)) ??
    '';
  const addressLine = lines.find((line) => /^address\s*:/i.test(line));
  const location =
    addressLine
      ?.replace(/^address\s*:\s*/i, '')
      .replace(/\s+,/g, ',')
      .replace(/[,\s]+$/, '')
      .trim() ||
    contactLines.find(isLikelyLocation) ||
    '';
  const summary = (sections.summary ?? []).join(' ').slice(0, 1200);
  const skillSection = sections.skills ?? [];
  const explicitSkills = skillSection
    .flatMap((line) => line.split(/[,|•·;:]|\s{2,}/))
    .map(cleanSkill)
    .filter(Boolean);
  const lower = positiveEvidenceText(normalizedText).toLowerCase();
  const detectedSkills = unique(findSkillSpans(lower, RESUME_SKILL_GROUPS).map(({ skill }) =>
    KNOWN_SKILLS.find(({ label, aliases }) =>
      [label, ...aliases].some((alias) => alias.toLowerCase() === skill),
    )?.label ?? skill,
  ));
  const experiences = parseExperiences(sections.experience ?? []);
  const education = parseEducation(sections.education ?? []);
  const projects = parseProjects(sections.projects ?? [], detectedSkills);
  const warnings = [
    sections.experience && !experiences.length
      ? 'Work experience was found, but its roles or dates need manual review.'
      : '',
    experiences.some(
      (item) => item.startedOn && item.endedOn && item.startedOn > item.endedOn,
    )
      ? 'One work date range appears reversed in the résumé and needs review.'
      : '',
    experiences.some((item) => !item.startedOn)
      ? 'A work entry has no readable dates. Confirm its dates before saving.'
      : '',
    sections.education && !education.length
      ? 'Education was found, but its institution or qualification needs manual review.'
      : '',
    sections.projects && !projects.length
      ? 'Projects were found, but their titles or descriptions need manual review.'
      : '',
    !summary ? 'No clearly labelled summary section was found.' : '',
    !sections.experience
      ? 'No work-history section was recognized. Check that any employment details in the document were imported.'
      : '',
    !sections.education
      ? 'No education section was recognized. Check the document before leaving this section empty.'
      : '',
  ].filter(Boolean);

  return {
    fullName,
    phone: phone.slice(0, 30),
    headline,
    summary,
    location,
    skills: unique([...explicitSkills, ...detectedSkills]).slice(0, 30),
    experiences,
    education,
    projects,
    detectedSections: {
      summary: Boolean(sections.summary?.length),
      skills: Boolean(sections.skills?.length || detectedSkills.length),
      experience: Boolean(sections.experience),
      education: Boolean(sections.education),
      projects: Boolean(sections.projects),
    },
    warnings,
  };
}

const SECTION_HEADINGS = new Set([
  'executive summary',
  'career summary',
  'skills summary',
  'professional skills',
  'work history',
  'employment',
  'career history',
  'professional background',
  'education and training',
  'education & training',
  'educational background',
  'academic qualifications',
  'summary',
  'professional summary',
  'profile',
  'profile summary',
  'objective',
  'about me',
  'skills',
  'technical skills',
  'core skills',
  'key skills',
  'competencies',
  'experience',
  'work experience',
  'professional experience',
  'employment history',
  'education',
  'academic background',
  'projects',
  'personal projects',
  'academic projects',
  'certifications',
  'achievements',
  'awards',
  'languages',
  'interests',
  'volunteering',
  'publications',
  'areas of expertise',
  'soft skills',
  'personal details',
]);

const KNOWN_SKILLS = [
  { label: 'JavaScript', aliases: ['javascript', 'js'] },
  { label: 'TypeScript', aliases: ['typescript'] },
  { label: 'React', aliases: ['react', 'react.js', 'reactjs'] },
  { label: 'React Native', aliases: ['react native'] },
  { label: 'Next.js', aliases: ['next.js', 'nextjs'] },
  { label: 'Node.js', aliases: ['node.js', 'nodejs'] },
  { label: 'Python', aliases: ['python'] },
  { label: 'Java', aliases: ['java'] },
  { label: 'C++', aliases: ['c++'] },
  { label: 'C#', aliases: ['c#'] },
  { label: 'SQL', aliases: ['sql'] },
  { label: 'PostgreSQL', aliases: ['postgresql', 'postgres'] },
  { label: 'MySQL', aliases: ['mysql'] },
  { label: 'MongoDB', aliases: ['mongodb'] },
  { label: 'AWS', aliases: ['aws', 'amazon web services'] },
  { label: 'Azure', aliases: ['azure'] },
  { label: 'Docker', aliases: ['docker'] },
  { label: 'Kubernetes', aliases: ['kubernetes'] },
  { label: 'Git', aliases: ['git', 'github', 'gitlab'] },
  { label: 'REST APIs', aliases: ['rest api', 'restful api'] },
  { label: 'GraphQL', aliases: ['graphql'] },
  { label: 'Machine learning', aliases: ['machine learning', 'ml'] },
  { label: 'Data analysis', aliases: ['data analysis', 'data analytics'] },
  { label: 'Power BI', aliases: ['power bi', 'powerbi'] },
  { label: 'Tableau', aliases: ['tableau'] },
  { label: 'Excel', aliases: ['excel', 'microsoft excel'] },
  { label: 'Figma', aliases: ['figma'] },
  { label: 'User research', aliases: ['user research', 'ux research'] },
  { label: 'Product management', aliases: ['product management'] },
  { label: 'Project management', aliases: ['project management'] },
  { label: 'Agile', aliases: ['agile', 'scrum'] },
  { label: 'Communication', aliases: ['communication'] },
  { label: 'Stakeholder management', aliases: ['stakeholder management'] },
];

// Keep legacy import labels while sharing longest-span alias resolution with scoring.
const RESUME_SKILL_GROUPS = [
  ...SKILL_SYNONYM_GROUPS,
  ...KNOWN_SKILLS.map(({ label, aliases }) => [label.toLowerCase(), ...aliases]),
];

type ResumeSection =
  | 'summary'
  | 'skills'
  | 'experience'
  | 'education'
  | 'projects'
  | 'other';

function collectSections(lines: string[]) {
  const sections: Partial<Record<ResumeSection, string[]>> = {};
  let current: ResumeSection | null = null;
  lines.forEach((line) => {
    const inline = splitInlineHeading(line);
    if (inline) {
      current = inline.section;
      if (inline.content)
        sections[current] = [...(sections[current] ?? []), inline.content];
      return;
    }
    const heading = classifyHeading(line);
    if (heading) {
      current = heading;
      return;
    }
    if (current) sections[current] = [...(sections[current] ?? []), line];
  });
  return sections;
}

function splitInlineHeading(
  value: string,
): { section: ResumeSection; content: string } | null {
  if (classifyHeading(value)) return null;
  const match =
    value.match(/^([^:|–—]{2,50})\s*[:|–—]\s*(.+)$/) ??
    value.match(
      /^(executive summary|professional summary|profile summary|summary|skills summary|technical skills|skills|work experience|professional experience|employment history|work history|education and training|education|academic background)\s+(.+)$/i,
    ) ??
    value.match(/^(WORK)\s+(.+)$/);
  if (!match) return null;
  const section = classifyHeading(match[1]);
  return section ? { section, content: match[2].trim() } : null;
}

function classifyHeading(value: string): ResumeSection | null {
  const heading = normalizeHeading(value);
  if (
    [
      'summary',
      'professional summary',
      'profile',
      'profile summary',
      'objective',
      'about me',
      'executive summary',
      'career summary',
    ].includes(heading)
  )
    return 'summary';
  if (
    [
      'skills',
      'technical skills',
      'core skills',
      'key skills',
      'competencies',
      'skills summary',
      'professional skills',
    ].includes(heading)
  )
    return 'skills';
  if (
    [
      'experience',
      'work',
      'work experience',
      'professional experience',
      'employment history',
      'work history',
      'employment',
      'career history',
      'professional background',
    ].includes(heading)
  )
    return 'experience';
  if (
    [
      'education',
      'academic background',
      'education and training',
      'education & training',
      'educational background',
      'academic qualifications',
    ].includes(heading)
  )
    return 'education';
  if (['projects', 'personal projects', 'academic projects'].includes(heading))
    return 'projects';
  if (SECTION_HEADINGS.has(heading)) return 'other';
  return null;
}

function normalizeHeading(value: string) {
  return value.toLowerCase().replace(/[:|]/g, '').replace(/\s+/g, ' ').trim();
}

function cleanSkill(value: string) {
  const cleaned = value
    .replace(/^[-–—•·\s]+/, '')
    .replace(/\s+/g, ' ')
    .trim();
  if (
    cleaned.length < 2 ||
    cleaned.length > 45 ||
    cleaned.split(' ').length > 6 ||
    /[!?]/.test(cleaned) ||
    hasExplicitDenial(cleaned) ||
    SECTION_HEADINGS.has(normalizeHeading(cleaned))
  )
    return '';
  return cleaned;
}

function isLikelyName(value: string) {
  const normalized = normalizeHeading(value);
  const words = value.trim().split(/\s+/);
  return (
    words.length >= 2 &&
    words.length <= 5 &&
    value.length <= 70 &&
    /^[\p{L} .'-]+$/u.test(value) &&
    !SECTION_HEADINGS.has(normalized) &&
    isProfileName(value) &&
    !/resume|curriculum|developer|engineer|manager|analyst|designer|student/i.test(
      value,
    )
  );
}

function isLikelyHeadline(value: string) {
  return (
    value.length >= 4 &&
    value.length <= 120 &&
    !classifyHeading(value) &&
    !/@|https?:|www\.|linkedin|github/i.test(value) &&
    !extractPhone([value]) &&
    !isLikelyLocation(value) &&
    !DATE_RANGE.test(value)
  );
}

function isLikelyLocation(value: string) {
  return (
    value.length <= 80 &&
    /[\p{L}]{2,}\s*,\s*[\p{L}]{2,}/u.test(value) &&
    !KNOWN_SKILLS.some((skill) =>
      skill.aliases.some((alias) => containsTerm(value.toLowerCase(), alias)),
    ) &&
    !/@|https?:|www\.|linkedin|github/i.test(value) &&
    !DATE_RANGE.test(value)
  );
}

function extractPhone(lines: string[]) {
  for (const line of lines) {
    for (const match of line.matchAll(/\+?\d[\d\s().-]{7,}\d/g)) {
      const digits = match[0].replace(/\D/g, '');
      if (isProfilePhone(match[0]) && !/^19\d{2}20\d{2}$/.test(digits))
        return match[0].replace(/\s+/g, ' ').trim();
    }
  }
  return '';
}

const MONTH_PATTERN =
  '(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)';
const MONTH_DATE_PATTERN = `${MONTH_PATTERN}(?:\\s*(?:\\d{4}|\\d{1,2}(?:st|nd|rd|th)(?:\\s*\\d{4})?))?`;
const NUMERIC_DATE_PATTERN =
  '(?:0?[1-9]|1[0-2])[/.]\\d{4}|\\d{4}[/.](?:0?[1-9]|1[0-2])';
const DATE_RANGE = new RegExp(
  `(${NUMERIC_DATE_PATTERN}|${MONTH_DATE_PATTERN}|\\d{4})\\s*(?:-|–|—|to)\\s*((?:present|current|now)|${NUMERIC_DATE_PATTERN}|${MONTH_DATE_PATTERN}|\\d{4})(?:\\s*\\((\\d{4})\\))?`,
  'i',
);
const ROLE_PATTERN =
  /engineer|developer|\bdev\b|designer|manager|analyst|consultant|intern|specialist|lead|director|associate|coordinator|officer|executive|architect|researcher/i;

function parseExperiences(lines: string[]): ResumeProfileImport['experiences'] {
  const blocks = parseDatedBlocks(lines);
  if (!blocks.length) {
    const starts = lines
      .map((line, index) => ({ line, index }))
      .filter(
        ({ line }) =>
          !isBullet(line) &&
          (isShortLabel(line) || (/^\d{4}/.test(line) && line.length < 150)) &&
          ROLE_PATTERN.test(line),
      );
    starts.forEach(({ line, index }, order) => {
      const previous =
        index > 0 &&
        !isBullet(lines[index - 1]) &&
        isShortLabel(lines[index - 1]) &&
        !/[.!?]$/.test(lines[index - 1])
          ? lines[index - 1]
          : '';
      const end = starts[order + 1]?.index ?? lines.length;
      blocks.push({
        header: previous ? [previous, line] : [line],
        body: lines.slice(index + 1, end),
        startedOn: '',
        endedOn: '',
        isCurrent: false,
      });
    });
  }
  return blocks
    .map((block) => {
      const header = block.header.flatMap(splitHeader).filter(Boolean);
      const titleIndex = header.findIndex((value) => ROLE_PATTERN.test(value));
      const bodyLabel =
        block.body[0]
          ?.replace(/^[^\p{L}\p{N}]+/u, '')
          .split(':')[0]
          .trim() ?? '';
      const title =
        header[titleIndex] ??
        ((/^[\p{L}][\p{L} /&-]{2,80}$/u.test(bodyLabel) ? bodyLabel : '') ||
          'Professional experience');
      const organizationName =
        header.find((_, index) => index !== titleIndex) ?? '';
      return {
        title: title.slice(0, 140),
        organizationName: organizationName.slice(0, 140),
        description: cleanDescription(block.body),
        startedOn: block.startedOn,
        endedOn: block.endedOn,
        isCurrent: block.isCurrent,
      };
    })
    .filter(
      (item) => item.title && (item.organizationName || item.description),
    );
}

function parseEducation(lines: string[]): ResumeProfileImport['education'] {
  const yearAnchors = lines
    .map((line, index) => ({
      line,
      index,
      year:
        line.match(/^(?:19|20)\s*\d{2}\s*[:|-]/)?.[0].replace(/\D/g, '') ?? '',
    }))
    .filter((item) => item.year.length === 4);
  if (yearAnchors.length) {
    return yearAnchors
      .map((anchor, index) => {
        const end = yearAnchors[index + 1]?.index ?? lines.length;
        const text = [
          anchor.line.replace(/^(?:19|20)\s*\d{2}\s*[:|-]\s*/, ''),
          ...lines.slice(anchor.index + 1, end),
        ]
          .join(' ')
          .replace(/\s+/g, ' ')
          .trim();
        const parts = text.split(/\s+from\s+/i);
        const qualification = (parts.shift() ?? '').trim();
        const institution = parts
          .join(' from ')
          .replace(/\s*\([^)]*(?:%|cgpa|gpa)[^)]*\)\s*$/i, '')
          .trim();
        return {
          institution: institution.slice(0, 160),
          qualification: qualification.slice(0, 120),
          fieldOfStudy: extractFieldOfStudy(qualification),
          startedOn: `${anchor.year}-01`,
          endedOn: `${anchor.year}-01`,
        };
      })
      .filter((item) => item.institution || item.qualification);
  }
  const blocks = parseDatedBlocks(lines);
  if (!blocks.length && lines.length)
    blocks.push({
      header: lines.slice(0, 2),
      body: lines.slice(2),
      startedOn: '',
      endedOn: '',
      isCurrent: false,
    });
  return blocks
    .map((block) => {
      const header = block.header.flatMap(splitHeader).filter(Boolean);
      const qualificationIndex = header.findIndex((value) =>
        /bachelor|master|b\.?tech|m\.?tech|b\.?e\.?|m\.?e\.?|bsc|msc|mba|degree|diploma|certificate|ph\.?d/i.test(
          value,
        ),
      );
      const qualification = header[qualificationIndex] ?? '';
      const institution =
        header.find((_, index) => index !== qualificationIndex) ?? '';
      return {
        institution: institution.slice(0, 160),
        qualification: qualification.slice(0, 120),
        fieldOfStudy: extractFieldOfStudy(qualification),
        startedOn: block.startedOn,
        endedOn: block.endedOn,
      };
    })
    .filter((item) => item.institution);
}

function parseProjects(
  lines: string[],
  detectedSkills: string[],
): ResumeProfileImport['projects'] {
  if (!lines.length) return [];
  const starts = lines
    .map((line, index) => ({ line, index }))
    .filter(
      ({ line, index }) =>
        !/^(?:tools|skills|technologies)\s*:/i.test(line) &&
        (index === 0 ||
          (isShortLabel(line) &&
            !isBullet(line) &&
            !DATE_RANGE.test(line) &&
            !/^https?:/i.test(line) &&
            (isBullet(lines[index + 1] ?? '') ||
              (lines[index + 1]?.length ?? 0) > 90 ||
              /^(?:tools|skills|technologies)\s*:/i.test(
                lines[index + 1] ?? '',
              ) ||
              /https?:/i.test(lines[index + 1] ?? '')))),
    );
  return starts
    .slice(0, 12)
    .map(({ line, index }, itemIndex) => {
      const end = starts[itemIndex + 1]?.index ?? lines.length;
      const body = lines.slice(index + 1, end);
      const urls = body.flatMap(
        (value) => value.match(/https?:\/\/\S+/gi) ?? [],
      );
      const projectSkills = detectedSkills.filter((skill) =>
        containsTerm(
          `${line} ${body.join(' ')}`.toLowerCase(),
          skill.toLowerCase(),
        ),
      );
      return {
        title: line.replace(/^[-–—•·\s]+/, '').slice(0, 160),
        description: cleanDescription(body),
        projectUrl: urls.find((url) => !/github\.com/i.test(url)) ?? '',
        repositoryUrl:
          urls.find((url) => /github\.com|gitlab\.com/i.test(url)) ?? '',
        skills: projectSkills.slice(0, 20),
      };
    })
    .filter((item) => item.title && item.description);
}

function parseDatedBlocks(lines: string[]) {
  const anchors = lines
    .map((line, index) => ({ line, index, match: line.match(DATE_RANGE) }))
    .filter((item) => item.match)
    .map((anchor) => {
      const prefix = anchor.line
        .slice(0, anchor.match?.index ?? 0)
        .replace(/[-–—|,\s]+$/, '')
        .trim();
      let start = anchor.index;
      if (!prefix) {
        for (
          let index = anchor.index - 1;
          index >= Math.max(0, anchor.index - 2);
          index--
        ) {
          if (
            isBullet(lines[index]) ||
            DATE_RANGE.test(lines[index]) ||
            !isShortLabel(lines[index]) ||
            /[.!?]$/.test(lines[index])
          )
            break;
          start = index;
        }
      }
      return { ...anchor, start, prefix };
    });
  return anchors.slice(0, 12).map((anchor, itemIndex) => {
    const nextAnchor = anchors[itemIndex + 1]?.start ?? lines.length;
    const candidates = anchor.prefix
      ? [anchor.prefix]
      : lines.slice(anchor.start, anchor.index);
    const body = lines.slice(anchor.index + 1, nextAnchor);
    const years = [...(anchor.match?.[0] ?? '').matchAll(/\d{4}/g)].map(
      (match) => match[0],
    );
    const fallbackYear = anchor.match?.[3] ?? years[years.length - 1] ?? '';
    const start = toMonth(anchor.match?.[1] ?? '', years[0] ?? fallbackYear);
    const endValue = anchor.match?.[2] ?? '';
    const isCurrent = /present|current|now/i.test(endValue);
    return {
      header: candidates.slice(-2),
      body,
      startedOn: start,
      endedOn: isCurrent ? '' : toMonth(endValue, fallbackYear),
      isCurrent,
    };
  });
}

function toMonth(value: string, fallbackYear = '') {
  const year = value.match(/\d{4}/)?.[0] ?? fallbackYear;
  if (!year) return '';
  const monthName = value
    .toLowerCase()
    .match(/jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec/)?.[0];
  const numericMonth =
    value.match(/^(\d{1,2})[/.]\d{4}$/)?.[1] ??
    value.match(/^\d{4}[/.](\d{1,2})$/)?.[1];
  const month = numericMonth
    ? numericMonth.padStart(2, '0')
    : monthName
      ? `${['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'].indexOf(monthName) + 1}`.padStart(
          2,
          '0',
        )
      : '01';
  return `${year}-${month}`;
}

function splitHeader(value: string) {
  return value.split(/\s+[|@]\s+|\s+[-–—]\s+/).map((part) => part.trim());
}
function isBullet(value: string) {
  return /^[-–—•·▪◦]/.test(value.trim());
}
function isShortLabel(value: string) {
  return (
    value.replace(/^[-–—•·\s]+/, '').length >= 2 &&
    value.length <= 90 &&
    value.split(/\s+/).length <= 10
  );
}
function cleanDescription(lines: string[]) {
  return lines
    .map((line) => line.replace(/^[^\p{L}\p{N}]+/u, '').trim())
    .filter(Boolean)
    .join(' ')
    .slice(0, 1500);
}
function extractFieldOfStudy(value: string) {
  return (
    value.match(/\bin\s+([\p{L}][\p{L}\s&-]{2,})/iu)?.[1] ??
    value.match(/\bof\s+([\p{L}][\p{L}\s&-]{2,})/iu)?.[1] ??
    ''
  )
    .trim()
    .slice(0, 120);
}

function containsTerm(text: string, term: string) {
  const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp(`(^|[^a-z0-9+#])${escaped}([^a-z0-9+#]|$)`, 'i').test(text);
}

function unique(values: string[]) {
  const seen = new Set<string>();
  return values.filter((value) => {
    const key = value.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function extractPdfOperators(content: string) {
  const sections = content.match(/BT[\s\S]*?ET/g) ?? [content];
  const text: string[] = [];
  for (const section of sections) {
    for (const match of section.matchAll(/\(((?:\\.|[^\\)])*)\)/g)) {
      const suffix = section.slice(
        (match.index ?? 0) + match[0].length,
        (match.index ?? 0) + match[0].length + 20,
      );
      if (/^\s*(?:Tj|'|"|\]|\))/i.test(suffix) || /TJ/.test(section))
        text.push(decodePdfString(match[1]));
    }
    for (const match of section.matchAll(/<([0-9a-fA-F]{4,})>\s*Tj/g))
      text.push(decodeHex(match[1]));
  }
  return text.join(' ');
}

function decodePdfString(value: string) {
  return value
    .replace(
      /\\([nrtbf()\\])/g,
      (_, code: string) =>
        ({
          n: '\n',
          r: '\r',
          t: '\t',
          b: '\b',
          f: '\f',
          '(': '(',
          ')': ')',
          '\\': '\\',
        })[code] ?? code,
    )
    .replace(/\\([0-7]{1,3})/g, (_, code: string) =>
      String.fromCharCode(parseInt(code, 8)),
    )
    .replace(/\\\r?\n/g, '');
}

function decodeHex(value: string) {
  const bytes = value.match(/.{2}/g)?.map((pair) => parseInt(pair, 16)) ?? [];
  const decoded = new Uint8Array(bytes);
  if (decoded[0] === 0xfe && decoded[1] === 0xff) {
    let result = '';
    for (let index = 2; index + 1 < decoded.length; index += 2)
      result += String.fromCharCode((decoded[index] << 8) | decoded[index + 1]);
    return result;
  }
  return textDecoder.decode(decoded);
}

async function inflate(bytes: Uint8Array, format: CompressionFormat) {
  const copy = new Uint8Array(bytes.length);
  copy.set(bytes);
  const stream = new Blob([copy])
    .stream()
    .pipeThrough(new DecompressionStream(format));
  const reader = stream.getReader();
  const chunks: Uint8Array[] = [];
  let length = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      length += value.length;
      if (length > 16 * 1024 * 1024) {
        await reader.cancel();
        throw new Error(
          'Document expands beyond the safe extraction limit. Export a smaller document.',
        );
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const result = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) {
    result.set(chunk, offset);
    offset += chunk.length;
  }
  return result;
}

function extractPrintableText(bytes: Uint8Array) {
  return textDecoder.decode(bytes).replace(/[^\x20-\x7e\r\n\t]+/g, ' ');
}

function latin1Bytes(value: string) {
  const result = new Uint8Array(value.length);
  for (let index = 0; index < value.length; index += 1)
    result[index] = value.charCodeAt(index) & 0xff;
  return result;
}

function findSignature(
  view: DataView,
  signature: number,
  start: number,
  end: number,
) {
  for (
    let offset = Math.min(start, view.byteLength - 4);
    offset >= end;
    offset -= 1
  )
    if (view.getUint32(offset, true) === signature) return offset;
  return -1;
}

function repairPdfToken(value: string) {
  return value
    .split('|')
    .map((segment) => {
      const tokens = segment.trim().split(/\s+/).filter(Boolean);
      if (
        tokens.length <= 1 ||
        !tokens.every((token) => /^\p{L}$/u.test(token))
      )
        return segment.trim();
      return tokens.join('').replace(/([\p{Ll}])([\p{Lu}])/gu, '$1 $2');
    })
    .join(' | ')
    .trim();
}

function decodeEntities(value: string) {
  return value
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");
}

function normalize(value: string) {
  return value
    .replaceAll('\u0000', ' ')
    .replace(/[ \t]+/g, ' ')
    .replace(/\s*\n\s*/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}
