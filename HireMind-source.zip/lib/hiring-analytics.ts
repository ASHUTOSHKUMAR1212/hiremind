import { APPLICATION_STATUSES } from './application-workflow.ts';

export const DAY_MS = 86_400_000;
export type AnalyticsApplication = {
  id: string;
  jobId: string;
  jobTitle: string;
  status: string;
  submittedAt: number;
};
export type AnalyticsEvent = {
  applicationId: string;
  fromStatus: string | null;
  toStatus: string | null;
  occurredAt: number;
};
export const STAGE_LABELS: Record<string, string> = {
  submitted: 'Submitted',
  in_review: 'Review',
  shortlisted: 'Shortlisted',
  interview: 'Interview',
  offer: 'Offer',
  hired: 'Hired',
  rejected: 'Rejected',
  withdrawn: 'Withdrawn',
};

function median(values: number[]) {
  if (!values.length) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return (
    Math.round(
      (sorted.length % 2
        ? sorted[middle]
        : (sorted[middle - 1] + sorted[middle]) / 2) * 10,
    ) / 10
  );
}
export function parseAnalyticsFilters(params: URLSearchParams, now: number) {
  const period = params.get('days') ?? '90';
  const age = params.get('ageDays') ?? '7';
  if (!['30', '90', '365'].includes(period))
    throw new Error('Choose a 30, 90, or 365 day application cohort.');
  if (!['3', '7', '14', '30'].includes(age))
    throw new Error('Choose an attention threshold of 3, 7, 14, or 30 days.');
  const jobId = params.get('jobId') ?? '';
  if (jobId.length > 128) throw new Error('Invalid job filter.');
  const format = params.get('format') ?? 'json';
  if (!['json', 'csv'].includes(format))
    throw new Error('Unsupported report format.');
  return {
    jobId,
    days: Number(period),
    ageDays: Number(age),
    since: now - Number(period) * DAY_MS,
    asOf: now,
    format,
  };
}

// Only observed states count. Skipped stages are not invented, and moving back
// into review resets its age rather than reusing the first review timestamp.
export function summarizeHiring(
  applications: AnalyticsApplication[],
  events: AnalyticsEvent[],
  asOf: number,
  ageDays: number,
) {
  const byApplication = new Map<string, AnalyticsEvent[]>();
  for (const event of events) {
    const list = byApplication.get(event.applicationId) ?? [];
    list.push(event);
    byApplication.set(event.applicationId, list);
  }
  const current: Record<string, number> = Object.fromEntries(
    APPLICATION_STATUSES.map((status) => [status, 0]),
  );
  const reached: Record<string, number> = { ...current };
  const reviewTimes: number[] = [],
    hireTimes: number[] = [];
  let active = 0,
    unknownAge = 0,
    unknownStatus = 0,
    offersHired = 0;
  const attention: Array<
    AnalyticsApplication & { ageDays: number; stageEnteredAt: number }
  > = [];
  const ages: Record<string, number[]> = {};
  for (const application of applications) {
    const validEvents = (byApplication.get(application.id) ?? [])
      .filter(
        (event) =>
          event.occurredAt >= application.submittedAt &&
          event.occurredAt <= asOf,
      )
      .sort((a, b) => a.occurredAt - b.occurredAt);
    const seen = new Set(['submitted', application.status]);
    for (const event of validEvents) {
      if (event.fromStatus) seen.add(event.fromStatus);
      if (event.toStatus) seen.add(event.toStatus);
    }
    for (const stage of seen) if (stage in reached) reached[stage]++;
    if (application.status in current) current[application.status]++;
    else unknownStatus++;
    const firstReview = validEvents.find(
      (event) =>
        event.toStatus === 'in_review' && event.fromStatus !== 'in_review',
    );
    if (firstReview)
      reviewTimes.push(
        (firstReview.occurredAt - application.submittedAt) / DAY_MS,
      );
    const firstHire = validEvents.find(
      (event) => event.toStatus === 'hired' && event.fromStatus !== 'hired',
    );
    if (application.status === 'hired' && firstHire)
      hireTimes.push((firstHire.occurredAt - application.submittedAt) / DAY_MS);
    if (application.status === 'hired' && seen.has('offer')) offersHired++;
    if (
      ['submitted', 'in_review', 'shortlisted', 'interview', 'offer'].includes(
        application.status,
      )
    ) {
      active++;
      const transitions = validEvents.filter(
        (event) => event.toStatus && event.fromStatus !== event.toStatus,
      );
      const latest = transitions.at(-1);
      const enteredAt =
        latest?.toStatus === application.status
          ? latest.occurredAt
          : application.status === 'submitted' && transitions.length === 0
            ? application.submittedAt
            : null;
      if (enteredAt === null) {
        unknownAge++;
        continue;
      }
      const elapsed = Math.max(0, (asOf - enteredAt) / DAY_MS);
      (ages[application.status] ??= []).push(elapsed);
      if (elapsed >= ageDays)
        attention.push({
          ...application,
          ageDays: Math.floor(elapsed),
          stageEnteredAt: enteredAt,
        });
    }
  }
  attention.sort((a, b) => b.ageDays - a.ageDays || a.id.localeCompare(b.id));
  return {
    total: applications.length,
    active,
    current,
    unknownStatus,
    stages: [
      'submitted',
      'in_review',
      'shortlisted',
      'interview',
      'offer',
      'hired',
    ].map((key) => ({
      key,
      label: STAGE_LABELS[key],
      reached: reached[key],
      current: current[key],
      cohortPercent: applications.length
        ? Math.round((reached[key] / applications.length) * 1000) / 10
        : null,
      medianCurrentAgeDays: median(ages[key] ?? []),
      ageSample: ages[key]?.length ?? 0,
    })),
    medianDaysToFirstReview: median(reviewTimes),
    firstReviewSample: reviewTimes.length,
    medianDaysToHire: median(hireTimes),
    hireSample: hireTimes.length,
    offerToHirePercent: reached.offer
      ? Math.round((offersHired / reached.offer) * 1000) / 10
      : null,
    offersObserved: reached.offer,
    offersHired,
    unknownAge,
    attentionCount: attention.length,
    attention,
  };
}

export type HiringSummary = ReturnType<typeof summarizeHiring>;
