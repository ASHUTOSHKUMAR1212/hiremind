import { SUPABASE_PUBLISHABLE_KEY, SUPABASE_URL } from './config';

export type HireMindIdentity = {
  userId: string;
  email: string;
  fullName: string | null;
};

export async function getHireMindIdentity(request: Request): Promise<HireMindIdentity | null> {
  const authorization = request.headers.get('authorization');
  if (!authorization?.startsWith('Bearer ')) return null;

  const response = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: {
      apikey: SUPABASE_PUBLISHABLE_KEY,
      authorization,
    },
  });
  if (!response.ok) return null;

  const user = await response.json() as {
    id?: string;
    email?: string;
    user_metadata?: { full_name?: string; name?: string };
  };
  if (!user.id || !user.email) return null;
  return {
    userId: user.id,
    email: user.email,
    fullName: user.user_metadata?.full_name ?? user.user_metadata?.name ?? null,
  };
}

