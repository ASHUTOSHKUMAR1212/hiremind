'use client';

import { createClient, type SupabaseClient } from '@supabase/supabase-js';

import { SUPABASE_PUBLISHABLE_KEY, SUPABASE_URL } from './config';

let browserClient: SupabaseClient | undefined;

export function getSupabaseBrowserClient() {
  browserClient ??= createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
    },
  });
  return browserClient;
}

function clearSupabaseAuthStorage() {
  const projectRef = new URL(SUPABASE_URL).hostname.split('.')[0];
  const storagePrefix = `sb-${projectRef}-auth-token`;

  for (let index = localStorage.length - 1; index >= 0; index -= 1) {
    const key = localStorage.key(index);
    if (key?.startsWith(storagePrefix)) localStorage.removeItem(key);
  }
}

export async function signOutAndRedirect(redirectTo = '/login') {
  const signOut = getSupabaseBrowserClient().auth
    .signOut({ scope: 'local' })
    .catch(() => undefined);

  await Promise.race([
    signOut,
    new Promise<void>((resolve) => window.setTimeout(resolve, 1_000)),
  ]);

  // Keep logout reliable even when the auth request is unavailable or stalled.
  clearSupabaseAuthStorage();
  window.location.replace(redirectTo);
}

export async function authenticatedFetch(input: RequestInfo | URL, init: RequestInit = {}) {
  const supabase = getSupabaseBrowserClient();
  const { data } = await supabase.auth.getSession();
  const accessToken = data.session?.access_token;
  const headers = new Headers(init.headers);
  if (accessToken) headers.set('authorization', `Bearer ${accessToken}`);
  return fetch(input, { ...init, headers });
}

export async function downloadAuthenticatedFile(fileId: string, filename: string) {
  const response = await authenticatedFetch(`/api/files?id=${encodeURIComponent(fileId)}`);
  if (!response.ok) {
    const result = await response.json().catch(() => ({})) as { error?: string };
    throw new Error(result.error ?? 'The file could not be downloaded. Please retry.');
  }
  const url = URL.createObjectURL(await response.blob());
  const anchor = document.createElement('a');
  anchor.href = url;
  const encodedName = response.headers.get('content-disposition')?.match(/filename\*=UTF-8''([^;]+)/i)?.[1];
  let name = filename;
  try { if (encodedName) name = decodeURIComponent(encodedName); } catch { /* Use the caller's filename. */ }
  anchor.download = name.replace(/[\\/\r\n]/g, '_') || 'resume';
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
}
