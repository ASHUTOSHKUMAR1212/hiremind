// Configure your own Supabase project before using authentication.
// Only a browser-safe publishable key belongs here, never a service-role key.
export const SUPABASE_URL = 'https://your-project.supabase.co';
export const SUPABASE_PUBLISHABLE_KEY = 'YOUR_SUPABASE_PUBLISHABLE_KEY';

