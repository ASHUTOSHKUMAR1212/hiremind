export const TALENT_PAGE_SIZE = 50;
export function talentSearchFilters(params: URLSearchParams, now = Date.now()) {
  const q = (params.get('q') ?? '').trim();
  const location = (params.get('location') ?? '').trim();
  const jobId = params.get('jobId') ?? '';
  if (!jobId || jobId.length > 128 || q.length > 160 || location.length > 100)
    throw new Error(
      'Choose a job and use search text under 160 characters and location under 100 characters.',
    );
  const terms = [...new Set(q.split(/\s+/).filter(Boolean))];
  if (terms.length > 6) throw new Error('Use up to six search words.');
  const raw = params.get('cursor');
  let cursor: { at: number; id: string; asOf: number } | null = null;
  if (raw) {
    if (raw.length > 1000)
      throw new Error('Invalid page cursor. Start a new search.');
    try {
      const value = JSON.parse(raw);
      if (
        !Number.isSafeInteger(value.at) ||
        !Number.isSafeInteger(value.asOf) ||
        value.at < 0 ||
        value.at > value.asOf ||
        value.asOf > now ||
        value.asOf < now - 86400000 ||
        typeof value.id !== 'string' ||
        !value.id ||
        value.id.length > 128
      )
        throw new Error();
      cursor = { at: value.at, id: value.id, asOf: value.asOf };
    } catch {
      throw new Error(
        'This search has expired or its page cursor is invalid. Start a new search.',
      );
    }
  }
  return { jobId, q, terms, location, cursor, asOf: cursor?.asOf ?? now };
}
