export const INTEGRATION_SCOPES = ['jobs:read', 'applications:read'] as const;

export async function hashIntegrationToken(token: string) {
  const hash = await crypto.subtle.digest(
    'SHA-256',
    new TextEncoder().encode(token),
  );
  return [...new Uint8Array(hash)]
    .map((value) => value.toString(16).padStart(2, '0'))
    .join('');
}

function escapeIcs(value: string) {
  return value
    .replace(/\\/g, '\\\\')
    .replace(/\r?\n/g, '\\n')
    .replace(/;/g, '\\;')
    .replace(/,/g, '\\,')
    .split('')
    .filter((char) => char.charCodeAt(0) >= 32 || char === '\t')
    .join('');
}
function icsTime(value: number) {
  return new Date(value)
    .toISOString()
    .replace(/[-:]/g, '')
    .replace(/\.\d{3}/, '');
}
function fold(line: string) {
  const lines: string[] = [];
  let current = '';
  let bytes = 0;
  for (const char of line) {
    const size = new TextEncoder().encode(char).length;
    if (bytes + size > 75) {
      lines.push(current);
      current = ' ';
      bytes = 1;
    }
    current += char;
    bytes += size;
  }
  lines.push(current);
  return lines.join('\r\n');
}
export function interviewCalendar(
  value: {
    id: string;
    jobTitle: string;
    companyName: string;
    scheduledAt: number;
    status: string;
    updatedAt: number;
    url: string;
  },
  durationMinutes = 60,
) {
  if (
    !Number.isFinite(value.scheduledAt) ||
    !Number.isFinite(value.updatedAt) ||
    !Number.isInteger(durationMinutes) ||
    durationMinutes < 15 ||
    durationMinutes > 240
  )
    throw new Error('Invalid interview calendar details.');
  const lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//HireMind//Interview Calendar//EN',
    'CALSCALE:GREGORIAN',
    'BEGIN:VEVENT',
    `UID:${escapeIcs(value.id)}@hiremind`,
    `DTSTAMP:${icsTime(value.updatedAt)}`,
    `LAST-MODIFIED:${icsTime(value.updatedAt)}`,
    `DTSTART:${icsTime(value.scheduledAt)}`,
    `DTEND:${icsTime(value.scheduledAt + durationMinutes * 60_000)}`,
    `SUMMARY:${escapeIcs(`Interview: ${value.jobTitle} · ${value.companyName}`)}`,
    `DESCRIPTION:${escapeIcs(`Open HireMind for the current interview status and joining instructions. Calendar duration (${durationMinutes} minutes) is your planning estimate. This file is not a live subscription.`)}`,
    `URL:${escapeIcs(value.url)}`,
    `STATUS:${value.status === 'cancelled' ? 'CANCELLED' : 'CONFIRMED'}`,
    'END:VEVENT',
    'END:VCALENDAR',
  ];
  return lines.map(fold).join('\r\n') + '\r\n';
}
