import { talentSearchFilters } from './talent-search.ts';

export const SAVED_TALENT_SEARCH_LIMIT = 20;
export function validateSavedTalentSearch(value: Record<string, unknown>) {
  if (
    typeof value.name !== 'string' ||
    !value.name.trim() ||
    value.name.trim().length > 60 ||
    Array.from(value.name).some(
      (character) =>
        character.charCodeAt(0) < 32 || character.charCodeAt(0) === 127,
    )
  )
    throw new Error(
      'Use a search name between 1 and 60 characters, without control characters.',
    );
  if (
    typeof value.jobId !== 'string' ||
    typeof value.q !== 'string' ||
    typeof value.location !== 'string'
  )
    throw new Error('Choose a job and supply text filters.');
  const { jobId, q, location } = talentSearchFilters(
    new URLSearchParams({
      jobId: value.jobId,
      q: value.q,
      location: value.location,
    }),
  );
  const name = value.name.trim();
  return { name, nameKey: name.toLowerCase(), jobId, q, location };
}
