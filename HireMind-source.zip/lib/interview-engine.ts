import { hasConcreteContribution, positiveEvidenceText } from './evidence-language.ts';

export type InterviewCriterion = {
  id: string;
  label: string;
  requirementClass: string;
  weight: number;
  evidenceDefinition: string;
  equivalentSignals: string[];
};

export type InterviewQuestion = {
  id: string;
  kind: 'opening' | 'criterion' | 'reflection' | 'follow_up';
  criterionId: string | null;
  criterionLabel: string;
  prompt: string;
  guidance: string;
  expectedSignals: string[];
  parentQuestionId?: string;
};

export type AnswerAssessment = {
  evidenceStrength: number;
  confidence: number;
  classification: 'substantive' | 'developing' | 'thin';
  dimensions: { relevance: number; specificity: number; ownership: number; outcome: number; reflection: number };
  matchedSignals: string[];
  missingSignals: string[];
  needsFollowUp: boolean;
  summary: string;
};

export function buildInterviewPlan(jobTitle: string, criteria: InterviewCriterion[]) {
  const prioritized = [...criteria].sort((first, second) => {
    if (first.requirementClass !== second.requirementClass) return first.requirementClass === 'essential' ? -1 : 1;
    return second.weight - first.weight;
  }).slice(0, 4);
  const questions: InterviewQuestion[] = [{
    id: 'opening_role_readiness', kind: 'opening', criterionId: null, criterionLabel: 'Role readiness',
    prompt: `Choose the experience, project, or piece of work that best demonstrates your readiness for the ${jobTitle} role. What was the context, what did you personally do, and what changed?`,
    guidance: 'A project, internship, freelance assignment, coursework, volunteer role, or paid job can all be relevant.',
    expectedSignals: ['context', 'action', 'result', 'learning'],
  }];
  prioritized.forEach((criterion, index) => questions.push({
    id: `criterion_${index + 1}_${safeId(criterion.id || criterion.label)}`, kind: 'criterion', criterionId: criterion.id,
    criterionLabel: criterion.label,
    prompt: `Tell us about one specific example that demonstrates ${criterion.label}. What was your contribution, how did you approach it, and what was the outcome?`,
    guidance: criterion.evidenceDefinition || 'Use an observable example and explain your own contribution.',
    expectedSignals: unique([criterion.label, criterion.evidenceDefinition, ...criterion.equivalentSignals]).filter(Boolean),
  }));
  questions.push({
    id: 'reflection_changed_mind', kind: 'reflection', criterionId: null, criterionLabel: 'Learning and judgement',
    prompt: 'Tell us about an assumption or decision you changed after receiving new evidence or feedback. What did you learn and what did you do differently?',
    guidance: 'We are looking for how you process evidence, not for a perfect outcome.',
    expectedSignals: ['feedback', 'evidence', 'changed', 'learned', 'decision'],
  });
  return questions.slice(0, 6);
}

export function assessInterviewAnswer(question: InterviewQuestion, answer: string): AnswerAssessment {
  const normalized = normalize(positiveEvidenceText(answer));
  const words = normalized.split(' ').filter(Boolean);
  const expectedTokens = unique(question.expectedSignals.flatMap((signal) => tokenize(signal))).filter((token) => token.length > 2);
  const matchedSignals = expectedTokens.filter((signal) => containsToken(normalized, signal)).slice(0, 8);
  const relevance = question.kind === 'reflection'
    ? Math.min(100, 35 + matchedSignals.length * 13)
    : Math.min(100, 35 + matchedSignals.length * 10 + (words.length >= 55 ? 15 : words.length >= 25 ? 7 : 0));
  const specificity = clamp((words.length >= 80 ? 45 : words.length >= 45 ? 30 : words.length >= 20 ? 16 : 5)
    + (/[0-9%]/.test(answer) ? 20 : 0) + (/(for example|specifically|when i|in my|during|project|client|team)/i.test(answer) ? 20 : 0));
  const ownership = clamp(15 + countMatches(normalized, ['i built', 'i created', 'i led', 'i designed', 'i analyzed', 'i implemented', 'i decided', 'i tested', 'i learned', 'i changed']) * 14
    + (/(my role|my contribution|i was responsible)/i.test(answer) ? 25 : 0));
  const outcome = clamp(10 + countMatches(normalized, ['result', 'outcome', 'improved', 'reduced', 'increased', 'saved', 'delivered', 'launched', 'measured', 'impact']) * 13
    + (/[0-9]+\s*(%|percent|hours?|days?|users?|customers?)/i.test(answer) ? 28 : 0));
  const reflection = clamp(10 + countMatches(normalized, ['learned', 'feedback', 'changed', 'next time', 'would improve', 'trade off', 'tradeoff', 'because']) * 13);
  const concrete = hasConcreteContribution(answer);
  const rawStrength = Math.round(relevance * .27 + specificity * .23 + ownership * .2 + outcome * .2 + reflection * .1);
  const evidenceStrength = concrete ? rawStrength : Math.min(40, rawStrength);
  const confidence = Math.min(concrete ? 80 : 40, clamp(35 + Math.min(35, Math.round(words.length * .35)) + (specificity >= 50 ? 12 : 0) + (ownership >= 45 ? 10 : 0)));
  const missingSignals = [!concrete || specificity < 45 ? 'a concrete example' : '', !concrete || ownership < 45 ? 'personal contribution' : '', outcome < 45 ? 'observable outcome' : '', reflection < 35 ? 'learning or trade-off' : ''].filter(Boolean);
  const needsFollowUp = question.kind !== 'reflection' && question.kind !== 'follow_up' && (!concrete || words.length < 55 || specificity < 45 || ownership < 45 || outcome < 40);
  const classification = evidenceStrength >= 70 ? 'substantive' : evidenceStrength >= 45 ? 'developing' : 'thin';
  return {
    evidenceStrength, confidence, classification, dimensions: { relevance, specificity: concrete ? specificity : Math.min(30, specificity), ownership: concrete ? ownership : Math.min(30, ownership), outcome, reflection },
    matchedSignals, missingSignals, needsFollowUp,
    summary: `${classification === 'substantive' ? 'Substantive' : classification === 'developing' ? 'Developing' : 'Limited'} self-reported detail in this answer. ${missingSignals.length ? `A reviewer should clarify ${missingSignals.slice(0, 2).join(' and ')}.` : 'Review the claimed contribution and outcome against the full transcript.'} This rule-based indicator does not verify capability or truth.`,
  };
}

export function buildAdaptiveFollowUp(question: InterviewQuestion, assessment: AnswerAssessment): InterviewQuestion {
  const missing = assessment.missingSignals[0] ?? 'specific evidence';
  const prompt = missing === 'personal contribution'
    ? 'What parts of that work were specifically yours? Walk us through one decision you made and why.'
    : missing === 'observable outcome'
      ? 'What changed because of your work? Share the clearest result, measure, feedback, or learning you observed.'
      : missing === 'learning or trade-off'
        ? 'What trade-off did you face, and what would you keep or change if you did this again?'
        : `Choose one concrete moment from that example. What happened, what did you personally do, and what was the result?`;
  return {
    id: `followup_${safeId(question.id)}`, kind: 'follow_up', criterionId: question.criterionId,
    criterionLabel: question.criterionLabel, prompt,
    guidance: `This follow-up asks for ${missing}; it is not a trick question.`,
    expectedSignals: unique([...question.expectedSignals, missing]), parentQuestionId: question.id,
  };
}

export function evaluateInterview(questions: InterviewQuestion[], answers: Array<{ questionId: string; answer: string; assessment?: AnswerAssessment }>) {
  const assessed = answers.map((answer) => {
    const question = questions.find((item) => item.id === answer.questionId);
    return question ? { question, answer: answer.answer, assessment: answer.assessment ?? assessInterviewAnswer(question, answer.answer) } : null;
  }).filter((item): item is NonNullable<typeof item> => Boolean(item));
  const overallEvidenceStrength = assessed.length ? Math.round(assessed.reduce((sum, item) => sum + item.assessment.evidenceStrength, 0) / assessed.length) : 0;
  const criterionRubric = Object.values(assessed.reduce<Record<string, { criterionId: string | null; label: string; scores: number[]; answerCount: number }>>((groups, item) => {
    const key = item.question.criterionId ?? item.question.criterionLabel;
    groups[key] ??= { criterionId: item.question.criterionId, label: item.question.criterionLabel, scores: [], answerCount: 0 };
    groups[key].scores.push(item.assessment.evidenceStrength); groups[key].answerCount += 1;
    return groups;
  }, {})).map((item) => ({ criterionId: item.criterionId, label: item.label, score: Math.max(...item.scores), answerCount: item.answerCount }));
  return {
    overallEvidenceStrength,
    classification: overallEvidenceStrength >= 70 ? 'substantive_evidence' : overallEvidenceStrength >= 45 ? 'developing_evidence' : 'limited_evidence',
    answeredQuestions: assessed.length,
    criterionRubric,
    humanReviewRequired: true,
    summary: `The interview contains ${assessed.length} saved answer${assessed.length === 1 ? '' : 's'}. The evidence-strength indicator is ${overallEvidenceStrength}/100 and must be reviewed alongside the transcript and cited résumé evidence.`,
    limitations: ['Scores measure answer structure and role-signal coverage, not truthfulness.', 'Accent, eye movement, tab changes, and camera availability are never scoring inputs.', 'A human must review the full transcript before making a decision.'],
  };
}

function tokenize(value: string) { return normalize(value).split(' ').filter((token) => token.length > 2 && !STOP_WORDS.has(token)); }
function normalize(value: string) { return value.toLowerCase().replace(/[^a-z0-9+#.%]+/g, ' ').replace(/\s+/g, ' ').trim(); }
function containsToken(text: string, token: string) { return new RegExp(`(^|\\s)${token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}($|\\s)`, 'i').test(text); }
function countMatches(text: string, values: string[]) { return values.filter((value) => text.includes(value)).length; }
function clamp(value: number) { return Math.max(0, Math.min(100, Math.round(value))); }
function unique<T>(values: T[]) { return [...new Set(values)]; }
function safeId(value: string) { return value.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 60) || 'question'; }
const STOP_WORDS = new Set(['and', 'the', 'for', 'with', 'that', 'this', 'from', 'your', 'you', 'what', 'how', 'did', 'one', 'specific', 'example', 'demonstrates', 'ability', 'uses', 'relevant']);
