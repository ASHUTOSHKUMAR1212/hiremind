import { findSkillSpans } from './skills-context.ts';
import { hasExplicitDenial } from './evidence-language.ts';

/** Longest named skill wins: React Native must not silently satisfy React. */
export const namedSkillSpans = findSkillSpans;

/** Only directly connected "or" alternatives are interchangeable; commas/and require both. */
export function requiredSkillGroups(label: string): string[][] {
  const spans = namedSkillSpans(label);
  const groups: string[][] = [];
  spans.forEach((span, index) => {
    const separator = index
      ? label.slice(spans[index - 1].end, span.start)
      : '';
    if (index && /^\s*or\s*$/i.test(separator)) groups.at(-1)!.push(span.skill);
    else groups.push([span.skill]);
  });
  return groups.map((group) => [...new Set(group)]);
}

export function affirmativeEvidenceClauses(value: string) {
  return (
    value
      .split(/(?:[!?](?:\s|$)|\.(?:\s|$)|\n|;|\bbut\b|\bhowever\b)/i)
      // Remove only a delimited denial, preserving the unrelated affirmative work.
      // "Built SQL reports, not Python scripts, for finance" must not prove Python.
      .map((clause) =>
        clause
          .replace(
            /,\s*(?:not(?!\s+only\b)|rather than|instead of)\s+[^,]+(?=,|$)/gi,
            '',
          )
          .trim(),
      )
      .filter(
        (clause) =>
          clause &&
          !hasExplicitDenial(clause) &&
          !/\b(?:plan(?:ning)?|hope|want|aim|intend|aspire|wish)\s+to\b|\b(?:will|would|could|might)\s+(?:have\s+|like to\s+)?(?:learn|use|build|built|study|develop|implement)|\b(?:if assigned|if given|hypothetically|interested in|seeking exposure|no hands.on)\b/i.test(
            clause,
          ),
      )
  );
}

/** Conservative evidence-depth heuristic, not verification of a résumé's truth. */
export function describesPerformedWork(clause: string) {
  // A team's output, observation, or funding is not personal hands-on work.
  // Keep these as claims for review rather than turning them into proficiency.
  if (
    /\b(?:observed|watched|shadowed|witnessed)\b|\b(?:colleagues?|coworkers?|other developers?|external (?:engineering )?team|vendors?|contractors?)\b.*\b(?:built|developed|delivered|implemented|wrote|authored|engineered|sustained)\b|\b(?:built|developed|delivered|implemented|written|authored|engineered|sustained)\b.*\bby (?:a |an |the )?(?:team|colleague|vendor|contractor)\b|\b(?:the|our|my) team\s+(?:built|developed|delivered|implemented|wrote|authored|engineered|sustained)\b|\b(?:managed?|approved?|oversaw|funded|coordinated)\s+(?:the\s+)?(?:budget|funding|procurement|contract)\b/i.test(
      clause,
    )
  )
    return false;
  const action =
    /\b(?:built|build|building|created?|creating|designed?|designing|develop(?:ed|ing)?|implement(?:ed|ing)?|deliver(?:ed|ing)?|deploy(?:ed|ing)?|analy[sz](?:ed|ing)|automate[ds]?|automating|optim(?:ized|izing)|migrat(?:ed|ing)|maintain(?:ed|ing)?|operat(?:ed|ing)|test(?:ed|ing)?|led|lead|managed?|managing|resolved?|resolving|reduced?|reducing|improved?|improving|reconcil(?:ed|ing)|trained?|training|used?|using|wrote|writing|integrat(?:ed|ing)|processed?|processing|author(?:ed|ing)?|engineer(?:ed|ing)?|sustain(?:ed|ing)?)\b/i.exec(
      clause,
    );
  if (!action) return false;
  if (
    /\b(?:would|could|might|will)\s+(?:have\s+)?$/i.test(
      clause.slice(0, action.index),
    )
  )
    return false;
  const object = clause.slice(action.index + action[0].length).trim();
  let context = object;
  for (const span of namedSkillSpans(object).reverse())
    context = context.slice(0, span.start) + ' ' + context.slice(span.end);
  const contextWords = context
    .toLowerCase()
    .split(/[^a-z]+/)
    .filter(
      (word) =>
        word.length > 2 &&
        !new Set([
          'and',
          'with',
          'using',
          'the',
          'for',
          'all',
          'skills',
          'tools',
          'technologies',
          'extensively',
          'expert',
          'proficient',
          'experience',
        ]).has(word),
    );
  return (
    contextWords.length > 0 &&
    (object.split(/\s+/).filter(Boolean).length >= 4 ||
      /\b(?:queries|scripts|pipelines|applications|services|interfaces|classifiers|models|dashboards|tests|reports|databases|indexes|apis)\b/i.test(
        object,
      ))
  );
}
