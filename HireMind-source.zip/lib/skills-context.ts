// Curated synonyms only. Related tools are not interchangeable qualifications.
export const SKILL_SYNONYM_GROUPS = [
  ['sql', 'structured query language'],
  ['javascript', 'ecmascript', 'js'],
  ['typescript', 'ts'],
  ['postgresql', 'postgres'],
  ['kubernetes', 'k8s'],
  ['amazon web services', 'aws'],
  ['google cloud platform', 'gcp'],
  ['continuous integration', 'ci'],
  ['continuous delivery', 'cd'],
  ['natural language processing', 'nlp'],
  ['machine learning', 'ml'],
  ['search engine optimization', 'seo'],
  ['customer relationship management', 'crm'],
  ['user experience', 'ux'],
  ['user interface', 'ui'],
  ['power bi', 'powerbi'],
  ['scikit learn', 'scikit-learn', 'sklearn'],
  ['python'],
  ['java'],
  ['c++', 'cpp'],
  ['c#', 'csharp'],
  ['dotnet', '.net'],
  ['react native'],
  ['react', 'react.js', 'reactjs'],
  ['nodejs', 'node.js'],
  ['angular'],
  ['angularjs'],
  ['vue', 'vue.js', 'vuejs'],
  ['django'],
  ['flask'],
  ['pytorch'],
  ['tensorflow'],
  ['docker'],
  ['mysql'],
  ['mongodb'],
  ['redis'],
  ['snowflake'],
  ['databricks'],
  ['apache spark'],
  ['pyspark'],
  ['tableau'],
  ['excel', 'microsoft excel'],
  ['azure', 'microsoft azure'],
  ['salesforce'],
  ['figma'],
  ['terraform'],
  ['git'],
];

/** Short CI/CD aliases need delivery context, not any occurrence of two letters. */
export function isSkillAliasInContext(
  alias: string,
  value: string,
  start: number,
) {
  if (!/^(?:ci|cd)$/i.test(alias)) return true;
  const before =
    value
      .slice(0, start)
      .split(/[.!?;\n]/)
      .at(-1) ?? '';
  const after = value.slice(start + alias.length).split(/[.!?;\n]/)[0];
  const context = `${before} ${alias} ${after}`;
  return /\bci\s*\/\s*cd\b|continuous_integration|continuous_delivery|\b(?:pipeline|pipelines|deployment|deployments|jenkins|github actions|gitlab|builds?|software|integration|devops|releases?)\b/i.test(
    context,
  );
}

export type SkillSpan = { start: number; end: number; skill: string };

/** Resolve aliases on the original text once; JS inside React.js is not JavaScript. */
export function findSkillSpans(
  value: string,
  groups: readonly (readonly string[])[] = SKILL_SYNONYM_GROUPS,
): SkillSpan[] {
  const matches = groups.flatMap(([skill, ...aliases]) =>
    [skill, ...aliases].flatMap((alias) => {
      const escaped = alias.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      return [...value.matchAll(new RegExp(`(?<![a-z0-9_+#])${escaped}(?![a-z0-9_+#])`, 'gi'))]
        .filter((match) => isSkillAliasInContext(alias, value, match.index!))
        .map((match) => ({ start: match.index!, end: match.index! + match[0].length, skill }));
    }),
  ).sort((a, b) => (b.end - b.start) - (a.end - a.start));
  const selected: SkillSpan[] = [];
  for (const match of matches)
    if (!selected.some((other) => match.start < other.end && match.end > other.start))
      selected.push(match);
  return selected.sort((a, b) => a.start - b.start);
}

export function normalizeSkillPhrases(value: string) {
  let result = value.toLowerCase();
  for (const span of findSkillSpans(value).reverse())
    result = result.slice(0, span.start) + span.skill.replace(/\s+/g, '_') + result.slice(span.end);
  return result;
}

export function requiredMonths(value: string) {
  const match = value.match(/\b(\d+(?:\.\d+)?)\s*\+?\s*(years?|months?)\b/i);
  return match
    ? Math.ceil(Number(match[1]) * (/year/i.test(match[2]) ? 12 : 1))
    : null;
}

function month(value: unknown): number | null {
  if (typeof value !== 'string') return null;
  // Year-only dates are ambiguous, so do not invent a month.
  const match = value.match(/^(\d{4})-(0[1-9]|1[0-2])(?:-\d{2})?$/);
  return match ? Number(match[1]) * 12 + Number(match[2]) - 1 : null;
}

export function relevantTenure(
  entries: Record<string, unknown>[],
  asOf = new Date(),
) {
  const now = asOf.getUTCFullYear() * 12 + asOf.getUTCMonth();
  const intervals: Array<[number, number]> = [];
  let unresolved = 0;
  for (const item of entries) {
    const start = month(item.startedOn);
    const end =
      item.isCurrent === true || item.isCurrent === 1
        ? now
        : month(item.endedOn);
    if (start === null || end === null || start > end || end > now) {
      unresolved++;
      continue;
    }
    // Count elapsed months, conservatively excluding an incomplete boundary month.
    intervals.push([start, end]);
  }
  intervals.sort((a, b) => a[0] - b[0]);
  const merged: Array<[number, number]> = [];
  for (const interval of intervals) {
    const previous = merged.at(-1);
    if (previous && interval[0] <= previous[1])
      previous[1] = Math.max(previous[1], interval[1]);
    else merged.push([...interval]);
  }
  return {
    months: merged.reduce((sum, [start, end]) => sum + end - start, 0),
    unresolved,
  };
}
