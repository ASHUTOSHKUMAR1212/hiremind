import type { ResumeProfileImport } from '@/lib/resume-text';

export function buildResumeScreeningProfile(parsed: ResumeProfileImport, filename: string) {
  return {
    fullName: parsed.fullName,
    headline: parsed.headline,
    summary: parsed.summary,
    location: parsed.location,
    metadata: { skills: parsed.skills },
    experiences: parsed.experiences,
    education: parsed.education,
    projects: parsed.projects,
    resume: { filename, parsed: true },
  };
}

export function resumeCandidateName(parsedName: string, filename: string) {
  if (parsedName.trim()) return parsedName.trim();
  const cleaned = filename
    .replace(/\.(pdf|docx?|rtf)$/i, '')
    .replace(/[_-]+/g, ' ')
    .replace(/\b(resume|résumé|cv|updated|latest|final|copy)\b/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  return cleaned || 'Unnamed candidate';
}

export function rankResumeComparisons<T extends { fitScore: number; uncertainty: number; candidateName: string }>(items: T[]) {
  // Stable input order for genuine ties; names are not a ranking signal.
  return [...items].sort((first, second) =>
    second.fitScore - first.fitScore
    || first.uncertainty - second.uncertainty,
  );
}
