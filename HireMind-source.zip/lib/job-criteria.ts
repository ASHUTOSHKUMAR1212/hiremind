import { namedSkillSpans } from './matching-signals.ts';
import { responsibilityRequirements, hasUnmappedWorkConstraint } from './work-evidence.ts';
import {
  jobRequirementClauses,
  namedRequirements,
  requirementClassNear,
} from './job-requirements.ts';

export type DraftJobCriterion = {
  label: string;
  requirementClass: 'essential' | 'preferred';
  weight: number;
  evidenceDefinition: string;
  equivalentSignals: string[];
  sourceHint: string;
};

type Competency = Omit<
  DraftJobCriterion,
  'requirementClass' | 'weight' | 'sourceHint'
> & { aliases: string[] };

export function draftJobCriteria(title: string, description: string) {
  const clauses = jobRequirementClauses(description);
  const detected: DraftJobCriterion[] = [];
  const reviewItems: Array<{ source: string; reason: string }> = [];
  for (const clause of clauses) {
    const before = detected.length;
    const responsibilities = responsibilityRequirements(clause.text);
    if (responsibilities.length) {
      // Preserve the action, named tools and qualifiers together; do not turn
      // "Python data pipelines" into unrelated Python and pipeline requirements.
      detected.push({
        label: clause.text.slice(0, 180),
        requirementClass: clause.requirementClass,
        weight: 1,
        evidenceDefinition: 'Describe your personal contribution and result. ' + responsibilities.map((item) => item.question).join(' '),
        equivalentSignals: [],
        sourceHint: clause.sourceHint.slice(0, 500),
      });
      if (hasUnmappedWorkConstraint(clause.text) || clause.text.length > 180)
        reviewItems.push({ source: clause.sourceHint, reason: 'Responsibility detected, but additional scope, qualifications or long wording need manual review. Do not remove a real requirement simply to raise matching scores.' });
    }
    for (const item of responsibilities.length ? [] : namedRequirements(clause))
      detected.push({
        label: item.label,
        requirementClass: item.requirementClass,
        weight: 1,
        evidenceDefinition:
          'Show a specific contribution using ' +
          item.names.join(' or ') +
          '. Job context: ' +
          clause.text.slice(0, 330),
        equivalentSignals: [],
        sourceHint: item.sourceHint.slice(0, 500),
      });
    // Generic competencies need their own explicit phrase; a named tool is not
    // permission to invent a broader requirement or a different technology.
    for (const competency of responsibilities.length ? [] : COMPETENCIES) {
      const aliases = competency.aliases.filter(
        (alias) =>
          !namedSkillSpans(alias).length &&
          containsTerm(normalize(clause.text), normalize(alias)),
      );
      if (!aliases.length) continue;
      detected.push({
        label: competency.label,
        requirementClass: requirementClassNear(
          clause,
          normalize(clause.text).indexOf(normalize(aliases[0])),
        ),
        weight: 1,
        evidenceDefinition: competency.evidenceDefinition,
        equivalentSignals: [],
        sourceHint: clause.sourceHint.slice(0, 500),
      });
    }
    const reasons = [
      detected.length === before
        ? 'No automatic criterion covers this clause.'
        : '',
      /\b(bachelor|master|degree|phd|ph\.d)\b/i.test(clause.text)
        ? 'Review qualification and any equivalent-experience alternative manually.'
        : '',
      /\b(licen[cs]e|certification|security clearance|work authori[sz]ation)\b/i.test(
        clause.text,
      )
        ? 'Review this credential or authorization requirement manually; a listed technical skill does not establish it.'
        : '',
      detectYearsRequirement(clause.text) &&
      !detected
        .slice(before)
        .some((item) => /\b(?:years?|months?)\b/i.test(item.label))
        ? 'Experience duration was not assigned automatically.'
        : '',
    ].filter(Boolean);
    if (reasons.length)
      reviewItems.push({
        source: clause.sourceHint,
        reason: reasons.join(' '),
      });
  }
  const conflict = detected.some((item) =>
    detected.some(
      (other) =>
        other.label.toLowerCase() === item.label.toLowerCase() &&
        other.requirementClass !== item.requirementClass,
    ),
  );
  const ordered = [...detected].sort(
    (a, b) =>
      Number(b.requirementClass === 'essential') -
      Number(a.requirementClass === 'essential'),
  );
  const unique = dedupe(ordered, (item) => item.label.toLowerCase());
  const criteria = unique.slice(0, 10);
  const cautions = [
    !criteria.length
      ? 'No explicit supported criteria were found. Add role-specific criteria manually; HireMind has not invented a generic rubric.'
      : '',
    conflict
      ? 'The same skill appears as required and preferred. Resolve that conflict before publishing.'
      : '',
    unique.length > 10
      ? 'More than 10 criteria were found. Review the omitted items: ' +
        unique
          .slice(10)
          .map((item) => item.label)
          .join(', ') +
        '.'
      : '',
    detectYearsRequirement(description)
      ? 'Review experience durations against the source text. Only unambiguous, single-skill durations are retained; other duration requirements need manual criteria.'
      : '',
    /\b(bachelor|master|degree|phd|ph\.d)\b/i.test(description)
      ? 'Review education requirements separately; no degree requirement or equivalent qualification has been invented.'
      : '',
    'Drafts use explicit description text, not the job title. Review every criterion and weight; alternatives are suggestions only after you add them.',
  ].filter(Boolean);
  return {
    criteria: normalizeWeights(
      criteria.map((item) => ({
        ...item,
        weight: item.requirementClass === 'essential' ? 2 : 1,
      })),
    ),
    cautions,
    reviewItems,
    context: title.trim(),
  };
}

function normalizeWeights<T extends { weight: number }>(criteria: T[]) {
  const total =
    criteria.reduce((sum, criterion) => sum + criterion.weight, 0) || 1;
  const result = criteria.map((criterion) => ({
    ...criterion,
    weight: Math.max(5, Math.round((criterion.weight / total) * 100)),
  }));
  const difference =
    100 - result.reduce((sum, criterion) => sum + criterion.weight, 0);
  if (result.length) result[0].weight += difference;
  return result;
}

function detectYearsRequirement(value: string) {
  return /\b\d+(?:\.\d+)?\s*\+?\s*(?:years?|yrs?|months?)\b/i.test(value);
}
function containsTerm(text: string, term: string) {
  const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp(`(^|[^a-z0-9+#])${escaped}([^a-z0-9+#]|$)`, 'i').test(text);
}
function normalize(value: string) {
  return value
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9+#.]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}
function dedupe<T>(values: T[], key: (value: T) => string) {
  const seen = new Set<string>();
  return values.filter((value) => {
    const itemKey = key(value);
    if (seen.has(itemKey)) return false;
    seen.add(itemKey);
    return true;
  });
}

const COMPETENCIES: Competency[] = [
  {
    label: 'Data quality and validation',
    aliases: [
      'data quality',
      'quality assurance',
      'qa review',
      'validation',
      'annotation',
    ],
    evidenceDefinition:
      'Defines, measures, or improves data quality through validation, review, root-cause analysis, or process controls.',
    equivalentSignals: [
      'quality audits',
      'annotation review',
      'data cleaning',
      'testing',
      'defect reduction',
    ],
  },
  {
    label: 'Data analysis',
    aliases: [
      'data analysis',
      'data analytics',
      'business intelligence',
      'power bi',
      'tableau',
      'excel',
    ],
    evidenceDefinition:
      'Turns data into a defensible insight, recommendation, dashboard, or measurable business outcome.',
    equivalentSignals: [
      'analysis projects',
      'dashboards',
      'case studies',
      'reporting',
      'statistical analysis',
    ],
  },
  {
    label: 'User and customer research',
    aliases: [
      'user research',
      'customer research',
      'ux research',
      'usability testing',
    ],
    evidenceDefinition:
      'Plans or conducts research, synthesizes evidence, and connects findings to a product or service decision.',
    equivalentSignals: [
      'research projects',
      'interviews',
      'surveys',
      'usability studies',
      'customer insight work',
    ],
  },
  {
    label: 'Product design',
    aliases: [
      'product design',
      'ux design',
      'ui design',
      'figma',
      'prototyping',
    ],
    evidenceDefinition:
      'Shows a design process from problem framing through prototypes, decisions, testing, and outcomes.',
    equivalentSignals: [
      'portfolio case studies',
      'Figma prototypes',
      'design systems',
      'student design projects',
    ],
  },
  {
    label: 'Product management',
    aliases: [
      'product management',
      'product manager',
      'roadmap',
      'product strategy',
    ],
    evidenceDefinition:
      'Prioritizes problems, aligns stakeholders, defines outcomes, and uses evidence to guide product decisions.',
    equivalentSignals: [
      'product case studies',
      'roadmaps',
      'launch ownership',
      'entrepreneurial projects',
    ],
  },
  {
    label: 'Project delivery',
    aliases: ['project management', 'program management', 'agile', 'scrum'],
    evidenceDefinition:
      'Plans and coordinates delivery, manages risks and dependencies, and communicates progress toward outcomes.',
    equivalentSignals: [
      'project leadership',
      'volunteer coordination',
      'event delivery',
      'Agile delivery',
    ],
  },
  {
    label: 'Stakeholder communication',
    aliases: [
      'stakeholder',
      'communication',
      'cross-functional',
      'client-facing',
      'presentation',
    ],
    evidenceDefinition:
      'Communicates clearly across functions, surfaces trade-offs, and creates alignment around decisions or delivery.',
    equivalentSignals: [
      'presentations',
      'documentation',
      'client communication',
      'team leadership',
    ],
  },
  {
    label: 'People leadership',
    aliases: ['people management', 'team leadership', 'mentoring', 'coaching'],
    evidenceDefinition:
      'Supports people, improves team effectiveness, and handles feedback, coaching, or delivery accountability.',
    equivalentSignals: [
      'mentoring',
      'volunteer leadership',
      'team lead responsibilities',
      'peer coaching',
    ],
  },
  {
    label: 'Security engineering',
    aliases: [
      'cybersecurity',
      'information security',
      'application security',
      'security engineering',
    ],
    evidenceDefinition:
      'Identifies and reduces security risk through design, testing, monitoring, or incident response.',
    equivalentSignals: [
      'security labs',
      'CTFs',
      'threat modelling',
      'security certifications',
      'incident response',
    ],
  },
  {
    label: 'DevOps and delivery automation',
    aliases: [
      'devops',
      'docker',
      'kubernetes',
      'ci/cd',
      'continuous integration',
    ],
    evidenceDefinition:
      'Automates reliable build, deployment, infrastructure, or operational workflows and can explain reliability trade-offs.',
    equivalentSignals: [
      'deployment pipelines',
      'container projects',
      'infrastructure automation',
      'site reliability work',
    ],
  },
];
