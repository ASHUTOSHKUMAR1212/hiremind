export type OrganizationPermission =
  | 'view_pipeline'
  | 'manage_jobs'
  | 'review_candidates'
  | 'manage_candidates'
  | 'schedule_interviews'
  | 'export_data'
  | 'manage_team';

const ROLE_PERMISSIONS: Record<string, ReadonlySet<OrganizationPermission>> = {
  owner: new Set([
    'view_pipeline', 'manage_jobs', 'review_candidates', 'manage_candidates',
    'schedule_interviews', 'export_data', 'manage_team',
  ]),
  admin: new Set([
    'view_pipeline', 'manage_jobs', 'review_candidates', 'manage_candidates',
    'schedule_interviews', 'export_data', 'manage_team',
  ]),
  recruiter: new Set([
    'view_pipeline', 'manage_jobs', 'review_candidates', 'manage_candidates',
    'schedule_interviews', 'export_data',
  ]),
  hiring_manager: new Set([
    'view_pipeline', 'review_candidates', 'manage_candidates',
    'schedule_interviews', 'export_data',
  ]),
};

export function canOrganizationRole(roleKey: string | null | undefined, permission: OrganizationPermission) {
  return Boolean(roleKey && ROLE_PERMISSIONS[roleKey]?.has(permission));
}
