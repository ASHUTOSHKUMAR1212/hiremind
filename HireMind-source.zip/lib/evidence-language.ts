// Conservative English-language assistance, not a truth or semantic verifier.
// Explicit denials must never become positive matching evidence.
export function positiveEvidenceText(value: string) {
  return value.split(/(?:[.!?](?:\s|$)|\n|;|\bbut\b|\bhowever\b)/i)
    .filter((clause) => !hasExplicitDenial(clause))
    .join(' ');
}

export function hasExplicitDenial(value: string) {
  const text = value.replace(/\bnot only\b/gi, '').replace(/[’]/g, "'");
  return /\b(?:never|without|lack(?:s|ed|ing)?|no\s+(?:prior\s+|professional\s+|hands.on\s+)?(?:experience|knowledge|skills?|exposure)|no\s+[\w+#.-]+\s+(?:experience|knowledge|skills?)|not\s+(?:yet\s+)?(?:used|use|built|worked|experienced|familiar|proficient|skilled)|(?:do|did|have|has|was|am|is|can)\s+not\b|(?:don|didn|haven|hasn|wasn|isn|can)'t\b)/i.test(text);
}

export function hasConcreteContribution(answer: string) {
  const action = /\bI\s+(?:personally\s+)?(?:built|created|led|designed|analyzed|analysed|implemented|decided|tested|developed|delivered|managed|resolved|automated|improved|reduced)\b/gi;
  return answer.split(/[.!?]\s+|\n/).some((sentence) => {
    if (hasExplicitDenial(sentence)) return false;
    const matches = [...sentence.matchAll(action)];
    if (matches.length !== 1) return false;
    const object = sentence.slice((matches[0].index ?? 0) + matches[0][0].length).trim().split(/\s+/);
    return object.length >= 4 && !/^i\b/i.test(object.join(' '));
  });
}
