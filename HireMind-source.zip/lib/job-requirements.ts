import { namedSkillSpans } from './matching-signals.ts';

export type RequirementClause = {
  text: string;
  requirementClass: 'essential' | 'preferred';
  sourceHint: string;
};

/** Preserve section context instead of treating every tool in a job ad as mandatory. */
export function jobRequirementClauses(
  description: string,
): RequirementClause[] {
  let section: 'essential' | 'preferred' | 'excluded' = 'essential';
  let heading = '';
  const output: RequirementClause[] = [];
  const lines = description
    .replace(
      /\b(Required|Requirements|Must[- ]haves?|Preferred|Nice[- ]to[- ]haves?|Benefits|What we offer)\s*:/gi,
      '\n$1:',
    )
    .split(/\n+/);
  for (const line of lines) {
    let text = line.replace(/^\s*(?:[-*•]|\d+[.)])\s*/, '').trim();
    if (!text) continue;
    const sectionMatch = text.match(
      /^(requirements?|required(?: skills)?|must[- ]haves?|minimum qualifications|qualifications|responsibilities|what you(?:'ll| will) do|preferred(?: qualifications| skills)?|nice[- ]to[- ]haves?|desirable(?: skills)?|bonus(?: skills)?|benefits|perks|what we offer|about us|about the company|equal opportunit(?:y|ies))(?:\s*:\s*(.*)|\s*)$/i,
    );
    if (sectionMatch) {
      heading = sectionMatch[1];
      section = /benefits|perks|what we offer|about|equal opportunit/i.test(
        heading,
      )
        ? 'excluded'
        : /preferred|nice|desirable|bonus/i.test(heading)
          ? 'preferred'
          : 'essential';
      text = sectionMatch[2]?.trim() ?? '';
    } else if (/^[A-Za-z][A-Za-z\s/-]{2,60}:$/.test(text)) {
      // Unknown headings do not inherit a previous benefits/preferred section.
      heading = text.slice(0, -1);
      section = 'essential';
      continue;
    }
    if (!text || section === 'excluded') continue;
    for (const clause of text
      .split(/(?<=[.!?])\s+|;|\s+but\s+/i)
      .map((item) => item.trim())
      .filter(Boolean)) {
      if (
        /\b(?:not (?:required|essential|necessary|needed)|(?:do|does) not require|without requiring|no (?:prior )?(?:\w+\s+){0,4}(?:required|needed)|no need to|training (?:is )?provided|we (?:offer|provide))\b/i.test(
          clause,
        )
      )
        continue;
      output.push({
        text: clause,
        requirementClass: section,
        sourceHint: (heading ? heading + ': ' : '') + clause,
      });
    }
  }
  return output;
}

export function requirementClassNear(
  clause: RequirementClause,
  anchor: number,
): 'essential' | 'preferred' {
  const cues = [
    ...clause.text.matchAll(
      /\b(preferred|bonus|nice[- ]to[- ]have|desirable|advantage|optional|a plus|must|required|essential|minimum)\b/gi,
    ),
  ];
  const closest = cues.sort(
    (a, b) => Math.abs(a.index! - anchor) - Math.abs(b.index! - anchor),
  )[0];
  return closest
    ? /preferred|bonus|nice|desirable|advantage|optional|a plus/i.test(
        closest[0],
      )
      ? 'preferred'
      : 'essential'
    : clause.requirementClass;
}

export function namedRequirements(clause: RequirementClause) {
  const spans = namedSkillSpans(clause.text);
  const groups: Array<{ names: string[]; start: number; end: number }> = [];
  spans.forEach((span, index) => {
    const previous = spans[index - 1];
    if (
      previous &&
      /^\s*or\s*$/i.test(clause.text.slice(previous.end, span.start))
    ) {
      groups.at(-1)!.names.push(span.skill);
      groups.at(-1)!.end = span.end;
    } else
      groups.push({ names: [span.skill], start: span.start, end: span.end });
  });
  const durations = [
    ...clause.text.matchAll(/\b(\d+(?:\.\d+)?)\s*(\+)?\s*(years?|months?)\b/gi),
  ];
  return groups.map((group) => {
    // Only bind unambiguous, adjacent tenure. Never apply one skill's years to all tools.
    const duration =
      durations.length === 1 && groups.length === 1 ? durations[0] : undefined;
    const tenure = duration
      ? duration[1] + (duration[2] ?? '') + ' ' + duration[3] + ' '
      : '';
    return {
      label: tenure + group.names.map(displaySkill).join(' or '),
      names: group.names,
      requirementClass: requirementClassNear(clause, group.start),
      sourceHint: clause.sourceHint,
    };
  });
}

function displaySkill(skill: string) {
  const names: Record<string, string> = {
    sql: 'SQL',
    javascript: 'JavaScript',
    typescript: 'TypeScript',
    postgresql: 'PostgreSQL',
    'amazon web services': 'AWS',
    'google cloud platform': 'Google Cloud Platform',
    nodejs: 'Node.js',
    'c++': 'C++',
    'c#': 'C#',
    dotnet: '.NET',
    'power bi': 'Power BI',
    'user experience': 'User experience',
    'user interface': 'User interface',
    mysql: 'MySQL',
    mongodb: 'MongoDB',
    pytorch: 'PyTorch',
    tensorflow: 'TensorFlow',
    angularjs: 'AngularJS',
  };
  return names[skill] ?? skill.replace(/\b\w/g, (char) => char.toUpperCase());
}
