import { affirmativeEvidenceClauses, namedSkillSpans, requiredSkillGroups } from './matching-signals.ts';

// Bounded English responsibility mappings, not a trained semantic model.
// A mapping requires a performed action and a work object in the same clause.
const RESPONSIBILITIES = [
  {
    id: 'data-pipelines', label: 'Data ingestion and transformation',
    requirement: /\b(?:data pipelines?|etl|elt|data ingestion|data transformation)\b/i,
    work: /\b(?:built|developed|implemented|maintained|operated)\b.{0,70}\b(?:data pipelines?|etl|elt)\b|\b(?:ingested|transformed|normalized|loaded|synchronized)\b.{0,70}\b(?:records|datasets|events|feeds|warehouse|data)\b/i,
    question: 'Which data sources did you connect, how did you handle failed or duplicate records, and what did you personally implement?',
  },
  {
    id: 'incident-resolution', label: 'Production incident diagnosis and recovery',
    requirement: /\b(?:(?:production |service )?incident (?:response|resolution)|(?:production|service) (?:incidents?|reliability)|on.call support)\b/i,
    work: /\b(?:diagnosed|investigated|resolved|remediated|triaged)\b.{0,70}\b(?:outages?|production (?:errors?|failures?|incidents?)|service disruptions?)\b|\b(?:restored|recovered)\b.{0,50}\b(?:service|availability|production)\b/i,
    question: 'Describe one incident: how did you find the cause, restore service, and prevent recurrence? What was your role?',
  },
  {
    id: 'controlled-experiments', label: 'Controlled experimentation',
    requirement: /\b(?:a\/b test(?:s|ing)?|controlled experiments?|experiment design)\b/i,
    work: /\b(?:designed|ran|conducted|implemented)\b.{0,70}\b(?:a\/b tests?|controlled experiments?|randomized (?:trials?|experiments?))\b|\b(?:randomized|split)\b.{0,50}\b(?:users|traffic|participants)\b.{0,90}\b(?:control|treatment|cohorts?)\b/i,
    question: 'What was the hypothesis, how were groups assigned, and how did you measure the result and check for bias?',
  },
  {
    id: 'requirements-discovery', label: 'Business requirements discovery',
    requirement: /\b(?:(?:business |user )?requirements (?:gathering|discovery|elicitation)|gather (?:business |user )?requirements|stakeholder discovery)\b/i,
    work: /\b(?:interviewed|consulted)\b.{0,50}\b(?:stakeholders|business users|customers)\b.{0,90}\b(?:requirements|workflows|acceptance criteria|needs)\b|\b(?:elicited|documented|mapped)\b.{0,50}\b(?:business requirements|user requirements|acceptance criteria)\b/i,
    question: 'Whose needs did you gather, what did you turn them into, and how did you resolve conflicting requirements?',
  },
  {
    id: 'process-automation', label: 'Manual process automation',
    requirement: /\b(?:process automation|workflow automation|automate (?:manual |business )?(?:processes|workflows|tasks))\b/i,
    work: /\b(?:automated|scripted)\b.{0,70}\b(?:reconciliation|invoicing|reporting|handoffs|manual tasks|workflows|data entry)\b|\b(?:replaced|eliminated)\b.{0,50}\b(?:manual|spreadsheet)\b.{0,80}\b(?:script|scripts|scheduled|automation)\b/i,
    question: 'What was manual before, what did you automate, and how did you check exceptions and the claimed time savings?',
  },
  {
    id: 'mentoring', label: 'Hands-on mentoring and coaching',
    requirement: /\b(?:mentor(?:ing)?|coach(?:ing)?)\b.{0,35}\b(?:engineers|developers|analysts|colleagues|team members)\b/i,
    work: /\b(?:mentored|coached)\b.{0,45}\b(?:engineers|developers|analysts|colleagues|team members)\b.{0,90}\b(?:feedback|reviews|pairing|onboarding|goals|sessions)\b/i,
    question: 'Who did you coach, what feedback or practice did you provide, and what change did you observe?',
  },
];

export type ResponsibilitySupport = { id: string; label: string; question: string };

export function responsibilityRequirements(label: string): ResponsibilitySupport[] {
  return RESPONSIBILITIES.filter((item) => item.requirement.test(label))
    .map(({ id, label: name, question }) => ({ id, label: name, question }));
}

export function responsibilitySupport(label: string, text: string): ResponsibilitySupport[] {
  const requested = new Set(responsibilityRequirements(label).map((item) => item.id));
  return RESPONSIBILITIES.filter((item) => requested.has(item.id) &&
    affirmativeEvidenceClauses(text).some((clause) => {
      // Do not upgrade plans, third-party work or a list prefixed with an action.
      if (/\b(?:will|would|could|might|plan|planning|hope|intend|wish|observed|watched|shadowed|witnessed)\b/i.test(clause)) return false;
      const ownership = clause.replace(/\bwith (?:my|our|the) team\b/gi, '');
      if (/\b(?:the team|our team|my team|colleagues?|coworkers?|vendors?|contractors?)\b/i.test(ownership)) return false;
      if (/\bby (?:a |an |the )?(?:team|colleague|vendor|contractor)\b/i.test(clause)) return false;
      if (/\b(?:slides?|presentations?|proposals?|tutorials?|documentation|training materials?)\b.{0,50}\b(?:about|on|for)\b/i.test(clause)) return false;
      return item.work.test(clause);
    }))
    .map(({ id, label: name, question }) => ({ id, label: name, question }));
}

/** Do not silently waive seniority, industry, scale, or an unknown technology. */
export function hasUnmappedWorkConstraint(label: string) {
  if (!responsibilityRequirements(label).length) return false;
  let rest = label;
  for (const span of namedSkillSpans(rest).reverse())
    rest = rest.slice(0, span.start) + ' ' + rest.slice(span.end);
  for (const item of RESPONSIBILITIES)
    rest = rest.replace(new RegExp(item.requirement.source, 'gi'), ' ');
  rest = rest.replace(/\b\d+(?:\.\d+)?\s*\+?\s*(?:years?|months?)\b/gi, ' ')
    .replace(/\b(?:build|building|design|designing|develop|developing|implement|implementing|maintain|maintaining|perform|performing|experience|required|preferred|must|have|with|in|of|and|or|using|the|a|an)\b/gi, ' ')
    .replace(/[^a-z0-9]+/gi, '');
  return rest.length > 0;
}

type Source = { key: string; sourceType: string; quote: string; text: string; sourceLocation: string };
export type GapCitation = { sourceKey: string; quote: string; sourceLocation: string; deniedSkills: string[]; deniedTasks: string[] };
export type RelatedWorkCitation = {
  sourceKey: string; sourceLocation: string; quote: string;
  tasks: ResponsibilitySupport[]; namedTools: string[]; unprovenToolGroups: string[][];
};
export type EvidenceStatus = 'supported' | 'needs_review' | 'claim_only' | 'not_found' | 'stated_gap' | 'conflicting' | 'related_work';
export type EvidenceReview = {
  status: EvidenceStatus;
  label: string;
  question: string;
  statedGaps: GapCitation[];
  relatedWork?: RelatedWorkCitation[];
  responsibilities: Array<ResponsibilitySupport & { supported: boolean; sourceKeys: string[] }>;
};

export const EVIDENCE_STATUS_LABELS: Record<EvidenceStatus, string> = {
  supported: 'Work evidence found',
  needs_review: 'Partial evidence — clarify',
  claim_only: 'Claim only — ask for an example',
  not_found: 'Not documented — ask, do not assume',
  stated_gap: 'Candidate states a gap — confirm',
  conflicting: 'Conflicting statements — clarify',
  related_work: 'Related task experience — required tools unproven',
};

/** Review leads only. Never feed these citations into scores or credited tenure. */
function findRelatedWork(label: string, sources: Source[], supportedTasks: Set<string>): RelatedWorkCitation[] {
  const groups = requiredSkillGroups(label);
  if (!groups.length) return [];
  const seen = new Set<string>();
  return sources.filter((source) => ['work_history', 'project'].includes(source.sourceType))
    .flatMap((source) => source.quote.split(/(?:[!?](?:\s|$)|\.(?:\s|$)|\n|;|\bbut\b|\bhowever\b)/i).flatMap((raw) => {
      // Keep the original excerpt for citation; inspect only its affirmative content.
      const quote = raw.trim();
      const affirmative = affirmativeEvidenceClauses(quote).join(' ');
      const tasks = responsibilitySupport(label, affirmative).filter((task) => !supportedTasks.has(task.id));
      const namedTools = [...new Set(namedSkillSpans(affirmative).map((span) => span.skill))];
      const unprovenToolGroups = groups.filter((group) => !group.some((skill) => namedTools.includes(skill)));
      const key = `${source.key}:${quote}`;
      if (!tasks.length || !unprovenToolGroups.length || seen.has(key)) return [];
      seen.add(key);
      return [{ sourceKey: source.key, sourceLocation: source.sourceLocation, quote, tasks, namedTools, unprovenToolGroups }];
    })).slice(0, 5);
}

/** Only direct, current candidate statements can become a stated gap. Absence cannot. */
export function candidateStatedGaps(label: string, sources: Source[]): GapCitation[] {
  const groups = requiredSkillGroups(label);
  const tasks = responsibilityRequirements(label);
  return sources.filter((source) => ['work_history', 'project', 'profile_summary', 'profile_skill'].includes(source.sourceType))
    .flatMap((source) => source.quote.split(/(?:[.!?](?:\s|$)|\n|;|\bbut\b|\bhowever\b)/i).flatMap((raw) => {
      const clause = raw.replace(/^\s*[-•]\s*/, '').trim();
      if (/\b(?:required|necessary|before|until|previously|used to)\b/i.test(clause)) return [];
      const denial = clause.match(/^(?:I (?:have )?)?no (?:prior |professional |hands.on )?experience(?: (?:with|in|using))?\s+(.+)/i)
        ?? clause.match(/^I (?:have never|haven't|have not|do not|don't) (?:used|use|worked with|have experience (?:with|in))\s+(.+)/i);
      if (!denial) return [];
      const skills = new Set(namedSkillSpans(denial[1]).map((item) => item.skill));
      // For an OR group, denial of one option does not disqualify the alternative.
      const deniedSkills = groups.filter((group) => group.every((skill) => skills.has(skill))).flat();
      const deniedTasks = !groups.length ? tasks.filter((task) => responsibilityRequirements(denial[1]).some((item) => item.id === task.id)).map((task) => task.id) : [];
      return deniedSkills.length || deniedTasks.length ? [{ sourceKey: source.key, quote: clause, sourceLocation: source.sourceLocation, deniedSkills, deniedTasks }] : [];
    }));
}

export function buildEvidenceReview(
  label: string,
  sources: Source[],
  matches: Array<{ source: Source; evidenceLevel: 'demonstrated' | 'claimed'; responsibilityMatches?: ResponsibilitySupport[] }>,
  score: number,
): EvidenceReview {
  const statedGaps = candidateStatedGaps(label, sources);
  const performed = matches.some((match) => match.evidenceLevel === 'demonstrated');
  const conflicting = statedGaps.some((gap) => matches.some((match) => match.evidenceLevel === 'demonstrated' &&
    (namedSkillSpans(match.source.text).some((item) => gap.deniedSkills.includes(item.skill)) ||
      match.responsibilityMatches?.some((item) => gap.deniedTasks.includes(item.id)))));
  const responsibilities = responsibilityRequirements(label).map((task) => {
    const sourceKeys = matches.filter((match) => match.responsibilityMatches?.some((item) => item.id === task.id)).map((match) => match.source.key);
    return { ...task, supported: sourceKeys.length > 0, sourceKeys };
  });
  const relatedWork = findRelatedWork(label, sources, new Set(responsibilities.filter((task) => task.supported).map((task) => task.id)));
  const status: EvidenceStatus = statedGaps.length ? (conflicting ? 'conflicting' : 'stated_gap')
    : performed ? (score >= 55 ? 'supported' : 'needs_review')
      : relatedWork.length ? 'related_work' : matches.length ? 'claim_only' : 'not_found';
  const related = relatedWork[0];
  const question = status === 'conflicting'
    ? `Your submitted statements about ${label} differ. Which reflects your current experience, and when did it change?`
    : status === 'stated_gap'
      ? `You noted a gap related to ${label}. Is that still current? Is there other relevant work you would like us to consider?`
      : related
        ? `You described ${related.tasks.map((task) => task.label.toLowerCase()).join(' and ')}. Have you personally done this using ${related.unprovenToolGroups.map((group) => group.join(' or ')).join(' and ')}? Give a concrete example or explain what you would need to learn. ${related.tasks[0].question}`
        : responsibilities.find((item) => !item.supported)?.question ?? responsibilities[0]?.question
        ?? `Describe a specific example of ${label}: what did you personally do, what changed, and how was it checked?`;
  return { status, label: EVIDENCE_STATUS_LABELS[status], question, statedGaps, responsibilities, relatedWork };
}
