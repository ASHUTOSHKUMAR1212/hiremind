export type CandidateInterviewPresentation = {
  title: string;
  actionLabel: string | null;
  canBegin: boolean;
  availableAt: number | null;
};

export const INTERVIEW_EARLY_ACCESS_MS = 15 * 60 * 1000;

export function getSessionContextChoice(consentRecorded: boolean, acceptedSignals: string[]) {
  if (!consentRecorded) return { shared: false, title: 'Not provided yet', detail: 'No session-context consent has been recorded.' };
  if (acceptedSignals.includes('tab_visibility')) return { shared: true, title: 'Shared', detail: 'Candidate agreed to share optional session context.' };
  return { shared: false, title: 'Not shared', detail: 'Candidate chose not to share optional session context.' };
}

export function isUpcomingInterview(interview: { status: string; scheduledAt: number | null }, now = Date.now()) {
  return interview.status === 'scheduled' && interview.scheduledAt != null && interview.scheduledAt >= now;
}

export function isOverdueInterview(interview: { status: string; scheduledAt: number | null }, now = Date.now()) {
  return interview.status === 'scheduled' && interview.scheduledAt != null && interview.scheduledAt < now;
}

export function getInterviewStartAvailability(
  status: string | null,
  scheduledAt: number | null,
  now = Date.now(),
) {
  if (status === 'in_progress') return { canBegin: true, availableAt: null };
  if (status !== 'scheduled') return { canBegin: false, availableAt: null };
  if (!scheduledAt) return { canBegin: true, availableAt: null };
  const availableAt = scheduledAt - INTERVIEW_EARLY_ACCESS_MS;
  return { canBegin: now >= availableAt, availableAt };
}

export function getCandidateInterviewPresentation(
  status: string | null,
  scheduledAt: number | null = null,
  mode = 'structured_screening',
  now = Date.now(),
): CandidateInterviewPresentation {
  const availability = getInterviewStartAvailability(status, scheduledAt, now);
  const isLive = mode === 'live_video';
  switch (status) {
    case 'in_progress':
      return {
        title: isLive ? 'Live interview in progress' : 'Screening in progress',
        actionLabel: isLive ? 'Join live interview' : 'Continue screening',
        ...availability,
      };
    case 'completed':
      return {
        title: isLive ? 'Live interview completed' : 'Screening completed',
        actionLabel: null,
        ...availability,
      };
    case 'cancelled':
      return {
        title: isLive ? 'Live interview cancelled' : 'Screening cancelled',
        actionLabel: null,
        ...availability,
      };
    case 'scheduled':
      return {
        title: availability.canBegin
          ? isLive
            ? 'Live room open'
            : 'Screening ready'
          : isLive
            ? 'Live interview scheduled'
            : 'Screening scheduled',
        actionLabel: availability.canBegin
          ? isLive
            ? 'Join live interview'
            : 'Start screening'
          : 'Prepare',
        ...availability,
      };
    default:
      return {
        title: 'Screening unavailable',
        actionLabel: null,
        ...availability,
      };
  }
}
