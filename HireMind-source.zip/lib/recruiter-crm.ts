export const CRM_STAGES = [
  'new',
  'contacted',
  'interested',
  'not_now',
  'closed',
] as const;
export const OUTREACH_STATES = [
  'draft',
  'approved',
  'sent',
  'replied',
  'cancelled',
] as const;

export function validateCrmContact(value: Record<string, unknown>) {
  if (!CRM_STAGES.includes(value.stage as (typeof CRM_STAGES)[number]))
    throw new Error('Choose a valid relationship stage.');
  if (typeof value.notes !== 'string' || value.notes.length > 4000)
    throw new Error('Notes must be under 4,000 characters.');
  if (
    !Array.isArray(value.tags) ||
    value.tags.length > 10 ||
    value.tags.some(
      (tag) => typeof tag !== 'string' || !tag.trim() || tag.length > 40,
    )
  )
    throw new Error('Use up to 10 tags, each under 40 characters.');
  if (typeof value.suppressed !== 'boolean')
    throw new Error('Contact suppression must be a boolean.');
  return {
    stage: value.stage as string,
    notes: value.notes.trim(),
    tags: [...new Set(value.tags.map((tag) => (tag as string).trim()))],
    suppressed: value.suppressed,
  };
}

export function validateOutreach(
  value: Record<string, unknown>,
  now = Date.now(),
) {
  if (
    typeof value.subject !== 'string' ||
    !value.subject.trim() ||
    value.subject.length > 160 ||
    /[\r\n]/.test(value.subject)
  )
    throw new Error('Enter a one-line subject under 160 characters.');
  if (
    typeof value.body !== 'string' ||
    value.body.trim().length < 20 ||
    value.body.length > 5000
  )
    throw new Error('Message must contain 20–5,000 characters.');
  const dueAt = value.dueAt === null ? null : Number(value.dueAt);
  if (
    dueAt !== null &&
    (!Number.isSafeInteger(dueAt) ||
      dueAt < now ||
      dueAt > now + 366 * 86400_000)
  )
    throw new Error('Choose a future follow-up within one year.');
  return { subject: value.subject.trim(), body: value.body.trim(), dueAt };
}

export function canTransitionOutreach(from: string, to: string) {
  const allowed: Record<string, string[]> = {
    draft: ['approved', 'cancelled'],
    approved: ['sent', 'cancelled'],
    sent: ['replied', 'cancelled'],
    replied: [],
    cancelled: [],
  };
  return allowed[from]?.includes(to) ?? false;
}
