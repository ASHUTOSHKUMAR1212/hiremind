CREATE TABLE `applications` (
	`id` text PRIMARY KEY NOT NULL,
	`organization_id` text NOT NULL,
	`job_id` text NOT NULL,
	`organization_candidate_id` text NOT NULL,
	`status` text DEFAULT 'submitted' NOT NULL,
	`current_stage_key` text,
	`profile_snapshot_json` text NOT NULL,
	`submitted_at` integer NOT NULL,
	`withdrawn_at` integer,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`organization_id`) REFERENCES `organizations`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`job_id`) REFERENCES `jobs`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`organization_candidate_id`) REFERENCES `organization_candidates`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_applications_job_candidate` ON `applications` (`job_id`,`organization_candidate_id`);--> statement-breakpoint
CREATE INDEX `idx_applications_job_status` ON `applications` (`job_id`,`status`);--> statement-breakpoint
CREATE INDEX `idx_applications_candidate` ON `applications` (`organization_candidate_id`,`submitted_at`);--> statement-breakpoint
CREATE TABLE `audit_events` (
	`id` text PRIMARY KEY NOT NULL,
	`organization_id` text,
	`actor_user_id` text,
	`action` text NOT NULL,
	`entity_type` text NOT NULL,
	`entity_id` text NOT NULL,
	`payload_json` text,
	`occurred_at` integer NOT NULL,
	FOREIGN KEY (`organization_id`) REFERENCES `organizations`(`id`) ON UPDATE no action ON DELETE set null,
	FOREIGN KEY (`actor_user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `idx_audit_events_org_time` ON `audit_events` (`organization_id`,`occurred_at`);--> statement-breakpoint
CREATE INDEX `idx_audit_events_entity` ON `audit_events` (`entity_type`,`entity_id`,`occurred_at`);--> statement-breakpoint
CREATE TABLE `candidate_criterion_assessments` (
	`id` text PRIMARY KEY NOT NULL,
	`screening_run_id` text NOT NULL,
	`application_id` text NOT NULL,
	`criterion_id` text NOT NULL,
	`classification` text NOT NULL,
	`score` integer,
	`confidence` integer NOT NULL,
	`evidence_ids_json` text,
	`explanation` text NOT NULL,
	`requires_human_review` integer DEFAULT false NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`screening_run_id`) REFERENCES `screening_runs`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`criterion_id`) REFERENCES `job_criteria`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_criterion_assessment_unique` ON `candidate_criterion_assessments` (`screening_run_id`,`application_id`,`criterion_id`);--> statement-breakpoint
CREATE INDEX `idx_criterion_assessments_application` ON `candidate_criterion_assessments` (`application_id`);--> statement-breakpoint
CREATE TABLE `candidate_education` (
	`id` text PRIMARY KEY NOT NULL,
	`candidate_profile_id` text NOT NULL,
	`institution` text NOT NULL,
	`qualification` text,
	`field_of_study` text,
	`started_on` text,
	`ended_on` text,
	`verification_status` text DEFAULT 'unverified' NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`candidate_profile_id`) REFERENCES `candidate_profiles`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_candidate_education_profile` ON `candidate_education` (`candidate_profile_id`);--> statement-breakpoint
CREATE TABLE `candidate_evidence` (
	`id` text PRIMARY KEY NOT NULL,
	`application_id` text NOT NULL,
	`source_type` text NOT NULL,
	`source_record_id` text,
	`category` text NOT NULL,
	`summary` text NOT NULL,
	`evidence_quote` text,
	`source_location` text,
	`confidence` integer NOT NULL,
	`verification_status` text DEFAULT 'unverified' NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_candidate_evidence_application` ON `candidate_evidence` (`application_id`,`category`);--> statement-breakpoint
CREATE TABLE `candidate_experiences` (
	`id` text PRIMARY KEY NOT NULL,
	`candidate_profile_id` text NOT NULL,
	`experience_type` text NOT NULL,
	`organization_name` text,
	`title` text NOT NULL,
	`description` text,
	`started_on` text,
	`ended_on` text,
	`is_current` integer DEFAULT false NOT NULL,
	`source_type` text DEFAULT 'candidate' NOT NULL,
	`verification_status` text DEFAULT 'unverified' NOT NULL,
	`evidence_file_id` text,
	`sort_order` integer DEFAULT 0 NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`candidate_profile_id`) REFERENCES `candidate_profiles`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_candidate_experiences_profile` ON `candidate_experiences` (`candidate_profile_id`,`sort_order`);--> statement-breakpoint
CREATE TABLE `candidate_profiles` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_user_id` text,
	`created_by_organization_id` text,
	`profile_type` text DEFAULT 'fresher' NOT NULL,
	`full_name` text NOT NULL,
	`primary_email` text,
	`phone` text,
	`headline` text,
	`summary` text,
	`location` text,
	`work_authorization` text,
	`availability` text,
	`visibility` text DEFAULT 'private' NOT NULL,
	`metadata_json` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`owner_user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE set null,
	FOREIGN KEY (`created_by_organization_id`) REFERENCES `organizations`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_candidate_profiles_owner` ON `candidate_profiles` (`owner_user_id`);--> statement-breakpoint
CREATE INDEX `idx_candidate_profiles_email` ON `candidate_profiles` (`primary_email`);--> statement-breakpoint
CREATE TABLE `candidate_projects` (
	`id` text PRIMARY KEY NOT NULL,
	`candidate_profile_id` text NOT NULL,
	`title` text NOT NULL,
	`description` text,
	`project_url` text,
	`repository_url` text,
	`skills_json` text,
	`outcomes_json` text,
	`verification_status` text DEFAULT 'unverified' NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`candidate_profile_id`) REFERENCES `candidate_profiles`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_candidate_projects_profile` ON `candidate_projects` (`candidate_profile_id`);--> statement-breakpoint
CREATE TABLE `custom_field_definitions` (
	`id` text PRIMARY KEY NOT NULL,
	`organization_id` text NOT NULL,
	`entity_type` text NOT NULL,
	`field_key` text NOT NULL,
	`label` text NOT NULL,
	`data_type` text NOT NULL,
	`configuration_json` text,
	`is_active` integer DEFAULT true NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`organization_id`) REFERENCES `organizations`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_custom_fields_org_entity_key` ON `custom_field_definitions` (`organization_id`,`entity_type`,`field_key`);--> statement-breakpoint
CREATE TABLE `custom_field_values` (
	`id` text PRIMARY KEY NOT NULL,
	`definition_id` text NOT NULL,
	`entity_id` text NOT NULL,
	`value_json` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`definition_id`) REFERENCES `custom_field_definitions`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_custom_field_values_entity` ON `custom_field_values` (`definition_id`,`entity_id`);--> statement-breakpoint
CREATE TABLE `files` (
	`id` text PRIMARY KEY NOT NULL,
	`organization_id` text,
	`owner_user_id` text,
	`entity_type` text NOT NULL,
	`entity_id` text NOT NULL,
	`r2_key` text NOT NULL,
	`filename` text NOT NULL,
	`content_type` text NOT NULL,
	`size_bytes` integer NOT NULL,
	`processing_status` text DEFAULT 'pending' NOT NULL,
	`checksum` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`organization_id`) REFERENCES `organizations`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`owner_user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_files_r2_key` ON `files` (`r2_key`);--> statement-breakpoint
CREATE INDEX `idx_files_entity` ON `files` (`entity_type`,`entity_id`);--> statement-breakpoint
CREATE TABLE `interview_plans` (
	`id` text PRIMARY KEY NOT NULL,
	`job_id` text NOT NULL,
	`version` integer NOT NULL,
	`name` text NOT NULL,
	`status` text DEFAULT 'draft' NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`job_id`) REFERENCES `jobs`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_interview_plans_job_version` ON `interview_plans` (`job_id`,`version`);--> statement-breakpoint
CREATE TABLE `interview_session_events` (
	`id` text PRIMARY KEY NOT NULL,
	`interview_session_id` text NOT NULL,
	`event_type` text NOT NULL,
	`occurred_at` integer NOT NULL,
	`duration_ms` integer,
	`payload_json` text,
	`candidate_explanation` text,
	FOREIGN KEY (`interview_session_id`) REFERENCES `interview_sessions`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_interview_events_session_time` ON `interview_session_events` (`interview_session_id`,`occurred_at`);--> statement-breakpoint
CREATE TABLE `interview_sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`application_id` text NOT NULL,
	`interview_stage_id` text NOT NULL,
	`status` text DEFAULT 'scheduled' NOT NULL,
	`scheduled_at` integer,
	`started_at` integer,
	`completed_at` integer,
	`transcript_file_key` text,
	`recording_file_key` text,
	`evaluation_json` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`interview_stage_id`) REFERENCES `interview_stages`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_interview_sessions_application` ON `interview_sessions` (`application_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `interview_stages` (
	`id` text PRIMARY KEY NOT NULL,
	`interview_plan_id` text NOT NULL,
	`stage_type` text NOT NULL,
	`name` text NOT NULL,
	`sort_order` integer NOT NULL,
	`configuration_json` text,
	`rubric_version` integer DEFAULT 1 NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`interview_plan_id`) REFERENCES `interview_plans`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_interview_stages_plan` ON `interview_stages` (`interview_plan_id`,`sort_order`);--> statement-breakpoint
CREATE TABLE `job_criteria` (
	`id` text PRIMARY KEY NOT NULL,
	`job_id` text NOT NULL,
	`version` integer NOT NULL,
	`label` text NOT NULL,
	`criterion_type` text NOT NULL,
	`requirement_class` text NOT NULL,
	`weight` integer NOT NULL,
	`evidence_definition` text,
	`equivalent_signals_json` text,
	`is_active` integer DEFAULT true NOT NULL,
	`sort_order` integer DEFAULT 0 NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`job_id`) REFERENCES `jobs`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_job_criteria_job_version` ON `job_criteria` (`job_id`,`version`,`sort_order`);--> statement-breakpoint
CREATE TABLE `jobs` (
	`id` text PRIMARY KEY NOT NULL,
	`organization_id` text NOT NULL,
	`title` text NOT NULL,
	`slug` text NOT NULL,
	`status` text DEFAULT 'draft' NOT NULL,
	`description` text NOT NULL,
	`location` text,
	`workplace_type` text,
	`employment_type` text,
	`experience_policy` text DEFAULT 'evidence_first' NOT NULL,
	`published_at` integer,
	`closed_at` integer,
	`created_by_user_id` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`organization_id`) REFERENCES `organizations`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`created_by_user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_jobs_org_slug` ON `jobs` (`organization_id`,`slug`);--> statement-breakpoint
CREATE INDEX `idx_jobs_org_status` ON `jobs` (`organization_id`,`status`);--> statement-breakpoint
CREATE TABLE `organization_candidates` (
	`id` text PRIMARY KEY NOT NULL,
	`organization_id` text NOT NULL,
	`candidate_profile_id` text,
	`display_name` text NOT NULL,
	`primary_email` text,
	`source_key` text,
	`owner_user_id` text,
	`consent_status` text DEFAULT 'pending' NOT NULL,
	`retention_until` integer,
	`private_metadata_json` text,
	`deleted_at` integer,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`organization_id`) REFERENCES `organizations`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`candidate_profile_id`) REFERENCES `candidate_profiles`(`id`) ON UPDATE no action ON DELETE set null,
	FOREIGN KEY (`owner_user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `idx_org_candidates_org` ON `organization_candidates` (`organization_id`,`deleted_at`);--> statement-breakpoint
CREATE INDEX `idx_org_candidates_profile` ON `organization_candidates` (`candidate_profile_id`);--> statement-breakpoint
CREATE INDEX `idx_org_candidates_email` ON `organization_candidates` (`organization_id`,`primary_email`);--> statement-breakpoint
CREATE TABLE `organization_members` (
	`organization_id` text NOT NULL,
	`user_id` text NOT NULL,
	`role_key` text NOT NULL,
	`permission_overrides_json` text,
	`status` text DEFAULT 'active' NOT NULL,
	`joined_at` integer NOT NULL,
	PRIMARY KEY(`organization_id`, `user_id`),
	FOREIGN KEY (`organization_id`) REFERENCES `organizations`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_organization_members_user` ON `organization_members` (`user_id`);--> statement-breakpoint
CREATE TABLE `organizations` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`slug` text NOT NULL,
	`status` text DEFAULT 'active' NOT NULL,
	`settings_json` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_organizations_slug` ON `organizations` (`slug`);--> statement-breakpoint
CREATE TABLE `screening_runs` (
	`id` text PRIMARY KEY NOT NULL,
	`job_id` text NOT NULL,
	`criteria_version` integer NOT NULL,
	`model_version` text NOT NULL,
	`pipeline_version` text NOT NULL,
	`status` text DEFAULT 'queued' NOT NULL,
	`started_at` integer,
	`completed_at` integer,
	`validation_json` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`job_id`) REFERENCES `jobs`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_screening_runs_job` ON `screening_runs` (`job_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `shortlist_rankings` (
	`id` text PRIMARY KEY NOT NULL,
	`screening_run_id` text NOT NULL,
	`application_id` text NOT NULL,
	`rank` integer NOT NULL,
	`fit_score` integer NOT NULL,
	`decision_band` text NOT NULL,
	`evidence_coverage` integer NOT NULL,
	`uncertainty` integer NOT NULL,
	`explanation` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`screening_run_id`) REFERENCES `screening_runs`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_shortlist_rankings_run_application` ON `shortlist_rankings` (`screening_run_id`,`application_id`);--> statement-breakpoint
CREATE INDEX `idx_shortlist_rankings_run_rank` ON `shortlist_rankings` (`screening_run_id`,`rank`);--> statement-breakpoint
CREATE TABLE `users` (
	`id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`full_name` text,
	`status` text DEFAULT 'active' NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_users_email` ON `users` (`email`);