CREATE TABLE `saved_talent_searches` (
	`id` text PRIMARY KEY NOT NULL,
	`organization_id` text NOT NULL,
	`owner_user_id` text NOT NULL,
	`job_id` text NOT NULL,
	`name` text NOT NULL,
	`name_key` text NOT NULL,
	`query` text NOT NULL,
	`location` text NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`organization_id`) REFERENCES `organizations`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`owner_user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`job_id`) REFERENCES `jobs`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_saved_talent_search_owner_name` ON `saved_talent_searches` (`organization_id`,`owner_user_id`,`name_key`);
--> statement-breakpoint
PRAGMA optimize;
