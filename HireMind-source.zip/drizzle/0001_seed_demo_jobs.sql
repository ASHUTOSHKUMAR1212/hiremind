INSERT OR IGNORE INTO organizations
  (id, name, slug, status, settings_json, created_at, updated_at)
VALUES
  ('org_demo_northstar', 'Northstar Labs', 'northstar-labs-demo', 'active', NULL, 1788126000000, 1788126000000),
  ('org_demo_morrow', 'Morrow Health', 'morrow-health-demo', 'active', NULL, 1788126000000, 1788126000000),
  ('org_demo_fieldwork', 'Fieldwork Studio', 'fieldwork-studio-demo', 'active', NULL, 1788126000000, 1788126000000);
--> statement-breakpoint
INSERT OR IGNORE INTO jobs
  (id, organization_id, title, slug, status, description, location, workplace_type,
   employment_type, experience_policy, published_at, closed_at, created_by_user_id,
   created_at, updated_at)
VALUES
  ('job_demo_northstar_analyst', 'org_demo_northstar', 'Associate product analyst',
   'associate-product-analyst-demo', 'published',
   'Help product teams turn customer and usage evidence into clear decisions. Partner with design, engineering, and go-to-market teams. Projects, internships, and equivalent evidence are welcome.',
   'Bengaluru', 'hybrid', 'full-time', 'evidence_first', 1788126000000, NULL, NULL, 1788126000000, 1788126000000),
  ('job_demo_morrow_researcher', 'org_demo_morrow', 'Junior UX researcher',
   'junior-ux-researcher-demo', 'published',
   'Plan and run thoughtful research for patient and clinical workflows, then help the team act on what you learn. Academic and independent research evidence is accepted.',
   'Remote · India', 'remote', 'full-time', 'evidence_first', 1788125900000, NULL, NULL, 1788125900000, 1788125900000),
  ('job_demo_fieldwork_designer', 'org_demo_fieldwork', 'Product designer',
   'product-designer-demo', 'published',
   'Design clear workflows for growing businesses and contribute to a mature, accessible design system. Show how your design choices improved an outcome.',
   'Mumbai', 'on-site', 'full-time', 'evidence_first', 1788125800000, NULL, NULL, 1788125800000, 1788125800000);
--> statement-breakpoint
PRAGMA optimize;
