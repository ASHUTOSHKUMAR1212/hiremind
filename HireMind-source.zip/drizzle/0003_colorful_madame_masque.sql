CREATE TABLE `resume_comparison_items` (
	`id` text PRIMARY KEY NOT NULL,
	`run_id` text NOT NULL,
	`file_id` text NOT NULL,
	`filename` text NOT NULL,
	`candidate_name` text NOT NULL,
	`headline` text,
	`parsed_profile_json` text NOT NULL,
	`fit_score` integer NOT NULL,
	`rank` integer NOT NULL,
	`decision_band` text NOT NULL,
	`evidence_coverage` integer NOT NULL,
	`uncertainty` integer NOT NULL,
	`explanation` text NOT NULL,
	`criterion_results_json` text NOT NULL,
	`warnings_json` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`run_id`) REFERENCES `resume_comparison_runs`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_resume_comparison_items_run_rank` ON `resume_comparison_items` (`run_id`,`rank`);--> statement-breakpoint
CREATE INDEX `idx_resume_comparison_items_run` ON `resume_comparison_items` (`run_id`);--> statement-breakpoint
CREATE TABLE `resume_comparison_runs` (
	`id` text PRIMARY KEY NOT NULL,
	`organization_id` text NOT NULL,
	`job_id` text NOT NULL,
	`created_by_user_id` text,
	`criteria_version` integer NOT NULL,
	`status` text DEFAULT 'processing' NOT NULL,
	`file_count` integer NOT NULL,
	`completed_at` integer,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`organization_id`) REFERENCES `organizations`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`job_id`) REFERENCES `jobs`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`created_by_user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `idx_resume_comparison_runs_org_job` ON `resume_comparison_runs` (`organization_id`,`job_id`,`created_at`);