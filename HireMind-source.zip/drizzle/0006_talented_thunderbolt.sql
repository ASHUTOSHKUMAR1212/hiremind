CREATE TABLE `interview_scorecards` (
	`session_id` text NOT NULL,
	`reviewer_user_id` text NOT NULL,
	`transcript_revision` integer NOT NULL,
	`rubric_json` text NOT NULL,
	`entries_json` text NOT NULL,
	`status` text NOT NULL,
	`revision` integer NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	PRIMARY KEY(`session_id`, `reviewer_user_id`),
	FOREIGN KEY (`session_id`) REFERENCES `interview_sessions`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`reviewer_user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `interview_transcripts` (
	`session_id` text PRIMARY KEY NOT NULL,
	`organization_id` text NOT NULL,
	`revision` integer NOT NULL,
	`segments_json` text NOT NULL,
	`source_name` text NOT NULL,
	`consent_note` text NOT NULL,
	`created_by_user_id` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`session_id`) REFERENCES `interview_sessions`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`organization_id`) REFERENCES `organizations`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`created_by_user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE TABLE `matching_benchmarks` (
	`id` text PRIMARY KEY NOT NULL,
	`organization_id` text NOT NULL,
	`created_by_user_id` text,
	`report_json` text NOT NULL,
	`dataset_json` text NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`organization_id`) REFERENCES `organizations`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`created_by_user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `idx_benchmarks_org_time` ON `matching_benchmarks` (`organization_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `recruiter_outreach` (
	`id` text PRIMARY KEY NOT NULL,
	`candidate_id` text NOT NULL,
	`organization_id` text NOT NULL,
	`created_by_user_id` text,
	`subject` text NOT NULL,
	`body` text NOT NULL,
	`status` text DEFAULT 'draft' NOT NULL,
	`due_at` integer,
	`sent_at` integer,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`candidate_id`) REFERENCES `organization_candidates`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`organization_id`) REFERENCES `organizations`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`created_by_user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `idx_outreach_org_due` ON `recruiter_outreach` (`organization_id`,`due_at`);--> statement-breakpoint
CREATE INDEX `idx_outreach_candidate` ON `recruiter_outreach` (`candidate_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `recruiter_relationships` (
	`candidate_id` text PRIMARY KEY NOT NULL,
	`organization_id` text NOT NULL,
	`stage` text DEFAULT 'new' NOT NULL,
	`tags_json` text DEFAULT '[]' NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`suppressed` integer DEFAULT 0 NOT NULL,
	`revision` integer DEFAULT 1 NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`candidate_id`) REFERENCES `organization_candidates`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`organization_id`) REFERENCES `organizations`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_relationships_org` ON `recruiter_relationships` (`organization_id`);