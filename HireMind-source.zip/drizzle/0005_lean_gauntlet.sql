CREATE TABLE `application_events` (
	`id` text PRIMARY KEY NOT NULL,
	`application_id` text NOT NULL,
	`actor_user_id` text,
	`event_type` text NOT NULL,
	`from_status` text,
	`to_status` text,
	`note` text,
	`visible_to_candidate` integer DEFAULT true NOT NULL,
	`occurred_at` integer NOT NULL,
	FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`actor_user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `idx_application_events_application_time` ON `application_events` (`application_id`,`occurred_at`);
--> statement-breakpoint
INSERT INTO `application_events`
  (`id`, `application_id`, `actor_user_id`, `event_type`, `from_status`, `to_status`, `note`, `visible_to_candidate`, `occurred_at`)
SELECT 'application_event_migrated_submitted_' || `id`, `id`, NULL, 'application_submitted', NULL, 'submitted', NULL, 1, `submitted_at`
FROM `applications`;
--> statement-breakpoint
INSERT INTO `application_events`
  (`id`, `application_id`, `actor_user_id`, `event_type`, `from_status`, `to_status`, `note`, `visible_to_candidate`, `occurred_at`)
SELECT 'application_event_migrated_current_' || `id`, `id`, NULL,
  CASE `status`
    WHEN 'withdrawn' THEN 'application_withdrawn'
    WHEN 'rejected' THEN 'application_rejected'
    WHEN 'offer' THEN 'offer_recorded'
    WHEN 'hired' THEN 'candidate_hired'
    ELSE 'application_stage_changed'
  END,
  'submitted', `status`, 'Current state added when the application timeline was enabled.', 1, `updated_at`
FROM `applications`
WHERE `status` <> 'submitted';
--> statement-breakpoint
PRAGMA optimize;
