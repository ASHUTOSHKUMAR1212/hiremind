CREATE TABLE `interview_room_notes` (
	`interview_session_id` text NOT NULL,
	`author_user_id` text NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	PRIMARY KEY(`interview_session_id`, `author_user_id`),
	FOREIGN KEY (`interview_session_id`) REFERENCES `interview_sessions`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`author_user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `interview_room_participants` (
	`interview_session_id` text NOT NULL,
	`user_id` text NOT NULL,
	`role` text NOT NULL,
	`display_name` text NOT NULL,
	`peer_id` text NOT NULL,
	`media_state_json` text,
	`joined_at` integer NOT NULL,
	`last_seen_at` integer NOT NULL,
	`left_at` integer,
	PRIMARY KEY(`interview_session_id`, `user_id`),
	FOREIGN KEY (`interview_session_id`) REFERENCES `interview_sessions`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_interview_room_presence` ON `interview_room_participants` (`interview_session_id`,`last_seen_at`);--> statement-breakpoint
CREATE TABLE `interview_room_signals` (
	`id` text PRIMARY KEY NOT NULL,
	`interview_session_id` text NOT NULL,
	`sender_user_id` text NOT NULL,
	`target_user_id` text NOT NULL,
	`signal_type` text NOT NULL,
	`payload_json` text NOT NULL,
	`created_at` integer NOT NULL,
	`expires_at` integer NOT NULL,
	FOREIGN KEY (`interview_session_id`) REFERENCES `interview_sessions`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`sender_user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`target_user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_interview_room_signals_target` ON `interview_room_signals` (`interview_session_id`,`target_user_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `idx_interview_room_signals_expiry` ON `interview_room_signals` (`expires_at`);--> statement-breakpoint
ALTER TABLE `interview_sessions` ADD `mode` text DEFAULT 'structured_screening' NOT NULL;